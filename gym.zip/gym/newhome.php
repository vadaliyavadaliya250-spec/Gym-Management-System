﻿<?php
session_start();
$con = mysqli_connect("localhost","root","","gym");
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
$member_id = 0;
$member_fullname = '';
$member_phone = '';
$event_msg = '';
$event_err = '';
$join_event_id = isset($_GET['join_event']) ? (int)$_GET['join_event'] : 0;
$join_event = null;

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: newhome.php");
    exit;
}

if ($username) {
    $username_esc = mysqli_real_escape_string($con, $username);
    $member_q = mysqli_query($con, "SELECT * FROM user_details WHERE username='$username_esc' LIMIT 1");
    if ($member_q && $member_r = mysqli_fetch_assoc($member_q)) {
        $member_id = (int)$member_r['id'];
        $member_fullname = $member_r['fullname'] ?? $username;
        $member_phone = $member_r['phone'] ?? '';
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['event_join_submit'])) {
    if (!$username) {
        header("Location: login.php");
        exit;
    }

    $event_id = (int)($_POST['event_id'] ?? 0);
    $fullname = trim($_POST['fullname'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (!$member_id) {
        $event_err = "Your member profile was not found.";
    } elseif (!$event_id || $fullname === '' || $phone === '') {
        $event_err = "Please fill all event details.";
    } else {
        $fullname_esc = mysqli_real_escape_string($con, $fullname);
        $phone_esc = mysqli_real_escape_string($con, $phone);
        $username_esc = mysqli_real_escape_string($con, $username);

        $ev_q = mysqli_query($con,"
            SELECT e.id, e.title, e.max_seats,
                   (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id=e.id AND er.status='approved') AS approved_count
            FROM events e
            WHERE e.id='$event_id' AND e.status='active' AND e.event_date >= CURDATE()
            LIMIT 1
        ");
        $ev = $ev_q ? mysqli_fetch_assoc($ev_q) : null;

        if (!$ev) {
            $event_err = "Event not available.";
        } else {
            $dup_q = mysqli_query($con,"
                SELECT id FROM event_registrations
                WHERE event_id='$event_id' AND (user_id='$member_id' OR username='$username_esc')
                LIMIT 1
            ");
            $dup = $dup_q ? mysqli_fetch_assoc($dup_q) : null;

            if ($dup) {
                $event_err = "You already requested this event.";
            } elseif ((int)$ev['max_seats'] > 0 && (int)$ev['approved_count'] >= (int)$ev['max_seats']) {
                $event_err = "This event is full.";
            } else {
                $ins = mysqli_query($con,"
                    INSERT INTO event_registrations (event_id, user_id, fullname, username, phone, status, registered_at)
                    VALUES ('$event_id', '$member_id', '$fullname_esc', '$username_esc', '$phone_esc', 'pending', NOW())
                ");
                if ($ins) {
                    $event_msg = "Join request sent. Admin will approve from Event Requests.";
                    $member_fullname = $fullname;
                    $member_phone = $phone;
                    $join_event_id = 0;
                } else {
                    $event_err = "Could not submit request. Please try again.";
                }
            }
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['contact_submit'])) {
    $name    = mysqli_real_escape_string($con, $_POST['name']);
    $email   = mysqli_real_escape_string($con, $_POST['email']);
    $message = mysqli_real_escape_string($con, $_POST['message']);
    $sql = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";
    if (mysqli_query($con, $sql)) {
        echo "<script>alert('Message sent successfully!');window.location.href='newhome.php#contact';</script>";
    } else {
        echo "<script>alert('Something went wrong!');window.history.back();</script>";
    }
}

if ($join_event_id > 0) {
    $join_q = mysqli_query($con, "
        SELECT e.id, e.title, e.event_date, e.event_time, e.max_seats,
               (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id=e.id AND er.status='approved') AS approved_count
        FROM events e
        WHERE e.id='$join_event_id' AND e.status='active' AND e.event_date >= CURDATE()
        LIMIT 1
    ");
    $join_event = $join_q ? mysqli_fetch_assoc($join_q) : null;
    if (!$join_event) {
        $join_event_id = 0;
    }
}

$prod_cats = mysqli_query($con,"SELECT * FROM product_categories WHERE status='active' ORDER BY category_name");
$cat_list = [];
if($prod_cats) while($pc = mysqli_fetch_assoc($prod_cats)) $cat_list[] = $pc;

$active_cat = isset($_GET['pcat']) ? (int)$_GET['pcat'] : 0;
$pcat_where = $active_cat ? "AND p.category_id='$active_cat'" : "";

$prod_res = mysqli_query($con,"
    SELECT p.id, p.product_name, p.image, p.description, pc.category_name, pc.id as cat_id,
           MIN(pv.final_price) as min_price, MAX(pv.final_price) as max_price,
           COALESCE(SUM(pv.stock),0) as total_stock,
           COUNT(DISTINCT pv.id) as variant_count
    FROM products_new p
    JOIN product_categories pc ON pc.id=p.category_id
    LEFT JOIN product_variants pv ON pv.product_id=p.id
    WHERE p.status='active' $pcat_where
    GROUP BY p.id
    ORDER BY p.created_at DESC
    LIMIT 12
");
$all_products = [];
if($prod_res){
    while($pr = mysqli_fetch_assoc($prod_res)) {
        $attr_res = mysqli_query($con,"
            SELECT DISTINCT pat.attribute_name as attr_name,
                   GROUP_CONCAT(DISTINCT av.value_label ORDER BY av.sort_order SEPARATOR ', ') as values_list
            FROM product_variants pv
            JOIN variant_attributes va ON va.variant_id=pv.id
            JOIN attribute_values av ON av.id=va.value_id
            JOIN product_attribute_types pat ON pat.id=va.attribute_id
            WHERE pv.product_id='{$pr['id']}'
            GROUP BY pat.id ORDER BY pat.id
        ");
        $pr['attributes'] = [];
        if($attr_res) while($ar = mysqli_fetch_assoc($attr_res)) $pr['attributes'][] = $ar;
        $all_products[] = $pr;
    }
}

// Upcoming events for home
$username_esc = mysqli_real_escape_string($con, $username);
$my_status_expr = $member_id
    ? "(SELECT er2.status FROM event_registrations er2 WHERE er2.event_id=e.id AND (er2.user_id='$member_id' OR er2.username='$username_esc') ORDER BY er2.id DESC LIMIT 1)"
    : "NULL";

$events_home = mysqli_query($con,"
    SELECT e.*, t.name as trainer_name,
        (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id=e.id AND er.status='approved') as approved_count,
        $my_status_expr as my_status
    FROM events e
    LEFT JOIN trainers t ON e.trainer_id=t.id
    WHERE e.status='active' AND e.event_date >= CURDATE()
    ORDER BY e.event_date ASC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gymness</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Sora:wght@600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
:root {
    --primary: #0f766e;
    --primary-deep: #115e59;
    --ink: #1f2937;
    --muted: #6b7280;
    --line: #e5e7eb;
    --surface: #ffffff;
    --soft: #f4f6fb;
    --shadow-soft: 0 14px 34px rgba(15, 23, 42, 0.08);
    --shadow-strong: 0 20px 48px rgba(15, 23, 42, 0.12);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: "Plus Jakarta Sans", sans-serif;
    color: var(--ink);
    background: radial-gradient(circle at 12% -8%, #d1fae5 0, transparent 34%),
                radial-gradient(circle at 88% 0%, #ddefff 0, transparent 30%),
                var(--soft);
}

h1, h2, h3, h4, .logo {
    font-family: "Outfit", sans-serif;
}

.navbar {
    padding: 18px 60px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: sticky;
    top: 0;
    z-index: 50;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(229, 231, 235, 0.9);
}

.logo {
    font-size: 28px;
    font-weight: 800;
    color: #111827;
    letter-spacing: 0.4px;
}

.logo span {
    color: var(--primary);
}

.nav-menu {
    list-style: none;
    display: flex;
    gap: 26px;
    margin-bottom: 0;
}

.nav-menu li a {
    text-decoration: none;
    color: #111827;
    font-weight: 600;
    transition: color 0.25s;
    position: relative;
    padding: 8px 0;
}

.nav-menu li a::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 0;
    height: 2px;
    background: var(--primary);
    transition: width 0.25s;
}

.nav-menu li a:hover {
    color: var(--primary);
}

.nav-menu li a:hover::after {
    width: 100%;
}

.nav-btns button {
    padding: 11px 20px;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    margin-left: 8px;
    font-weight: 700;
    transition: transform 0.2s, box-shadow 0.2s;
}

.nav-btns button:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-soft);
}

.nav-btns a {
    text-decoration: none;
    color: #111827;
}

.signup {
    background: var(--primary) !important;
}

.signup a {
    color: #fff !important;
}

.profile-link {
    display: flex;
    align-items: center;
    padding: 10px 18px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 700;
    color: #111827;
    border: 1px solid var(--line);
    transition: all 0.25s;
}

.profile-link:hover {
    background: #ecfdf5;
    color: var(--primary);
    border-color: #99f6e4;
}

.profile-icon {
    font-size: 23px;
    margin-right: 10px;
    color: var(--primary);
}

.dropdown-menu {
    border-radius: 12px;
    box-shadow: var(--shadow-strong);
    border: 1px solid var(--line);
    margin-top: 10px;
}

.dropdown-item {
    padding: 11px 18px;
    font-weight: 600;
    transition: all 0.25s;
}

.dropdown-item:hover {
    background: #f8fafc;
    padding-left: 24px;
}

.hero {
    padding: 92px 60px 82px;
    display: flex;
    align-items: center;
    gap: 42px;
    background: linear-gradient(140deg, #ffffff 0%, #f6f8ff 52%, #eef2ff 100%);
    position: relative;
    overflow: hidden;
}

.hero::before {
    content: "";
    position: absolute;
    width: 460px;
    height: 460px;
    border-radius: 50%;
    right: -170px;
    top: -190px;
    background: radial-gradient(circle, rgba(15, 118, 110, 0.24) 0%, rgba(15, 118, 110, 0) 72%);
    pointer-events: none;
}

.hero::after {
    content: "";
    position: absolute;
    width: 340px;
    height: 340px;
    border-radius: 50%;
    left: -130px;
    bottom: -180px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.16) 0%, rgba(59, 130, 246, 0) 72%);
    pointer-events: none;
}

.hero-left {
    width: 50%;
    position: relative;
    z-index: 1;
}

.hero-left span {
    color: var(--primary);
    letter-spacing: 2px;
    font-weight: 700;
    font-size: 12px;
}

.hero-left h1 {
    font-size: 54px;
    margin: 16px 0 18px;
    line-height: 1.1;
    color: #111827;
}

.hero-left p {
    color: var(--muted);
    max-width: 520px;
    font-size: 17px;
    line-height: 1.7;
}

.hero-left button {
    margin-top: 28px;
    margin-right: 10px;
    padding: 15px 30px;
    border: none;
    border-radius: 10px;
    background: var(--primary);
    color: #fff;
    font-weight: 700;
    cursor: pointer;
    transition: transform 0.25s, box-shadow 0.25s, background 0.25s;
}

.hero-left button:hover {
    transform: translateY(-3px);
    box-shadow: 0 14px 26px rgba(15, 118, 110, 0.28);
}

.hero-left button:nth-of-type(2) {
    background: #fff;
    color: #111827;
    border: 1px solid #d1d5db;
}

.hero-left button:nth-of-type(2):hover {
    box-shadow: var(--shadow-soft);
    background: #f9fafb;
}

.hero-right {
    width: 50%;
    position: relative;
    z-index: 1;
}

.hero-right img {
    width: 100%;
    border-radius: 24px;
    border: 1px solid #dbe2f0;
    box-shadow: var(--shadow-strong);
    animation: floatSoft 5s ease-in-out infinite;
}

.section {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #111827 100%);
    color: #fff;
    padding: 92px 60px;
    display: flex;
    gap: 52px;
    position: relative;
    overflow: hidden;
}

.section::before {
    content: "";
    position: absolute;
    inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 42px 42px;
    opacity: 0.35;
    pointer-events: none;
}

.section-left, .section-right {
    width: 50%;
    position: relative;
    z-index: 1;
}

.section-left img, .section-right img {
    width: 100%;
    border-radius: 22px;
    border: 1px solid rgba(255, 255, 255, 0.12);
    box-shadow: 0 16px 34px rgba(0, 0, 0, 0.28);
}

.section-right span {
    color: #99f6e4;
    letter-spacing: 2px;
    font-weight: 700;
    font-size: 12px;
}

.section-right h2 {
    font-size: 42px;
    margin: 14px 0 15px;
}

.section-right p {
    color: #d7dbe2;
    line-height: 1.75;
    font-size: 16px;
}

.section-box {
    background: rgba(255, 255, 255, 0.09);
    backdrop-filter: blur(4px);
    padding: 22px;
    margin: 22px 0;
    border-left: 4px solid #2dd4bf;
    border-radius: 12px;
    line-height: 1.8;
}

.membership-section {
    padding: 96px 60px;
    background: linear-gradient(130deg, #ecfeff 0%, #fff 48%, #eff6ff 100%);
}

.membership-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 52px;
}

.membership-left {
    width: 50%;
}

.membership-left span {
    color: var(--primary);
    letter-spacing: 2px;
    font-weight: 700;
    font-size: 12px;
}

.membership-left h2 {
    font-size: 42px;
    margin: 16px 0;
    font-weight: 800;
    color: #111827;
}

.membership-left p {
    color: var(--muted);
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 24px;
}

.membership-points .point {
    display: flex;
    align-items: center;
    margin-bottom: 12px;
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
}

.membership-points i {
    color: var(--primary);
    margin-right: 10px;
    font-size: 19px;
}

.explore-btn {
    display: inline-block;
    margin-top: 28px;
    padding: 14px 30px;
    background: var(--primary);
    color: #fff;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 700;
    transition: transform 0.25s, box-shadow 0.25s, background 0.25s;
}

.explore-btn:hover {
    background: var(--primary-deep);
    color: #fff;
    transform: translateY(-3px);
    box-shadow: 0 14px 26px rgba(15, 118, 110, 0.3);
}

.membership-right {
    width: 50%;
}

.membership-right img {
    width: 100%;
    border-radius: 22px;
    box-shadow: var(--shadow-strong);
    border: 1px solid #e5e7eb;
}

.events-section {
    padding: 82px 60px;
    background: linear-gradient(135deg, #f0fdfa 0%, #fff 42%, #eef9ff 100%);
}

.contact-title {
    text-align: center;
    margin-bottom: 54px;
}

.contact-title span {
    color: var(--primary);
    letter-spacing: 2px;
    font-weight: 700;
    font-size: 12px;
}

.contact-title h2 {
    font-size: 42px;
    margin-top: 8px;
    color: #111827;
}

.event-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 20px;
    max-width: 1200px;
    margin: 0 auto;
}

.event-card {
    background: #fff;
    border: 1px solid #e8edf5;
    border-radius: 16px;
    padding: 16px;
    box-shadow: var(--shadow-soft);
    display: flex;
    flex-direction: column;
    gap: 8px;
    transition: transform 0.25s, box-shadow 0.25s;
}

.event-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-strong);
}

.event-date {
    font-weight: 800;
    color: var(--primary);
    font-size: 13px;
}

.event-title {
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
    margin: 2px 0;
}

.event-meta {
    color: #4b5563;
    font-size: 13px;
    line-height: 1.55;
}

.event-seats {
    font-weight: 700;
    color: #15803d;
    font-size: 12px;
}

.event-seats.full {
    color: #b91c1c;
}

.event-btn {
    display: inline-block;
    margin-top: 6px;
    padding: 10px 14px;
    border-radius: 10px;
    background: var(--primary);
    color: #fff;
    font-weight: 700;
    text-align: center;
    text-decoration: none;
    transition: transform 0.2s, box-shadow 0.2s;
}

.event-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 18px rgba(15, 118, 110, 0.24);
    color: #fff;
}

.event-btn.disabled {
    background: #9ca3af;
    pointer-events: none;
    opacity: 0.7;
}

.event-alert {
    max-width: 1200px;
    margin: 0 auto 16px;
    padding: 12px 14px;
    border-radius: 10px;
    font-weight: 700;
}

.event-alert.ok {
    background: #e8f5e9;
    color: #166534;
    border: 1px solid #ccebd4;
}

.event-alert.err {
    background: #ffebee;
    color: #b91c1c;
    border: 1px solid #fecaca;
}

.event-join-box {
    max-width: 1200px;
    margin: 0 auto 20px;
    background: #fff;
    border: 1px solid #99f6e4;
    border-radius: 14px;
    padding: 18px;
    box-shadow: var(--shadow-soft);
}

.event-join-box h4 {
    margin: 0 0 10px;
    color: var(--primary-deep);
    font-size: 18px;
    font-weight: 800;
}

.event-join-form {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
}

.event-join-form .jg label {
    display: block;
    margin-bottom: 6px;
    font-size: 12px;
    color: #4b5563;
    font-weight: 700;
}

.event-join-form .jg input {
    width: 100%;
    padding: 10px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
}

.event-join-actions {
    display: flex;
    align-items: end;
    gap: 8px;
}

.event-note {
    max-width: 1200px;
    margin: 0 auto 16px;
    color: #6b7280;
}

.products-section {
    padding: 84px 60px;
    background: linear-gradient(125deg, #effcf8 0%, #ffffff 45%, #eef6ff 100%);
}

.prod-filter-tabs {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    justify-content: center;
    margin-bottom: 34px;
}

.prod-filter-tab {
    padding: 9px 22px;
    border-radius: 999px;
    border: 1px solid #d6dce8;
    background: #fff;
    cursor: pointer;
    font-weight: 700;
    font-size: 13px;
    text-decoration: none;
    color: #374151;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.prod-filter-tab:hover, .prod-filter-tab.active {
    background: var(--primary);
    color: #fff;
    border-color: var(--primary);
    transform: translateY(-1px);
}

.prod-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 24px;
    max-width: 1200px;
    margin: 0 auto;
}

.prod-card {
    background: #fff;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: var(--shadow-soft);
    border: 1px solid #e9edf5;
    transition: transform 0.25s, box-shadow 0.25s;
}

.prod-card:hover {
    transform: translateY(-6px);
    box-shadow: var(--shadow-strong);
}

.prod-card img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.prod-card-noimg {
    width: 100%;
    height: 200px;
    background: linear-gradient(135deg, #f0f4fb, #e4e8f1);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 60px;
}

.prod-card-noimg i {
    color: #7b8794;
}

.prod-card-body {
    padding: 16px;
}

.prod-cat-badge {
    display: inline-block;
    background: #ecfeff;
    color: var(--primary-deep);
    font-size: 11px;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 20px;
    margin-bottom: 8px;
}

.prod-card-body h3 {
    font-size: 16px;
    font-weight: 700;
    margin: 0 0 8px;
    color: #0f172a;
}

.prod-attrs {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    margin: 8px 0;
}

.prod-attr-chip {
    background: #eef2ff;
    color: #3446a8;
    font-size: 11px;
    padding: 3px 9px;
    border-radius: 12px;
    font-weight: 600;
}

.prod-attr-label {
    color: #6b7280;
    font-size: 10px;
    margin-right: 2px;
}

.prod-price {
    font-size: 20px;
    font-weight: 800;
    color: var(--primary);
    margin: 10px 0 4px;
}

.prod-price-range {
    font-size: 13px;
    color: #6b7280;
}

.prod-stock-ok {
    color: #15803d;
    font-size: 12px;
    font-weight: 700;
}

.prod-stock-out {
    color: #b91c1c;
    font-size: 12px;
    font-weight: 700;
}

.prod-variants-badge {
    font-size: 11px;
    color: #6b7280;
    margin-bottom: 5px;
}

.prod-no-data {
    text-align: center;
    padding: 60px;
    color: #9ca3af;
    font-size: 16px;
    grid-column: 1 / -1;
}

.contact {
    padding: 92px 60px;
    background: linear-gradient(140deg, #ffffff 0%, #f0fdfa 44%, #ecfeff 100%);
}

.contact-wrapper {
    display: flex;
    gap: 30px;
}

.contact-info {
    width: 40%;
    display: flex;
    flex-direction: column;
    gap: 18px;
}

.info-card {
    background: #fff;
    padding: 28px;
    border-radius: 16px;
    border: 1px solid #e8edf5;
    box-shadow: var(--shadow-soft);
    transition: all 0.3s;
    min-width: 320px;
}

.info-card:hover {
    transform: translateY(-6px);
    box-shadow: var(--shadow-strong);
}

.info-card h4 {
    margin-bottom: 10px;
    color: var(--primary);
    font-size: 22px;
}

.contact-form {
    width: 60%;
    background: #fff;
    padding: 34px;
    border-radius: 16px;
    border: 1px solid #e8edf5;
    box-shadow: var(--shadow-soft);
}

.contact-form h3 {
    margin-bottom: 14px;
    color: #111827;
}

.contact-form input, .contact-form textarea {
    width: 100%;
    padding: 14px;
    margin-bottom: 16px;
    border-radius: 10px;
    border: 1px solid #d1d5db;
    font-size: 15px;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.contact-form input:focus, .contact-form textarea:focus {
    border-color: #34d399;
    box-shadow: 0 0 0 3px rgba(15, 118, 110, 0.12);
}

.contact-form button {
    padding: 14px 30px;
    background: var(--primary);
    color: #fff;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-size: 15px;
    font-weight: 700;
    width: 100%;
    transition: transform 0.2s, box-shadow 0.2s, background 0.2s;
}

.contact-form button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 18px rgba(15, 118, 110, 0.24);
    background: var(--primary-deep);
}

.footer {
    background: #0f172a;
    color: #cbd5e1;
    text-align: center;
    padding: 28px 20px;
    font-size: 14px;
}

.hero,
.section,
.membership-section,
.events-section,
.products-section,
.contact {
    animation: fadeUp 0.7s ease both;
}

.section { animation-delay: 0.05s; }
.membership-section { animation-delay: 0.1s; }
.events-section { animation-delay: 0.15s; }
.products-section { animation-delay: 0.2s; }
.contact { animation-delay: 0.25s; }

@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(18px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes floatSoft {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
}

@media (max-width: 1140px) {
    .navbar,
    .hero,
    .section,
    .membership-section,
    .events-section,
    .products-section,
    .contact {
        padding-left: 28px;
        padding-right: 28px;
    }

    .hero-left h1 {
        font-size: 46px;
    }
}

@media (max-width: 920px) {
    .navbar {
        flex-wrap: wrap;
        gap: 12px;
    }

    .nav-menu {
        width: 100%;
        order: 3;
        justify-content: center;
        flex-wrap: wrap;
        gap: 14px 20px;
    }

    .hero,
    .section,
    .membership-container,
    .contact-wrapper {
        flex-direction: column;
    }

    .hero-left,
    .hero-right,
    .section-left,
    .section-right,
    .membership-left,
    .membership-right,
    .contact-info,
    .contact-form {
        width: 100%;
    }

    .hero {
        padding-top: 70px;
    }

    .hero-left h1 {
        font-size: 40px;
    }

    .contact-form {
        padding: 26px;
    }

    .info-card {
        min-width: auto;
    }
}

@media (max-width: 640px) {
    .navbar,
    .hero,
    .section,
    .membership-section,
    .events-section,
    .products-section,
    .contact {
        padding-left: 18px;
        padding-right: 18px;
    }

    .logo {
        font-size: 24px;
    }

    .nav-btns button {
        padding: 10px 14px;
        font-size: 13px;
    }

    .hero-left h1 {
        font-size: 34px;
    }

    .contact-title h2 {
        font-size: 32px;
    }

    .event-join-actions {
        flex-direction: column;
        align-items: stretch;
    }
}

/* ---------- FULL HOMEPAGE REDESIGN (LAYOUT OVERRIDE) ---------- */
:root {
    --home-primary: #0b7a75;
    --home-primary-dark: #0b5d59;
    --home-accent: #f97316;
    --home-ink: #102638;
    --home-muted: #5f7285;
    --home-line: #d8e3ec;
    --home-bg: #eef4f8;
    --home-card: #ffffff;
}

body {
    font-family: "Plus Jakarta Sans", sans-serif;
    color: var(--home-ink);
    background:
        radial-gradient(circle at 10% 0%, #d5efea 0, transparent 28%),
        radial-gradient(circle at 92% 8%, #fff0df 0, transparent 24%),
        var(--home-bg);
}

.navbar,
.hero,
.section,
.membership-section,
.events-section,
.products-section,
.contact,
.footer {
    width: auto;
    margin-left: 34px;
    margin-right: 34px;
}

.navbar {
    margin-top: 14px;
    margin-bottom: 0;
    padding: 14px 24px;
    border-radius: 18px;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(13px);
    border: 1px solid var(--home-line);
    box-shadow: 0 12px 28px rgba(15, 23, 42, 0.1);
}

.logo {
    font-family: "Outfit", sans-serif;
    color: #0f2b3e;
}

.logo span {
    color: var(--home-accent);
}

.nav-menu li a {
    font-weight: 700;
    border-radius: 8px;
    padding: 8px 10px;
}

.nav-menu li a:hover {
    color: var(--home-primary);
    background: #ebf9f6;
}

.signup {
    background: linear-gradient(120deg, var(--home-primary), #089992) !important;
}

.profile-link,
.nav-btns button {
    border: 1px solid var(--home-line);
    background: #fff;
}

.profile-link:hover {
    background: #ebf9f6;
    border-color: #bce4de;
}

.profile-icon {
    color: var(--home-primary);
}

.hero {
    margin-top: 24px;
    margin-bottom: 0;
    padding: 64px 56px;
    display: grid;
    grid-template-columns: 1.08fr 0.92fr;
    gap: 40px;
    align-items: center;
    border-radius: 28px;
    border: 1px solid var(--home-line);
    background: linear-gradient(145deg, #ffffff 0%, #f7fcfb 48%, #edf8f6 100%);
    box-shadow: 0 18px 44px rgba(15, 23, 42, 0.12);
}

.hero::before {
    background: radial-gradient(circle, rgba(11, 122, 117, 0.24) 0%, rgba(11, 122, 117, 0) 72%);
}

.hero-left,
.hero-right,
.section-left,
.section-right,
.membership-left,
.membership-right,
.contact-info,
.contact-form {
    width: auto;
}

.hero-left span {
    display: inline-block;
    background: #e8f8f5;
    color: var(--home-primary);
    padding: 7px 12px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
}

.hero-left h1 {
    font-family: "Outfit", sans-serif;
    font-size: 58px;
    line-height: 1.05;
    margin-top: 16px;
    color: #102638;
}

.hero-left p {
    color: var(--home-muted);
    font-size: 17px;
}

.hero-left button {
    background: linear-gradient(120deg, var(--home-primary), #089992);
    border-radius: 11px;
    font-weight: 800;
}

.hero-left button:nth-of-type(2) {
    background: #fff;
    color: var(--home-ink);
    border: 1px solid var(--home-line);
}

.hero-right img {
    border-radius: 24px;
    border: 1px solid var(--home-line);
    box-shadow: 0 24px 48px rgba(15, 23, 42, 0.18);
    transform: rotate(-2deg);
}

.section {
    margin-top: 32px;
    padding: 26px;
    display: grid;
    grid-template-columns: 0.94fr 1.06fr;
    gap: 40px;
    border-radius: 28px;
    border: 1px solid #1f4a5e;
    background: linear-gradient(130deg, #0f2838, #15394c);
}

.section-right h2 {
    font-family: "Outfit", sans-serif;
}

.section-box {
    border-left-color: #fbbf24;
}

.membership-section {
    margin-top: 32px;
    padding: 54px;
    border-radius: 28px;
    border: 1px solid var(--home-line);
    background: linear-gradient(132deg, #ffffff 0%, #f1fbf8 48%, #fff8ec 100%);
    box-shadow: 0 18px 44px rgba(15, 23, 42, 0.12);
}

.membership-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 36px;
    align-items: center;
}

.membership-left span {
    color: var(--home-accent);
}

.membership-left h2 {
    color: #0f2a3b;
    font-family: "Outfit", sans-serif;
}

.membership-left p {
    color: var(--home-muted);
}

.membership-points .point {
    color: #153144;
    font-weight: 700;
}

.membership-points i {
    color: var(--home-primary);
}

.explore-btn {
    border-radius: 11px;
    background: linear-gradient(120deg, var(--home-primary), #0a9992);
    font-weight: 800;
}

.events-section {
    margin-top: 32px;
    padding: 56px 46px;
    border-radius: 28px;
    border: 1px solid var(--home-line);
    background: linear-gradient(130deg, #f3faf9 0%, #ffffff 54%, #edf5ff 100%);
    box-shadow: 0 18px 44px rgba(15, 23, 42, 0.12);
}

.contact-title h2 {
    font-family: "Outfit", sans-serif;
    color: #0f2a3b;
}

.contact-title span {
    color: var(--home-primary);
}

.event-grid {
    gap: 18px;
}

.event-card {
    border: 1px solid var(--home-line);
    box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
}

.event-date {
    color: var(--home-accent);
}

.event-title {
    color: #0f2a3b;
}

.event-btn {
    background: linear-gradient(120deg, var(--home-primary), #089992);
}

.event-btn.disabled {
    background: #94a3b8;
}

.event-join-box {
    border-color: #c9e4df;
}

.products-section {
    margin-top: 32px;
    padding: 56px 46px;
    border-radius: 28px;
    border: 1px solid var(--home-line);
    background: linear-gradient(130deg, #f4faf6 0%, #ffffff 50%, #fff5e8 100%);
    box-shadow: 0 18px 44px rgba(15, 23, 42, 0.12);
}

.prod-filter-tab {
    border-color: #ccdae4;
    color: #274258;
    font-weight: 800;
}

.prod-filter-tab:hover,
.prod-filter-tab.active {
    background: #0f3b50;
    border-color: #0f3b50;
}

.prod-card {
    border: 1px solid var(--home-line);
}

.prod-cat-badge {
    background: #edf7ff;
    color: #1f4f8c;
}

.prod-price {
    color: #0f3b50;
}

.prod-attr-chip {
    background: #f0fdfb;
    color: var(--home-primary);
    border: 1px solid #cce7e4;
}

.contact {
    margin-top: 32px;
    margin-bottom: 36px;
    padding: 56px 46px;
    border-radius: 28px;
    border: 1px solid var(--home-line);
    background: linear-gradient(130deg, #f0f7ff 0%, #ffffff 48%, #eaf8f6 100%);
    box-shadow: 0 18px 44px rgba(15, 23, 42, 0.12);
}

.contact-wrapper {
    display: grid;
    grid-template-columns: 0.92fr 1.08fr;
    gap: 20px;
}

.contact-info {
    display: grid;
    gap: 14px;
}

.info-card,
.contact-form {
    border: 1px solid var(--home-line);
}

.info-card h4 {
    color: #0f3b50;
}

.contact-form button {
    background: linear-gradient(120deg, var(--home-primary), #0a9992);
}

.contact-form input:focus,
.contact-form textarea:focus {
    border-color: #62c7be;
    box-shadow: 0 0 0 3px rgba(11, 122, 117, 0.14);
}

.footer {
    border-radius: 16px;
    background: #0f2433;
    border: 1px solid #1a3d52;
    color: #cfdeeb;
}

@media (max-width: 980px) {
    .navbar,
    .hero,
    .section,
    .membership-section,
    .events-section,
    .products-section,
    .contact,
    .footer {
        margin-left: 16px;
        margin-right: 16px;
    }

    .hero,
    .section,
    .membership-container,
    .contact-wrapper {
        grid-template-columns: 1fr;
    }

    .hero-left h1 {
        font-size: 42px;
    }
}

@media (max-width: 640px) {
    .hero,
    .membership-section,
    .events-section,
    .products-section,
    .contact {
        padding: 34px 18px;
    }

    .section {
        padding: 18px;
    }
}
</style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
<div class="logo">UNIQUE <span>GYM</span></div>
<ul class="nav-menu">
<li><a href="#">Home</a></li>
<li><a href="#about">About</a></li>
<li><a href="#events">Events</a></li>
<li><a href="#product">Products</a></li>
<li><a href="#membership">Membership</a></li>
<li><a href="#contact">Contact</a></li>
</ul>
<div class="nav-btns">
<?php if (empty($username)): ?>
    <button class="login" style="background:#0066ff;"><a href="login.php">Login</a></button>
    <button class="signup"><a href="signup.php">Sign Up</a></button>
<?php else: ?>
    <div class="dropdown">
        <a href="#" class="profile-link dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle profile-icon"></i>
            <span><?php echo htmlspecialchars($username); ?></span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
            <li><a class="dropdown-item" href="sampleprofile.php"><i class="bi bi-person me-2"></i>View Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="?logout=1"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
    </div>
<?php endif; ?>
</div>
</div>

<!-- HERO -->
<div class="hero">
<div class="hero-left">
<span>WELCOME AT UNIQUE GYM</span>
<h1>THE MOST COMPLETED<br>GYM TO WORK OUT</h1>
<p>Build your body, improve your strength and stay fit with our professional trainers.</p>
<button onclick="location.href='#about'">About Us</button>
<button onclick="location.href='#contact'">Contact</button>
</div>
<div class="hero-right"><img src="image1.jpeg" alt="Gym"></div>
</div>

<!-- ABOUT -->
<div class="section" id="about">
<div class="section-left"><img src="image1.jpeg" alt="About"></div>
<div class="section-right">
<span>ABOUT UNIQUE GYM</span>
<h2 style="color:white;">We Help You Build Your Body</h2>
<p>Unique Gym is a modern fitness center where strength, discipline and healthy lifestyle come together.</p>
<div class="section-box" style="color:white;">&#10004; Certified Trainers<br>&#10004; Yoga &amp; Zumba <br>&#10004; Modern Equipment</div>
<p>Join Unique Gym and transform yourself with expert guidance and a motivating environment.</p>
</div>
</div>

<!-- MEMBERSHIP -->
<div class="membership-section" id="membership">
<div class="membership-container">
<div class="membership-left">
<span>OUR MEMBERSHIP</span>
<h2>Flexible Plans Designed For Every Fitness Goal</h2>
<p>Whether you're just starting your fitness journey or you're a professional athlete, Gymness offers flexible and affordable membership plans tailored to your needs.</p>
<div class="membership-points">
<div class="point"><i class="bi bi-check-circle-fill"></i>Access to modern gym equipment</div>
<div class="point"><i class="bi bi-check-circle-fill"></i>Certified personal trainers</div>
<div class="point"><i class="bi bi-check-circle-fill"></i>Steam, sauna &amp; shower facility</div>
<div class="point"><i class="bi bi-check-circle-fill"></i>Flexible duration plans</div>
</div>
<a href="mmm.php" class="explore-btn">Explore Membership Plans &rarr;</a>
</div>
<div class="membership-right"><img src="image1.jpeg" alt="Membership"></div>
</div>
</div>

<!-- EVENTS -->
<div class="events-section" id="events">
  <div class="contact-title">
    <span>EVENTS</span>
    <h2>Upcoming Events</h2>
    <p style="color:#666;margin-top:8px;">Join group workouts, workshops and community sessions.</p>
  </div>
  <?php if($event_msg): ?>
    <div class="event-alert ok"><?php echo htmlspecialchars($event_msg); ?></div>
  <?php endif; ?>
  <?php if($event_err): ?>
    <div class="event-alert err"><?php echo htmlspecialchars($event_err); ?></div>
  <?php endif; ?>

  <?php if($join_event_id && $join_event): ?>
    <?php $join_remaining = ((int)$join_event['max_seats'] > 0) ? max((int)$join_event['max_seats'] - (int)$join_event['approved_count'], 0) : null; ?>
    <div class="event-join-box">
      <h4>
        Join Event: <?php echo htmlspecialchars($join_event['title']); ?>
        (<?php echo date('d M Y', strtotime($join_event['event_date'])); ?>)
      </h4>
      <?php if(!$username): ?>
        <div class="event-note">Please login first to join this event.</div>
        <a class="event-btn" href="login.php">Login</a>
      <?php elseif($join_remaining === 0): ?>
        <div class="event-note">This event is full.</div>
        <a class="event-btn disabled" href="#">Full</a>
      <?php else: ?>
        <form method="POST" action="newhome.php#events" class="event-join-form">
          <input type="hidden" name="event_join_submit" value="1">
          <input type="hidden" name="event_id" value="<?php echo (int)$join_event['id']; ?>">
          <div class="jg">
            <label>Full Name</label>
            <input type="text" name="fullname" value="<?php echo htmlspecialchars($member_fullname ?: $username); ?>" required>
          </div>
          <div class="jg">
            <label>Username</label>
            <input type="text" value="<?php echo htmlspecialchars($username); ?>" readonly>
          </div>
          <div class="jg">
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo htmlspecialchars($member_phone); ?>" required>
          </div>
          <div class="event-join-actions">
            <button type="submit" class="event-btn" style="border:none;cursor:pointer;">Send Request</button>
            <a class="event-btn" style="background:#444;" href="newhome.php#events">Cancel</a>
          </div>
        </form>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <div class="event-grid">
    <?php if($events_home && mysqli_num_rows($events_home)>0): while($e=mysqli_fetch_assoc($events_home)):
      $remaining = ($e['max_seats']>0)? max($e['max_seats'] - $e['approved_count'],0) : null;
      $my_status = $e['my_status'] ?? '';
    ?>
    <div class="event-card">
      <div class="event-date"><?php echo date('d M Y',strtotime($e['event_date'])); ?> <?php if($e['event_time']) echo ' | '.date('h:i A',strtotime($e['event_time'])); ?></div>
      <div class="event-title"><?php echo htmlspecialchars($e['title']); ?></div>
      <div class="event-meta"><?php echo htmlspecialchars($e['description'] ?: ''); ?></div>
      <div class="event-meta"><strong>Trainer:</strong> <?php echo htmlspecialchars($e['trainer_name'] ?: 'TBA'); ?></div>
      <div class="event-meta"><strong>Location:</strong> <?php echo htmlspecialchars($e['location'] ?: 'Gym Floor'); ?></div>
      <div class="event-seats <?php echo ($remaining===0)?'full':'';?>">
        <?php echo $e['max_seats']>0 ? ($remaining>0 ? "$remaining seats left / ".$e['max_seats'] : "Fully booked") : "Unlimited seats"; ?>
      </div>
      <?php if($my_status === 'pending'): ?>
        <a class="event-btn disabled" href="#">Request Sent</a>
      <?php elseif($my_status === 'approved'): ?>
        <a class="event-btn disabled" href="#">Joined</a>
      <?php elseif($my_status === 'cancelled'): ?>
        <a class="event-btn disabled" href="#">Already Requested</a>
      <?php elseif($remaining===0): ?>
        <a class="event-btn disabled" href="#">Full</a>
      <?php elseif(!$username): ?>
        <a class="event-btn" href="login.php">Login to Join</a>
      <?php else: ?>
        <a class="event-btn" href="newhome.php?join_event=<?php echo $e['id']; ?>#events">Join Event</a>
      <?php endif; ?>
    </div>
    <?php endwhile; else: ?>
      <div class="prod-no-data" style="grid-column:1/-1;">No upcoming events. Check back soon!</div>
    <?php endif; ?>
  </div>
</div>
<!-- PRODUCTS -->
<div class="products-section" id="product">
<div class="contact-title">
<span>PRODUCTS</span>
<h2>Our Gym Products</h2>
<p style="color:#666;margin-top:8px;">Browse products &mdash; available to all visitors</p>
</div>

<!-- Category Filter Tabs -->
<div class="prod-filter-tabs">
    <a href="newhome.php#product" class="prod-filter-tab <?php echo $active_cat==0?'active':''; ?>"><i class="bi bi-grid-3x3-gap-fill"></i> All</a>
    <?php foreach($cat_list as $cl):
        $icons=[
            'equipments'=>'<i class="bi bi-tools"></i>',
            'supplements'=>'<i class="bi bi-capsule-pill"></i>',
            'merchandise'=>'<i class="bi bi-bag-fill"></i>'
        ];
        $slug=strtolower(str_replace(' ','-',$cl['category_name']));
        $icon=$icons[$slug]??'<i class="bi bi-box-seam"></i>';
    ?>
    <a href="newhome.php?pcat=<?php echo $cl['id']; ?>#product"
       class="prod-filter-tab <?php echo $active_cat==$cl['id']?'active':''; ?>">
        <?php echo $icon.' '.htmlspecialchars($cl['category_name']); ?>
    </a>
    <?php endforeach; ?>
</div>

<!-- Products Grid -->
<div class="prod-grid">
<?php if(count($all_products)>0): ?>
    <?php foreach($all_products as $prod): ?>
    <div class="prod-card">
        <?php if(!empty($prod['image'])): ?>
        <img src="uploads/products/<?php echo htmlspecialchars($prod['image']); ?>" alt="<?php echo htmlspecialchars($prod['product_name']); ?>">
        <?php else: ?><div class="prod-card-noimg"><i class="bi bi-box-seam"></i></div><?php endif; ?>
        <div class="prod-card-body">
            <div class="prod-cat-badge"><?php echo htmlspecialchars($prod['category_name']); ?></div>
            <h3><?php echo htmlspecialchars($prod['product_name']); ?></h3>
            <?php if(!empty($prod['attributes'])): ?>
            <div class="prod-attrs">
                <?php foreach($prod['attributes'] as $attr): ?>
                <span class="prod-attr-chip">
                    <span class="prod-attr-label"><?php echo htmlspecialchars($attr['attr_name']); ?>:</span>
                    <?php echo htmlspecialchars($attr['values_list']); ?>
                </span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php if($prod['variant_count']>1): ?>
            <div class="prod-variants-badge"><i class="bi bi-box-seam"></i> <?php echo $prod['variant_count']; ?> variants available</div>
            <?php endif; ?>
            <div class="prod-price">
                &#8377;<?php echo number_format($prod['min_price'],2); ?>
                <?php if($prod['min_price']!=$prod['max_price']): ?>
                <span class="prod-price-range"> &ndash; &#8377;<?php echo number_format($prod['max_price'],2); ?></span>
                <?php endif; ?>
            </div>
            <?php if($prod['total_stock']>0): ?>
            <div class="prod-stock-ok"><i class="bi bi-check-circle-fill"></i> In Stock (<?php echo $prod['total_stock']; ?> units)</div>
            <?php else: ?>
            <div class="prod-stock-out"><i class="bi bi-x-circle-fill"></i> Out of Stock</div>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="prod-no-data"><i class="bi bi-inboxes-fill"></i> No products available yet.<br><small>Check back soon!</small></div>
<?php endif; ?>
</div>

<div style="text-align:center;margin-top:40px;">
<a href="products.php" style="display:inline-block;padding:14px 36px;background:var(--primary);color:#fff;border-radius:8px;font-weight:700;font-size:15px;text-decoration:none;">View All Products &rarr;</a>
</div>
</div>

<!-- CONTACT -->
<div class="contact" id="contact">
<div class="contact-title">
<span>CONTACT US</span>
<h2>We'd Love To Hear From You</h2>
</div>
<div class="contact-wrapper">
<div class="contact-info">
<div class="info-card"><h4><i class="bi bi-geo-alt me-2 text-primary"></i>Address</h4>Ghodasar, Ahmedabad</div>
<div class="info-card"><h4><i class="bi bi-telephone me-2 text-success"></i>Phone</h4>+91 98765 43210</div>
<div class="info-card"><h4><i class="bi bi-envelope me-2 text-danger"></i>Email</h4><a href="mailto:gymness@gmail.com">gymness@gmail.com</a></div>
</div>
<div class="contact-form">
<h3>Send Message</h3>
<form action="newhome.php" method="POST">
<input type="hidden" name="contact_submit" value="1">
<input type="text" name="name" placeholder="Your Name" required>
<input type="email" name="email" placeholder="Your Email" required>
<textarea name="message" rows="5" placeholder="Your Message" required></textarea>
<button type="submit">Send Message <i class="bi bi-send ms-2"></i></button>
</form>
</div>
</div>
</div>

<div class="footer"><?php include 'footer.php';?></div>

</body>
</html>


