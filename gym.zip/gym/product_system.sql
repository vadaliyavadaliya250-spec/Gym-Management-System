-- ============================================================
-- GYM PRODUCT SYSTEM - NEW TABLES
-- Run this on your existing `gym` database
-- ============================================================

-- --------------------------------------------------------
-- 1. product_categories  (Equipments, Supplements, Merchandise)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Default categories
INSERT INTO `product_categories` (`category_name`, `slug`, `description`) VALUES
('Equipments',    'equipments',    'Gym equipment like dumbbells, barbells, machines'),
('Supplements',   'supplements',   'Protein powder, creatine, vitamins, etc.'),
('Merchandise',   'merchandise',   'T-shirts, bottles, gym bags, accessories');

-- --------------------------------------------------------
-- 2. product_attribute_types  (KG, Flavour, Size, Liter, etc.)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `product_attribute_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(100) NOT NULL,   -- e.g. Weight (KG), Flavour, Size, Liter
  `attribute_key`  varchar(50)  NOT NULL,   -- e.g. weight_kg, flavour, size, liter
  `unit_label`     varchar(30)  DEFAULT NULL, -- e.g. KG, L, ml
  `input_type`     enum('text','select','number') DEFAULT 'select',
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_key` (`attribute_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `product_attribute_types` (`attribute_name`,`attribute_key`,`unit_label`,`input_type`) VALUES
('Weight (KG)',  'weight_kg', 'KG',    'select'),
('Flavour',      'flavour',   NULL,    'select'),
('Size',         'size',      NULL,    'select'),
('Liter',        'liter',     'L',     'select');

-- --------------------------------------------------------
-- 3. category_attributes  (which attribute types belong to which category)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `category_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id`  int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cat_attr` (`category_id`,`attribute_id`),
  KEY `category_id` (`category_id`),
  KEY `attribute_id` (`attribute_id`),
  CONSTRAINT `ca_cat_fk` FOREIGN KEY (`category_id`)  REFERENCES `product_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ca_attr_fk` FOREIGN KEY (`attribute_id`) REFERENCES `product_attribute_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Equipments → Weight (KG)
-- Supplements → Weight (KG) + Flavour
-- Merchandise → Size + Liter (for bottles)
INSERT INTO `category_attributes` (`category_id`,`attribute_id`) VALUES
(1, 1),   -- Equipments   → Weight(KG)
(2, 1),   -- Supplements  → Weight(KG)
(2, 2),   -- Supplements  → Flavour
(3, 3),   -- Merchandise  → Size
(3, 4);   -- Merchandise  → Liter

-- --------------------------------------------------------
-- 4. attribute_values  (pre-defined values for each attribute)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attribute_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value_label`  varchar(100) NOT NULL,  -- e.g. "1 KG", "Chocolate", "XL", "1 L"
  `sort_order`   int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`),
  CONSTRAINT `av_attr_fk` FOREIGN KEY (`attribute_id`) REFERENCES `product_attribute_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Weight values
INSERT INTO `attribute_values` (`attribute_id`,`value_label`,`sort_order`) VALUES
(1,'0.5 KG',1),(1,'1 KG',2),(1,'2 KG',3),(1,'5 KG',4),
(1,'10 KG',5),(1,'20 KG',6),(1,'25 KG',7),(1,'50 KG',8);
-- Flavour values
INSERT INTO `attribute_values` (`attribute_id`,`value_label`,`sort_order`) VALUES
(2,'Chocolate',1),(2,'Vanilla',2),(2,'Strawberry',3),
(2,'Mango',4),(2,'Unflavoured',5),(2,'Coffee',6);
-- Size values
INSERT INTO `attribute_values` (`attribute_id`,`value_label`,`sort_order`) VALUES
(3,'XS',1),(3,'S',2),(3,'M',3),(3,'L',4),(3,'XL',5),(3,'XXL',6);
-- Liter values
INSERT INTO `attribute_values` (`attribute_id`,`value_label`,`sort_order`) VALUES
(4,'500 ml',1),(4,'750 ml',2),(4,'1 L',3),(4,'1.5 L',4),(4,'2 L',5);

-- --------------------------------------------------------
-- 5. products_new  (clean product master — replaces old `products`)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products_new` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id`    int(11) NOT NULL,
  `product_name`   varchar(150) NOT NULL,
  `image`          varchar(255) DEFAULT NULL,
  `description`    text DEFAULT NULL,
  `price`          decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount`       decimal(5,2)  NOT NULL DEFAULT 0.00,
  `final_price`    decimal(10,2) NOT NULL DEFAULT 0.00,
  `status`         enum('active','inactive') DEFAULT 'active',
  `created_at`     timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `pn_cat_fk` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- 6. product_variants  (each combination of attribute values = one variant with own stock/price)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id`   int(11) NOT NULL,
  `variant_name` varchar(255) NOT NULL,   -- auto-generated e.g. "1 KG / Chocolate"
  `sku`          varchar(100) DEFAULT NULL,
  `extra_price`  decimal(10,2) DEFAULT 0.00,  -- price addition over base
  `final_price`  decimal(10,2) DEFAULT 0.00,  -- base + extra - discount
  `stock`        int(11) NOT NULL DEFAULT 0,
  `status`       enum('active','inactive') DEFAULT 'active',
  `created_at`   timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `pv_prod_fk` FOREIGN KEY (`product_id`) REFERENCES `products_new` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- 7. variant_attributes  (which attribute values are in each variant)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `variant_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `variant_id`   int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value_id`     int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `variant_id`   (`variant_id`),
  KEY `attribute_id` (`attribute_id`),
  KEY `value_id`     (`value_id`),
  CONSTRAINT `va_var_fk`  FOREIGN KEY (`variant_id`)   REFERENCES `product_variants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `va_attr_fk` FOREIGN KEY (`attribute_id`) REFERENCES `product_attribute_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `va_val_fk`  FOREIGN KEY (`value_id`)     REFERENCES `attribute_values` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- 8. stock_log  (track every stock in/out movement)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `variant_id`   int(11) NOT NULL,
  `change_type`  enum('add','reduce','sale','return','adjustment') NOT NULL,
  `quantity`     int(11) NOT NULL,
  `stock_before` int(11) NOT NULL,
  `stock_after`  int(11) NOT NULL,
  `note`         varchar(255) DEFAULT NULL,
  `done_by`      varchar(100) DEFAULT 'admin',
  `created_at`   timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `variant_id` (`variant_id`),
  CONSTRAINT `sl_var_fk` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
-- USEFUL VIEWS
-- ============================================================

-- Full product + variant overview
CREATE OR REPLACE VIEW `v_product_stock` AS
SELECT
  p.id           AS product_id,
  pc.category_name,
  p.product_name,
  p.price        AS base_price,
  p.discount,
  pv.id          AS variant_id,
  pv.variant_name,
  pv.sku,
  pv.final_price,
  pv.stock,
  pv.status      AS variant_status
FROM products_new p
JOIN product_categories pc ON pc.id = p.category_id
JOIN product_variants pv   ON pv.product_id = p.id
ORDER BY pc.category_name, p.product_name, pv.variant_name;

-- ============================================================
-- SAMPLE DATA  (Dumbbells / Protein / T-Shirt / Bottle)
-- ============================================================

-- Dumbbell (Equipment - KG only)
INSERT INTO `products_new` (`category_id`,`product_name`,`description`,`price`,`discount`,`final_price`)
VALUES (1, 'Iron Dumbbell', 'Heavy-duty cast iron dumbbell', 500.00, 0.00, 500.00);

INSERT INTO `product_variants` (`product_id`,`variant_name`,`sku`,`extra_price`,`final_price`,`stock`) VALUES
(1,'1 KG','DUMB-1KG',0.00,500.00,20),
(1,'2 KG','DUMB-2KG',200.00,700.00,15),
(1,'5 KG','DUMB-5KG',500.00,1000.00,10);

INSERT INTO `variant_attributes` (`variant_id`,`attribute_id`,`value_id`) VALUES
(1,1,2),(2,1,3),(3,1,4);   -- weight 1KG, 2KG, 5KG

-- Protein Powder (Supplement - KG + Flavour)
INSERT INTO `products_new` (`category_id`,`product_name`,`description`,`price`,`discount`,`final_price`)
VALUES (2, 'Whey Protein', 'Fast-absorbing whey protein powder', 1500.00, 5.00, 1425.00);

INSERT INTO `product_variants` (`product_id`,`variant_name`,`sku`,`extra_price`,`final_price`,`stock`) VALUES
(2,'1 KG / Chocolate','WHEY-1KG-CHO',0.00,1425.00,30),
(2,'1 KG / Vanilla',  'WHEY-1KG-VAN',0.00,1425.00,25),
(2,'2 KG / Chocolate','WHEY-2KG-CHO',800.00,2205.00,18);

INSERT INTO `variant_attributes` (`variant_id`,`attribute_id`,`value_id`) VALUES
(4,1,2),(4,2,1),   -- 1KG Chocolate
(5,1,2),(5,2,2),   -- 1KG Vanilla
(6,1,3),(6,2,1);   -- 2KG Chocolate

-- T-Shirt (Merchandise - Size)
INSERT INTO `products_new` (`category_id`,`product_name`,`description`,`price`,`discount`,`final_price`)
VALUES (3, 'Gym T-Shirt', 'Dry-fit performance gym t-shirt', 499.00, 10.00, 449.10);

INSERT INTO `product_variants` (`product_id`,`variant_name`,`sku`,`extra_price`,`final_price`,`stock`) VALUES
(3,'S','TSHIRT-S',0.00,449.10,15),
(3,'M','TSHIRT-M',0.00,449.10,20),
(3,'L','TSHIRT-L',0.00,449.10,18),
(3,'XL','TSHIRT-XL',0.00,449.10,10),
(3,'XXL','TSHIRT-XXL',50.00,499.10,5);

INSERT INTO `variant_attributes` (`variant_id`,`attribute_id`,`value_id`) VALUES
(7,3,2),(8,3,3),(9,3,4),(10,3,5),(11,3,6);   -- S,M,L,XL,XXL

-- Water Bottle (Merchandise - Liter)
INSERT INTO `products_new` (`category_id`,`product_name`,`description`,`price`,`discount`,`final_price`)
VALUES (3, 'Gym Water Bottle', 'BPA-free shaker bottle', 299.00, 0.00, 299.00);

INSERT INTO `product_variants` (`product_id`,`variant_name`,`sku`,`extra_price`,`final_price`,`stock`) VALUES
(4,'500 ml','BTL-500ML',0.00,299.00,30),
(4,'1 L',   'BTL-1L',   100.00,399.00,25),
(4,'1.5 L', 'BTL-1.5L', 150.00,449.00,20);

INSERT INTO `variant_attributes` (`variant_id`,`attribute_id`,`value_id`) VALUES
(12,4,1),(13,4,3),(14,4,4);   -- 500ml, 1L, 1.5L

-- Initial stock log entries
INSERT INTO `stock_log` (`variant_id`,`change_type`,`quantity`,`stock_before`,`stock_after`,`note`) VALUES
(1,'add',20,0,20,'Initial stock'),
(2,'add',15,0,15,'Initial stock'),
(3,'add',10,0,10,'Initial stock'),
(4,'add',30,0,30,'Initial stock'),
(5,'add',25,0,25,'Initial stock'),
(6,'add',18,0,18,'Initial stock');
