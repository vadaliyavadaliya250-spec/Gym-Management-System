<?php
session_start();
$con = mysqli_connect("localhost","root","","gym");
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: newhome.php");
    exit;
}

// Check form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $message = mysqli_real_escape_string($con, $_POST['message']);

    $sql = "INSERT INTO contact_messages (name, email, message) 
            VALUES ('$name', '$email', '$message')";

    if (mysqli_query($con, $sql)) {
        echo "<script>
                alert('Message sent successfully!');
                window.location.href='newhome.php#contact';
              </script>";
    } else {
        echo "<script>
                alert('Something went wrong!');
                window.history.back();
              </script>";
    }
}

mysqli_close($con);

?>
<!DOCTYPE html>
<html>
<head>
<title>Gymness</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
* { margin:0; padding:0; box-sizing:border-box; font-family:Arial, Helvetica, sans-serif; color:black; }
html { scroll-behavior:smooth; }

.navbar {
    padding:20px 60px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:sticky;
    top:0;
    background:#fff;
    z-index:10;
    box-shadow:0 2px 10px rgba(0,0,0,0.1);
}
.logo { font-size:26px; font-weight:800; }
.nav-menu { list-style:none; display:flex; gap:30px; }
.nav-menu li a { 
    text-decoration:none; 
    color:black; 
    font-weight:600; 
    transition:color 0.3s; 
    padding:8px 0;
}
.nav-menu li a:hover { color:#c82027; }

.nav-btns button {
    padding:12px 24px;
    border-radius:8px;
    border:none;
    cursor:pointer;
    margin-left:10px;
    font-weight:600;
    transition:all 0.3s;
}
.nav-btns button:hover { transform:translateY(-2px); }
.nav-btns a { text-decoration:none; color:black; }
.signup { background:#c82027 !important; }
.signup a { color:white !important; }

/* Profile Dropdown */
.profile-link {
    display:flex; align-items:center;
    padding:12px 24px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
    color:black;
    transition:all 0.3s;
}
.profile-link:hover { background:#f8f9fa; color:#c82027; }
.profile-icon { font-size:26px; margin-right:12px; color:#c82027; }
.dropdown-menu {
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
    border:none;
    margin-top:12px;
}
.dropdown-item {
    padding:12px 20px;
    font-weight:500;
    transition:all 0.3s;
}
.dropdown-item:hover { background:#f8f9fa; padding-left:28px; }

.hero {
    padding:80px 60px;
    display:flex;
    align-items:center;
    background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%);
}
.hero-left { width:50%; }
.hero-left span { color:#c82027; letter-spacing:2px; font-weight:600; }
.hero-left h1 { font-size:52px; margin:20px 0; line-height:1.2; }
.hero-left p { color:#666; max-width:480px; font-size:18px; }
.hero-left button {
    margin-top:30px;
    margin-right:10px;
    padding:16px 32px;
    border:none;
    border-radius:8px;
    background:#c82027;
    color:#fff;
    font-weight:600;
    cursor:pointer;
    transition:all 0.3s;
}
.hero-left button:hover { transform:translateY(-3px); box-shadow:0 10px 25px rgba(200,32,39,0.3); }

.hero-right { width:50%; }
.hero-right img { width:100%; border-radius:20px; box-shadow:0 20px 40px rgba(0,0,0,0.1); }

.section {
    background:#111;
    color:white;
    padding:90px 60px;
    display:flex;
    gap:60px;
}
.section-left, .section-right { width:50%; }
.section-left img, .section-right img { width:100%; border-radius:20px; }
.section-right span { color:#c82027; letter-spacing:2px; font-weight:600; }
.section-right h2 { font-size:40px; margin:15px 0; }
.section-right p { color:#ccc; line-height:1.7; font-size:16px; }
.section-box {
    background:#1f1f1f;
    padding:25px;
    margin:25px 0;
    border-left:4px solid #c82027;
    border-radius:10px;
}

.contact {
    padding:90px 60px;
    background:#f8f9fa;
}
.contact-title { text-align:center; margin-bottom:60px; }
.contact-title span { color:#c82027; letter-spacing:2px; font-weight:600; }
.contact-title h2 { font-size:40px; margin-top:10px; }

.contact-wrapper { display:flex; gap:40px; }
.info-card {
    background:white;
    padding:35px;
    border-radius:20px;
    box-shadow:0 15px 35px rgba(0,0,0,0.1);
    transition:all 0.4s;
    flex:1;
    min-width:320px;
}
.info-card:hover { 
    transform:translateY(-12px); 
    box-shadow:0 25px 50px rgba(0,0,0,0.2); 
}
.info-card h4 { margin-bottom:15px; color:#c82027; font-size:24px; }

.contact-info { width:40%; display:flex; flex-direction:column; gap:20px; }
.contact-form {
    width:60%;
    background:white;
    padding:45px;
    border-radius:20px;
    box-shadow:0 15px 35px rgba(0,0,0,0.1);
}
.contact-form input, .contact-form textarea {
    width:100%;
    padding:16px;
    margin-bottom:20px;
    border-radius:10px;
    border:1px solid #ddd;
    font-size:16px;
}
.contact-form button {
    padding:16px 40px;
    background:#c82027;
    color:white;
    border:none;
    border-radius:10px;
    cursor:pointer;
    font-size:16px;
    font-weight:600;
    width:100%;
    transition:all 0.3s;
}
.contact-form button:hover { transform:translateY(-2px); }

.footer {
    background:#000;
    color:#aaa;
    text-align:center;
    padding:30px;
    font-size:14px;
}

/* ================= MEMBERSHIP SECTION NEW DESIGN ================= */

.membership-section {
    padding:100px 60px;
    background:linear-gradient(135deg,#ffffff,#f0f2f5);
}

.membership-container {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:60px;
}

.membership-left {
    width:50%;
}

.membership-left span {
    color:#c82027;
    letter-spacing:2px;
    font-weight:600;
}

.membership-left h2 {
    font-size:42px;
    margin:20px 0;
    font-weight:800;
}

.membership-left p {
    color:#555;
    font-size:17px;
    line-height:1.7;
    margin-bottom:30px;
}

.membership-points .point {
    display:flex;
    align-items:center;
    margin-bottom:15px;
    font-size:16px;
    font-weight:500;
}

.membership-points i {
    color:#c82027;
    margin-right:12px;
    font-size:20px;
}

.explore-btn {
    display:inline-block;
    margin-top:30px;
    padding:15px 35px;
    background:#c82027;
    color:white;
    text-decoration:none;
    border-radius:8px;
    font-weight:600;
    transition:all 0.3s;
}

.explore-btn:hover {
    background:black;
    color:white;
    transform:translateY(-3px);
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

.membership-right {
    width:50%;
}

.membership-right img {
    width:100%;
    border-radius:20px;
    box-shadow:0 25px 50px rgba(0,0,0,0.15);
}

</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
<div class="logo">UNIQUE GYM</div>

<ul class="nav-menu">
<li><a href="#">Home</a></li>
<li><a href="#about">About</a></li>
<li><a href="#contact">Contact</a></li>
<li><a href="#membership">Membership</a></li>
<li><a href="#product">Product</a></li>
</ul>

<div class="nav-btns">
<?php if (empty($username)): ?>
    <!-- Not Logged In -->
    <button class="login" style="background:#0066ff;"><a href="login.php">Login</a></button>
    <button class="signup"><a href="signup.php">Sign Up</a></button>
<?php else: ?>
    <!-- Logged In - Profile Dropdown -->
    <div class="dropdown">
        <a href="#" class="profile-link dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle profile-icon"></i>
            <span><?php echo htmlspecialchars($username); ?></span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
            <li><a class="dropdown-item" href="profile.php">
                <i class="bi bi-person me-2"></i>View Profile
            </a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="?logout=1">
                <i class="bi bi-box-arrow-right me-2"></i>Logout
            </a></li>
        </ul>
    </div>
<?php endif; ?>
</div>
</div>

<!-- HERO -->
<div class="hero">
<div class="hero-left">
<span>WELCOME AT UNIQUE GYM</span>
<h1>THE MOST COMPLETED<br>GYM TO WORK OUT</h1>
<p>Build your body, improve your strength and stay fit with our professional trainers.</p>
<button onclick="location.href='#about'">About Us</button>
<button onclick="location.href='#contact'">Contact</button>
</div>
<div class="hero-right">
<img src="image1.jpeg" alt="Gym">
</div>
</div>

<!-- ABOUT -->
<div class="section" id="about">
<div class="section-left">
<img src="image1.jpeg" alt="About">
</div>
<div class="section-right">
<span>ABOUT UNIQUE GYM</span>
<h2 style="color:white;">We Help You Build Your Body</h2>
<p>Unique Gym is a modern fitness center where strength, discipline and healthy lifestyle come together.</p>

<div class="section-box" style="color:white;">
✔ Certified Trainers<br>✔ Yoga & Zumba <br>✔ Modern Equipment
</div>

<p>Join Unique Gym and transform yourself with expert guidance and a motivating environment.</p>
</div>
</div>

<!-- MEMBERSHIP -->
<div class="membership-section" id="membership">
    <div class="membership-container">
        
        <!-- Left Content -->
        <div class="membership-left">
            <span>OUR MEMBERSHIP</span>
            <h2>Flexible Plans Designed For Every Fitness Goal</h2>
            <p>
                Whether you're just starting your fitness journey or you're a professional athlete, 
                Gymness offers flexible and affordable membership plans tailored to your needs.
            </p>

            <div class="membership-points">
                <div class="point">
                    <i class="bi bi-check-circle-fill"></i>
                    Access to modern gym equipment
                </div>
                <div class="point">
                    <i class="bi bi-check-circle-fill"></i>
                    Certified personal trainers
                </div>
                <div class="point">
                    <i class="bi bi-check-circle-fill"></i>
                    Steam, sauna & shower facility
                </div>
                <div class="point">
                    <i class="bi bi-check-circle-fill"></i>
                    Flexible duration plans
                </div>
            </div>

            <a href="membership2.php" class="explore-btn">
                Explore Membership Plans →
            </a>
        </div>

        <!-- Right Image -->
        <div class="membership-right">
            <img src="image1.jpeg" alt="Membership">
        </div>

    </div>
</div>


<!-- PRODUCTS -->
<div class="contact" id="product">
<div class="contact-title">
<span>PRODUCTS</span>
<h2>Our Gym Products</h2>
</div>
<div class="contact-wrapper">
<div class="info-card">
<h4>Protein Powder</h4>
<p class="fs-3 fw-bold text-success">₹2500</p>
<p>High quality whey protein for muscle building.</p>
</div>
<div class="info-card">
<h4>Dumbbells Set</h4>
<p class="fs-3 fw-bold text-success">₹5000</p>
<p>Rubber coated dumbbells (5kg - 20kg).</p>
</div>
<div class="info-card">
<h4>Yoga Mat</h4>
<p class="fs-3 fw-bold text-success">₹800</p>
<p>Anti-slip premium yoga mat.</p>
</div>
</div>
<div style="text-align:center;margin-top:50px;">
<a href="products.php" class="btn btn-lg signup px-5 py-3 fs-5">View More Products →</a>
</div>
</div>

<!-- CONTACT -->
<div class="contact" id="contact">
<div class="contact-title">
<span>CONTACT US</span>
<h2>We'd Love To Hear From You</h2>
</div>
<div class="contact-wrapper">
<div class="contact-info">
<div class="info-card">
<h4><i class="bi bi-geo-alt me-2 text-primary"></i>Address</h4>
Ghodasar, Ahmedabad
</div>
<div class="info-card">
<h4><i class="bi bi-telephone me-2 text-success"></i>Phone</h4>
+91 98765 43210
</div>
<div class="info-card">
<h4><i class="bi bi-envelope me-2 text-danger"></i>Email</h4>
<a href="mailto:gymness@gmail.com">gymness@gmail.com</a>
</div>
</div>
<div class="contact-form">
    <h3>Send Message</h3>

    <form action="newhome.php" method="POST">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="email" name="email" placeholder="Your Email" required>
        <textarea name="message" rows="5" placeholder="Your Message" required></textarea>

        <button type="submit">
            Send Message <i class="bi bi-send ms-2"></i>
        </button>
    </form>
</div>
</div>
</div>

<div class="footer">
<?php include 'footer.php';?>
</div>

</body>
</html>
