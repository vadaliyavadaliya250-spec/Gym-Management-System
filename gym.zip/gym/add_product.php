<?php
$con = mysqli_connect("localhost","root","","gym");
if(!$con){ die("DB Error"); }

// DELETE
if(isset($_GET['delete'])){
    mysqli_query($con,"DELETE FROM products WHERE id=".$_GET['delete']);
    header("Location: admin_products.php");
}

// ADD / UPDATE
if(isset($_POST['save'])){
    $id = $_POST['id'];
    $category = $_POST['category'];
    $product = $_POST['product'];
    $desc = $_POST['description'];

    $kg = $_POST['kg'] ?? '';
    $flavour = $_POST['flavour'] ?? '';
    $mm = $_POST['mm'] ?? '';
    $size = $_POST['size'] ?? '';
    $ml = $_POST['ml'] ?? '';

    $stock = $_POST['stock'];
    $price = $_POST['price'];
    $discount = $_POST['discount'];
    $final = $price - $discount;

    if($_FILES['image']['name']){
        $img = time().$_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'],"uploads/".$img);
    }else{
        $img = $_POST['old_image'];
    }

    if($id==""){
        mysqli_query($con,"INSERT INTO products 
        (category,product_name,image,description,weight_kg,flavour,thickness_mm,size,capacity_ml,stock,price,discount,final_price)
        VALUES('$category','$product','$img','$desc','$kg','$flavour','$mm','$size','$ml','$stock','$price','$discount','$final')");
    }else{
        mysqli_query($con,"UPDATE products SET 
        category='$category',
        product_name='$product',
        image='$img',
        description='$desc',
        weight_kg='$kg',
        flavour='$flavour',
        thickness_mm='$mm',
        size='$size',
        capacity_ml='$ml',
        stock='$stock',
        price='$price',
        discount='$discount',
        final_price='$final'
        WHERE id='$id'");
    }
    header("Location: admin_products.php");
}

// EDIT FETCH
$edit = [];
if(isset($_GET['edit'])){
    $q = mysqli_query($con,"SELECT * FROM products WHERE id=".$_GET['edit']);
    $edit = mysqli_fetch_assoc($q);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Panel</title>
<style>
body{margin:0;font-family:Arial;background:#f4f4f4;}
.sidebar{width:220px;height:100vh;background:#111;color:#fff;position:fixed;}
.sidebar h2{text-align:center;padding:20px}
.sidebar a{display:block;color:#fff;padding:15px;text-decoration:none}
.sidebar a:hover{background:#333}

.topbar{margin-left:220px;background:#fff;padding:15px;text-align:right;font-weight:bold}
.container{margin-left:220px;padding:30px}

input,select,textarea{width:100%;padding:8px;margin:8px 0}
button{padding:10px 20px;background:#000;color:#fff;border:none}

table{width:100%;background:#fff;border-collapse:collapse;margin-top:30px}
th,td{border:1px solid #ccc;padding:10px;text-align:center}
img{width:60px}
</style>

<script>
function showFields(){
    let p = document.getElementById("product").value;
    document.querySelectorAll(".extra").forEach(e=>e.style.display="none");

    if(p=="Dumbbells"||p=="Barbells") document.getElementById("kg").style.display="block";
    if(p=="Protein Powder"){ document.getElementById("kg").style.display="block"; document.getElementById("flavour").style.display="block";}
    if(p=="Yoga Mats") document.getElementById("mm").style.display="block";
    if(p=="Gym T-Shirt"||p=="Gym Shorts") document.getElementById("size").style.display="block";
    if(p=="Water Bottle") document.getElementById("ml").style.display="block";
}

function loadProducts(){
    let c = document.getElementById("category").value;
    let p = document.getElementById("product");
    p.innerHTML="";

    let data={
        Equipments:["Dumbbells","Barbells","Resistance Bands","Skipping Rope","Hand Gripper","Gym Gloves","Yoga Mats"],
        Supplements:["Protein Powder"],
        Merchandise:["Gym T-Shirt","Gym Shorts","Water Bottle"]
    };

    data[c].forEach(v=>{
        let o=document.createElement("option");
        o.text=v;o.value=v;p.add(o);
    });
    showFields();
}
</script>
</head>

<body>

<div class="sidebar">
<h2>ADMIN</h2>
<a href="#">Dashboard</a>
<a href="#">Products</a>
<a href="#">Membership</a>
</div>

<div class="topbar">Admin Panel</div>

<div class="container">

<h2>Add / Edit Product</h2>

<form method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">
<input type="hidden" name="old_image" value="<?= $edit['image'] ?? '' ?>">

<select name="category" id="category" onchange="loadProducts()" required>
<option value="">Select Category</option>
<option <?=(@$edit['category']=="Equipments")?"selected":""?>>Equipments</option>
<option <?=(@$edit['category']=="Supplements")?"selected":""?>>Supplements</option>
<option <?=(@$edit['category']=="Merchandise")?"selected":""?>>Merchandise</option>
</select>

<select name="product" id="product" onchange="showFields()" required></select>

<textarea name="description" placeholder="Description"><?= $edit['description'] ?? '' ?></textarea>
<input type="file" name="image">

<div id="kg" class="extra" style="display:none">
<input name="kg" placeholder="Weight (KG)" value="<?= $edit['weight_kg'] ?? '' ?>">
</div>

<div id="flavour" class="extra" style="display:none">
<input name="flavour" placeholder="Flavour" value="<?= $edit['flavour'] ?? '' ?>">
</div>

<div id="mm" class="extra" style="display:none">
<input name="mm" placeholder="Thickness (MM)" value="<?= $edit['thickness_mm'] ?? '' ?>">
</div>

<div id="size" class="extra" style="display:none">
<input name="size" placeholder="Size" value="<?= $edit['size'] ?? '' ?>">
</div>

<div id="ml" class="extra" style="display:none">
<input name="ml" placeholder="Capacity (ML)" value="<?= $edit['capacity_ml'] ?? '' ?>">
</div>

<input name="stock" placeholder="Stock" value="<?= $edit['stock'] ?? '' ?>">
<input name="price" placeholder="Price" value="<?= $edit['price'] ?? '' ?>">
<input name="discount" placeholder="Discount" value="<?= $edit['discount'] ?? '' ?>">

<button name="save">Save Product</button>
</form>

<table>
<tr>
<th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Action</th>
</tr>
<?php
$res=mysqli_query($con,"SELECT * FROM products");
while($r=mysqli_fetch_assoc($res)){
?>
<tr>
<td><img src="uploads/<?= $r['image'] ?>"></td>
<td><?= $r['product_name'] ?></td>
<td><?= $r['category'] ?></td>
<td><?= $r['final_price'] ?></td>
<td>
<a href="?edit=<?= $r['id'] ?>">Edit</a> |
<a href="?delete=<?= $r['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>
<?php } ?>
</table>

</div>

<script>
<?php if(isset($edit['category'])){ ?>
document.getElementById("category").value="<?= $edit['category'] ?>";
loadProducts();
document.getElementById("product").value="<?= $edit['product_name'] ?>";
showFields();
<?php } ?>
</script>

</body>
</html>
