<!DOCTYPE html>
<html lang="en">
<head>
    <title>WORD STORM - Cyber Edition</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            background: radial-gradient(ellipse at center, #0a0a1a 0%, #000305 70%);
            overflow: hidden;
            font-family: 'Courier New', monospace;
            color: #fff;
            position: relative;
        }

        /* Animated Background Particles */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            background: #00ffff;
            border-radius: 50%;
            animation: float 6s infinite linear;
        }

        @keyframes float {
            0% { transform: translateY(100vh) scale(0); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100px) scale(1); opacity: 0; }
        }

        /* Game Title with Glow */
        .title {
            position: absolute;
            top: 30px;
            width: 100%;
            text-align: center;
            font-size: clamp(24px, 4vw, 32px);
            letter-spacing: 6px;
            background: linear-gradient(45deg, #00ffff, #ff00ff, #00ff00);
            background-size: 300% 300%;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 0 30px rgba(0, 255, 255, 0.5);
            animation: glow 2s ease-in-out infinite alternate;
            z-index: 10;
        }

        @keyframes glow {
            0% { filter: drop-shadow(0 0 10px #00ffff); }
            100% { filter: drop-shadow(0 0 20px #ff00ff); }
        }

        /* Score Display */
        .score {
            position: absolute;
            top: 90px;
            right: 30px;
            font-size: 24px;
            font-weight: bold;
            background: rgba(0, 255, 255, 0.1);
            padding: 15px 25px;
            border-radius: 25px;
            border: 2px solid #00ffff;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 25px rgba(0, 255, 255, 0.3);
            z-index: 10;
        }

        /* Circular Arena with Neon Border */
        #arena {
            width: 75vmin;
            height: 75vmin;
            border-radius: 50%;
            border: 4px solid transparent;
            background: conic-gradient(from 0deg, #1a1a2e, #16213e, #0f3460, #1a1a2e);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            overflow: hidden;
            box-shadow: 
                inset 0 0 50px rgba(0, 0, 0, 0.8),
                0 0 100px rgba(0, 255, 255, 0.3),
                inset 0 0 100px rgba(255, 0, 255, 0.1);
            z-index: 5;
        }

        /* Enhanced Word Styling */
        .word {
            position: absolute;
            top: 0;
            font-size: clamp(20px, 2.5vw, 28px);
            font-weight: bold;
            text-shadow: 0 0 15px currentColor;
            transition: all 0.2s ease;
            cursor: pointer;
            padding: 8px 16px;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 2px solid transparent;
        }

        .word.locked {
            background: linear-gradient(45deg, #00ff88, #00ccff);
            border-color: #00ff88;
            box-shadow: 0 0 30px rgba(0, 255, 136, 0.6);
            transform: scale(1.05);
            animation: pulse 0.5s ease-in-out;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1.05); }
            50% { transform: scale(1.12); }
        }

        .word.destroyed {
            animation: explode 0.6s ease-out forwards;
        }

        @keyframes explode {
            0% { transform: scale(1) rotate(0deg); opacity: 1; }
            50% { transform: scale(1.3) rotate(180deg); opacity: 0.7; }
            100% { transform: scale(0) rotate(360deg); opacity: 0; }
        }

        /* Input Area with Glassmorphism */
        #inputBox {
            position: absolute;
            bottom: 50px;
            width: 100%;
            text-align: center;
            z-index: 10;
        }

        input {
            width: min(90vw, 400px);
            padding: 20px 30px;
            font-size: 20px;
            font-family: inherit;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border: 2px solid rgba(0, 255, 255, 0.5);
            border-radius: 50px;
            color: #fff;
            outline: none;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 8px 32px rgba(0, 255, 255, 0.2);
        }

        input:focus {
            border-color: #ff00ff;
            box-shadow: 
                0 0 40px rgba(255, 0, 255, 0.5),
                0 8px 32px rgba(0, 255, 255, 0.3);
            transform: scale(1.02);
        }

        input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        /* Game Over Screen */
        #over {
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, 0.9);
            backdrop-filter: blur(15px);
            display: none;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            z-index: 20;
        }

        #over h1 {
            font-size: clamp(48px, 8vw, 72px);
            margin-bottom: 30px;
            background: linear-gradient(45deg, #ff006e, #00ff88, #00d4ff);
            background-size: 300% 300%;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradientShift 3s ease infinite;
            text-shadow: 0 0 50px rgba(255, 0, 110, 0.8);
        }

        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        button {
            padding: 18px 50px;
            font-size: 20px;
            font-family: inherit;
            font-weight: bold;
            cursor: pointer;
            background: linear-gradient(45deg, #00ffff, #ff00ff);
            border: none;
            border-radius: 50px;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 2px;
            transition: all 0.3s ease;
            box-shadow: 0 10px 40px rgba(0, 255, 255, 0.4);
        }

        button:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 50px rgba(255, 0, 255, 0.6);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .title { top: 20px; font-size: 24px; }
            .score { 
                top: 70px; 
                right: 20px; 
                font-size: 20px; 
                padding: 12px 20px; 
            }
            #arena { width: 85vmin; height: 85vmin; }
        }
    </style>
</head>

<body>
    <!-- Background Particles -->
    <div class="particles" id="particles"></div>

    <div class="title">WORD STORM</div>
    <div class="score" id="score">SCORE: 0</div>

    <div id="arena"></div>

    <div id="inputBox">
        <input type="text" id="input" placeholder="Type to destroy words..." autofocus>
    </div>

    <div id="over">
        <h1 id="finalScore">GAME OVER</h1>
        <button onclick="location.reload()">RESTART</button>
    </div>

    <script>
        const words = ["cat", "dog", "code", "fast", "document", "fire", "type", "play", "focus", "skill", "mind", "react", "build", "swift", "pixel", "logic"];
        const arena = document.getElementById("arena");
        const input = document.getElementById("input");
        const over = document.getElementById("over");
        const scoreEl = document.getElementById("score");
        const finalScoreEl = document.getElementById("finalScore");
        const particlesEl = document.getElementById("particles");

        let falling = [];
        let locked = null;
        let speed = 1.5;
        let score = 0;
        let gameOver = false;

        // Create animated particles
        function createParticles() {
            for (let i = 0; i < 50; i++) {
                setTimeout(() => {
                    const p = document.createElement("div");
                    p.className = "particle";
                    p.style.left = Math.random() * 100 + "%";
                    p.style.animationDelay = Math.random() * 6 + "s";
                    p.style.animationDuration = (Math.random() * 3 + 4) + "s";
                    particlesEl.appendChild(p);

                    setTimeout(() => p.remove(), 7000);
                }, i * 100);
            }
        }

        // Spawn Words
        function spawnWord() {
            if (gameOver) return;

            const w = document.createElement("div");
            w.className = "word";
            w.innerText = words[Math.floor(Math.random() * words.length)];
            
            const colors = ['#00ffff', '#ff00ff', '#00ff88', '#ffff00', '#ff6600'];
            w.style.color = colors[Math.floor(Math.random() * colors.length)];
            w.style.left = Math.random() * (arena.clientWidth - 120) + "px";
            w.style.top = "-50px";
            
            arena.appendChild(w);
            falling.push(w);
        }

        // Animate falling words
        function fall() {
            if (gameOver) return;

            for (let i = falling.length - 1; i >= 0; i--) {
                const w = falling[i];
                let y = parseInt(w.style.top);
                y += speed;
                w.style.top = y + "px";

                if (y > arena.clientHeight - 50) {
                    gameOver = true;
                    over.style.display = "flex";
                    finalScoreEl.textContent = `FINAL SCORE: ${score}`;
                    input.disabled = true;
                    return;
                }
            }
        }

        // Typing Logic with Visual Feedback
        input.addEventListener("input", () => {
            let t = input.value.toLowerCase();

            if (!locked) {
                for (let w of falling) {
                    if (w.innerText.toLowerCase().startsWith(t)) {
                        locked = w;
                        w.classList.add("locked");
                        break;
                    }
                }
            }

            if (locked) {
                if (!locked.innerText.toLowerCase().startsWith(t)) {
                    input.value = t.slice(0, -1);
                }
                if (t === locked.innerText.toLowerCase()) {
                    locked.classList.add("destroyed");
                    score += Math.floor(100 / speed);
                    scoreEl.textContent = `SCORE: ${score}`;
                    
                    setTimeout(() => {
                        arena.removeChild(locked);
                        falling = falling.filter(x => x !== locked);
                        locked = null;
                        input.value = "";
                        
                        // Reset other words
                        falling.forEach(w => w.classList.remove("locked"));
                    }, 600);
                }
            }
        });

        // Increase difficulty
        setInterval(() => { 
            if (!gameOver) speed += 0.15; 
        }, 5000);

        // Continuous particle generation
        setInterval(createParticles, 3000);
        createParticles();

        // Game loops
        setInterval(spawnWord, 1200);
        setInterval(fall, 30);

        // Prevent backspace navigation
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && input.value) {
                input.value = "";
            }
        });
    </script>
</body>
</html>
