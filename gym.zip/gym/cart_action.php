﻿<?php
session_start();
require 'db.php';

$username = $_SESSION['username'] ?? '';
$user_id  = $_SESSION['user_id'] ?? 0;
$action   = $_POST['action'] ?? '';
$variant  = (int)($_POST['variant_id'] ?? 0);
$qty      = max(1,(int)($_POST['qty'] ?? 1));

// resolve user_id if missing but username exists
if(!$user_id && $username){
    $urow = mysqli_fetch_assoc(mysqli_query($con,"SELECT id FROM user_table WHERE username='".mysqli_real_escape_string($con,$username)."' LIMIT 1"));
    if($urow){ $user_id = (int)$urow['id']; $_SESSION['user_id']=$user_id; }
}

if(!$user_id){ header("Location: login.php?msg=login_required"); exit; }
if(!$variant){ header("Location: products.php?msg=variant_missing"); exit; }

$has_col = function($table,$col) use ($con){
    $db = mysqli_fetch_row(mysqli_query($con,"SELECT DATABASE()"))[0] ?? '';
    $db = mysqli_real_escape_string($con,$db);
    $table = mysqli_real_escape_string($con,$table);
    $col = mysqli_real_escape_string($con,$col);
    $q = mysqli_query($con,"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$db' AND TABLE_NAME='$table' AND COLUMN_NAME='$col' LIMIT 1");
    return $q && mysqli_num_rows($q)>0;
};

$pv = mysqli_fetch_assoc(mysqli_query($con,"SELECT pv.*, pv.product_id, p.product_name, p.image FROM product_variants pv JOIN products_new p ON p.id=pv.product_id WHERE pv.id='$variant'"));
if(!$pv){ header("Location: products.php?msg=variant_missing"); exit; }

$product_id = (int)$pv['product_id'];
$price      = (float)$pv['final_price'];
$total      = $price * $qty;

if($action === 'add'){
    mysqli_query($con,"INSERT INTO cart_items(user_id,product_id,variant_id,qty,created_at) VALUES('$user_id','$product_id','$variant','$qty',NOW())");
    header("Location: product_detail.php?id=$product_id&msg=cartadded"); exit;
}

if($action === 'buy'){
    $modern_orders = $has_col('orders','product_id') && $has_col('orders','variant_id') && $has_col('orders','qty');
    if($modern_orders){
        mysqli_query($con,"INSERT INTO orders(user_id,product_id,variant_id,qty,unit_price,total,payment_method,status,created_at) VALUES('$user_id','$product_id','$variant','$qty','$price','$total','COD','pending',NOW())");
    } else {
        $items_json = json_encode([[
            'name'  => $pv['product_name'],
            'price' => (string)$price,
            'qty'   => (int)$qty,
            'image' => $pv['image'] ?? ''
        ]], JSON_UNESCAPED_UNICODE);
        $items_json = mysqli_real_escape_string($con, $items_json ?: '[]');
        mysqli_query($con,"INSERT INTO orders(user_id,address,total,payment_method,status,items,created_at) VALUES('$user_id',NULL,'$total','COD','pending','$items_json',NOW())");
    }
    header("Location: product_detail.php?id=$product_id&msg=order_placed"); exit;
}

header("Location: product_detail.php?id=$product_id");
exit;
?>
