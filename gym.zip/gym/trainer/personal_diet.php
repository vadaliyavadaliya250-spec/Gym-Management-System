<?php
session_start();
include "../db.php";
include "personal_header.php";

if(isset($_POST['save'])){
    $mid   = (int)$_POST['member_id'];
    $title = mysqli_real_escape_string($con,$_POST['title']);
    $mor   = mysqli_real_escape_string($con,$_POST['morning']);
    $lun   = mysqli_real_escape_string($con,$_POST['lunch']);
    $eve   = mysqli_real_escape_string($con,$_POST['evening']);
    $din   = mysqli_real_escape_string($con,$_POST['dinner']);
    mysqli_query($con,"INSERT INTO diet_plans(trainer_id,member_id,title,morning,lunch,evening,dinner,created_at) VALUES('$tid','$mid','$title','$mor','$lun','$eve','$din',NOW())");
    $success = "Diet plan saved successfully!";
}

$members = mysqli_query($con,"SELECT ud.* FROM user_details ud JOIN assign_trainer a ON ud.id=a.member_id WHERE a.trainer_id='$tid'");
$plans   = mysqli_query($con,"SELECT d.*,ud.username FROM diet_plans d JOIN user_details ud ON d.member_id=ud.id WHERE d.trainer_id='$tid' ORDER BY d.id DESC");
$presel  = isset($_GET['member_id']) ? (int)$_GET['member_id'] : 0;
?>
<div class="ptitle">Create Diet Plan</div>
<?php if(isset($success)): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>

<div class="fcard">
    <div class="fhead">🥗 New Diet Plan</div>
    <div class="fbody">
        <form method="POST">
            <div class="frow">
                <div class="fg">
                    <label>Select Member</label>
                    <select name="member_id" required>
                        <option value="">-- Choose Member --</option>
                        <?php while($m=mysqli_fetch_assoc($members)): ?>
                        <option value="<?php echo $m['id']; ?>" <?php echo $m['id']==$presel?'selected':''; ?>><?php echo htmlspecialchars($m['username'].' ('.$m['fullname'].')'); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="fg">
                    <label>Plan Title</label>
                    <input type="text" name="title" placeholder="e.g. Weight Loss Plan" required>
                </div>
            </div>
            <div class="frow">
                <div class="fg"><label>🌅 Morning</label><textarea name="morning" rows="3" placeholder="Oats, Banana, Boiled Eggs..."></textarea></div>
                <div class="fg"><label>☀ Lunch</label><textarea name="lunch" rows="3" placeholder="Chapati, Dal, Salad..."></textarea></div>
            </div>
            <div class="frow">
                <div class="fg"><label>🌆 Evening</label><textarea name="evening" rows="3" placeholder="Fruits, Protein Shake..."></textarea></div>
                <div class="fg"><label>🌙 Dinner</label><textarea name="dinner" rows="3" placeholder="Light Soup, Chapati..."></textarea></div>
            </div>
            <button type="submit" name="save" class="btn btn-s">💾 Save Plan</button>
        </form>
    </div>
</div>

<div class="twrap">
    <div class="thead">📋 All Diet Plans</div>
    <table>
        <tr><th>#</th><th>Member</th><th>Title</th><th>Morning</th><th>Lunch</th><th>Evening</th><th>Dinner</th><th>Created</th><th>Action</th></tr>
        <?php $i=1; if(mysqli_num_rows($plans)>0): while($p=mysqli_fetch_assoc($plans)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($p['username']); ?></td>
            <td><?php echo htmlspecialchars($p['title']); ?></td>
            <td><?php echo htmlspecialchars(substr($p['morning'],0,20)); ?>...</td>
            <td><?php echo htmlspecialchars(substr($p['lunch'],0,20)); ?>...</td>
            <td><?php echo htmlspecialchars(substr($p['evening'],0,20)); ?>...</td>
            <td><?php echo htmlspecialchars(substr($p['dinner'],0,20)); ?>...</td>
            <td><?php echo date('d M Y',strtotime($p['created_at'])); ?></td>
            <td>
                <a href="personal_diet_edit.php?id=<?php echo $p['id']; ?>" class="btn btn-w">Edit</a>
                <a href="personal_diet_delete.php?id=<?php echo $p['id']; ?>" class="btn btn-d" onclick="return confirm('Delete this plan?')">Del</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="9" style="text-align:center;color:#888;padding:20px;">No diet plans yet.</td></tr>
        <?php endif; ?>
    </table>
</div>
</div></body></html>
