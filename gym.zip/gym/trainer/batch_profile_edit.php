<?php
session_start();
include "../db.php";
include "batch_header.php";

$q = mysqli_query($con,"SELECT * FROM trainers WHERE id='$tid'");
$d = mysqli_fetch_assoc($q);

if(isset($_POST['update'])){
    $name  = mysqli_real_escape_string($con,$_POST['name']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $phone = mysqli_real_escape_string($con,$_POST['phone']);
    $spec  = mysqli_real_escape_string($con,$_POST['specialization']);
    $exp   = (int)$_POST['experience'];
    $addr  = mysqli_real_escape_string($con,$_POST['address']);
    mysqli_query($con,"UPDATE trainers SET name='$name',email='$email',phone='$phone',specialization='$spec',experience='$exp',address='$addr' WHERE id='$tid'");
    $_SESSION['trainer_name'] = $name;
    $success = "Profile updated successfully!";
    $q = mysqli_query($con,"SELECT * FROM trainers WHERE id='$tid'");
    $d = mysqli_fetch_assoc($q);
}
?>
<div class="ptitle">Edit Profile</div>
<?php if(isset($success)): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<div class="fcard" style="max-width:640px;">
    <div class="fhead">✏ Update Profile</div>
    <div class="fbody">
        <form method="POST">
            <div class="frow">
                <div class="fg"><label>Full Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($d['name']); ?>" required></div>
                <div class="fg"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($d['email']); ?>" required></div>
            </div>
            <div class="frow">
                <div class="fg"><label>Phone</label><input type="text" name="phone" value="<?php echo htmlspecialchars($d['phone']); ?>"></div>
                <div class="fg"><label>Specialization</label><input type="text" name="specialization" value="<?php echo htmlspecialchars($d['specialization']); ?>"></div>
            </div>
            <div class="frow">
                <div class="fg"><label>Experience (years)</label><input type="number" name="experience" value="<?php echo $d['experience']; ?>" min="0"></div>
                <div class="fg"><label>Address</label><input type="text" name="address" value="<?php echo htmlspecialchars($d['address']); ?>"></div>
            </div>
            <button type="submit" name="update" class="btn btn-s">💾 Save</button>
            <a href="batch_profile.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
        </form>
    </div>
</div>
</div></body></html>
