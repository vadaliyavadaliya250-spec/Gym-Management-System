<?php
session_start();
include "../db.php";
include "batch_header.php";

$date = isset($_GET['date']) ? $_GET['date'] : '';

if($date != ''){
    $q = mysqli_query($con,"SELECT ta.*,b.batch_name FROM trainer_attendance ta LEFT JOIN batches b ON ta.batch_id=b.id WHERE ta.trainer_id='$tid' AND ta.date='$date' ORDER BY ta.date DESC");
} else {
    $q = mysqli_query($con,"SELECT ta.*,b.batch_name FROM trainer_attendance ta LEFT JOIN batches b ON ta.batch_id=b.id WHERE ta.trainer_id='$tid' ORDER BY ta.date DESC");
}

$qp = mysqli_query($con,"SELECT COUNT(*) as c FROM trainer_attendance WHERE trainer_id='$tid' AND status='Present'");
$present = mysqli_fetch_assoc($qp)['c'];
$qa = mysqli_query($con,"SELECT COUNT(*) as c FROM trainer_attendance WHERE trainer_id='$tid' AND status='Absent'");
$absent  = mysqli_fetch_assoc($qa)['c'];
$total   = $present + $absent;
$pct     = $total > 0 ? round(($present/$total)*100) : 0;
?>
<div class="ptitle">Attendance</div>

<div class="crow">
    <div class="sc g"><div class="n"><?php echo $present; ?></div><div class="l">✅ Present</div></div>
    <div class="sc r"><div class="n"><?php echo $absent; ?></div><div class="l">❌ Absent</div></div>
    <div class="sc"><div class="n"><?php echo $total; ?></div><div class="l">📅 Total Days</div></div>
    <div class="sc o"><div class="n"><?php echo $pct; ?>%</div><div class="l">📊 Rate</div></div>
</div>

<div style="background:#fff;border-radius:10px;padding:14px 18px;margin-bottom:18px;box-shadow:0 2px 10px rgba(0,0,0,0.07);">
    <div style="display:flex;justify-content:space-between;font-size:13px;font-weight:600;color:#333;margin-bottom:6px;">
        <span>Attendance Rate</span>
        <span style="color:<?php echo $pct>=75?'#27ae60':($pct>=50?'#e67e22':'#e74c3c'); ?>"><?php echo $pct; ?>%</span>
    </div>
    <div style="background:#e0e0e0;border-radius:20px;height:8px;">
        <div style="width:<?php echo $pct; ?>%;background:<?php echo $pct>=75?'#27ae60':($pct>=50?'#e67e22':'#e74c3c'); ?>;height:8px;border-radius:20px;"></div>
    </div>
</div>

<div style="margin-bottom:16px;display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;">
    <form method="GET" style="display:flex;gap:10px;align-items:flex-end;">
        <div>
            <label style="display:block;font-size:12px;font-weight:600;color:#555;margin-bottom:4px;">Filter by Date</label>
            <input type="date" name="date" value="<?php echo $date; ?>" style="padding:8px 12px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;outline:none;">
        </div>
        <button type="submit" class="btn btn-dk">Filter</button>
        <?php if($date): ?><a href="batch_attendance.php" class="btn btn-d">Clear</a><?php endif; ?>
    </form>
</div>

<div class="twrap">
    <div class="thead">📅 Attendance Records (Marked by Admin)</div>
    <table>
        <tr><th>#</th><th>Date</th><th>Batch</th><th>Type</th><th>Status</th></tr>
        <?php $i=1; if(mysqli_num_rows($q)>0): while($r=mysqli_fetch_assoc($q)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo date('d M Y',strtotime($r['date'])); ?></td>
            <td><?php echo $r['batch_name'] ? htmlspecialchars($r['batch_name']) : '-'; ?></td>
            <td><span class="bx bx-i"><?php echo ucfirst($r['entity_type']); ?></span></td>
            <td><span class="bx <?php echo strtolower($r['status'])=='present'?'bx-s':'bx-d'; ?>"><?php echo $r['status']; ?></span></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="5" style="text-align:center;color:#888;padding:22px;">No attendance records found.</td></tr>
        <?php endif; ?>
    </table>
</div>
</div></body></html>
