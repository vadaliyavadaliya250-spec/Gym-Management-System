<?php
// batch_header.php — included ONLY in batch trainer pages
// Every page that includes this must have session_start() BEFORE including this file

if(!isset($_SESSION['trainer_id']) || $_SESSION['trainer_type'] != 'batch'){
    header("Location: trainer_login.php");
    exit();
}
$tid   = $_SESSION['trainer_id'];
$tname = $_SESSION['trainer_name'];
$cur   = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Trainer Panel</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;}
/* HEADER */
.hdr{position:fixed;top:0;left:0;right:0;height:58px;background:#1a1a2e;display:flex;align-items:center;justify-content:space-between;padding:0 22px;z-index:1000;box-shadow:0 2px 8px rgba(0,0,0,0.35);}
.hdr .brand{font-size:19px;font-weight:800;color:#e74c3c;letter-spacing:1px;}.hdr .brand span{color:#fff;}
.hdr .right{display:flex;align-items:center;gap:14px;}
.hdr .wname{font-size:13px;color:rgba(255,255,255,0.7);}.hdr .wname b{color:#fff;}
.btag{background:#2980b9;color:#fff;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700;text-transform:uppercase;}
.logout-btn{background:#e74c3c;color:#fff;padding:6px 14px;border-radius:6px;text-decoration:none;font-size:13px;font-weight:600;}
.logout-btn:hover{background:#c0392b;}
/* SIDEBAR */
.sdb{position:fixed;top:58px;left:0;width:215px;height:calc(100vh - 58px);background:#16213e;overflow-y:auto;z-index:900;}
.sdb-top{padding:20px 16px 14px;border-bottom:1px solid rgba(255,255,255,0.07);text-align:center;}
.sdb-av{width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,#2980b9,#1a6fa0);display:inline-flex;align-items:center;justify-content:center;font-size:20px;margin-bottom:7px;}
.sdb-top h4{color:#fff;font-size:13px;margin-bottom:2px;}
.sdb-top p{color:rgba(255,255,255,0.38);font-size:11px;}
.sdb-sec{padding:14px 16px 4px;color:rgba(255,255,255,0.28);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;}
.sdb a{display:flex;align-items:center;gap:10px;color:rgba(255,255,255,0.62);padding:11px 18px;text-decoration:none;font-size:14px;border-left:3px solid transparent;transition:all 0.2s;}
.sdb a:hover,.sdb a.on{background:rgba(255,255,255,0.07);color:#fff;border-left-color:#2980b9;}
.sdb a .i{font-size:15px;width:18px;text-align:center;}
/* CONTENT */
.wrap{margin-left:215px;margin-top:58px;padding:26px;min-height:calc(100vh - 58px);}
/* COMMON UI */
.ptitle{font-size:20px;font-weight:700;color:#1a1a2e;margin-bottom:18px;padding-bottom:8px;border-bottom:2px solid #2980b9;display:inline-block;}
.crow{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:22px;}
.sc{background:#fff;border-radius:10px;padding:18px 22px;flex:1;min-width:140px;box-shadow:0 2px 10px rgba(0,0,0,0.07);border-left:4px solid #2980b9;transition:transform 0.2s;}.sc:hover{transform:translateY(-2px);}
.sc .n{font-size:26px;font-weight:800;color:#1a1a2e;}.sc .l{color:#888;font-size:12px;margin-top:3px;}
.sc.g{border-left-color:#27ae60;}.sc.r{border-left-color:#e74c3c;}.sc.o{border-left-color:#e67e22;}
.twrap{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.07);overflow:hidden;margin-bottom:20px;}
.thead{background:#1a1a2e;color:#fff;padding:13px 18px;font-size:14px;font-weight:600;}
table{width:100%;border-collapse:collapse;}
th{background:#f8f9fa;padding:10px 13px;text-align:left;font-size:12px;color:#555;font-weight:600;border-bottom:2px solid #eee;}
td{padding:10px 13px;font-size:13px;color:#333;border-bottom:1px solid #f0f0f0;}
tr:last-child td{border-bottom:none;}tr:hover td{background:#fafafa;}
.fcard{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.07);overflow:hidden;margin-bottom:20px;}
.fhead{background:#1a1a2e;color:#fff;padding:13px 18px;font-size:14px;font-weight:600;}
.fbody{padding:20px 18px;}
.frow{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:14px;}
.fg{flex:1;min-width:190px;}
.fg label{display:block;font-size:12px;color:#555;font-weight:600;margin-bottom:5px;}
.fg input,.fg select,.fg textarea{width:100%;padding:9px 12px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;color:#333;outline:none;transition:border 0.2s;font-family:inherit;background:#fff;}
.fg input:focus,.fg select:focus,.fg textarea:focus{border-color:#2980b9;}
.btn{padding:8px 16px;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block;border:none;transition:opacity 0.2s;}
.btn:hover{opacity:0.85;}.btn-p{background:#2980b9;color:#fff;}.btn-s{background:#27ae60;color:#fff;}.btn-w{background:#e67e22;color:#fff;}.btn-d{background:#e74c3c;color:#fff;}.btn-dk{background:#1a1a2e;color:#fff;}
.al{padding:10px 15px;border-radius:7px;margin-bottom:14px;font-size:13px;font-weight:500;}
.al-s{background:#d4edda;color:#155724;border:1px solid #c3e6cb;}.al-d{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;}.al-i{background:#d1ecf1;color:#0c5460;border:1px solid #bee5eb;}
.bx{padding:3px 9px;border-radius:10px;font-size:11px;font-weight:600;}
.bx-s{background:#d4edda;color:#155724;}.bx-d{background:#f8d7da;color:#721c24;}.bx-i{background:#d1ecf1;color:#0c5460;}.bx-w{background:#fff3cd;color:#856404;}
</style>
</head>
<body>
<div class="hdr">
    <div class="brand">GYM<span>Pro</span></div>
    <div class="right">
        <span class="wname">Welcome, <b><?php echo htmlspecialchars($tname); ?></b></span>
        <span class="btag">Batch Trainer</span>
        <a href="trainer_logout.php" class="logout-btn">Logout</a>
    </div>
</div>
<div class="sdb">
    <div class="sdb-top">
        <div class="sdb-av">🏋</div>
        <h4><?php echo htmlspecialchars($tname); ?></h4>
        <p>Batch Trainer</p>
    </div>
    <div class="sdb-sec">Menu</div>
    <a href="batch_dashboard.php"    class="<?php echo $cur=='batch_dashboard.php'?'on':''; ?>"><span class="i">🏠</span> Dashboard</a>
    <a href="batch_batches.php"      class="<?php echo in_array($cur,['batch_batches.php','batch_members_view.php','batch_update_time.php'])?'on':''; ?>"><span class="i">📋</span> Batch</a>
    <a href="batch_attendance.php"   class="<?php echo $cur=='batch_attendance.php'?'on':''; ?>"><span class="i">📅</span> Attendance</a>
    <a href="batch_profile.php"      class="<?php echo in_array($cur,['batch_profile.php','batch_profile_edit.php'])?'on':''; ?>"><span class="i">👤</span> Profile</a>
</div>
<div class="wrap">
