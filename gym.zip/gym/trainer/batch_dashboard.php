<?php
session_start();
include "../db.php";
include "batch_header.php";

$q1 = mysqli_query($con,"SELECT COUNT(*) as c FROM batches WHERE trainer_id='$tid'");
$bc  = mysqli_fetch_assoc($q1)['c'];
$q2  = mysqli_query($con,"SELECT COUNT(*) as c FROM batch_members bm JOIN batches b ON bm.batch_id=b.id WHERE b.trainer_id='$tid'");
$mc  = mysqli_fetch_assoc($q2)['c'];
$today = date('Y-m-d');
$q3  = mysqli_query($con,"SELECT status FROM trainer_attendance WHERE trainer_id='$tid' AND date='$today' LIMIT 1");
$att = mysqli_num_rows($q3)>0 ? mysqli_fetch_assoc($q3)['status'] : 'Not Marked';

$batches = mysqli_query($con,"SELECT * FROM batches WHERE trainer_id='$tid' ORDER BY created_at DESC");
?>
<div class="ptitle">Dashboard</div>

<div class="crow">
    <div class="sc"><div class="n"><?php echo $bc; ?></div><div class="l">📋 My Batches</div></div>
    <div class="sc g"><div class="n"><?php echo $mc; ?></div><div class="l">👥 Total Members</div></div>
    <div class="sc"><div class="n"><?php echo $att; ?></div><div class="l">📅 Today's Status</div></div>
</div>

<div class="crow">
    <a href="batch_batches.php" style="text-decoration:none;flex:1;min-width:130px;">
        <div class="sc" style="text-align:center;cursor:pointer;"><div style="font-size:28px;">📋</div><div style="font-weight:700;font-size:13px;margin-top:6px;color:#1a1a2e;">Batch</div><div style="font-size:11px;color:#888;margin-top:2px;">View, members & time</div></div>
    </a>
    <a href="batch_attendance.php" style="text-decoration:none;flex:1;min-width:130px;">
        <div class="sc g" style="text-align:center;cursor:pointer;"><div style="font-size:28px;">📅</div><div style="font-weight:700;font-size:13px;margin-top:6px;color:#1a1a2e;">Attendance</div><div style="font-size:11px;color:#888;margin-top:2px;">Check your attendance</div></div>
    </a>
    <a href="batch_profile.php" style="text-decoration:none;flex:1;min-width:130px;">
        <div class="sc o" style="text-align:center;cursor:pointer;"><div style="font-size:28px;">👤</div><div style="font-weight:700;font-size:13px;margin-top:6px;color:#1a1a2e;">Profile</div><div style="font-size:11px;color:#888;margin-top:2px;">View & edit profile</div></div>
    </a>
</div>

<div class="twrap">
    <div class="thead">📋 My Batches Overview</div>
    <table>
        <tr><th>#</th><th>Batch Name</th><th>Start Time</th><th>End Time</th><th>Capacity</th><th>Status</th><th>Action</th></tr>
        <?php $i=1; if(mysqli_num_rows($batches)>0): while($r=mysqli_fetch_assoc($batches)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['batch_name']); ?></td>
            <td><?php echo date('h:i A',strtotime($r['start_time'])); ?></td>
            <td><?php echo date('h:i A',strtotime($r['end_time'])); ?></td>
            <td><?php echo $r['capacity']; ?></td>
            <td><span class="bx <?php echo $r['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($r['status']); ?></span></td>
            <td>
                <a href="batch_members_view.php?batch_id=<?php echo $r['id']; ?>" class="btn btn-p">👥 Members</a>
                <a href="batch_update_time.php?batch_id=<?php echo $r['id']; ?>" class="btn btn-w">⏰ Time</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="7" style="text-align:center;color:#888;padding:20px;">No batches assigned yet.</td></tr>
        <?php endif; ?>
    </table>
</div>
</div></body></html>
