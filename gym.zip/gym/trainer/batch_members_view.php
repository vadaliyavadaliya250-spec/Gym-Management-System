<?php
session_start();
include "../db.php";
include "batch_header.php";

$batch_filter = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : 0;

// Get this trainer's batches for dropdown
$my_batches_q = mysqli_query($con,"SELECT * FROM batches WHERE trainer_id='$tid'");
$my_batches   = [];
while($b = mysqli_fetch_assoc($my_batches_q)) $my_batches[] = $b;

if($batch_filter > 0){
    $q = mysqli_query($con,"
        SELECT ud.*, b.batch_name, COALESCE(bm.joined_at, ud.updated_at) AS joined_at
        FROM user_details ud
        JOIN batches b ON ud.batch_id = b.id
        LEFT JOIN batch_members bm ON bm.member_id = ud.id AND bm.batch_id = b.id
        WHERE b.trainer_id='$tid' AND ud.batch_id='$batch_filter'
        ORDER BY joined_at DESC
    ");
} else {
    $q = mysqli_query($con,"
        SELECT ud.*, b.batch_name, COALESCE(bm.joined_at, ud.updated_at) AS joined_at
        FROM user_details ud
        JOIN batches b ON ud.batch_id = b.id
        LEFT JOIN batch_members bm ON bm.member_id = ud.id AND bm.batch_id = b.id
        WHERE b.trainer_id='$tid'
        ORDER BY b.batch_name, joined_at DESC
    ");
}
?>
<div class="ptitle">Batch Members</div>

<div style="margin-bottom:16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
    <form method="GET" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <div>
            <label style="display:block;font-size:12px;font-weight:600;color:#555;margin-bottom:4px;">Filter by Batch</label>
            <select name="batch_id" onchange="this.form.submit()" style="padding:8px 12px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;outline:none;background:#fff;">
                <option value="0">All Batches</option>
                <?php foreach($my_batches as $b): ?>
                <option value="<?php echo $b['id']; ?>" <?php echo $b['id']==$batch_filter?'selected':''; ?>><?php echo htmlspecialchars($b['batch_name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if($batch_filter): ?><a href="batch_members_view.php" class="btn btn-d" style="margin-top:18px;">Clear</a><?php endif; ?>
    </form>
    <a href="batch_batches.php" class="btn btn-dk" style="margin-top:18px;">← Back to Batches</a>
</div>

<div class="twrap">
    <div class="thead">👥 Members in Your Batches</div>
    <table>
        <tr><th>#</th><th>Username</th><th>Full Name</th><th>Batch</th><th>Age</th><th>Gender</th><th>Height</th><th>Weight</th><th>Joined On</th></tr>
        <?php $i=1; if(mysqli_num_rows($q)>0): while($r=mysqli_fetch_assoc($q)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['username']); ?></td>
            <td><?php echo htmlspecialchars($r['fullname']); ?></td>
            <td><span class="bx bx-i"><?php echo htmlspecialchars($r['batch_name']); ?></span></td>
            <td><?php echo $r['age']; ?></td>
            <td><?php echo $r['gender']; ?></td>
            <td><?php echo $r['height'] ? $r['height'].' ft' : '-'; ?></td>
            <td><?php echo $r['weight'] ? $r['weight'].' kg' : '-'; ?></td>
            <td><?php echo date('d M Y',strtotime($r['joined_at'])); ?></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="9" style="text-align:center;color:#888;padding:22px;">No members found in your batches.</td></tr>
        <?php endif; ?>
    </table>
</div>
</div></body></html>
