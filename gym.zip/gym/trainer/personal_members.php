<?php
session_start();
include "../db.php";
include "personal_header.php";

$q = mysqli_query($con,"SELECT ud.*,at.assigned_at FROM user_details ud JOIN assign_trainer at ON ud.id=at.member_id WHERE at.trainer_id='$tid' ORDER BY at.assigned_at DESC");
?>
<div class="ptitle">My Members</div>
<div class="twrap">
    <div class="thead">👥 All Assigned Members</div>
    <table>
        <tr><th>#</th><th>Username</th><th>Full Name</th><th>Age</th><th>Gender</th><th>Height</th><th>Weight</th><th>Medical</th><th>Assigned On</th><th>Action</th></tr>
        <?php $i=1; if(mysqli_num_rows($q)>0): while($r=mysqli_fetch_assoc($q)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['username']); ?></td>
            <td><?php echo htmlspecialchars($r['fullname']); ?></td>
            <td><?php echo $r['age']; ?></td>
            <td><?php echo $r['gender']; ?></td>
            <td><?php echo $r['height'] ? $r['height'].' ft' : '-'; ?></td>
            <td><?php echo $r['weight'] ? $r['weight'].' kg' : '-'; ?></td>
            <td><?php echo $r['medical'] ? htmlspecialchars($r['medical']) : '-'; ?></td>
            <td><?php echo date('d M Y',strtotime($r['assigned_at'])); ?></td>
            <td><a href="personal_diet.php?member_id=<?php echo $r['id']; ?>" class="btn btn-s">🥗 Diet Plan</a></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="10" style="text-align:center;color:#888;padding:22px;">No members assigned yet.</td></tr>
        <?php endif; ?>
    </table>
</div>
</div></body></html>
