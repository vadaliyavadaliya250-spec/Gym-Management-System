<?php
session_start();
include "../db.php";
include "personal_header.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$q  = mysqli_query($con,"SELECT * FROM diet_plans WHERE id='$id' AND trainer_id='$tid'");
$d  = mysqli_fetch_assoc($q);

if(!$d){
    echo "<div class='al al-d'>Diet plan not found. <a href='personal_diet.php'>Go back</a></div>";
    echo "</div></body></html>"; exit();
}

if(isset($_POST['update'])){
    $title = mysqli_real_escape_string($con,$_POST['title']);
    $mor   = mysqli_real_escape_string($con,$_POST['morning']);
    $lun   = mysqli_real_escape_string($con,$_POST['lunch']);
    $eve   = mysqli_real_escape_string($con,$_POST['evening']);
    $din   = mysqli_real_escape_string($con,$_POST['dinner']);
    mysqli_query($con,"UPDATE diet_plans SET title='$title',morning='$mor',lunch='$lun',evening='$eve',dinner='$din' WHERE id='$id' AND trainer_id='$tid'");
    $success = "Diet plan updated!";
    $q = mysqli_query($con,"SELECT * FROM diet_plans WHERE id='$id'");
    $d = mysqli_fetch_assoc($q);
}
?>
<div class="ptitle">Edit Diet Plan</div>
<?php if(isset($success)): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>

<div class="fcard" style="max-width:700px;">
    <div class="fhead">🥗 Edit Diet Plan</div>
    <div class="fbody">
        <form method="POST">
            <div class="fg" style="margin-bottom:14px;">
                <label>Plan Title</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($d['title']); ?>" required>
            </div>
            <div class="frow">
                <div class="fg"><label>🌅 Morning</label><textarea name="morning" rows="3"><?php echo htmlspecialchars($d['morning']); ?></textarea></div>
                <div class="fg"><label>☀ Lunch</label><textarea name="lunch" rows="3"><?php echo htmlspecialchars($d['lunch']); ?></textarea></div>
            </div>
            <div class="frow">
                <div class="fg"><label>🌆 Evening</label><textarea name="evening" rows="3"><?php echo htmlspecialchars($d['evening']); ?></textarea></div>
                <div class="fg"><label>🌙 Dinner</label><textarea name="dinner" rows="3"><?php echo htmlspecialchars($d['dinner']); ?></textarea></div>
            </div>
            <button type="submit" name="update" class="btn btn-s">💾 Update</button>
            <a href="personal_diet.php" class="btn btn-dk" style="margin-left:10px;">← Back</a>
        </form>
    </div>
</div>
</div></body></html>
