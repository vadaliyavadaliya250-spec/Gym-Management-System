<?php
session_start();
include "../db.php";
include "personal_header.php";

$q1 = mysqli_query($con,"SELECT COUNT(*) as c FROM assign_trainer WHERE trainer_id='$tid'");
$mc = mysqli_fetch_assoc($q1)['c'];
$q2 = mysqli_query($con,"SELECT COUNT(*) as c FROM diet_plans WHERE trainer_id='$tid'");
$dc = mysqli_fetch_assoc($q2)['c'];
$today = date('Y-m-d');
$q3 = mysqli_query($con,"SELECT status FROM trainer_attendance WHERE trainer_id='$tid' AND date='$today' LIMIT 1");
$att = mysqli_num_rows($q3) > 0 ? mysqli_fetch_assoc($q3)['status'] : 'Not Marked';

$recent = mysqli_query($con,"SELECT ud.username,ud.fullname,ud.age,ud.gender,at.assigned_at FROM user_details ud JOIN assign_trainer at ON ud.id=at.member_id WHERE at.trainer_id='$tid' ORDER BY at.assigned_at DESC LIMIT 5");
?>
<div class="ptitle">Dashboard</div>

<div class="crow">
    <div class="sc"><div class="n"><?php echo $mc; ?></div><div class="l">👥 My Members</div></div>
    <div class="sc g"><div class="n"><?php echo $dc; ?></div><div class="l">🥗 Diet Plans Created</div></div>
    <div class="sc b"><div class="n"><?php echo $att; ?></div><div class="l">📅 Today's Status</div></div>
</div>

<div class="crow">
    <a href="personal_members.php" style="text-decoration:none;flex:1;min-width:130px;">
        <div class="sc" style="text-align:center;cursor:pointer;"><div style="font-size:28px;">👥</div><div style="font-weight:700;font-size:13px;margin-top:6px;color:#1a1a2e;">My Members</div></div>
    </a>
    <a href="personal_diet.php" style="text-decoration:none;flex:1;min-width:130px;">
        <div class="sc g" style="text-align:center;cursor:pointer;"><div style="font-size:28px;">🥗</div><div style="font-weight:700;font-size:13px;margin-top:6px;color:#1a1a2e;">Create Diet Plan</div></div>
    </a>
    <a href="personal_attendance.php" style="text-decoration:none;flex:1;min-width:130px;">
        <div class="sc b" style="text-align:center;cursor:pointer;"><div style="font-size:28px;">📅</div><div style="font-weight:700;font-size:13px;margin-top:6px;color:#1a1a2e;">Attendance</div></div>
    </a>
    <a href="personal_profile.php" style="text-decoration:none;flex:1;min-width:130px;">
        <div class="sc o" style="text-align:center;cursor:pointer;"><div style="font-size:28px;">👤</div><div style="font-weight:700;font-size:13px;margin-top:6px;color:#1a1a2e;">Profile</div></div>
    </a>
</div>

<div class="twrap">
    <div class="thead">👥 Recently Assigned Members</div>
    <table>
        <tr><th>#</th><th>Username</th><th>Full Name</th><th>Age</th><th>Gender</th><th>Assigned On</th><th>Action</th></tr>
        <?php $i=1; if(mysqli_num_rows($recent)>0): while($r=mysqli_fetch_assoc($recent)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['username']); ?></td>
            <td><?php echo htmlspecialchars($r['fullname']); ?></td>
            <td><?php echo $r['age']; ?></td>
            <td><?php echo $r['gender']; ?></td>
            <td><?php echo date('d M Y',strtotime($r['assigned_at'])); ?></td>
            <td><a href="personal_diet.php" class="btn btn-s">+ Diet Plan</a></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="7" style="text-align:center;color:#888;padding:20px;">No members assigned yet.</td></tr>
        <?php endif; ?>
    </table>
</div>
</div></body></html>
