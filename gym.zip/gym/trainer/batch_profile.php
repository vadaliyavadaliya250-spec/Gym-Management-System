<?php
session_start();
include "../db.php";
include "batch_header.php";

$q  = mysqli_query($con,"SELECT * FROM trainers WHERE id='$tid'");
$d  = mysqli_fetch_assoc($q);
$qp = mysqli_query($con,"SELECT COUNT(*) as c FROM trainer_attendance WHERE trainer_id='$tid' AND status='Present'");
$present = mysqli_fetch_assoc($qp)['c'];
$qa = mysqli_query($con,"SELECT COUNT(*) as c FROM trainer_attendance WHERE trainer_id='$tid' AND status='Absent'");
$absent  = mysqli_fetch_assoc($qa)['c'];
$total   = $present+$absent;
$pct     = $total>0?round(($present/$total)*100):0;
$bq      = mysqli_query($con,"SELECT b.*,(SELECT COUNT(*) FROM batch_members WHERE batch_id=b.id) as member_count FROM batches b WHERE b.trainer_id='$tid'");
$qbc     = mysqli_query($con,"SELECT COUNT(*) as c FROM batches WHERE trainer_id='$tid'");
$bc      = mysqli_fetch_assoc($qbc)['c'];
$qmc     = mysqli_query($con,"SELECT COUNT(*) as c FROM batch_members bm JOIN batches b ON bm.batch_id=b.id WHERE b.trainer_id='$tid'");
$mc      = mysqli_fetch_assoc($qmc)['c'];
?>
<div class="ptitle">Profile</div>
<div style="display:flex;gap:20px;flex-wrap:wrap;align-items:flex-start;">
    <!-- LEFT -->
    <div style="background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);overflow:hidden;min-width:250px;flex:1;max-width:320px;">
        <div style="background:linear-gradient(135deg,#1a1a2e,#16213e);padding:28px 20px;text-align:center;">
            <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,#2980b9,#1a6fa0);display:inline-flex;align-items:center;justify-content:center;font-size:26px;margin-bottom:10px;">🏋</div>
            <h3 style="color:#fff;font-size:17px;margin-bottom:6px;"><?php echo htmlspecialchars($d['name']); ?></h3>
            <span style="background:#2980b9;color:#fff;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;">BATCH TRAINER</span>
        </div>
        <div style="padding:18px;">
            <?php foreach([['Email','📧',$d['email']],['Phone','📞',$d['phone']],['Gender','',$d['gender']],['Specialization','🎯',$d['specialization']],['Experience','⭐',$d['experience'].' years'],['Address','📍',$d['address']]] as $f): ?>
            <div style="margin-bottom:11px;padding-bottom:11px;border-bottom:1px solid #f0f0f0;">
                <div style="font-size:10px;color:#aaa;text-transform:uppercase;margin-bottom:2px;"><?php echo $f[0]; ?></div>
                <div style="font-size:13px;font-weight:500;color:#333;"><?php echo $f[1].' '.htmlspecialchars($f[2]); ?></div>
            </div>
            <?php endforeach; ?>
            <a href="batch_profile_edit.php" class="btn btn-p" style="width:100%;text-align:center;padding:10px;margin-top:4px;">✏ Edit Profile</a>
        </div>
    </div>
    <!-- RIGHT -->
    <div style="flex:2;min-width:250px;">
        <!-- Attendance -->
        <div style="background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);padding:18px;margin-bottom:18px;">
            <div style="font-size:14px;font-weight:700;color:#1a1a2e;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #2980b9;display:inline-block;">📊 Attendance Summary</div>
            <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
                <div style="flex:1;min-width:80px;background:#d4edda;border-radius:8px;padding:14px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#155724;"><?php echo $present; ?></div><div style="font-size:11px;color:#155724;">Present</div></div>
                <div style="flex:1;min-width:80px;background:#f8d7da;border-radius:8px;padding:14px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#721c24;"><?php echo $absent; ?></div><div style="font-size:11px;color:#721c24;">Absent</div></div>
                <div style="flex:1;min-width:80px;background:#d1ecf1;border-radius:8px;padding:14px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#0c5460;"><?php echo $pct; ?>%</div><div style="font-size:11px;color:#0c5460;">Rate</div></div>
            </div>
            <div style="background:#e0e0e0;border-radius:20px;height:7px;"><div style="width:<?php echo $pct; ?>%;background:<?php echo $pct>=75?'#27ae60':($pct>=50?'#e67e22':'#e74c3c'); ?>;height:7px;border-radius:20px;"></div></div>
        </div>
        <!-- Batch Summary -->
        <div style="background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);padding:18px;margin-bottom:18px;">
            <div style="font-size:14px;font-weight:700;color:#1a1a2e;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #2980b9;display:inline-block;">📋 Batch Summary</div>
            <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:14px;">
                <div style="flex:1;min-width:100px;background:linear-gradient(135deg,#2980b9,#1a6fa0);border-radius:8px;padding:14px;text-align:center;"><div style="font-size:24px;font-weight:800;color:#fff;"><?php echo $bc; ?></div><div style="font-size:11px;color:rgba(255,255,255,0.8);">Batches</div></div>
                <div style="flex:1;min-width:100px;background:linear-gradient(135deg,#27ae60,#1e8449);border-radius:8px;padding:14px;text-align:center;"><div style="font-size:24px;font-weight:800;color:#fff;"><?php echo $mc; ?></div><div style="font-size:11px;color:rgba(255,255,255,0.8);">Total Members</div></div>
            </div>
            <table style="width:100%;border-collapse:collapse;">
                <tr style="background:#f8f9fa;"><th style="padding:8px 12px;text-align:left;font-size:12px;color:#555;border-bottom:2px solid #eee;">Batch</th><th style="padding:8px 12px;text-align:left;font-size:12px;color:#555;border-bottom:2px solid #eee;">Time</th><th style="padding:8px 12px;text-align:left;font-size:12px;color:#555;border-bottom:2px solid #eee;">Members</th><th style="padding:8px 12px;text-align:left;font-size:12px;color:#555;border-bottom:2px solid #eee;">Status</th></tr>
                <?php while($b=mysqli_fetch_assoc($bq)): ?>
                <tr>
                    <td style="padding:8px 12px;font-size:13px;border-bottom:1px solid #f0f0f0;"><?php echo htmlspecialchars($b['batch_name']); ?></td>
                    <td style="padding:8px 12px;font-size:13px;border-bottom:1px solid #f0f0f0;"><?php echo date('h:i A',strtotime($b['start_time'])); ?> – <?php echo date('h:i A',strtotime($b['end_time'])); ?></td>
                    <td style="padding:8px 12px;font-size:13px;border-bottom:1px solid #f0f0f0;"><?php echo $b['member_count']; ?></td>
                    <td style="padding:8px 12px;font-size:13px;border-bottom:1px solid #f0f0f0;"><span class="bx <?php echo $b['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($b['status']); ?></span></td>
                </tr>
                <?php endwhile; ?>
            </table>
            <a href="batch_update_time.php" class="btn btn-w" style="margin-top:12px;">⏰ Change Batch Time</a>
        </div>
    </div>
</div>
</div></body></html>
