<?php
session_start();
include "../db.php";
if(!isset($_SESSION['trainer_id'])){ header("Location: trainer_login.php"); exit(); }
$tid = $_SESSION['trainer_id'];
$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
mysqli_query($con,"DELETE FROM diet_plans WHERE id='$id' AND trainer_id='$tid'");
header("Location: personal_diet.php");
exit();
