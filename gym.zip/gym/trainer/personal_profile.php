<?php
session_start();
include "../db.php";
include "personal_header.php";

$q  = mysqli_query($con,"SELECT * FROM trainers WHERE id='$tid'");
$d  = mysqli_fetch_assoc($q);
$qp = mysqli_query($con,"SELECT COUNT(*) as c FROM trainer_attendance WHERE trainer_id='$tid' AND status='Present'");
$present = mysqli_fetch_assoc($qp)['c'];
$qa = mysqli_query($con,"SELECT COUNT(*) as c FROM trainer_attendance WHERE trainer_id='$tid' AND status='Absent'");
$absent = mysqli_fetch_assoc($qa)['c'];
$total  = $present+$absent;
$pct    = $total>0 ? round(($present/$total)*100) : 0;
$qmc = mysqli_query($con,"SELECT COUNT(*) as c FROM assign_trainer WHERE trainer_id='$tid'");
$mc  = mysqli_fetch_assoc($qmc)['c'];
$qdc = mysqli_query($con,"SELECT COUNT(*) as c FROM diet_plans WHERE trainer_id='$tid'");
$dc  = mysqli_fetch_assoc($qdc)['c'];
?>
<div class="ptitle">Profile</div>
<div style="display:flex;gap:20px;flex-wrap:wrap;align-items:flex-start;">
    <!-- LEFT -->
    <div style="background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);overflow:hidden;min-width:250px;flex:1;max-width:320px;">
        <div style="background:linear-gradient(135deg,#1a1a2e,#16213e);padding:28px 20px;text-align:center;">
            <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,#e74c3c,#c0392b);display:inline-flex;align-items:center;justify-content:center;font-size:26px;margin-bottom:10px;">🏋</div>
            <h3 style="color:#fff;font-size:17px;margin-bottom:6px;"><?php echo htmlspecialchars($d['name']); ?></h3>
            <span style="background:#27ae60;color:#fff;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;">PERSONAL TRAINER</span>
        </div>
        <div style="padding:18px;">
            <?php foreach([['Email','📧',$d['email']],['Phone','📞',$d['phone']],['Gender','',$d['gender']],['Specialization','🎯',$d['specialization']],['Experience','⭐',$d['experience'].' years'],['Address','📍',$d['address']]] as $f): ?>
            <div style="margin-bottom:11px;padding-bottom:11px;border-bottom:1px solid #f0f0f0;">
                <div style="font-size:10px;color:#aaa;text-transform:uppercase;margin-bottom:2px;"><?php echo $f[0]; ?></div>
                <div style="font-size:13px;font-weight:500;color:#333;"><?php echo $f[1].' '.htmlspecialchars($f[2]); ?></div>
            </div>
            <?php endforeach; ?>
            <a href="personal_profile_edit.php" class="btn btn-p" style="width:100%;text-align:center;padding:10px;margin-top:4px;">✏ Edit Profile</a>
        </div>
    </div>
    <!-- RIGHT -->
    <div style="flex:2;min-width:250px;">
        <div style="background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);padding:18px;margin-bottom:18px;">
            <div style="font-size:14px;font-weight:700;color:#1a1a2e;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #e74c3c;display:inline-block;">📊 Attendance Summary</div>
            <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
                <div style="flex:1;min-width:80px;background:#d4edda;border-radius:8px;padding:14px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#155724;"><?php echo $present; ?></div><div style="font-size:11px;color:#155724;">Present</div></div>
                <div style="flex:1;min-width:80px;background:#f8d7da;border-radius:8px;padding:14px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#721c24;"><?php echo $absent; ?></div><div style="font-size:11px;color:#721c24;">Absent</div></div>
                <div style="flex:1;min-width:80px;background:#d1ecf1;border-radius:8px;padding:14px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#0c5460;"><?php echo $pct; ?>%</div><div style="font-size:11px;color:#0c5460;">Rate</div></div>
            </div>
            <div style="background:#e0e0e0;border-radius:20px;height:7px;"><div style="width:<?php echo $pct; ?>%;background:<?php echo $pct>=75?'#27ae60':($pct>=50?'#e67e22':'#e74c3c'); ?>;height:7px;border-radius:20px;"></div></div>
        </div>
        <div style="background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);padding:18px;">
            <div style="font-size:14px;font-weight:700;color:#1a1a2e;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #27ae60;display:inline-block;">📈 Activity</div>
            <div style="display:flex;gap:12px;flex-wrap:wrap;">
                <div style="flex:1;min-width:110px;background:linear-gradient(135deg,#8e44ad,#6c3483);border-radius:8px;padding:16px;text-align:center;"><div style="font-size:26px;font-weight:800;color:#fff;"><?php echo $mc; ?></div><div style="font-size:11px;color:rgba(255,255,255,0.8);margin-top:3px;">Members Assigned</div></div>
                <div style="flex:1;min-width:110px;background:linear-gradient(135deg,#27ae60,#1e8449);border-radius:8px;padding:16px;text-align:center;"><div style="font-size:26px;font-weight:800;color:#fff;"><?php echo $dc; ?></div><div style="font-size:11px;color:rgba(255,255,255,0.8);margin-top:3px;">Diet Plans Made</div></div>
            </div>
        </div>
    </div>
</div>
</div></body></html>
