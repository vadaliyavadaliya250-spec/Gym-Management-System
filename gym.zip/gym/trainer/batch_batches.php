<?php
session_start();
include "../db.php";
include "batch_header.php";

$batches = mysqli_query($con,"SELECT * FROM batches WHERE trainer_id='$tid' ORDER BY created_at DESC");
?>
<div class="ptitle">Batch</div>

<div style="display:flex;gap:12px;margin-bottom:18px;flex-wrap:wrap;">
    <a href="batch_members_view.php" class="btn btn-p">👥 View Batch Members</a>
    <a href="batch_update_time.php" class="btn btn-w">⏰ Update Batch Time</a>
</div>

<div class="twrap">
    <div class="thead">📋 My Assigned Batches</div>
    <table>
        <tr><th>#</th><th>Batch Name</th><th>Start Time</th><th>End Time</th><th>Capacity</th><th>Status</th><th>Created</th><th>Action</th></tr>
        <?php $i=1; if(mysqli_num_rows($batches)>0): while($r=mysqli_fetch_assoc($batches)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['batch_name']); ?></td>
            <td><?php echo date('h:i A',strtotime($r['start_time'])); ?></td>
            <td><?php echo date('h:i A',strtotime($r['end_time'])); ?></td>
            <td><?php echo $r['capacity']; ?></td>
            <td><span class="bx <?php echo $r['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($r['status']); ?></span></td>
            <td><?php echo date('d M Y',strtotime($r['created_at'])); ?></td>
            <td>
                <a href="batch_members_view.php?batch_id=<?php echo $r['id']; ?>" class="btn btn-p">👥 Members</a>
                <a href="batch_update_time.php?batch_id=<?php echo $r['id']; ?>" class="btn btn-w">⏰ Change Time</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" style="text-align:center;color:#888;padding:22px;">No batches assigned to you yet.</td></tr>
        <?php endif; ?>
    </table>
</div>
</div></body></html>
