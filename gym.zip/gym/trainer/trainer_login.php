<?php
session_start();
include "../db.php";

if(isset($_POST['login'])){
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $q = mysqli_query($con,"SELECT * FROM trainers WHERE username='$username' AND password='$password' AND status='active'");
    if(mysqli_num_rows($q) > 0){
        $data = mysqli_fetch_assoc($q);
        $_SESSION['trainer_id']   = $data['id'];
        $_SESSION['trainer_type'] = $data['type'];   // 'personal' or 'batch'
        $_SESSION['trainer_name'] = $data['name'];

        // Redirect based on type
        if($data['type'] == 'personal'){
            header("Location: personal_dashboard.php");
        } else {
            header("Location: batch_dashboard.php");
        }
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Trainer Login</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Segoe UI',Arial,sans-serif;background:linear-gradient(135deg,#1a1a2e,#16213e,#0f3460);min-height:100vh;display:flex;align-items:center;justify-content:center;}
.box{width:400px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:16px;padding:48px 40px;backdrop-filter:blur(12px);box-shadow:0 24px 60px rgba(0,0,0,0.5);}
.logo{text-align:center;margin-bottom:32px;}
.logo .ic{display:inline-block;width:62px;height:62px;background:linear-gradient(135deg,#e74c3c,#c0392b);border-radius:50%;font-size:26px;line-height:62px;margin-bottom:12px;}
.logo h2{color:#fff;font-size:24px;font-weight:700;margin-bottom:4px;}
.logo p{color:rgba(255,255,255,0.4);font-size:13px;}
.err{background:rgba(231,76,60,0.18);border:1px solid rgba(231,76,60,0.5);color:#ff8080;padding:10px 14px;border-radius:8px;margin-bottom:20px;font-size:13px;}
.fg{margin-bottom:20px;}
.fg label{display:block;color:rgba(255,255,255,0.6);font-size:12px;font-weight:600;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px;}
.fg input{width:100%;padding:12px 16px;background:rgba(255,255,255,0.08);border:1.5px solid rgba(255,255,255,0.12);border-radius:8px;color:#fff;font-size:14px;outline:none;transition:border 0.25s;}
.fg input:focus{border-color:#e74c3c;}
.fg input::placeholder{color:rgba(255,255,255,0.25);}
.sbtn{width:100%;padding:13px;background:linear-gradient(135deg,#e74c3c,#c0392b);color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;transition:opacity 0.2s;margin-top:4px;}
.sbtn:hover{opacity:0.88;}
.back{text-align:center;margin-top:20px;}
.back a{color:rgba(255,255,255,0.3);font-size:12px;text-decoration:none;}
.back a:hover{color:#fff;}
</style>
</head>
<body>
<div class="box">
    <div class="logo">
        <div class="ic">🏋</div>
        <h2>Trainer Login</h2>
        <p>GymPro Management System</p>
    </div>
    <?php if(isset($error)): ?>
    <div class="err">⚠ <?php echo $error; ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="fg">
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter your username" required>
        </div>
        <div class="fg">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>
        </div>
        <button type="submit" name="login" class="sbtn">Login</button>
    </form>
    <div class="back"><a href="../index.php">← Back to Home</a></div>
</div>
</body>
</html>
