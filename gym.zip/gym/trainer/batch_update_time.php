<?php
session_start();
include "../db.php";
include "batch_header.php";

$batch_pre = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : 0;

if(isset($_POST['update_time'])){
    $bid   = (int)$_POST['batch_id'];
    $start = mysqli_real_escape_string($con,$_POST['start_time']);
    $end   = mysqli_real_escape_string($con,$_POST['end_time']);
    // Security: make sure this batch belongs to this trainer
    $chk = mysqli_query($con,"SELECT id FROM batches WHERE id='$bid' AND trainer_id='$tid'");
    if(mysqli_num_rows($chk) > 0){
        mysqli_query($con,"UPDATE batches SET start_time='$start',end_time='$end' WHERE id='$bid'");
        $success = "Batch time updated! The new schedule is now visible to Admin.";
    } else {
        $error = "You are not allowed to edit this batch.";
    }
}

$batches_q = mysqli_query($con,"SELECT * FROM batches WHERE trainer_id='$tid' ORDER BY batch_name");
$batches   = [];
while($b = mysqli_fetch_assoc($batches_q)) $batches[] = $b;
?>
<div class="ptitle">Update Batch Time</div>
<?php if(isset($success)): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if(isset($error)): ?><div class="al al-d">⚠ <?php echo $error; ?></div><?php endif; ?>
<div class="al al-i">ℹ Any time change you make here will immediately update in the Admin panel under Manage Batches.</div>

<?php if(count($batches) > 0): foreach($batches as $b): ?>
<div class="fcard" style="max-width:600px;margin-bottom:18px;">
    <div class="fhead">
        📋 <?php echo htmlspecialchars($b['batch_name']); ?>
        <span style="font-size:12px;font-weight:400;opacity:0.65;margin-left:10px;">
            Current: <?php echo date('h:i A',strtotime($b['start_time'])); ?> – <?php echo date('h:i A',strtotime($b['end_time'])); ?>
        </span>
    </div>
    <div class="fbody">
        <form method="POST">
            <input type="hidden" name="batch_id" value="<?php echo $b['id']; ?>">
            <div class="frow" style="align-items:flex-end;">
                <div class="fg">
                    <label>New Start Time</label>
                    <input type="time" name="start_time" value="<?php echo $b['start_time']; ?>" required>
                </div>
                <div class="fg">
                    <label>New End Time</label>
                    <input type="time" name="end_time" value="<?php echo $b['end_time']; ?>" required>
                </div>
                <div class="fg" style="flex:0.5;">
                    <label>&nbsp;</label>
                    <button type="submit" name="update_time" class="btn btn-w" style="width:100%;padding:10px;"
                        onclick="return confirm('Update time for <?php echo htmlspecialchars($b['batch_name']); ?>?')">
                        ⏰ Update
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endforeach; else: ?>
<div class="al al-i">No batches assigned to you.</div>
<?php endif; ?>

<div class="twrap">
    <div class="thead">📅 Current Batch Schedule</div>
    <table>
        <tr><th>Batch Name</th><th>Start Time</th><th>End Time</th><th>Capacity</th><th>Status</th></tr>
        <?php foreach($batches as $b): ?>
        <tr>
            <td><?php echo htmlspecialchars($b['batch_name']); ?></td>
            <td><?php echo date('h:i A',strtotime($b['start_time'])); ?></td>
            <td><?php echo date('h:i A',strtotime($b['end_time'])); ?></td>
            <td><?php echo $b['capacity']; ?></td>
            <td><span class="bx <?php echo $b['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($b['status']); ?></span></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<a href="batch_batches.php" class="btn btn-dk">← Back to Batches</a>
</div></body></html>
