﻿<?php
$con = mysqli_connect('localhost','root','','gym');
if(!$con){ die(mysqli_connect_error()); }
$q = mysqli_query($con, "SELECT username, photo FROM user_details ORDER BY id DESC LIMIT 25");
while($r = mysqli_fetch_assoc($q)){
    echo ($r['username'] ?? '')." => ".($r['photo'] ?? '').PHP_EOL;
}
