<?php
session_start();
require 'db.php';

$username = $_SESSION['username'] ?? '';
$user_id  = $_SESSION['user_id'] ?? 0;
if(!$user_id && $username){
    $urow = mysqli_fetch_assoc(mysqli_query($con,"SELECT id FROM user_table WHERE username='".mysqli_real_escape_string($con,$username)."' LIMIT 1"));
    if($urow){ $user_id = (int)$urow['id']; $_SESSION['user_id']=$user_id; }
}
if(!$user_id){ header("Location: login.php?msg=login_required"); exit; }

// remove item
if(isset($_GET['remove'])){
    $rid = (int)$_GET['remove'];
    mysqli_query($con,"DELETE FROM wishlists WHERE id='$rid' AND user_id='$user_id'");
    header("Location: wishlist.php?msg=removed"); exit;
}

// wishlist disabled
$items = [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Wishlist Disabled</title>
<style>
:root{--primary:#e63946;--ink:#0f172a;--muted:#6b7280;--card:#ffffff;--line:#e5e7eb;--soft:#f5f7fb;}
*{box-sizing:border-box;}
body{margin:0;font-family:'Segoe UI',Arial,sans-serif;background:var(--soft);color:var(--ink);}
.shell{max-width:1180px;margin:26px auto;padding:0 18px;}
.title-wrap{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:14px;}
.title{font-size:26px;font-weight:900;}
.pill{background:#fff;border:1px solid var(--line);padding:8px 12px;border-radius:10px;font-weight:700;color:var(--muted);}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px;}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;box-shadow:0 16px 40px rgba(0,0,0,0.05);overflow:hidden;display:flex;flex-direction:column;transition:transform .2s;}
.card:hover{transform:translateY(-4px);}
.img{height:200px;background:linear-gradient(135deg,#eef1f7,#dfe6f2);display:flex;align-items:center;justify-content:center;overflow:hidden;}
.img img{width:100%;height:100%;object-fit:cover;transition:transform .3s;}
.card:hover .img img{transform:scale(1.04);}
.body{padding:16px;display:flex;flex-direction:column;gap:6px;flex:1;}
.name{font-weight:800;font-size:16px;}
.price{color:var(--primary);font-weight:900;font-size:18px;}
.stock-ok{color:#1f9d55;font-weight:700;font-size:12px;} .stock-bad{color:#c42431;font-weight:700;font-size:12px;}
.actions{display:flex;gap:8px;margin-top:auto;}
.btn{flex:1;text-align:center;padding:10px;border-radius:10px;border:1px solid var(--line);font-weight:800;text-decoration:none;}
.btn-primary{background:var(--primary);color:#fff;border:none;}
.btn-ghost{background:#fff;color:#111;}
.msg{background:#e8f5e9;color:#1f9d55;padding:10px 12px;border-radius:10px;margin-bottom:12px;font-weight:700;}
.empty{background:var(--card);border:1px dashed var(--line);padding:24px;border-radius:14px;text-align:center;color:var(--muted);box-shadow:0 12px 32px rgba(0,0,0,0.04);}
@media(max-width:700px){.grid{grid-template-columns:repeat(auto-fit,minmax(210px,1fr));}}
</style>
</head>
<body>
<div class="shell">
  <div class="title">Wishlist Disabled</div>
  <div class="empty">Wishlist feature is turned off. <a href="products.php" style="color:var(--primary);font-weight:700;">Browse products</a></div>
</div>
</body>
</html>
