<?php
session_start();
require 'db.php';

$username = $_SESSION['username'] ?? '';
$user_id  = $_SESSION['user_id'] ?? 0;
if(!$user_id && $username){
    $urow = mysqli_fetch_assoc(mysqli_query($con,"SELECT id FROM user_table WHERE username='".mysqli_real_escape_string($con,$username)."' LIMIT 1"));
    if($urow){ $user_id = (int)$urow['id']; $_SESSION['user_id']=$user_id; }
}
if(!$user_id){ header("Location: login.php?msg=login_required"); exit; }

$has_col = function($table,$col) use ($con){
    $db = mysqli_fetch_row(mysqli_query($con,"SELECT DATABASE()"))[0] ?? '';
    $db = mysqli_real_escape_string($con,$db);
    $table = mysqli_real_escape_string($con,$table);
    $col = mysqli_real_escape_string($con,$col);
    $q = mysqli_query($con,"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$db' AND TABLE_NAME='$table' AND COLUMN_NAME='$col' LIMIT 1");
    return $q && mysqli_num_rows($q)>0;
};

// remove or update qty
if(isset($_GET['remove'])){
    $rid = (int)$_GET['remove'];
    mysqli_query($con,"DELETE FROM cart_items WHERE id='$rid' AND user_id='$user_id'");
    header("Location: cart.php?msg=removed"); exit;
}

if(isset($_POST['update_qty'])){
    foreach($_POST['qty'] as $id=>$q){
        $id=(int)$id; $q=max(1,(int)$q);
        mysqli_query($con,"UPDATE cart_items SET qty='$q' WHERE id='$id' AND user_id='$user_id'");
    }
    header("Location: cart.php?msg=updated"); exit;
}

// checkout -> create orders and clear
if(isset($_POST['checkout'])){
    $modern_orders = $has_col('orders','product_id') && $has_col('orders','variant_id') && $has_col('orders','qty');
    $cart_rows = mysqli_query($con,"
        SELECT ci.*, pv.final_price, p.product_name, p.image
        FROM cart_items ci
        JOIN product_variants pv ON pv.id=ci.variant_id
        JOIN products_new p ON p.id=ci.product_id
        WHERE ci.user_id='$user_id'
    ");

    $items_payload = [];
    $order_total = 0;
    while($row=mysqli_fetch_assoc($cart_rows)){
        $line_total = $row['final_price'] * $row['qty'];
        if($modern_orders){
            mysqli_query($con,"INSERT INTO orders(user_id,product_id,variant_id,qty,unit_price,total,payment_method,status,created_at) VALUES('{$row['user_id']}','{$row['product_id']}','{$row['variant_id']}','{$row['qty']}','{$row['final_price']}','$line_total','COD','pending',NOW())");
        } else {
            $order_total += $line_total;
            $items_payload[] = [
                'name'  => $row['product_name'],
                'price' => (string)$row['final_price'],
                'qty'   => (int)$row['qty'],
                'image' => $row['image'] ?? ''
            ];
        }
    }

    if(!$modern_orders && count($items_payload) > 0){
        $items_json = json_encode($items_payload, JSON_UNESCAPED_UNICODE);
        $items_json = mysqli_real_escape_string($con, $items_json ?: '[]');
        mysqli_query($con,"INSERT INTO orders(user_id,address,total,payment_method,status,items,created_at) VALUES('$user_id',NULL,'$order_total','COD','pending','$items_json',NOW())");
    }

    mysqli_query($con,"DELETE FROM cart_items WHERE user_id='$user_id'");
    header("Location: cart.php?msg=placed"); exit;
}

// fetch cart items
$items = mysqli_query($con,"
    SELECT ci.id as cid, ci.qty, p.id as pid, p.product_name, p.image, pv.id as vid, pv.final_price, pv.stock
    FROM cart_items ci
    JOIN product_variants pv ON pv.id = ci.variant_id
    JOIN products_new p ON p.id = ci.product_id
    WHERE ci.user_id='$user_id'
    ORDER BY ci.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Cart</title>
<style>
:root{--primary:#e63946;--ink:#0f172a;--muted:#6b7280;--line:#e5e7eb;--soft:#f5f7fb;}
*{box-sizing:border-box;}
body{margin:0;font-family:'Segoe UI',Arial,sans-serif;background:var(--soft);color:var(--ink);}
.shell{max-width:1180px;margin:26px auto;padding:0 18px;}
.title-wrap{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px;}
.title{font-size:26px;font-weight:900;}
.pill{background:#fff;border:1px solid var(--line);padding:8px 12px;border-radius:10px;font-weight:700;color:var(--muted);}
.table-wrap{background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 16px 40px rgba(0,0,0,0.05);overflow:hidden;}
table{width:100%;border-collapse:collapse;font-size:14px;}
th,td{padding:12px;border-bottom:1px solid #eef1f5;text-align:left;}
th{background:#f9fafb;color:#6b7280;text-transform:uppercase;font-size:12px;}
.thumb{width:64px;height:64px;border-radius:10px;object-fit:cover;background:#eef1f7;}
.price{font-weight:800;color:var(--primary);}
.btn{padding:10px 14px;border-radius:10px;border:1px solid var(--line);font-weight:800;text-decoration:none;cursor:pointer;background:#fff;}
.btn-danger{background:#fee2e2;color:#b91c1c;border:none;}
.btn-primary{background:var(--primary);color:#fff;border:none;}
.bar{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin:12px 0;}
.msg{background:#e8f5e9;color:#1f9d55;padding:10px 12px;border-radius:10px;margin-bottom:12px;font-weight:700;}
.empty{background:#fff;border:1px dashed var(--line);padding:24px;border-radius:14px;text-align:center;color:var(--muted);box-shadow:0 12px 32px rgba(0,0,0,0.04);}
input[type=number]{padding:8px;border:1px solid var(--line);border-radius:10px;}
@media(max-width:720px){th:nth-child(2),td:nth-child(2){display:none;}}
</style>
</head>
<body>
<div class="shell">
  <div class="title">My Cart</div>
  <?php if(isset($_GET['msg']) && $_GET['msg']=='removed'): ?><div class="msg">Item removed.</div><?php endif; ?>
  <?php if(isset($_GET['msg']) && $_GET['msg']=='updated'): ?><div class="msg">Quantities updated.</div><?php endif; ?>
  <?php if(isset($_GET['msg']) && $_GET['msg']=='placed'): ?><div class="msg">Order placed (COD). Status pending for admin.</div><?php endif; ?>

  <?php if(mysqli_num_rows($items)>0): ?>
  <form method="POST">
  <div class="table-wrap">
    <table>
      <tr><th>Product</th><th>Variant</th><th>Price</th><th>Qty</th><th>Subtotal</th><th>Action</th></tr>
      <?php $total=0; while($it=mysqli_fetch_assoc($items)):
        $sub = $it['final_price'] * $it['qty']; $total+=$sub;
      ?>
      <tr>
        <td style="display:flex;align-items:center;gap:10px;">
            <?php if($it['image']): ?><img class="thumb" src="uploads/products/<?php echo htmlspecialchars($it['image']); ?>"><?php else: ?><div class="thumb" style="display:grid;place-items:center;">📦</div><?php endif; ?>
            <div>
                <div style="font-weight:800;"><?php echo htmlspecialchars($it['product_name']); ?></div>
            </div>
        </td>
        <td>#<?php echo $it['vid']; ?></td>
        <td class="price">₹<?php echo number_format($it['final_price'],2); ?></td>
        <td><input type="number" name="qty[<?php echo $it['cid']; ?>]" value="<?php echo $it['qty']; ?>" min="1" style="width:70px;padding:6px;border:1px solid #e5e7eb;border-radius:8px;"></td>
        <td class="price">₹<?php echo number_format($sub,2); ?></td>
        <td><a class="btn btn-danger" href="cart.php?remove=<?php echo $it['cid']; ?>">Remove</a></td>
      </tr>
      <?php endwhile; ?>
      <tr>
        <td colspan="4" style="text-align:right;font-weight:800;">Total</td>
        <td class="price">₹<?php echo number_format($total,2); ?></td>
        <td></td>
      </tr>
    </table>
  </div>
  <div class="bar">
    <div style="display:flex;gap:8px;">
      <button class="btn" type="submit" name="update_qty">Update Qty</button>
      <a class="btn" href="products.php">Continue Shopping</a>
    </div>
    <button class="btn btn-primary" type="submit" name="checkout">Buy (COD)</button>
  </div>
  </form>
  <?php else: ?>
    <div class="empty">Your cart is empty. <a href="products.php" style="color:var(--primary);font-weight:700;">Shop now</a></div>
  <?php endif; ?>
</div>
</body>
</html>
