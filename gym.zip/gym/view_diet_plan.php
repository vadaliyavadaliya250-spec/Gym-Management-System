<?php
include "header.php";
include "db.php";

$member_id=$_SESSION['user_id'];

$res=mysqli_query($con,"SELECT dp.*,t.name trainer_name
FROM diet_plans dp
JOIN trainers t ON dp.trainer_id=t.id
WHERE dp.member_id='$member_id'");
?>

<div class="card">

<h2>My Diet Plan</h2>

<?php while($row=mysqli_fetch_assoc($res)){ ?>

<p><b>Trainer:</b> <?= $row['trainer_name'] ?></p>

<p><b>Goal:</b> <?= $row['goal'] ?></p>

<hr>

<p><b>Breakfast:</b><br> <?= $row['breakfast'] ?></p>

<p><b>Lunch:</b><br> <?= $row['lunch'] ?></p>

<p><b>Snacks:</b><br> <?= $row['snacks'] ?></p>

<p><b>Dinner:</b><br> <?= $row['dinner'] ?></p>

<p><b>Notes:</b><br> <?= $row['notes'] ?></p>

<hr>

<?php } ?>

</div>

<?php include "footer.php"; ?>