<?php
$con = mysqli_connect("localhost","root","","gym");
if(!$con){ die("DB Error"); }

/* DELETE */
if(isset($_GET['delete'])){
    mysqli_query($con,"DELETE FROM products WHERE id=".$_GET['delete']);
    header("Location: admin_products.php");
}

/* ADD */
if(isset($_POST['add'])){
    $category = $_POST['category'];
    $product  = $_POST['product'];
    $desc     = $_POST['description'];

    $kg   = $_POST['kg'] ?? '';
    $flav = $_POST['flavour'] ?? '';
    $mm   = $_POST['mm'] ?? '';

    $stock = $_POST['stock'];
    $price = $_POST['price'];
    $dis   = $_POST['discount'];
    $final = $price - $dis;

    $img = time().$_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$img);

    mysqli_query($con,"INSERT INTO products
    (category,product_name,image,description,weight_kg,flavour,thickness_mm,stock,price,discount,final_price)
    VALUES
    ('$category','$product','$img','$desc','$kg','$flav','$mm','$stock','$price','$dis','$final')");
}

/* EDIT FETCH */
$edit = null;
if(isset($_GET['edit'])){
    $q = mysqli_query($con,"SELECT * FROM products WHERE id=".$_GET['edit']);
    $edit = mysqli_fetch_assoc($q);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Simple Admin</title>
<style>
body{margin:0;font-family:Arial;background:#f2f2f2}
.sidebar{width:200px;height:100vh;position:fixed;background:#111;color:#fff}
.sidebar h2{text-align:center;padding:20px}
.sidebar a{display:block;padding:15px;color:#fff;text-decoration:none}
.sidebar a:hover{background:#333}

.main{margin-left:200px;padding:30px}
input,select,textarea{width:100%;padding:8px;margin:8px 0}
button{padding:10px 20px;background:black;color:white;border:none}

table{width:100%;margin-top:30px;background:white;border-collapse:collapse}
th,td{border:1px solid #ccc;padding:10px;text-align:center}
img{width:60px}
</style>
</head>

<body>

<div class="sidebar">
<h2>ADMIN</h2>
<a href="#">Dashboard</a>
<a href="admin_products.php">Products</a>
<a href="#">Membership</a>
</div>

<div class="main">

<h2>Add Product</h2>

<form method="post" enctype="multipart/form-data">

<!-- CATEGORY -->
<select name="category" onchange="this.form.submit()" required>
    <option value="">Select Category</option>
    <option value="Equipments" <?=(@$_POST['category']=="Equipments")?"selected":""?>>Equipments</option>
    <option value="Supplements" <?=(@$_POST['category']=="Supplements")?"selected":""?>>Supplements</option>
    <option value="Merchandise" <?=(@$_POST['category']=="Merchandise")?"selected":""?>>Merchandise</option>
</select>

<?php
$cat = $_POST['category'] ?? '';
$product = $_POST['product'] ?? '';

if($cat!=""){
?>
<!-- PRODUCT -->
<select name="product" onchange="this.form.submit()" required>
    <option value="">Select Product</option>

<?php
if($cat=="Equipments"){
?>
    <option value="Dumbbells" <?=($product=="Dumbbells")?"selected":""?>>Dumbbells</option>
    <option value="Barbells" <?=($product=="Barbells")?"selected":""?>>Barbells</option>
    <option value="Yoga Mats" <?=($product=="Yoga Mats")?"selected":""?>>Yoga Mats</option>
<?php
}

if($cat=="Supplements"){
?>
    <option value="Protein Powder" <?=($product=="Protein Powder")?"selected":""?>>Protein Powder</option>
<?php
}

if($cat=="Merchandise"){
?>
    <option value="Gym T-Shirt" <?=($product=="Gym T-Shirt")?"selected":""?>>Gym T-Shirt</option>
    <option value="Gym Shorts" <?=($product=="Gym Shorts")?"selected":""?>>Gym Shorts</option>
    <option value="Bottle" <?=($product=="Bottle")?"selected":""?>>Bottle</option>
<?php
}
?>
</select>
<?php } ?>


<textarea name="description" placeholder="Description"></textarea>
<input type="file" name="image" required>

<?php
$p = $_POST['product'] ?? '';

if($p=="Dumbbells" || $p=="Barbells"){
    echo '<input name="kg" placeholder="Weight (KG)">';
}
if($p=="Protein Powder"){
    echo '<input name="kg" placeholder="Weight (KG)">';
    echo '<input name="flavour" placeholder="Flavour">';
}
if($p=="Yoga Mats"){
    echo '<input name="mm" placeholder="Thickness (MM)">';
}
if($p=="Gym T-Shirt" || $p=="Gym Shorts"){
    echo '<input name="size" placeholder="Size (S/M/L/XL/XXL)">';
}
if($p=="Bottle"){
    echo '<input name="Liter" placeholder="Liter ">';
}
?>

<input name="stock" placeholder="Stock" required>
<input name="price" placeholder="Price" required>
<input name="discount" placeholder="Discount">

<button name="add">Add Product</button>

</form>

<!-- PRODUCT LIST -->
<table>
<tr>
<th>Image</th>
<th>Name</th>
<th>Category</th>
<th>Price</th>
<th>Action</th>
</tr>

<?php
$res = mysqli_query($con,"SELECT * FROM products");
while($r=mysqli_fetch_assoc($res)){
?>
<tr>
<td><img src="uploads/<?= $r['image'] ?>"></td>
<td><?= $r['product_name'] ?></td>
<td><?= $r['category'] ?></td>
<td><?= $r['final_price'] ?></td>
<td>
<a href="?delete=<?= $r['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>
<?php } ?>
</table>

</div>
</body>
</html>
