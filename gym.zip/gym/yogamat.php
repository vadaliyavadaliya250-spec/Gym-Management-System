<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Yoga Mat - Gymness</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;}
body{background:#f6f6f6;}

/* HEADER */
.navbar{
    padding:20px 60px;
    background:#fff;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 10px rgba(0,0,0,0.1);
}
.logo{font-size:26px;font-weight:800;}
.nav-menu{list-style:none;display:flex;gap:30px;align-items:center;}
.nav-menu a{text-decoration:none;color:#000;font-weight:600;}
.cart-btn{
    background:#c82027;
    color:#fff !important;
    padding:8px 14px;
    border-radius:6px;
}

/* PRODUCT */
.container{
    max-width:1200px;
    margin:50px auto;
    background:#fff;
    padding:40px;
    border-radius:10px;
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:40px;
}
.product-img img{width:100%;border-radius:10px;}
.product-title{font-size:30px;font-weight:800;margin-bottom:10px;}
.desc{color:#555;line-height:1.6;margin-bottom:15px;}

.price-box{margin:15px 0;}
.original-price{text-decoration:line-through;color:#777;}
.discount-price{color:#c82027;font-size:28px;font-weight:800;margin-left:10px;}
.discount-badge{
    background:#c82027;color:#fff;padding:6px 12px;
    border-radius:20px;display:inline-block;margin-bottom:10px;
}

/* OPTIONS */
.option-box{margin:20px 0;}
.options{display:flex;flex-wrap:wrap;gap:10px;}
.options button{
    padding:10px 18px;border:1px solid #ccc;
    background:#fff;cursor:pointer;border-radius:6px;
}
.options button.active{
    border:2px solid #c82027;
    color:#c82027;
}

/* BUTTON */
.buy-btn{
    margin-top:15px;padding:15px;width:100%;
    background:#c82027;color:#fff;border:none;
    font-size:18px;border-radius:8px;cursor:pointer;
}

/* CART (TOP FIXED) */
.cart{
    position:fixed;
    top:90px;
    right:40px;
    width:350px;
    background:#fff;
    padding:30px;
    border-radius:10px;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
    display:none;
    z-index:999;
}

.footer{
    margin-top:60px;background:#000;color:#aaa;
    text-align:center;padding:20px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="navbar">
    <div class="logo">GYMNESS</div>
    <ul class="nav-menu">
        <li><a href="newhome.php">Home</a></li>
        <li><a href="#">Yoga Mat</a></li>
        <li>
            <a href="javascript:void(0)" class="cart-btn" onclick="toggleCart()">
                🛒 Cart (<span id="cartCount">0</span>)
            </a>
        </li>
    </ul>
</div>

<!-- PRODUCT -->
<div class="container">
    <div class="product-img">
        <img src="https://images.unsplash.com/photo-1599447421416-3414500d18a5">
    </div>

    <div>
        <span class="discount-badge">30% OFF</span>
        <div class="product-title">Premium Yoga Mat</div>

        <p class="desc">
            Non-slip premium yoga mat for yoga, meditation, stretching & workouts.
        </p>

        <div class="price-box">
            <span class="original-price" id="originalPrice">₹1000</span>
            <span class="discount-price" id="finalPrice">₹700</span>
        </div>

        <p><b>Stock:</b> <span id="stockShow">15</span></p>

        <!-- THICKNESS -->
        <div class="option-box">
            <h4>Select Thickness</h4><br>
            <div class="options">
                <button class="active" onclick="setThickness(4)">4 mm</button>
                <button onclick="setThickness(6)">6 mm</button>
                <button onclick="setThickness(8)">8 mm</button>
            </div>
        </div>

        <button class="buy-btn" onclick="addToCart()">Add to Cart</button>
    </div>
</div>

<!-- CART -->
<div class="cart" id="cartBox">
    <h2>🛒 Your Cart</h2>
    <div id="cartItems" style="margin-top:15px;color:#777;">Cart is empty</div>
</div>

<!-- FOOTER -->
<div class="footer">© 2024 Gymness. All rights reserved.</div>

<script>
let basePrice = 350;
let baseOriginal = 500;
let thickness = 4;
let cartQty = 0;

let stock = {
    4: 15,
    6: 10,
    8: 6
};

function setThickness(t){
    thickness = t;
    updatePrice();
    updateStock();
    setActive(event);
}

function updatePrice(){
    document.getElementById("finalPrice").innerText = "₹" + (basePrice * thickness/2);
    document.getElementById("originalPrice").innerText = "₹" + (baseOriginal * thickness/2);
}

function updateStock(){
    document.getElementById("stockShow").innerText = stock[thickness];
}

function setActive(e){
    let btns = e.target.parentElement.querySelectorAll("button");
    btns.forEach(b=>b.classList.remove("active"));
    e.target.classList.add("active");
}

function addToCart(){
    if(stock[thickness] <= 0){
        alert("Out of Stock");
        return;
    }
    stock[thickness]--;
    cartQty++;
    updateStock();
    renderCart();
}

function removeFromCart(){
    cartQty--;
    stock[thickness]++;
    if(cartQty < 0) cartQty = 0;
    updateStock();
    renderCart();
}

function renderCart(){
    document.getElementById("cartCount").innerText = cartQty;
    let cart = document.getElementById("cartItems");

    if(cartQty == 0){
        cart.innerHTML = "Cart is empty";
        return;
    }

    cart.innerHTML = `
        <b>Premium Yoga Mat</b><br>
        Thickness: ${thickness} mm<br>
        Qty: ${cartQty}<br>
        Total: ₹${cartQty * basePrice * thickness/2}<br><br>
        <button onclick="removeFromCart()">Remove</button>
    `;
}

function toggleCart(){
    let cart = document.getElementById("cartBox");
    cart.style.display = cart.style.display === "block" ? "none" : "block";
}

updateStock();
</script>

</body>
</html>
