<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Checkout - Gymness</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;}
body{background:#f6f6f6}

/* STEP HEADER */
.steps{
    display:flex;
    justify-content:center;
    align-items:center;
    gap:20px;
    margin:30px 0;
}
.step{
    width:40px;
    height:40px;
    border-radius:50%;
    border:2px solid #c82027;
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:700;
    color:#c82027;
}
.step.active{
    background:#c82027;
    color:#fff;
}
.line{
    width:80px;
    height:3px;
    background:#c82027;
}

/* CONTAINER */
.container{
    max-width:900px;
    background:#fff;
    margin:auto;
    padding:30px;
    border-radius:10px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

.section{
    border-bottom:1px solid #eee;
    padding-bottom:20px;
    margin-bottom:20px;
}

.section h3{
    margin-bottom:10px;
}

/* ADDRESS */
textarea{
    width:100%;
    padding:12px;
    border-radius:6px;
    border:1px solid #ccc;
    resize:none;
}
.change{
    color:#c82027;
    font-size:14px;
    cursor:pointer;
    margin-top:6px;
    display:inline-block;
}

/* PRICE */
.price-row{
    display:flex;
    justify-content:space-between;
    margin:8px 0;
}
.total{
    font-size:20px;
    font-weight:800;
}
.offer{
    color:green;
    font-weight:700;
    margin-top:5px;
}

/* BUTTON */
.btn{
    width:100%;
    padding:15px;
    background:#c82027;
    color:#fff;
    border:none;
    border-radius:8px;
    font-size:18px;
    cursor:pointer;
}
</style>
</head>

<body>

<!-- STEP INDICATOR -->
<div class="steps">
    <div class="step active" id="step1">1</div>
    <div class="line"></div>
    <div class="step" id="step2">2</div>
</div>

<div class="container">

    <!-- PRODUCT DETAILS -->
    <div class="section">
        <h3>Product Details</h3>
        <p><b>Gold Standard Whey Protein</b></p>
        <p id="productInfo"></p>
    </div>

    <!-- ADDRESS -->
    <div class="section">
        <h3>Delivery Address</h3>
        <textarea rows="3" placeholder="Enter your full address"></textarea>
        <span class="change">Change Address</span>
    </div>

    <!-- PRICE DETAILS -->
    <div class="section">
        <h3>Price Details</h3>

        <div class="price-row">
            <span>Total Product Price</span>
            <span id="productPrice"></span>
        </div>

        <div class="price-row">
            <span>Total Discount</span>
            <span id="discount"></span>
        </div>

        <div class="price-row total">
            <span>Total Payable</span>
            <span id="totalPrice"></span>
        </div>

        <div class="offer" id="offerText"></div>
    </div>

    <button class="btn" onclick="goAhead()">Go Ahead</button>

</div>

<script>
let data = JSON.parse(localStorage.getItem("checkoutData"));

let flavour =
    data.flavour == 0 ? "Chocolate" :
    data.flavour == 200 ? "Vanilla" :
    "Strawberry";

document.getElementById("productInfo").innerText =
    `Weight: ${data.weight} KG | Flavour: ${flavour} | Quantity: ${data.qty}`;

let productTotal = data.original * data.qty;
let finalTotal = data.price * data.qty;
let discount = productTotal - finalTotal;

productPrice.innerText = "₹" + productTotal;
discount.innerText = "- ₹" + discount;
totalPrice.innerText = "₹" + finalTotal;
offerText.innerText = `You saved ₹${discount} 🎉`;

/* GO AHEAD */
function goAhead(){
    document.getElementById("step1").classList.add("active");
    document.getElementById("step2").classList.add("active");

    alert("Proceeding to Payment Page 💳");
}
</script>

</body>
</html>
