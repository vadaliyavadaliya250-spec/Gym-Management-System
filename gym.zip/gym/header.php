<?php
// Start buffering early so downstream redirects work even if this header outputs first
ob_start();
// ================= SESSION =================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ================= DB CONNECTION =================
$con = mysqli_connect("localhost","root","","gym");
if(!$con){
    die("Database connection failed");
}

// ================= USER =================
$username = $_SESSION['username'] ?? '';

// ================= LOGOUT =================
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: newhome.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>UNIQUE GYM</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
body{
    margin:0;
    font-family:Arial, Helvetica, sans-serif;
}

/* NAVBAR */
.navbar {
    padding:20px 60px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:sticky;
    top:0;
    background:#fff;
    z-index:1000;
    box-shadow:0 2px 10px rgba(0,0,0,0.1);
}
.logo {
    font-size:26px;
    font-weight:800;
}
.nav-menu {
    list-style:none;
    display:flex;
    gap:30px;
    margin:0;
    padding:0;
}
.nav-menu li a {
    text-decoration:none;
    color:black;
    font-weight:600;
}
.nav-menu li a:hover {
    color:#c82027;
}
.nav-btns button {
    padding:12px 24px;
    border-radius:8px;
    border:none;
    cursor:pointer;
    margin-left:10px;
    font-weight:600;
}
.nav-btns a {
    text-decoration:none;
    color:black;
}
.signup {
    background:#c82027;
}
.signup a {
    color:white;
}
.profile-link {
    display:flex;
    align-items:center;
    padding:12px 24px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
    color:black;
}
.profile-link:hover {
    background:#f8f9fa;
    color:#c82027;
}
.profile-icon {
    font-size:26px;
    margin-right:10px;
    color:#c82027;
}
.dropdown-menu {
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
    border:none;
}
</style>
</head>

<body>

<!-- ================= NAVBAR ================= -->
<div class="navbar">
    <div class="logo">UNIQUE GYM</div>

    <ul class="nav-menu">
        <li><a href="newhome.php">Home</a></li>
        <li><a href="newhome.php#about">About</a></li>
        <li><a href="newhome.php#contact">Contact</a></li>
        <li><a href="newhome.php#membership">Membership</a></li>
    </ul>

    <div class="nav-btns">
    <?php if (empty($username)): ?>
        <button style="background:#0066ff;">
            <a href="login.php" style="color:white;">Login</a>
        </button>
        <button class="signup">
            <a href="signup.php">Sign Up</a>
        </button>
    <?php else: ?>
        <div class="dropdown">
            <a href="#" class="profile-link dropdown-toggle" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle profile-icon"></i>
                <?= htmlspecialchars($username) ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li>
                    <a class="dropdown-item" href="sampleprofile.php">
                        <i class="bi bi-person me-2"></i>Profile
                    </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <a class="dropdown-item text-danger" href="?logout=1">
                        <i class="bi bi-box-arrow-right me-2"></i>Logout
                    </a>
                </li>
            </ul>
        </div>
    <?php endif; ?>
    </div>
</div>
<!-- ================= HEADER END ================= -->
