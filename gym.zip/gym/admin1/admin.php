<?php include("db.php"); ?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Panel</title>

<style>
body{margin:0;font-family:Arial;background:#f2f2f2}
.sidebar{width:200px;height:100vh;position:fixed;background:#111;color:#fff}
.sidebar h2{text-align:center;padding:20px}
.sidebar a{display:block;padding:15px;color:#fff;text-decoration:none}
.sidebar a:hover{background:#333}
.main{margin-left:200px;padding:30px}
</style>

</head>

<body>

<div class="sidebar">

<h2>ADMIN</h2>

<a href="admin/dashboard.php">Dashboard</a>
<a href="admin/products.php">Products</a>
<a href="admin/membership.php">Membership</a>
<a href="admin/purchase_requests.php">Membership Requests</a>
<a href="admin/trainers.php">Add Trainer</a>
<a href="admin/assign_trainer.php">Assign Trainer</a>
<a href="admin/batches.php">Manage Batches</a>
<a href="admin/members.php">Members</a>
<a href="admin/attendance.php">Attendance</a>
<a href="admin/contact_messages.php">Contact Messages</a>

</div>




<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<h1>Dashboard</h1>

<?php
include "db.php";

$members = mysqli_num_rows(mysqli_query($con,"SELECT * FROM membership_purchases"));
$products = mysqli_num_rows(mysqli_query($con,"SELECT * FROM products"));
$trainers = mysqli_num_rows(mysqli_query($con,"SELECT * FROM trainers"));
?>

<div style="display:flex;gap:20px;margin-top:30px;">

<div style="background:white;padding:30px;width:200px;text-align:center;border-radius:8px">
<h2><?= $members ?></h2>
<p>Total Membership Purchases</p>
</div>

<div style="background:white;padding:30px;width:200px;text-align:center;border-radius:8px">
<h2><?= $products ?></h2>
<p>Total Products</p>
</div>

<div style="background:white;padding:30px;width:200px;text-align:center;border-radius:8px">
<h2><?= $trainers ?></h2>
<p>Total Trainers</p>
</div>

</div>

<?php include "footer.php"; ?>


</body>
</html>