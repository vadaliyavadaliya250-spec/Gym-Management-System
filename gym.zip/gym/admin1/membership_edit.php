<?php
$conn = mysqli_connect("localhost","root","","gym");
if(!$conn){ die("Connection Failed"); }

$id = $_GET['id'];

$result = mysqli_query($conn,"SELECT * FROM membership_plans WHERE id='$id'");
$data = mysqli_fetch_assoc($result);

$selected_features = explode(",", $data['features']);

$all_features = [
"Gym Equipment Access",
"Cardio Section Access",
"Weight Training Area",
"Locker Facility",
"Personal Trainer Guidance",
"Free Diet Plan",
"Yoga Classes",
"Zumba Classes"
];
?>

<!DOCTYPE html>
<html>
<head>

<title>Update Membership</title>

<style>

body{
font-family:Arial;
background:#f4f6f9;
margin:0;
}

.container{
width:700px;
margin:40px auto;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}

h2{
margin-bottom:20px;
}

input,textarea,select{
width:100%;
padding:10px;
margin-top:5px;
margin-bottom:15px;
border:1px solid #ccc;
border-radius:5px;
}

.features{
display:grid;
grid-template-columns:1fr 1fr;
gap:10px;
margin-bottom:20px;
}

button{
background:#28a745;
color:white;
padding:10px 20px;
border:none;
border-radius:5px;
cursor:pointer;
}

button:hover{
background:#218838;
}

</style>

</head>

<body>

<div class="container">

<h2>Update Membership Plan</h2>

<form method="POST" action="update_membership_process.php">

<input type="hidden" name="id" value="<?php echo $data['id']; ?>">

<label>Plan Name</label>
<input type="text" name="plan_name" value="<?php echo $data['plan_name']; ?>" required>

<label>Duration (Days)</label>
<input type="number" name="duration" value="<?php echo $data['duration']; ?>" required>

<label>Price</label>
<input type="number" name="price" value="<?php echo $data['price']; ?>" required>

<label>Description</label>
<textarea name="description"><?php echo $data['description']; ?></textarea>

<label>Features</label>

<div class="features">

<?php
foreach($all_features as $feature){

$checked = in_array($feature,$selected_features) ? "checked" : "";

echo '<label>
<input type="checkbox" name="features[]" value="'.$feature.'" '.$checked.'> '.$feature.'
</label>';

}
?>

</div>

<label>Status</label>
<select name="status">
<option value="active" <?php if($data['status']=="active") echo "selected"; ?>>Active</option>
<option value="inactive" <?php if($data['status']=="inactive") echo "selected"; ?>>Inactive</option>
</select>

<button type="submit">Update Plan</button>

</form>

</div>

</body>
</html>