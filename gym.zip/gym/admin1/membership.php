<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>
<?php include "db.php"; ?>

<?php

if(isset($_POST['add'])){

$name=$_POST['plan_name'];
$duration=$_POST['duration'];
$price=$_POST['price'];
$description=$_POST['description'];
$status=$_POST['status'];

$features = isset($_POST['features']) ? implode(",",$_POST['features']) : "";

mysqli_query($con,"INSERT INTO membership_plans
(plan_name,duration,price,description,features,status)
VALUES
('$name','$duration','$price','$description','$features','$status')");

}

$res=mysqli_query($con,"SELECT * FROM membership_plans");

?>

<div class="card">

<h2>Add Membership Plan</h2>

<form method="post" class="membership-form">

<div class="form-row">

<div class="form-group">
<label>Plan Name</label>
<input type="text" name="plan_name" placeholder="Example: 1 Month Plan" required>
</div>

<div class="form-group">
<label>Duration (Days)</label>
<input type="number" name="duration" placeholder="30" required>
</div>

</div>


<div class="form-row">

<div class="form-group">
<label>Price (₹)</label>
<input type="number" name="price" placeholder="1999" required>
</div>

<div class="form-group">
<label>Status</label>
<select name="status">
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>
</div>

</div>


<div class="form-group">
<label>Description</label>
<textarea name="description" rows="4" placeholder="Write membership description..."></textarea>
</div>


<div class="form-group">

<label>Features</label>

<div class="features-grid">

<label><input type="checkbox" name="features[]" value="Gym Equipment Access"> Gym Equipment Access</label>

<label><input type="checkbox" name="features[]" value="Cardio Section Access"> Cardio Section Access</label>

<label><input type="checkbox" name="features[]" value="Weight Training"> Weight Training</label>

<label><input type="checkbox" name="features[]" value="Locker Facility"> Locker Facility</label>

<label><input type="checkbox" name="features[]" value="Free Diet Plan"> Free Diet Plan</label>

<label><input type="checkbox" name="features[]" value="Personal Trainer"> Personal Trainer</label>

<label><input type="checkbox" name="features[]" value="Group Classes"> Group Classes</label>

<label><input type="checkbox" name="features[]" value="Steam Bath"> Steam Bath</label>

</div>

</div>

<button class="btn-save" name="add">Add Membership Plan</button>

</form>

</div>


<div class="card">

<h2>Membership Plans</h2>

<table>

<tr>
<th>ID</th>
<th>Name</th>
<th>Duration</th>
<th>Price</th>
<th>Description</th>
<th>Features</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($m=mysqli_fetch_assoc($res)){ ?>

<tr>

<td><?= $m['id'] ?></td>

<td><?= $m['plan_name'] ?></td>

<td><?= $m['duration'] ?> Days</td>

<td>₹<?= $m['price'] ?></td>

<td><?= $m['description'] ?></td>

<td>

<?php
$features = explode(",",$m['features']);
foreach($features as $f){
echo "✔ ".$f."<br>";
}
?>

</td>

<td><?= $m['status'] ?></td>

<td>

<a href="membership_edit.php?id=<?= $m['id'] ?>" class="edit-btn">Update</a>

<a href="membership_delete.php?id=<?= $m['id'] ?>" 
class="delete-btn"
onclick="return confirm('Delete this plan?')">
Delete
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

<?php include "footer.php"; ?>