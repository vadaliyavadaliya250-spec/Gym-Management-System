<div class="sidebar">

<h2>ADMIN</h2>

<a href="dashboard.php">Dashboard</a>
<a href="products.php">🛍 All Products</a>
<a href="add_product.php">➕ Add Product</a>
<a href="trainers.php">Add Trainer</a>
<a href="assign_trainer.php">Assign Personal Trainer</a>
<a href="membership.php">Add Membership</a>
<a href="purchase_requests.php">Membership Requests</a>
<a href="batches.php">Manage Batches</a>
<a href="assign_member_batch.php">Assign Members To Batches</a>
<a href="attendance.php">Member Attendance</a>
<a href="trainer_attendance.php">Trainer Attendance</a> 
<a href="admin/contact_messages.php">Contact Messages</a>

</div>

<div class="main">