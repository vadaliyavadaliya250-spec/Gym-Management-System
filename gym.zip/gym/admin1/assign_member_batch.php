<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php

// ASSIGN MEMBER TO BATCH
if(isset($_POST['assign'])){

$member=$_POST['member'];
$batch=$_POST['batch'];

// GET BATCH CAPACITY
$capRes=mysqli_query($con,"SELECT capacity FROM batches WHERE id='$batch'");
$capData=mysqli_fetch_assoc($capRes);
$capacity=$capData['capacity'];

// COUNT CURRENT MEMBERS IN BATCH
$countRes=mysqli_query($con,"SELECT COUNT(*) as total FROM user_details WHERE batch_id='$batch'");
$countData=mysqli_fetch_assoc($countRes);
$current_members=$countData['total'];

if($current_members >= $capacity){

echo "<script>alert('Batch Full! Cannot add more members');</script>";

}else{

mysqli_query($con,"DELETE FROM batch_members WHERE member_id='$member'");
mysqli_query($con,"UPDATE user_details SET batch_id='$batch' WHERE id='$member'");
mysqli_query($con,"INSERT INTO batch_members(batch_id,member_id,joined_at) VALUES('$batch','$member',NOW())");

echo "<script>alert('Member Assigned Successfully');</script>";

}

}

// FETCH MEMBERS
$res=mysqli_query($con,"SELECT user_details.*, batches.batch_name
FROM user_details
LEFT JOIN batches ON user_details.batch_id=batches.id");

?>

<style>

.card{
background:white;
padding:25px;
border-radius:10px;
margin-bottom:30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.form-grid{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
}

input,select{
padding:10px;
border:1px solid #ccc;
border-radius:6px;
width:100%;
}

button{
background:#28a745;
color:white;
border:none;
padding:10px 20px;
border-radius:6px;
cursor:pointer;
}

table{
width:100%;
border-collapse:collapse;
margin-top:20px;
}

th,td{
border:1px solid #ddd;
padding:10px;
text-align:center;
}

th{
background:#f4f4f4;
}

.action-btn{
padding:6px 10px;
border-radius:5px;
text-decoration:none;
color:white;
}

.edit{
background:#007bff;
}

.remove{
background:red;
}

</style>


<div class="card">

<h2>Assign Member To Batch</h2>

<form method="post">

<div class="form-grid">

<select name="member" required>

<option value="">Select Member</option>

<?php
$m=mysqli_query($con,"SELECT * FROM user_details");
while($mem=mysqli_fetch_assoc($m)){
?>

<option value="<?= $mem['id'] ?>"><?= $mem['fullname'] ?></option>

<?php } ?>

</select>


<select name="batch" required>

<option value="">Select Batch</option>

<?php
$b=mysqli_query($con,"SELECT * FROM batches");
while($bat=mysqli_fetch_assoc($b)){
?>

<option value="<?= $bat['id'] ?>"><?= $bat['batch_name'] ?></option>

<?php } ?>

</select>

</div>

<br>

<button name="assign">Assign Batch</button>

</form>

</div>



<div class="card">

<h2>Member Batch List</h2>

<table>

<tr>

<th>ID</th>
<th>Member Name</th>
<th>Batch</th>
<th>Action</th>

</tr>

<?php while($r=mysqli_fetch_assoc($res)){ ?>

<tr>

<td><?= $r['id'] ?></td>

<td><?= $r['fullname'] ?></td>

<td><?= $r['batch_name'] ?></td>

<td>

<a class="action-btn edit" href="edit_member_batch.php?id=<?= $r['id'] ?>">Edit</a>

<a class="action-btn remove" href="remove_member_batch.php?id=<?= $r['id'] ?>">Remove</a>

</td>

</tr>

<?php } ?>

</table>

</div>


<?php include "footer.php"; ?>
