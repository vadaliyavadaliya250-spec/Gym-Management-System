<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php

$id=$_GET['id'];

$res=mysqli_query($con,"SELECT * FROM user_details WHERE id='$id'");
$data=mysqli_fetch_assoc($res);

if(isset($_POST['update'])){

$batch=$_POST['batch'];

mysqli_query($con,"DELETE FROM batch_members WHERE member_id='$id'");
mysqli_query($con,"UPDATE user_details SET batch_id='$batch' WHERE id='$id'");
if(!empty($batch)){
mysqli_query($con,"INSERT INTO batch_members(batch_id,member_id,joined_at) VALUES('$batch','$id',NOW())");
}

header("Location:assign_member_batch.php");

}

?>

<div class="card">

<h2>Edit Member Batch</h2>

<form method="post">

<select name="batch">

<?php
$b=mysqli_query($con,"SELECT * FROM batches");
while($bat=mysqli_fetch_assoc($b)){
?>

<option value="<?= $bat['id'] ?>"
<?php if($data['batch_id']==$bat['id']) echo "selected"; ?>>

<?= $bat['batch_name'] ?>

</option>

<?php } ?>

</select>

<br><br>

<button name="update">Update Batch</button>

</form>

</div>

<?php include "footer.php"; ?>
