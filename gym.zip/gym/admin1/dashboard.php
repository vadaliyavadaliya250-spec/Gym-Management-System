<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<div class="card">
<h2>Dashboard</h2>
<p>Welcome to Gym Admin Panel</p>
</div>

<?php include "footer.php"; ?>