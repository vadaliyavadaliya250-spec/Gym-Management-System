<?php
include "header.php";
include "sidebar.php";
include "db.php";

$id = $_GET['id'];

// FETCH ASSIGNMENT DETAILS
$res = mysqli_query($con, "SELECT at.id, at.member_id, at.trainer_id, 
    ud.fullname, mp.plan_name, t.name as trainer_name, t.specialization
    FROM assign_trainer at
    INNER JOIN user_details ud ON at.member_id = ud.id
    INNER JOIN membership_purchases mp ON ud.id = mp.id
    INNER JOIN trainers t ON at.trainer_id = t.id
    WHERE at.id='$id'");

$assignment = mysqli_fetch_assoc($res);

// FETCH MEMBERS WITH APPROVED MEMBERSHIPS
$members = mysqli_query($con, "
SELECT ud.id, ud.fullname, mp.plan_name
FROM user_details ud
INNER JOIN membership_purchases mp 
ON ud.username = mp.username
WHERE mp.status='approved'
");


// FETCH ACTIVE TRAINERS
$trainers = mysqli_query($con,"
SELECT * 
FROM trainers 
WHERE status='active' AND type='personal'
");
// UPDATE ASSIGNMENT
if(isset($_POST['update'])){
    $member_id = $_POST['member'];
    $trainer_id = $_POST['trainer'];

    mysqli_query($con, "UPDATE assign_trainer SET member_id='$member_id', trainer_id='$trainer_id' WHERE id='$id'");
    echo "<script>alert('Trainer Assignment Updated');window.location='assign_trainer.php';</script>";
}
$id = $_GET['id'];

$result = mysqli_query($con,"
SELECT * FROM assign_trainer WHERE id='$id'
");

$assignment = mysqli_fetch_assoc($result);

if(!$assignment){
    echo "Record not found";
    exit;
}
?>

<div class="card">
    <h2>Edit Trainer Assignment</h2>
    <form method="post">
        <div class="form-row">
            <select name="member" required>
                <option value="">Select Member</option>
                <?php while($m=mysqli_fetch_assoc($members)){ ?>
                    <option value="<?= $m['id'] ?>" <?= ($m['id']==$assignment['member_id'])?'selected':'' ?>>
                        <?= $m['fullname'] ?> - <?= $m['plan_name'] ?>
                    </option>
                <?php } ?>
            </select>

            <select name="trainer" required>
                <option value="">Select Trainer</option>
                <?php while($t=mysqli_fetch_assoc($trainers)){ ?>
                    <option value="<?= $t['id'] ?>" <?= ($t['id']==$assignment['trainer_id'])?'selected':'' ?>>
                        <?= $t['name'] ?> - <?= $t['specialization'] ?>
                    </option>
                <?php } ?>
            </select>

            <button name="update">Update Assignment</button>
        </div>
    </form>
</div>

<?php include "footer.php"; ?>