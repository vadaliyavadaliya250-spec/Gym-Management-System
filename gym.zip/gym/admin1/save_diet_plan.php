<?php
include "db.php";

if(isset($_POST['save'])){

$member=$_POST['member'];
$trainer=$_POST['trainer'];
$goal=$_POST['goal'];
$breakfast=$_POST['breakfast'];
$lunch=$_POST['lunch'];
$snacks=$_POST['snacks'];
$dinner=$_POST['dinner'];
$notes=$_POST['notes'];

mysqli_query($con,"INSERT INTO diet_plans
(member_id,trainer_id,goal,breakfast,lunch,snacks,dinner,notes)
VALUES
('$member','$trainer','$goal','$breakfast','$lunch','$snacks','$dinner','$notes')");

echo "<script>alert('Diet Plan Added');window.location='add_diet_plan.php';</script>";

}
?>