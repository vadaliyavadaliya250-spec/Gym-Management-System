<?php
include "header.php";
include "sidebar.php";
include "db.php";

// ASSIGN TRAINER
if(isset($_POST['assign'])){
    $member_id = $_POST['member'];
    $trainer_id = $_POST['trainer'];

    // CHECK IF MEMBER ALREADY ASSIGNED
    $check = mysqli_query($con,"SELECT * FROM assign_trainer WHERE member_id='$member_id'");

    if(mysqli_num_rows($check) > 0){
        echo "<script>alert('This member already has a trainer assigned');</script>";
    }else{

        mysqli_query($con,"
        INSERT INTO assign_trainer(member_id, trainer_id)
        VALUES('$member_id', '$trainer_id')
        ");

        echo "<script>alert('Trainer Assigned Successfully');</script>";
    }
}

// FETCH MEMBERS WITH APPROVED MEMBERSHIPS
$members = mysqli_query($con,"
SELECT ud.id, ud.fullname, mp.plan_name
FROM user_details ud
JOIN membership_purchases mp 
ON ud.username = mp.username
WHERE mp.status='approved'
GROUP BY ud.id
");


// FETCH TRAINERS
$trainers = mysqli_query($con, "SELECT * FROM trainers WHERE status='active' AND type='personal'");
// FETCH ASSIGNED TRAINERS
$assignments = mysqli_query($con, "SELECT at.id, ud.fullname as member_name, t.name as trainer_name
    FROM assign_trainer at
    INNER JOIN user_details ud ON at.member_id = ud.id
    INNER JOIN trainers t ON at.trainer_id = t.id");


?>

<style>
.card{
    background:white;
    padding:25px;
    border-radius:10px;
    margin-bottom:30px;
    box-shadow:0 2px 10px rgba(0,0,0,0.1);
}
.form-row{
    display:flex;
    gap:20px;
    margin-bottom:20px;
}
select, input{
    padding:10px;
    border:1px solid #ccc;
    border-radius:6px;
    width:200px;
}
button{
    background:#28a745;
    color:white;
    border:none;
    padding:10px 20px;
    border-radius:6px;
    cursor:pointer;
}
table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}
th,td{
    border:1px solid #ddd;
    padding:10px;
    text-align:center;
}
th{
    background:#f4f4f4;
}
</style>

<div class="card">
    <h2>Assign Trainer</h2>
    <form method="post">
        <div class="form-row">
            <select name="member" required>
                <option value="">Select Member</option>
                <?php while($m=mysqli_fetch_assoc($members)){ ?>
                    <option value="<?= $m['id'] ?>"><?= $m['fullname'] ?> - <?= $m['plan_name'] ?></option>
                <?php } ?>
            </select>

            <select name="trainer" required>
                <option value="">Select Trainer</option>
                <?php while($t=mysqli_fetch_assoc($trainers)){ ?>
                    <option value="<?= $t['id'] ?>"><?= $t['name'] ?> - <?= $t['specialization'] ?></option>
                <?php } ?>
            </select>

            <button name="assign">Assign Trainer</button>
        </div>
    </form>
</div>

<div class="card">
    <h2>Assigned Trainers</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Member Name</th>
            <th>Trainer Name</th>
            <th>Actions</th>
        </tr>
        <?php while($a=mysqli_fetch_assoc($assignments)){ ?>
        <tr>
            <td><?= $a['id'] ?></td>
            <td><?= $a['member_name'] ?></td>
            <td><?= $a['trainer_name'] ?></td>
            <td>
                <a href="edit_assign_trainer.php?id=<?= $a['id'] ?>">Edit</a> |
                <a href="delete_assign_trainer.php?id=<?= $a['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>

<?php include "footer.php"; ?>