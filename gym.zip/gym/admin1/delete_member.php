<?php

include "../config.php";

$id=$_GET['id'];

mysqli_query($con,"DELETE FROM members WHERE id='$id'");

header("Location:members.php");

?>