<?php
$conn = mysqli_connect("localhost","root","","gym");

$result = mysqli_query($conn,"
SELECT attendance.*, user_details.name 
FROM attendance
JOIN user_details ON attendance.user_id=user_details.id
ORDER BY date DESC
");
?>

<!DOCTYPE html>
<html>
<head>

<title>Attendance Report</title>

<style>

table{
width:80%;
margin:auto;
border-collapse:collapse;
}

th,td{
padding:12px;
border:1px solid #ccc;
text-align:center;
}

th{
background:#222;
color:white;
}

.present{
color:green;
font-weight:bold;
}

.absent{
color:red;
font-weight:bold;
}

</style>

</head>

<body>

<h2 align="center">Attendance Report</h2>

<table>

<tr>
<th>Member</th>
<th>Date</th>
<th>Status</th>
</tr>

<?php
while($row=mysqli_fetch_assoc($result))
{
?>

<tr>

<td><?php echo $row['name']; ?></td>
<td><?php echo $row['date']; ?></td>

<td class="<?php echo strtolower($row['status']); ?>">
<?php echo $row['status']; ?>
</td>

</tr>

<?php
}
?>

</table>

</body>
</html>