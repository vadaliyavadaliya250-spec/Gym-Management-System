<?php
include "db.php";

$id = $_GET['id'];

mysqli_query($con,"DELETE FROM membership_plans WHERE id='$id'");

header("Location: membership.php");
?>