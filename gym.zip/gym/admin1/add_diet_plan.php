<?php 
include "header.php";
include "sidebar.php";
include "db.php";
?>

<div class="card">
<h2>Create Diet Plan</h2>

<form method="post" action="save_diet_plan.php">

<select name="member" required>
<option value="">Select Member</option>

<?php
$m=mysqli_query($con,"SELECT ud.id,ud.fullname 
FROM user_details ud
JOIN assign_trainer at ON ud.id=at.member_id");

while($mem=mysqli_fetch_assoc($m)){
?>

<option value="<?= $mem['id'] ?>">
<?= $mem['fullname'] ?>
</option>

<?php } ?>

</select>


<select name="trainer" required>

<option value="">Select Personal Trainer</option>

<?php
$t=mysqli_query($con,"SELECT * FROM trainers 
WHERE type='personal' AND status='active'");

while($tr=mysqli_fetch_assoc($t)){
?>

<option value="<?= $tr['id'] ?>">
<?= $tr['name'] ?>
</option>

<?php } ?>

</select>


<input type="text" name="goal" placeholder="Goal (Weight Loss / Muscle Gain)">

<textarea name="breakfast" placeholder="Breakfast"></textarea>

<textarea name="lunch" placeholder="Lunch"></textarea>

<textarea name="snacks" placeholder="Snacks"></textarea>

<textarea name="dinner" placeholder="Dinner"></textarea>

<textarea name="notes" placeholder="Extra Notes"></textarea>

<br><br>

<button type="submit" name="save">Save Diet Plan</button>

</form>
</div>

<?php include "footer.php"; ?>