<?php

include "db.php";

$id=$_GET['id'];

mysqli_query($con,"DELETE FROM trainers WHERE id='$id'");

header("Location:trainers.php");

?>