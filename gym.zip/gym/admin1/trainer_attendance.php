<?php 
include "header.php";
include "sidebar.php";
include "db.php";

// Save Attendance
if(isset($_POST['save_attendance'])){

$date = $_POST['date'];
$type = $_POST['trainer_type'];
$batch_id = $_POST['batch'] ?? 0;

$ids = $_POST['status'] ?? [];

foreach($ids as $trainer_id => $status){

// check if attendance already exists
$check = mysqli_query($con,"SELECT * FROM trainer_attendance 
WHERE trainer_id='$trainer_id' AND date='$date'");

if(mysqli_num_rows($check) == 0){

mysqli_query($con,"INSERT INTO trainer_attendance(trainer_id,batch_id,date,status,entity_type)
VALUES('$trainer_id','$batch_id','$date','$status','$type')");

}else{

mysqli_query($con,"UPDATE trainer_attendance
SET status='$status'
WHERE trainer_id='$trainer_id' AND date='$date'");

}

}

echo "<div style='color:green;'>Attendance Saved Successfully!</div>";
}
?>

<div class="card">
    <h2>Trainer Attendance</h2>

    <form method="post">
        <div class="form-row">
            <select name="trainer_type" required id="trainer_type" onchange="toggleBatch()">
                <option value="">Select Trainer Type</option>
                <option value="batch">Batch Trainer</option>
                <option value="personal">Personal Trainer</option>
            </select>

            <select name="batch" id="batch_select">
                <option value="">Select Batch</option>
                <?php
                $batches = mysqli_query($con,"SELECT * FROM batches");
                while($b = mysqli_fetch_assoc($batches)){
                    echo "<option value='{$b['id']}'>{$b['batch_name']}</option>";
                }
                ?>
            </select>

            <input type="date" name="date" required>
            <button type="submit" name="load_trainers">Load Trainers</button>
        </div>
    </form>
</div>

<?php
if(isset($_POST['load_trainers'])){
    $type = $_POST['trainer_type'];
    $batch = $_POST['batch'];
    $date = $_POST['date'];

    if($type == 'batch'){
        $trainers = mysqli_query($con,"SELECT t.* FROM trainers t
            JOIN batches b ON b.id = '$batch' 
            WHERE t.type='batch'");
    } else {
        // personal trainers assigned to members
        $trainers = mysqli_query($con,"SELECT DISTINCT t.* 
            FROM trainers t
            JOIN assign_trainer at ON t.id = at.trainer_id
            WHERE t.type='personal'");
    }
?>

<div class="card">
    <h3>Mark Attendance (<?= ucfirst($type) ?> Trainers)</h3>

    <form method="post">
        <input type="hidden" name="trainer_type" value="<?= $type ?>">
        <input type="hidden" name="batch" value="<?= $batch ?>">
        <input type="hidden" name="date" value="<?= $date ?>">

        <table>
            <tr>
                <th>ID</th>
                <th>Trainer Name</th>
                <th>Present</th>
                <th>Absent</th>
            </tr>

            <?php while($t = mysqli_fetch_assoc($trainers)){ ?>
                <tr>
                    <td><?= $t['id'] ?></td>
                    <td><?= $t['name'] ?></td>
                    <td><input type="radio" name="status[<?= $t['id'] ?>]" value="Present" required></td>
                    <td><input type="radio" name="status[<?= $t['id'] ?>]" value="Absent"></td>
                </tr>
            <?php } ?>
        </table>
        <br>
        <button type="submit" name="save_attendance">Save Attendance</button>
    </form>
</div>

<?php } ?>

<script>
function toggleBatch(){
    var type = document.getElementById('trainer_type').value;
    var batchSelect = document.getElementById('batch_select');
    if(type == 'batch'){
        batchSelect.style.display = 'inline-block';
        batchSelect.required = true;
    } else {
        batchSelect.style.display = 'none';
        batchSelect.required = false;
    }
}
window.onload = toggleBatch;
</script>

<?php include "footer.php"; ?>