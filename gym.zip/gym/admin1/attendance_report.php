<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>
<?php include "db.php"; ?>

<style>

.card{
background:white;
padding:25px;
border-radius:10px;
margin-bottom:30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

table{
width:100%;
border-collapse:collapse;
}

th,td{
border:1px solid #ddd;
padding:10px;
text-align:center;
}

th{
background:#f4f4f4;
}

.present{
color:green;
font-weight:bold;
}

.absent{
color:red;
font-weight:bold;
}

</style>

<div class="card">

<h2>Attendance Report</h2>

<table>

<tr>

<th>ID</th>
<th>Member</th>
<th>Batch</th>
<th>Date</th>
<th>Status</th>

</tr>

<?php

$q=mysqli_query($con,"SELECT attendance.*,user_details.fullname,batches.batch_name
FROM attendance
JOIN user_details ON attendance.member_id=user_details.id
JOIN batches ON attendance.batch_id=batches.id
ORDER BY date DESC");

while($row=mysqli_fetch_assoc($q)){

?>

<tr>

<td><?= $row['id'] ?></td>

<td><?= $row['fullname'] ?></td>

<td><?= $row['batch_name'] ?></td>

<td><?= $row['date'] ?></td>

<td class="<?= strtolower($row['status']) ?>"><?= $row['status'] ?></td>

</tr>

<?php } ?>

</table>

</div>

<?php include "footer.php"; ?>