<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php

$id=$_GET['id'];

$res=mysqli_query($con,"SELECT * FROM batches WHERE id='$id'");
$data=mysqli_fetch_assoc($res);

if(isset($_POST['update_batch'])){

$name=$_POST['batch_name'];
$trainer=$_POST['trainer'];
$start=$_POST['start'];
$end=$_POST['end'];
$capacity=$_POST['capacity'];

mysqli_query($con,"UPDATE batches SET
batch_name='$name',
trainer_id='$trainer',
start_time='$start',
end_time='$end',
capacity='$capacity'
WHERE id='$id'");

header("Location:batches.php");

}

?>

<style>

.card{
background:white;
padding:25px;
border-radius:10px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.form-grid{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
}

input,select{
padding:10px;
border:1px solid #ccc;
border-radius:6px;
width:100%;
}

button{
background:#007bff;
color:white;
border:none;
padding:10px 20px;
border-radius:6px;
cursor:pointer;
}

</style>


<div class="card">

<h2>Edit Batch</h2>

<form method="post">

<div class="form-grid">

<input type="text" name="batch_name" value="<?= $data['batch_name'] ?>">

<select name="trainer">

<?php
$t=mysqli_query($con,"SELECT * FROM trainers");
while($tr=mysqli_fetch_assoc($t)){
?>

<option value="<?= $tr['id'] ?>" 
<?php if($data['trainer_id']==$tr['id']) echo "selected"; ?>>

<?= $tr['name'] ?>

</option>

<?php } ?>

</select>

<input type="time" name="start" value="<?= $data['start_time'] ?>">

<input type="time" name="end" value="<?= $data['end_time'] ?>">

<input type="number" name="capacity" value="<?= $data['capacity'] ?>">

</div>

<br>

<button name="update_batch">Update Batch</button>

</form>

</div>

<?php include "footer.php"; ?>