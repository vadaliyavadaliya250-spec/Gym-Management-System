<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>

<title>Gym Admin Panel</title>

<style>

body{
margin:0;
font-family:Arial;
background:#f4f6f9;
}

.sidebar{
width:220px;
height:100vh;
background:#111;
position:fixed;
}

.sidebar h2{
color:white;
text-align:center;
padding:20px;
border-bottom:1px solid #444;
}

.sidebar a{
display:block;
color:white;
padding:15px;
text-decoration:none;
border-bottom:1px solid #333;
}

.sidebar a:hover{
background:#ff6600;
}

.main{
margin-left:220px;
padding:30px;
}

.card{
background:white;
padding:20px;
border-radius:5px;
box-shadow:0 2px 5px rgba(0,0,0,0.1);
margin-bottom:20px;
}

table{
width:100%;
border-collapse:collapse;
}

table th,table td{
padding:10px;
border:1px solid #ddd;
}

button{
padding:8px 15px;
background:#ff6600;
border:none;
color:white;
cursor:pointer;
}

input,select{
padding:8px;
margin:5px;
}

.membership-form{
margin-top:20px;
}

.form-row{
display:flex;
gap:20px;
margin-bottom:15px;
}

.form-group{
flex:1;
display:flex;
flex-direction:column;
}

.form-group label{
font-weight:bold;
margin-bottom:5px;
}

.form-group input,
.form-group select,
.form-group textarea{
padding:10px;
border:1px solid #ddd;
border-radius:6px;
font-size:14px;
}

.features-grid{
display:grid;
grid-template-columns:repeat(2,1fr);
gap:8px;
margin-top:10px;
}

.btn-save{
margin-top:15px;
padding:10px 18px;
background:#ff6600;
color:white;
border:none;
border-radius:6px;
font-size:15px;
cursor:pointer;
}

.btn-save:hover{
background:#e65c00;
}



.sidebar{
width:230px;
height:100vh;
background:#111;
color:white;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;   /* aa line scroll mate */
}

.sidebar h2{
margin-bottom:20px;
}

.sidebar a{
display:block;
color:white;
text-decoration:none;
padding:10px;
margin-bottom:5px;
border-radius:5px;
}

.sidebar a:hover{
background:#333;
}

.main{
margin-left:250px;
padding:20px;
}
</style>

</head>

<body>