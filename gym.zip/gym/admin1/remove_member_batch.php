<?php

include "db.php";   // correct file include

$id=$_GET['id'];

mysqli_query($con,"DELETE FROM batch_members WHERE member_id='$id'");
mysqli_query($con,"UPDATE user_details SET batch_id=NULL WHERE id='$id'");

header("Location:assign_member_batch.php");

?>
