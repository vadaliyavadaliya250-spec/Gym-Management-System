<?php

include "../config.php";

$id=$_GET['id'];

mysqli_query($con,"DELETE FROM batches WHERE id='$id'");

header("Location:batches.php");

?>