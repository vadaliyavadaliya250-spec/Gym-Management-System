<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>
<?php include "db.php"; ?>

<?php
// SAVE ATTENDANCE
if(isset($_POST['save_attendance'])){

    $date = $_POST['date'];
    $batch = $_POST['batch'];

    foreach($_POST['status'] as $member_id => $status){
        // Check if attendance already exists for same date & member
        $check = mysqli_query($con,"SELECT * FROM attendance WHERE member_id='$member_id' AND date='$date'");
        if(mysqli_num_rows($check) > 0){
            // Update existing record
            mysqli_query($con,"UPDATE attendance SET status='$status', batch_id='$batch' WHERE member_id='$member_id' AND date='$date'");
        } else {
            // Insert new record
            mysqli_query($con,"INSERT INTO attendance(member_id,batch_id,date,status)
            VALUES('$member_id','$batch','$date','$status')");
        }
    }

    echo "<h3 style='text-align:center;color:green;'>Attendance saved successfully</h3>";
}
?>

<style>
.card{
    background:white;
    padding:25px;
    border-radius:10px;
    margin-bottom:30px;
    box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.form-row{
    display:flex;
    gap:20px;
    margin-bottom:20px;
}

select,input{
    padding:10px;
    border:1px solid #ccc;
    border-radius:6px;
    width:200px;
}

button{
    background:#28a745;
    color:white;
    border:none;
    padding:10px 20px;
    border-radius:6px;
    cursor:pointer;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}

th,td{
    border:1px solid #ddd;
    padding:10px;
    text-align:center;
}

th{
    background:#f4f4f4;
}
</style>

<div class="card">
<h2>Attendance</h2>

<form method="post">
<div class="form-row">

<select name="batch" required>
<option value="">Select Batch</option>
<?php
$batches = mysqli_query($con,"SELECT * FROM batches");
while($batch=mysqli_fetch_assoc($batches)){
?>
<option value="<?= $batch['id'] ?>"><?= $batch['batch_name'] ?></option>
<?php } ?>
</select>

<input type="date" name="date" required>

<button name="load_members">Load Members</button>

</div>
</form>
</div>

<?php
// LOAD MEMBERS FORM
if(isset($_POST['load_members'])){

    $batch = $_POST['batch'];
    $date = $_POST['date'];

    $members = mysqli_query($con,"SELECT * FROM user_details WHERE batch_id='$batch'");
?>

<div class="card">
<h3>Mark Attendance</h3>

<form method="post">

<input type="hidden" name="batch" value="<?= $batch ?>">
<input type="hidden" name="date" value="<?= $date ?>">

<table>
<tr>
<th>ID</th>
<th>Member Name</th>
<th>Present</th>
<th>Absent</th>
</tr>

<?php while($m = mysqli_fetch_assoc($members)){ ?>

<tr>
<td><?= $m['id'] ?></td>
<td><?= $m['fullname'] ?></td>
<td>
<input type="radio" name="status[<?= $m['id'] ?>]" value="Present" required>
</td>
<td>
<input type="radio" name="status[<?= $m['id'] ?>]" value="Absent">
</td>
</tr>

<?php } ?>

</table>
<br>
<button name="save_attendance">Save Attendance</button>

</form>
</div>

<?php } ?>



<?php include "footer.php"; ?>