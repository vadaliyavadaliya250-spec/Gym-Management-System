<?php

$conn = mysqli_connect("localhost","root","","gym");

$id = $_POST['id'];
$plan_name = $_POST['plan_name'];
$duration = $_POST['duration'];
$price = $_POST['price'];
$description = $_POST['description'];
$status = $_POST['status'];

$features = implode(",", $_POST['features']);

$query = "UPDATE membership_plans SET 
plan_name='$plan_name',
duration='$duration',
price='$price',
description='$description',
features='$features',
status='$status'
WHERE id='$id'";

mysqli_query($conn,$query);

header("Location: membership.php");

?>