<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php

$id=$_GET['id'];

$res=mysqli_query($con,"SELECT * FROM trainers WHERE id='$id'");
$t=mysqli_fetch_assoc($res);

if(isset($_POST['update'])){

$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$gender=$_POST['gender'];
$specialization=$_POST['specialization'];
$experience=$_POST['experience'];
$address=$_POST['address'];
$username=$_POST['username'];
$password=$_POST['password'];
$status=$_POST['status'];

mysqli_query($con,"UPDATE trainers SET
name='$name',
email='$email',
phone='$phone',
gender='$gender',
specialization='$specialization',
experience='$experience',
address='$address',
username='$username',
password='$password',
status='$status'
WHERE id='$id'");

header("Location:trainers.php");

}

?>

<div class="card">

<h2>Edit Trainer</h2>

<form method="post">

<div class="form-grid">

<div class="form-group">
<label>Name</label>
<input type="text" name="name" value="<?= $t['name'] ?>">
</div>

<div class="form-group">
<label>Email</label>
<input type="email" name="email" value="<?= $t['email'] ?>">
</div>

<div class="form-group">
<label>Phone</label>
<input type="text" name="phone" value="<?= $t['phone'] ?>">
</div>

<div class="form-group">
<label>Gender</label>
<select name="gender">
<option <?= $t['gender']=="Male"?"selected":"" ?>>Male</option>
<option <?= $t['gender']=="Female"?"selected":"" ?>>Female</option>
</select>
</div>

<div class="form-group">
<label>Specialization</label>
<input type="text" name="specialization" value="<?= $t['specialization'] ?>">
</div>

<div class="form-group">
<label>Experience</label>
<input type="number" name="experience" value="<?= $t['experience'] ?>">
</div>

<div class="form-group">
<label>Username</label>
<input type="text" name="username" value="<?= $t['username'] ?>">
</div>

<div class="form-group">
<label>Password</label>
<input type="text" name="password" value="<?= $t['password'] ?>">
</div>

<div class="form-group">
<label>Status</label>
<select name="status">
<option value="active" <?= $t['status']=="active"?"selected":"" ?>>Active</option>
<option value="inactive" <?= $t['status']=="inactive"?"selected":"" ?>>Inactive</option>
</select>
</div>

<div class="form-group">
<label>Address</label>
<textarea name="address"><?= $t['address'] ?></textarea>
</div>

</div>

<button class="btn" name="update">Update Trainer</button>

</form>

</div>

<?php include "footer.php"; ?>