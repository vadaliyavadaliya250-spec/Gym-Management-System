<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>
<?php include "db.php"; ?>

<?php

/* APPROVE */
if(isset($_GET['approve'])){
    $id = (int)$_GET['approve'];
    $approve_user = '';
    $rq = mysqli_query($con,"SELECT username FROM membership_purchases WHERE id='$id' LIMIT 1");
    if($rq && mysqli_num_rows($rq) > 0){
        $approve_row = mysqli_fetch_assoc($rq);
        $approve_user = trim((string)($approve_row['username'] ?? ''));
    }

    mysqli_query($con,"UPDATE membership_purchases SET status='approved' WHERE id='$id'");

    // Keep legacy user_memberships status in sync when available.
    if($approve_user !== ''){
        $um_tbl = mysqli_query($con, "SHOW TABLES LIKE 'user_memberships'");
        if($um_tbl && mysqli_num_rows($um_tbl) > 0){
            $u = mysqli_real_escape_string($con, $approve_user);
            $uq = mysqli_query($con, "SELECT id FROM user_table WHERE username='$u' LIMIT 1");
            if($uq && mysqli_num_rows($uq) > 0){
                $uid = (int)(mysqli_fetch_assoc($uq)['id'] ?? 0);
                if($uid > 0){
                    mysqli_query($con,"UPDATE user_memberships SET status='approved' WHERE user_id='$uid' AND status IN ('pending','cancelled','canceled') ORDER BY id DESC LIMIT 1");
                }
            }
        }
    }

    header("Location: purchase_requests.php");
}

/* CANCEL */
if(isset($_GET['cancel'])){
    $id = (int)$_GET['cancel'];
    $cancel_user = '';
    $rq = mysqli_query($con,"SELECT username FROM membership_purchases WHERE id='$id' LIMIT 1");
    if($rq && mysqli_num_rows($rq) > 0){
        $cancel_row = mysqli_fetch_assoc($rq);
        $cancel_user = trim((string)($cancel_row['username'] ?? ''));
    }

    mysqli_query($con,"UPDATE membership_purchases SET status='cancelled' WHERE id='$id'");

    // Remove free items entry for this cancelled membership request.
    mysqli_query($con,"DELETE FROM free_membership_items WHERE purchase_id='$id'");

    // Keep legacy user_memberships status in sync when available.
    if($cancel_user !== ''){
        $um_tbl = mysqli_query($con, "SHOW TABLES LIKE 'user_memberships'");
        if($um_tbl && mysqli_num_rows($um_tbl) > 0){
            $u = mysqli_real_escape_string($con, $cancel_user);
            $uq = mysqli_query($con, "SELECT id FROM user_table WHERE username='$u' LIMIT 1");
            if($uq && mysqli_num_rows($uq) > 0){
                $uid = (int)(mysqli_fetch_assoc($uq)['id'] ?? 0);
                if($uid > 0){
                    mysqli_query($con,"UPDATE user_memberships SET status='cancelled' WHERE user_id='$uid' AND status='approved'");
                }
            }
        }
    }

    header("Location: purchase_requests.php");
}

?>

<h2>Membership Purchase Requests</h2>

<table>

<tr>
<th>ID</th>
<th>Plan</th>
<th>Amount</th>
<th>Transaction</th>
<th>Status</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php
$res = mysqli_query($con,"SELECT * FROM membership_purchases ORDER BY id DESC");

while($row = mysqli_fetch_assoc($res)){
?>

<tr>

<td><?= $row['id'] ?></td>
<td><?= $row['plan_name'] ?></td>
<td>₹<?= $row['amount'] ?></td>
<td><?= $row['txn'] ?></td>

<td>
<?php
if($row['status']=="approved"){
    echo "<span style='color:green'>Approved</span>";
}
elseif($row['status']=="cancelled"){
    echo "<span style='color:red'>Cancelled</span>";
}
else{
    echo "<span style='color:orange'>Pending</span>";
}
?>
</td>

<td><?= $row['purchase_date'] ?></td>

<td>
<?php if($row['status']=="pending"): ?>
<a href="?approve=<?= $row['id'] ?>" 
style="background:green;color:white;padding:6px 12px;text-decoration:none;border-radius:4px">
Approve
</a>
<a href="?cancel=<?= $row['id'] ?>" 
style="background:red;color:white;padding:6px 12px;text-decoration:none;border-radius:4px"
onclick="return confirm('Cancel this request?')">
Cancel
</a>
<?php elseif($row['status']=="approved"): ?>
<a href="?cancel=<?= $row['id'] ?>" 
style="background:red;color:white;padding:6px 12px;text-decoration:none;border-radius:4px"
onclick="return confirm('Cancel this approved membership?')">
Cancel
</a>
<?php elseif($row['status']=="cancelled"): ?>
<a href="?approve=<?= $row['id'] ?>" 
style="background:green;color:white;padding:6px 12px;text-decoration:none;border-radius:4px"
onclick="return confirm('Approve this cancelled membership again?')">
Approve
</a>
<?php else: ?>
<span style="color:#aaa;font-size:12px;">Done</span>
<?php endif; ?>

</td>

</tr>

<?php } ?>

</table>

<?php include "footer.php"; ?>
