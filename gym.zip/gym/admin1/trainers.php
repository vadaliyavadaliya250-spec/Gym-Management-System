<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php
if(isset($_POST['add'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $specialization = $_POST['specialization'];
    $experience = $_POST['experience'];
    $address = $_POST['address'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $status = $_POST['status'];
    $type = $_POST['type']; // NEW FIELD

    mysqli_query($con, "INSERT INTO trainers(name,email,phone,gender,specialization,experience,address,username,password,type,status,created_at)
    VALUES('$name','$email','$phone','$gender','$specialization','$experience','$address','$username','$password','$type','$status',NOW())");
}

$res=mysqli_query($con,"SELECT * FROM trainers");
?>

<style>
/* Form & Card */
.card{
    background:white;
    padding:25px;
    margin:20px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}
.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}
.form-group{
    display:flex;
    flex-direction:column;
}
.form-group label{
    font-weight:bold;
    margin-bottom:5px;
}
.form-group input,
.form-group select,
.form-group textarea{
    padding:10px;
    border:1px solid #ccc;
    border-radius:5px;
}
textarea{
    resize:none;
    height:70px;
}
.btn{
    margin-top:20px;
    padding:10px 20px;
    background:#007bff;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

/* Table */
.table-container{
    width:100%;
    overflow-x:auto;
}
table{
    width:100%;
    min-width:1000px;
    border-collapse:collapse;
    margin-top:20px;
    background:white;
}
table th{
    background:#f5f5f5;
    padding:12px;
    border:1px solid #ddd;
    text-align:center;
}
table td{
    padding:10px;
    border:1px solid #ddd;
    text-align:center;
}
.action{
    display:flex;
    justify-content:center;
    gap:10px;
}
.action a{
    padding:6px 12px;
    text-decoration:none;
    color:white;
    border-radius:4px;
    font-size:14px;
}
.edit{background:#28a745;}
.delete{background:#dc3545;}
.card-header{
    margin-bottom:15px;
}
.card-header h2{
    margin:0;
    font-size:22px;
}
.card-header p{
    margin:5px 0 0;
    color:#777;
    font-size:14px;
}
</style>

<div class="card">
    <h2>Add Trainer</h2>
    <form method="post">
        <div class="form-grid">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" required>
            </div>
            <div class="form-group">
                <label>Gender</label>
                <select name="gender" required>
                    <option value="">Select Gender</option>
                    <option>Male</option>
                    <option>Female</option>
                </select>
            </div>
            <div class="form-group">
                <label>Specialization</label>
                <input type="text" name="specialization">
            </div>
            <div class="form-group">
                <label>Experience (Years)</label>
                <input type="number" name="experience">
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <div class="form-group">
                <label>Address</label>
                <textarea name="address"></textarea>
            </div>
            <div class="form-group">
                <label>Trainer Type</label>
                <select name="type" required>
                    <option value="">Select Type</option>
                    <option value="personal">Personal Trainer</option>
                    <option value="batch">Batch Trainer</option>
                </select>
            </div>
        </div>
        <button class="btn" name="add">Add Trainer</button>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2>Trainer List</h2>
        <p>All registered gym trainers information</p>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Gender</th>
                    <th>Specialization</th>
                    <th>Experience</th>
                    <th>Username</th>
                    <th>Status</th>
                    <th>Type</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($t=mysqli_fetch_assoc($res)){ ?>
                <tr>
                    <td><?= $t['id'] ?></td>
                    <td><?= $t['name'] ?></td>
                    <td><?= $t['email'] ?></td>
                    <td><?= $t['phone'] ?></td>
                    <td><?= $t['gender'] ?></td>
                    <td><?= $t['specialization'] ?></td>
                    <td><?= $t['experience'] ?></td>
                    <td><?= $t['username'] ?></td>
                    <td><?= $t['status'] ?></td>
                    <td><?= ucfirst($t['type']) ?></td> <!-- Display type -->
                    <td class="action">
                        <a class="edit" href="edit_trainer.php?id=<?= $t['id'] ?>">Edit</a>
                        <a class="delete" href="delete_trainer.php?id=<?= $t['id'] ?>">Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<?php include "footer.php"; ?>