<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php

// ADD MEMBER
if(isset($_POST['add_member'])){

$username=$_POST['username'];
$fullname=$_POST['fullname'];
$age=$_POST['age'];
$gender=$_POST['gender'];
$height=$_POST['height'];
$weight=$_POST['weight'];
$medical=$_POST['medical'];
$batch=$_POST['batch'];

$photo=$_FILES['photo']['name'];
$tmp=$_FILES['photo']['tmp_name'];

$path="uploads/".time()."_".$photo;

move_uploaded_file($tmp,$path);

mysqli_query($con,"INSERT INTO user_details(username,fullname,age,gender,height,weight,medical,photo,batch_id)
VALUES('$username','$fullname','$age','$gender','$height','$weight','$medical','$path','$batch')");

}

// GET MEMBERS
$res=mysqli_query($con,"SELECT user_details.*, batches.batch_name 
FROM user_details 
LEFT JOIN batches ON user_details.batch_id=batches.id");

?>

<style>

.card{
background:white;
padding:25px;
border-radius:10px;
margin-bottom:30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.form-grid{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
}

input,select{
padding:10px;
border:1px solid #ccc;
border-radius:6px;
width:100%;
}

button{
background:#28a745;
color:white;
border:none;
padding:10px 20px;
border-radius:6px;
cursor:pointer;
}

table{
width:100%;
border-collapse:collapse;
margin-top:20px;
}

th,td{
padding:10px;
border:1px solid #ddd;
text-align:center;
}

th{
background:#f4f4f4;
}

.action-btn{
padding:6px 10px;
border-radius:5px;
text-decoration:none;
color:white;
}

.edit{
background:#007bff;
}

.delete{
background:red;
}

img{
width:60px;
height:60px;
object-fit:cover;
border-radius:6px;
}

</style>


<div class="card">

<h2>Add Member</h2>

<form method="post" enctype="multipart/form-data">

<div class="form-grid">

<input type="text" name="username" placeholder="Username" required>

<input type="text" name="fullname" placeholder="Full Name" required>

<input type="number" name="age" placeholder="Age">

<select name="gender">
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>

<input type="text" name="height" placeholder="Height">

<input type="text" name="weight" placeholder="Weight">

<input type="text" name="medical" placeholder="Medical Issue">

<select name="batch">

<option value="">Select Batch</option>

<?php
$batches=mysqli_query($con,"SELECT * FROM batches");
while($b=mysqli_fetch_assoc($batches)){
?>

<option value="<?= $b['id'] ?>"><?= $b['batch_name'] ?></option>

<?php } ?>

</select>

<input type="file" name="photo">

</div>

<br>

<button name="add_member">Add Member</button>

</form>

</div>



<div class="card">

<h2>Member List</h2>

<table>

<tr>

<th>ID</th>
<th>Photo</th>
<th>Username</th>
<th>Name</th>
<th>Age</th>
<th>Gender</th>
<th>Height</th>
<th>Weight</th>
<th>Medical</th>
<th>Batch</th>
<th>Action</th>

</tr>

<?php while($m=mysqli_fetch_assoc($res)){ ?>

<tr>

<td><?= $m['id'] ?></td>

<td>
<img src="<?= $m['photo'] ?>">
</td>

<td><?= $m['username'] ?></td>

<td><?= $m['fullname'] ?></td>

<td><?= $m['age'] ?></td>

<td><?= $m['gender'] ?></td>

<td><?= $m['height'] ?></td>

<td><?= $m['weight'] ?></td>

<td><?= $m['medical'] ?></td>

<td><?= $m['batch_name'] ?></td>

<td>

<a class="action-btn edit" href="edit_member.php?id=<?= $m['id'] ?>">Edit</a>

<a class="action-btn delete" href="delete_member.php?id=<?= $m['id'] ?>">Delete</a>

</td>

</tr>

<?php } ?>

</table>

</div>


<?php include "footer.php"; ?>