<?php
// get_category_attributes.php — AJAX: returns attributes + values for a category
include "db.php";
header('Content-Type: application/json');

$category_id = (int)($_GET['category_id'] ?? 0);
if(!$category_id){ echo json_encode(['attributes' => []]); exit; }

$res = mysqli_query($con,"
    SELECT at.id, at.attribute_name, at.attribute_key, at.unit_label, at.input_type
    FROM category_attributes ca
    JOIN product_attribute_types at ON at.id = ca.attribute_id
    WHERE ca.category_id='$category_id'
    ORDER BY at.id
");
$attributes = [];
while($row = mysqli_fetch_assoc($res)){
    $vres = mysqli_query($con,"SELECT id, value_label FROM attribute_values WHERE attribute_id='{$row['id']}' ORDER BY sort_order, value_label");
    $row['values'] = [];
    while($vr = mysqli_fetch_assoc($vres)) $row['values'][] = $vr;
    $attributes[] = $row;
}
echo json_encode(['attributes' => $attributes]);
