<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php

// ADD BATCH
if(isset($_POST['add_batch'])){

$batch_name=$_POST['batch_name'];
$trainer=$_POST['trainer'];
$start=$_POST['start'];
$end=$_POST['end'];
$capacity=$_POST['capacity'];

mysqli_query($con,"INSERT INTO batches(batch_name,trainer_id,start_time,end_time,capacity)
VALUES('$batch_name','$trainer','$start','$end','$capacity')");

}

// FETCH BATCH
$res=mysqli_query($con,"SELECT batches.*, trainers.name 
FROM batches 
LEFT JOIN trainers ON batches.trainer_id=trainers.id");

?>

<style>

.card{
background:white;
padding:25px;
border-radius:10px;
margin-bottom:30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.form-grid{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
}

input,select{
padding:10px;
border:1px solid #ccc;
border-radius:6px;
width:100%;
}

button{
background:#28a745;
color:white;
border:none;
padding:10px 20px;
border-radius:6px;
cursor:pointer;
}

table{
width:100%;
border-collapse:collapse;
margin-top:20px;
}

th,td{
border:1px solid #ddd;
padding:10px;
text-align:center;
}

th{
background:#f4f4f4;
}

.action-btn{
padding:6px 10px;
border-radius:5px;
color:white;
text-decoration:none;
}

.edit{
background:#007bff;
}

.delete{
background:red;
}

</style>


<div class="card">

<h2>Add Batch</h2>

<form method="post">

<div class="form-grid">

<input type="text" name="batch_name" placeholder="Batch Name" required>

<select name="trainer">

<option value="">Select Trainer</option>

<?php
$t=mysqli_query($con,"SELECT * FROM trainers WHERE type='batch' AND status='active'");
while($tr=mysqli_fetch_assoc($t)){
?>

<option value="<?= $tr['id'] ?>"><?= $tr['name'] ?></option>

<?php } ?>

</select>

<input type="time" name="start">

<input type="time" name="end">

<input type="number" name="capacity" placeholder="Batch Capacity">

</div>

<br>

<button name="add_batch">Add Batch</button>

</form>

</div>



<div class="card">

<h2>Batch List</h2>

<table>

<tr>

<th>ID</th>
<th>Batch Name</th>
<th>Trainer</th>
<th>Start Time</th>
<th>End Time</th>
<th>Capacity</th>
<th>Action</th>

</tr>

<?php while($b=mysqli_fetch_assoc($res)){ ?>

<tr>

<td><?= $b['id'] ?></td>
<td><?= $b['batch_name'] ?></td>
<td><?= $b['name'] ?></td>
<td><?= $b['start_time'] ?></td>
<td><?= $b['end_time'] ?></td>
<td><?= $b['capacity'] ?></td>

<td>

<a class="action-btn edit" href="edit_batch.php?id=<?= $b['id'] ?>">Edit</a>

<a class="action-btn delete" href="delete_batch.php?id=<?= $b['id'] ?>">Delete</a>

</td>

</tr>

<?php } ?>

</table>

</div>


<?php include "footer.php"; ?>