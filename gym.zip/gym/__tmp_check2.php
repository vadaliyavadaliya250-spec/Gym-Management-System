﻿<?php
$con = mysqli_connect('localhost','root','','gym');
if(!$con){ die('db fail'); }

$db = mysqli_fetch_row(mysqli_query($con, "SELECT DATABASE()"))[0] ?? '';
$cols = [];
$q = mysqli_query($con, "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='".mysqli_real_escape_string($con,$db)."' AND TABLE_NAME='orders' ORDER BY ORDINAL_POSITION");
while($r=mysqli_fetch_assoc($q)){ $cols[] = $r['COLUMN_NAME']; }
echo "orders columns: ".implode(', ', $cols)."\n\n";

if(in_array('items',$cols)){
    $q2 = mysqli_query($con, "SELECT id, user_id, status, created_at, items FROM orders ORDER BY id DESC LIMIT 15");
    while($r=mysqli_fetch_assoc($q2)){
        echo "order #".$r['id']." uid=".$r['user_id']." status=".$r['status']." created=".$r['created_at']."\n";
        $items = json_decode((string)$r['items'], true);
        if(is_array($items)){
            $i=0;
            foreach($items as $it){
                $i++;
                if($i>3){ echo "  ...\n"; break; }
                echo "  item{$i}: name=".($it['name'] ?? '')." | image=".($it['image'] ?? '')." | qty=".($it['qty'] ?? '')." | price=".($it['price'] ?? '')."\n";
            }
        } else {
            echo "  items: (invalid json)\n";
        }
    }
}
?>
