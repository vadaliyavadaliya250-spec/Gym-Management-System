﻿<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "gym");
if (!$conn) {
    http_response_code(500);
    die("Connection Failed");
}
mysqli_set_charset($conn, "utf8mb4");

/*
|--------------------------------------------------------------------------
| Razorpay Test Mode Configuration
|--------------------------------------------------------------------------
| Replace these with your Razorpay TEST keys.
| Dashboard -> Settings -> API Keys -> Generate Test Key.
*/
const RAZORPAY_TEST_KEY_ID = "rzp_test_SY54Vjs4v4dVyD";
const RAZORPAY_TEST_KEY_SECRET = "vQ4uk12u6LP95qfcepEPoiAQ";

function send_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    header("Content-Type: application/json");
    echo json_encode($payload);
    exit;
}

function razorpay_keys_configured(): bool
{
    return strpos(RAZORPAY_TEST_KEY_ID, "your_") === false
        && strpos(RAZORPAY_TEST_KEY_SECRET, "your_") === false
        && RAZORPAY_TEST_KEY_ID !== ""
        && RAZORPAY_TEST_KEY_SECRET !== "";
}

function create_razorpay_order(array $payload): array
{
    $ch = curl_init("https://api.razorpay.com/v1/orders");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
        CURLOPT_USERPWD => RAZORPAY_TEST_KEY_ID . ":" . RAZORPAY_TEST_KEY_SECRET,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_TIMEOUT => 20,
    ]);

    $raw = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($raw === false || $curlError) {
        return ["ok" => false, "message" => "Unable to connect to Razorpay: " . $curlError];
    }

    $decoded = json_decode($raw, true);
    if ($httpCode < 200 || $httpCode >= 300 || !is_array($decoded) || empty($decoded["id"])) {
        $errorMessage = $decoded["error"]["description"] ?? "Order creation failed";
        return ["ok" => false, "message" => $errorMessage];
    }

    return ["ok" => true, "data" => $decoded];
}

function verify_razorpay_signature(string $orderId, string $paymentId, string $signature): bool
{
    $expected = hash_hmac("sha256", $orderId . "|" . $paymentId, RAZORPAY_TEST_KEY_SECRET);
    return hash_equals($expected, $signature);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $contentType = $_SERVER["CONTENT_TYPE"] ?? "";
    $input = [];

    if (stripos($contentType, "application/json") !== false) {
        $decoded = json_decode(file_get_contents("php://input"), true);
        $input = is_array($decoded) ? $decoded : [];
    } else {
        $input = $_POST;
    }

    $action = trim((string)($input["action"] ?? ""));

    if ($action === "create_razorpay_order") {
        if (!isset($_SESSION["username"]) || $_SESSION["username"] === "") {
            send_json(["success" => false, "message" => "Please login to buy membership."], 401);
        }

        if (!razorpay_keys_configured()) {
            send_json([
                "success" => false,
                "message" => "Razorpay test keys are not configured in mmm.php.",
            ], 500);
        }

        $planId = (int)($input["plan_id"] ?? 0);
        if ($planId <= 0) {
            send_json(["success" => false, "message" => "Invalid plan selected."], 422);
        }

        $stmt = mysqli_prepare(
            $conn,
            "SELECT id, plan_name, price, duration FROM membership_plans WHERE id=? AND status='active' LIMIT 1"
        );
        mysqli_stmt_bind_param($stmt, "i", $planId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $plan = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if (!$plan) {
            send_json(["success" => false, "message" => "Selected plan not found or inactive."], 404);
        }

        $amountPaise = (int) round(((float)$plan["price"]) * 100);
        if ($amountPaise <= 0) {
            send_json(["success" => false, "message" => "Plan price is invalid."], 422);
        }

        $receipt = "mem_" . $planId . "_" . time();
        $orderPayload = [
            "amount" => $amountPaise,
            "currency" => "INR",
            "receipt" => $receipt,
            "payment_capture" => 1,
            "notes" => [
                "username" => (string)$_SESSION["username"],
                "plan_id" => (string)$plan["id"],
                "plan_name" => (string)$plan["plan_name"],
            ],
        ];

        $rzpOrder = create_razorpay_order($orderPayload);
        if (!$rzpOrder["ok"]) {
            send_json(["success" => false, "message" => $rzpOrder["message"]], 502);
        }

        $orderData = $rzpOrder["data"];
        $orderId = (string)$orderData["id"];

        if (!isset($_SESSION["rzp_membership_orders"]) || !is_array($_SESSION["rzp_membership_orders"])) {
            $_SESSION["rzp_membership_orders"] = [];
        }

        $_SESSION["rzp_membership_orders"][$orderId] = [
            "username" => (string)$_SESSION["username"],
            "plan_id" => (int)$plan["id"],
            "plan_name" => (string)$plan["plan_name"],
            "amount" => (string)$plan["price"],
            "duration" => (string)$plan["duration"],
            "created_at" => time(),
        ];

        send_json([
            "success" => true,
            "message" => "Order created.",
            "key_id" => RAZORPAY_TEST_KEY_ID,
            "order_id" => $orderId,
            "amount" => $orderData["amount"],
            "currency" => $orderData["currency"],
            "plan_name" => $plan["plan_name"],
            "duration" => $plan["duration"],
            "price" => $plan["price"],
        ]);
    }

    if ($action === "verify_razorpay_payment") {
        if (!isset($_SESSION["username"]) || $_SESSION["username"] === "") {
            send_json(["success" => false, "message" => "Please login to continue."], 401);
        }

        if (!razorpay_keys_configured()) {
            send_json(["success" => false, "message" => "Razorpay test keys are missing."], 500);
        }

        $orderId = trim((string)($input["razorpay_order_id"] ?? ""));
        $paymentId = trim((string)($input["razorpay_payment_id"] ?? ""));
        $signature = trim((string)($input["razorpay_signature"] ?? ""));

        if ($orderId === "" || $paymentId === "" || $signature === "") {
            send_json(["success" => false, "message" => "Missing payment verification data."], 422);
        }

        if (
            !isset($_SESSION["rzp_membership_orders"]) ||
            !is_array($_SESSION["rzp_membership_orders"]) ||
            !isset($_SESSION["rzp_membership_orders"][$orderId])
        ) {
            send_json(["success" => false, "message" => "Payment order session expired. Please retry."], 409);
        }

        $orderMeta = $_SESSION["rzp_membership_orders"][$orderId];
        if ($orderMeta["username"] !== $_SESSION["username"]) {
            send_json(["success" => false, "message" => "Order does not belong to current user."], 403);
        }

        if (!verify_razorpay_signature($orderId, $paymentId, $signature)) {
            send_json(["success" => false, "message" => "Payment signature verification failed."], 400);
        }

        $txnCheck = mysqli_prepare($conn, "SELECT id FROM membership_purchases WHERE txn=? LIMIT 1");
        mysqli_stmt_bind_param($txnCheck, "s", $paymentId);
        mysqli_stmt_execute($txnCheck);
        $existing = mysqli_stmt_get_result($txnCheck);
        $already = mysqli_num_rows($existing) > 0;
        mysqli_stmt_close($txnCheck);

        if (!$already) {
            $username = (string)$orderMeta["username"];
            $planId = (int)$orderMeta["plan_id"];
            $planName = (string)$orderMeta["plan_name"];
            $amount = (string)$orderMeta["amount"];
            $duration = (string)$orderMeta["duration"];
            $txn = $paymentId;

            $insert = mysqli_prepare(
                $conn,
                "INSERT INTO membership_purchases
                (username,plan_id,plan_name,amount,duration,txn,status)
                VALUES (?,?,?,?,?,?,'pending')"
            );
            mysqli_stmt_bind_param($insert, "sissss", $username, $planId, $planName, $amount, $duration, $txn);
            $ok = mysqli_stmt_execute($insert);
            $dbError = mysqli_error($conn);
            mysqli_stmt_close($insert);

            if (!$ok) {
                send_json(["success" => false, "message" => "DB insert failed: " . $dbError], 500);
            }
        }

        unset($_SESSION["rzp_membership_orders"][$orderId]);

        send_json([
            "success" => true,
            "message" => "Payment verified. Membership request submitted successfully.",
            "txn" => $paymentId,
            "plan_name" => $orderMeta["plan_name"],
            "amount" => $orderMeta["amount"],
            "duration" => $orderMeta["duration"],
        ]);
    }
}

$plans = [];
$result = mysqli_query($conn, "SELECT * FROM membership_plans WHERE status='active'");
while ($row = mysqli_fetch_assoc($result)) {
    $plans[] = $row;
}

$isLoggedIn = isset($_SESSION["username"]) && $_SESSION["username"] !== "";
$keysReady = razorpay_keys_configured();
$planCount = count($plans);
$minPrice = null;
$maxDuration = 0;

foreach ($plans as $p) {
    $currentPrice = (float)($p["price"] ?? 0);
    $currentDuration = (int)($p["duration"] ?? 0);

    if ($minPrice === null || $currentPrice < $minPrice) {
        $minPrice = $currentPrice;
    }
    if ($currentDuration > $maxDuration) {
        $maxDuration = $currentDuration;
    }
}

$minPriceLabel = $minPrice !== null ? number_format($minPrice, 2) : "0.00";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Elite Membership</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@400;500;700;800&display=swap');

        :root{
            --bg-deep:#080a10;
            --panel:#121722;
            --panel-soft:#181f2c;
            --line:#2b3345;
            --text:#f6f7fb;
            --muted:#aab4c9;
            --accent:#ff453a;
            --accent-soft:#ff7a18;
            --success:#8be48d;
            --warning:#ffd978;
        }

        *{
            box-sizing:border-box;
        }

        body{
            margin:0;
            font-family:"Manrope", sans-serif;
            color:var(--text);
            background:
                radial-gradient(circle at 12% 0%, rgba(255,122,24,.2), transparent 35%),
                radial-gradient(circle at 88% 12%, rgba(255,69,58,.17), transparent 40%),
                linear-gradient(180deg, #07090f 0%, #0f141e 64%, #090b11 100%);
            min-height:100vh;
        }

        .page-wrap{
            width:min(1180px, 94%);
            margin:0 auto;
        }

        .hero{
            padding:44px 0 18px;
        }

        .hero-panel{
            position:relative;
            overflow:hidden;
            border-radius:22px;
            border:1px solid rgba(255,255,255,.12);
            background:linear-gradient(135deg, rgba(255,69,58,.16), rgba(16,20,30,.8) 48%, rgba(255,122,24,.14) 100%);
            box-shadow:0 24px 50px rgba(0,0,0,.38);
            padding:38px 34px;
        }

        .hero-panel::before{
            content:"";
            position:absolute;
            width:340px;
            height:340px;
            border-radius:50%;
            background:radial-gradient(circle, rgba(255,255,255,.16) 0%, rgba(255,255,255,0) 70%);
            top:-180px;
            right:-90px;
            pointer-events:none;
        }

        .kicker{
            display:inline-block;
            padding:6px 11px;
            border:1px solid rgba(255,255,255,.28);
            border-radius:999px;
            font-size:11px;
            letter-spacing:1.2px;
            font-weight:700;
            background:rgba(5,8,13,.3);
        }

        .hero h1{
            margin:10px 0 12px;
            font-family:"Bebas Neue", sans-serif;
            font-size:clamp(44px, 8vw, 76px);
            line-height:.95;
            letter-spacing:1.2px;
            color:#fff;
        }

        .sub{
            margin:0;
            max-width:760px;
            color:var(--muted);
            font-size:15px;
            line-height:1.75;
        }

        .hero-chips{
            margin-top:18px;
            display:flex;
            flex-wrap:wrap;
            gap:10px;
        }

        .chip{
            font-size:12px;
            padding:8px 12px;
            border-radius:10px;
            border:1px solid rgba(255,255,255,.12);
            background:rgba(8,10,16,.42);
            color:#e9ecf6;
        }

        .hero-stats{
            margin-top:22px;
            display:grid;
            grid-template-columns:repeat(3, minmax(120px, 1fr));
            gap:12px;
            max-width:680px;
        }

        .stat{
            border:1px solid var(--line);
            border-radius:12px;
            background:rgba(5,8,14,.5);
            padding:12px 14px;
        }

        .stat b{
            display:block;
            font-size:20px;
            font-weight:800;
            color:#fff;
        }

        .stat span{
            display:block;
            margin-top:4px;
            color:var(--muted);
            font-size:12px;
        }

        .warn{
            margin:16px 0 0;
            max-width:900px;
            padding:12px 14px;
            border:1px solid #8f6a00;
            background:#2a2209;
            color:#ffd776;
            border-radius:10px;
            font-size:14px;
        }

        .highlights{
            display:grid;
            grid-template-columns:repeat(3, minmax(0, 1fr));
            gap:14px;
            padding:14px 0 10px;
        }

        .highlight{
            border:1px solid var(--line);
            border-radius:14px;
            background:linear-gradient(160deg, rgba(20,26,37,.82), rgba(13,17,25,.7));
            padding:16px;
            box-shadow:0 10px 18px rgba(0,0,0,.2);
        }

        .highlight h3{
            margin:0 0 8px;
            font-size:15px;
            color:#f2f5ff;
            letter-spacing:.2px;
        }

        .highlight p{
            margin:0;
            font-size:13px;
            line-height:1.65;
            color:var(--muted);
        }

        .container{
            display:grid;
            grid-template-columns:repeat(auto-fit, minmax(260px, 1fr));
            gap:18px;
            padding:24px 0 42px;
        }

        .card{
            position:relative;
            display:flex;
            flex-direction:column;
            min-height:410px;
            border:1px solid var(--line);
            border-radius:18px;
            padding:22px;
            background:linear-gradient(175deg, rgba(23,28,40,.9), rgba(12,16,23,.95));
            box-shadow:0 16px 32px rgba(0,0,0,.28);
            transition:transform .22s ease, border-color .22s ease, box-shadow .22s ease;
            animation:cardIn .45s ease both;
        }

        .card:hover{
            transform:translateY(-8px);
            border-color:#ff6949;
            box-shadow:0 20px 38px rgba(0,0,0,.34);
        }

        .card:nth-child(2){ animation-delay:.06s; }
        .card:nth-child(3){ animation-delay:.12s; }
        .card:nth-child(4){ animation-delay:.18s; }

        .plan-badge{
            position:absolute;
            top:12px;
            right:12px;
            padding:6px 10px;
            font-size:11px;
            font-weight:700;
            letter-spacing:.4px;
            border-radius:999px;
            background:linear-gradient(90deg, var(--accent), var(--accent-soft));
            color:#fff;
            box-shadow:0 8px 16px rgba(255,69,58,.25);
        }

        .card h3{
            margin:2px 0 0;
            font-size:24px;
            color:#fff;
            padding-right:90px;
        }

        .price-line{
            display:flex;
            justify-content:space-between;
            align-items:flex-end;
            gap:10px;
            margin:14px 0 12px;
        }

        .price{
            margin:0;
            font-size:34px;
            color:#ff5a4b;
            font-weight:800;
            line-height:1;
        }

        .duration-pill{
            font-size:12px;
            font-weight:700;
            padding:7px 10px;
            border-radius:999px;
            border:1px solid rgba(255,255,255,.16);
            background:rgba(7,10,16,.5);
            color:#e8edf7;
            white-space:nowrap;
        }

        .desc{
            margin:0 0 10px;
            color:#c3cbde;
            font-size:13px;
            line-height:1.65;
            min-height:42px;
        }

        .feature-title{
            margin:8px 0 10px;
            font-size:12px;
            text-transform:uppercase;
            letter-spacing:1.1px;
            color:#8f9ab3;
            font-weight:700;
        }

        .features-list{
            list-style:none;
            padding:0;
            margin:0 0 16px;
            display:flex;
            flex-direction:column;
            gap:8px;
        }

        .features-list li{
            position:relative;
            padding:8px 10px 8px 30px;
            border:1px solid rgba(255,255,255,.08);
            border-radius:8px;
            background:rgba(9,12,18,.45);
            color:#dce2f0;
            font-size:13px;
            line-height:1.4;
        }

        .features-list li::before{
            content:"+";
            position:absolute;
            left:11px;
            top:50%;
            transform:translateY(-50%);
            width:14px;
            height:14px;
            border-radius:50%;
            background:rgba(139,228,141,.22);
            border:1px solid rgba(139,228,141,.42);
            color:var(--success);
            font-size:11px;
            display:flex;
            align-items:center;
            justify-content:center;
            font-weight:700;
        }

        .meta{
            margin-top:auto;
            margin-bottom:12px;
            color:#95a0ba;
            font-size:12px;
            line-height:1.5;
        }

        .buy-btn{
            width:100%;
            padding:12px 14px;
            border:none;
            border-radius:10px;
            cursor:pointer;
            font-weight:700;
            color:#fff;
            background:linear-gradient(90deg, var(--accent), var(--accent-soft));
            transition:transform .16s ease, box-shadow .16s ease, filter .16s ease;
            box-shadow:0 12px 22px rgba(255,69,58,.24);
        }

        .buy-btn:hover{
            transform:translateY(-2px);
            filter:brightness(1.06);
            box-shadow:0 16px 24px rgba(255,69,58,.33);
        }

        .buy-btn:disabled{
            cursor:not-allowed;
            background:#555;
            box-shadow:none;
        }

        .empty{
            grid-column:1 / -1;
            text-align:center;
            color:#aeb6c8;
            border:1px dashed #394259;
            border-radius:14px;
            padding:34px 12px;
            background:rgba(9,12,18,.4);
        }

        .perks{
            padding-bottom:40px;
        }

        .perks-box{
            border:1px solid var(--line);
            border-radius:18px;
            padding:22px;
            background:linear-gradient(160deg, rgba(18,24,35,.92), rgba(10,14,21,.94));
        }

        .perks-box h2{
            margin:0 0 8px;
            font-size:24px;
            letter-spacing:.2px;
        }

        .perks-box p{
            margin:0;
            color:var(--muted);
            font-size:14px;
            line-height:1.7;
        }

        .perk-grid{
            margin-top:16px;
            display:grid;
            grid-template-columns:repeat(4, minmax(0, 1fr));
            gap:12px;
        }

        .perk{
            border:1px solid rgba(255,255,255,.1);
            border-radius:12px;
            background:rgba(7,10,15,.42);
            padding:12px;
        }

        .perk strong{
            display:block;
            font-size:14px;
            margin-bottom:5px;
            color:#f1f5ff;
        }

        .perk span{
            display:block;
            color:#9ea9c0;
            font-size:12px;
            line-height:1.55;
        }

        .modal{
            display:none;
            position:fixed;
            inset:0;
            background:rgba(0,0,0,.86);
            justify-content:center;
            align-items:center;
            z-index:9999;
            padding:16px;
        }

        .modal-box{
            width:520px;
            max-width:100%;
            background:#0f141e;
            border-radius:16px;
            padding:24px;
            border:1px solid #273047;
            box-shadow:0 24px 42px rgba(0,0,0,.45);
        }

        .close-btn{
            text-align:right;
            cursor:pointer;
            font-size:13px;
            color:#b8c2d8;
            margin-bottom:8px;
            text-transform:uppercase;
            letter-spacing:.8px;
        }

        .summary{
            margin:16px 0;
            background:#171d2a;
            border:1px solid #2a3348;
            border-radius:10px;
            padding:12px;
            line-height:1.8;
            color:#e0e6f4;
            font-size:15px;
        }

        .pay-btn{
            width:100%;
            padding:12px;
            background:linear-gradient(90deg, var(--accent), var(--accent-soft));
            border:none;
            color:#fff;
            border-radius:10px;
            cursor:pointer;
            font-weight:700;
        }

        .pay-btn:hover{
            filter:brightness(1.05);
        }

        .pay-btn:disabled{
            background:#555;
            cursor:not-allowed;
        }

        .status{
            margin-top:12px;
            font-size:14px;
            color:#ddd;
            min-height:18px;
        }

        .status.error{ color:#ff8d8d; }
        .status.success{ color:var(--success); }
        .status.warn{ color:var(--warning); }

        .success-box{
            text-align:center;
            line-height:1.8;
        }

        @keyframes cardIn{
            from{
                opacity:0;
                transform:translateY(14px);
            }
            to{
                opacity:1;
                transform:translateY(0);
            }
        }

        @media (max-width:1000px){
            .hero-stats{
                grid-template-columns:repeat(2, minmax(120px, 1fr));
            }
            .highlights{
                grid-template-columns:1fr;
            }
            .perk-grid{
                grid-template-columns:repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width:680px){
            .hero-panel{
                padding:28px 20px;
            }
            .hero-stats{
                grid-template-columns:1fr;
            }
            .container{
                grid-template-columns:1fr;
            }
            .card{
                min-height:unset;
            }
            .perks-box{
                padding:18px;
            }
            .perk-grid{
                grid-template-columns:1fr;
            }
        }
    </style>
</head>
<body>
<?php include "header.php"; ?>

<div class="page-wrap">
    <div class="hero">
        <div class="hero-panel">
            <div class="kicker">MEMBERSHIP ACCESS</div>
            <h1>Build Your Strongest Version</h1>
            <p class="sub">
                Choose a plan that fits your training style and activate it instantly.
                Razorpay checkout is connected in test mode, and your existing admin approval workflow remains unchanged.
            </p>

            <?php if (!$keysReady): ?>
                <div class="warn">
                    Razorpay keys are not set in <strong>mmm.php</strong>. Update
                    <code>RAZORPAY_TEST_KEY_ID</code> and <code>RAZORPAY_TEST_KEY_SECRET</code> before payment.
                </div>
            <?php endif; ?>

            <div class="hero-chips">
                <div class="chip">Secure Razorpay Checkout</div>
                <div class="chip">Fast Plan Activation Request</div>
                <div class="chip">Clean Approval Tracking</div>
            </div>

            <div class="hero-stats">
                <div class="stat">
                    <b><?= (int)$planCount ?></b>
                    <span>Active Plans</span>
                </div>
                <div class="stat">
                    <b>INR <?= htmlspecialchars($minPriceLabel) ?></b>
                    <span>Starting Price</span>
                </div>
                <div class="stat">
                    <b><?= (int)$maxDuration ?> Days</b>
                    <span>Max Duration</span>
                </div>
            </div>
        </div>
    </div>

    <div class="highlights">
        <div class="highlight">
            <h3>Structured Programs</h3>
            <p>Every plan is focused on measurable progress, not random workouts.</p>
        </div>
        <div class="highlight">
            <h3>Payment Confidence</h3>
            <p>Checkout uses Razorpay flow with server-side signature validation.</p>
        </div>
        <div class="highlight">
            <h3>Member First Support</h3>
            <p>From plan onboarding to progress adjustments, support is built in.</p>
        </div>
    </div>

    <div class="container">
        <?php if (empty($plans)): ?>
            <div class="empty">No active membership plans found.</div>
        <?php else: ?>
            <?php foreach ($plans as $index => $plan): ?>
                <?php
                    $description = trim((string)($plan["description"] ?? ""));
                    $rawFeatures = trim((string)($plan["features"] ?? ""));
                    $featureList = array_values(array_filter(array_map("trim", explode(",", $rawFeatures))));

                    if (empty($featureList)) {
                        $featureList = ["Gym access", "Guided workouts", "Progress support"];
                    }

                    $featureList = array_slice($featureList, 0, 4);
                    $isFeatured = ($planCount === 1 && $index === 0) || ($planCount > 1 && $index === 1);
                ?>
                <div class="card">
                    <?php if ($isFeatured): ?>
                        <div class="plan-badge">Most Popular</div>
                    <?php endif; ?>

                    <h3><?= htmlspecialchars($plan["plan_name"]) ?></h3>

                    <div class="price-line">
                        <div class="price">&#8377;<?= htmlspecialchars((string)$plan["price"]) ?></div>
                        <div class="duration-pill"><?= htmlspecialchars((string)$plan["duration"]) ?> Days</div>
                    </div>

                    <p class="desc">
                        <?= $description !== "" ? htmlspecialchars($description) : "Designed for focused fitness progress with smart support and premium training quality." ?>
                    </p>

                    <div class="feature-title">What You Get</div>
                    <ul class="features-list">
                        <?php foreach ($featureList as $feature): ?>
                            <li><?= htmlspecialchars($feature) ?></li>
                        <?php endforeach; ?>
                    </ul>

                    <div class="meta">Checkout in test mode. Membership entry goes to admin approval.</div>

                    <button
                        class="buy-btn"
                        data-plan-id="<?= (int)$plan["id"] ?>"
                        data-plan-name="<?= htmlspecialchars($plan["plan_name"], ENT_QUOTES) ?>"
                        data-plan-price="<?= htmlspecialchars((string)$plan["price"], ENT_QUOTES) ?>"
                        data-plan-duration="<?= htmlspecialchars((string)$plan["duration"], ENT_QUOTES) ?>"
                        onclick="openPaymentFromButton(this)">
                        Activate Plan
                    </button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="perks">
        <div class="perks-box">
            <h2>Membership Extras</h2>
            <p>More than entry access. Your membership is built to support consistency and long-term outcomes.</p>
            <div class="perk-grid">
                <div class="perk">
                    <strong>Priority Help</strong>
                    <span>Quick assistance for membership or training related queries.</span>
                </div>
                <div class="perk">
                    <strong>Flexible Duration</strong>
                    <span>Choose short or long plans depending on your cycle and goals.</span>
                </div>
                <div class="perk">
                    <strong>Progress Focus</strong>
                    <span>Plans are aligned with visible results and sustainable routine.</span>
                </div>
                <div class="perk">
                    <strong>Secure Billing</strong>
                    <span>Payment flow is handled via Razorpay checkout with verification.</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal" id="paymentModal">
    <div class="modal-box">
        <div class="close-btn" onclick="closeModal()">X Close</div>
        <div id="paymentContent">
            <h2 style="margin:0 0 12px;">Confirm Membership Payment</h2>
            <div class="summary">
                <div>Plan: <strong id="planNameView">-</strong></div>
                <div>Amount: <strong id="planPriceView">-</strong></div>
                <div>Duration: <strong id="planDurationView">-</strong></div>
            </div>
            <button id="payNowBtn" class="pay-btn" onclick="payWithRazorpay()">
                Pay Now (Test Mode)
            </button>
            <div class="status" id="payStatus"></div>
        </div>
    </div>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
const isLoggedIn = <?= json_encode($isLoggedIn) ?>;
const keysReady = <?= json_encode($keysReady) ?>;
const endpoint = "mmm.php";
let isProcessing = false;
const currentPlan = {
    id: "",
    name: "",
    price: "",
    duration: ""
};

function openPaymentFromButton(btn){
    openPayment({
        id: btn.dataset.planId,
        name: btn.dataset.planName,
        price: btn.dataset.planPrice,
        duration: btn.dataset.planDuration
    });
}

function openPayment(plan){
    if (!isLoggedIn) {
        alert("Please login first to buy a membership.");
        window.location.href = "login.php";
        return;
    }

    currentPlan.id = plan.id || "";
    currentPlan.name = plan.name || "";
    currentPlan.price = plan.price || "";
    currentPlan.duration = plan.duration || "";

    document.getElementById("planNameView").textContent = currentPlan.name;
    document.getElementById("planPriceView").innerHTML = "&#8377;" + currentPlan.price;
    document.getElementById("planDurationView").textContent = currentPlan.duration + " Days";
    setStatus("");
    document.getElementById("paymentModal").style.display = "flex";
}

function closeModal(){
    if (isProcessing) return;
    document.getElementById("paymentModal").style.display = "none";
}

function setStatus(message, type = ""){
    const box = document.getElementById("payStatus");
    box.textContent = message;
    box.className = "status" + (type ? " " + type : "");
}

function setPayButtonState(disabled){
    document.getElementById("payNowBtn").disabled = disabled;
}

async function payWithRazorpay(){
    if (isProcessing) return;
    if (!keysReady) {
        setStatus("Razorpay test keys are missing in mmm.php.", "error");
        return;
    }
    if (!currentPlan.id) {
        setStatus("Please select a valid plan.", "error");
        return;
    }

    try {
        isProcessing = true;
        setPayButtonState(true);
        setStatus("Creating Razorpay order...", "warn");

        const orderResponse = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "create_razorpay_order",
                plan_id: currentPlan.id
            })
        });

        const orderData = await orderResponse.json();
        if (!orderResponse.ok || !orderData.success) {
            throw new Error(orderData.message || "Unable to create payment order.");
        }

        const options = {
            key: orderData.key_id,
            amount: orderData.amount,
            currency: orderData.currency,
            name: "Elite Gym",
            description: orderData.plan_name + " Membership",
            order_id: orderData.order_id,
            handler: function (response) {
                verifyPayment(response);
            },
            modal: {
                ondismiss: function () {
                    isProcessing = false;
                    setPayButtonState(false);
                    setStatus("Payment popup closed.", "warn");
                }
            },
            theme: { color: "#f3212f" }
        };

        const rzp = new Razorpay(options);
        rzp.on("payment.failed", function (response) {
            isProcessing = false;
            setPayButtonState(false);
            const reason = response.error && response.error.description
                ? response.error.description
                : "Payment failed.";
            setStatus(reason, "error");
        });
        rzp.open();
    } catch (err) {
        isProcessing = false;
        setPayButtonState(false);
        setStatus(err.message || "Something went wrong while starting payment.", "error");
    }
}

async function verifyPayment(paymentResponse){
    try {
        setStatus("Verifying payment...", "warn");

        const verifyResponse = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "verify_razorpay_payment",
                razorpay_order_id: paymentResponse.razorpay_order_id,
                razorpay_payment_id: paymentResponse.razorpay_payment_id,
                razorpay_signature: paymentResponse.razorpay_signature
            })
        });

        const verifyData = await verifyResponse.json();
        if (!verifyResponse.ok || !verifyData.success) {
            throw new Error(verifyData.message || "Payment verification failed.");
        }

        isProcessing = false;
        setPayButtonState(false);
        showSuccessView(verifyData);
    } catch (err) {
        isProcessing = false;
        setPayButtonState(false);
        setStatus(err.message || "Unable to verify payment.", "error");
    }
}

function showSuccessView(data){
    const content = document.getElementById("paymentContent");
    const txn = data.txn || "N/A";
    const planName = data.plan_name || currentPlan.name;
    const amount = data.amount || currentPlan.price;

    content.innerHTML = `
        <div class="success-box">
            <h2 style="margin-top:0;">Payment Successful</h2>
            <div>Plan: <strong>${escapeHtml(planName)}</strong></div>
            <div>Amount: <strong>&#8377;${escapeHtml(String(amount))}</strong></div>
            <div>Txn: <strong>${escapeHtml(txn)}</strong></div>
            <div>Membership status: <strong>Pending Admin Approval</strong></div>
            <button class="pay-btn" style="margin-top:14px;" onclick="location.reload()">Done</button>
        </div>
    `;
}

function escapeHtml(value){
    return value
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
</script>
</body>
</html>
