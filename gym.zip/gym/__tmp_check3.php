﻿<?php
$con = mysqli_connect('localhost','root','','gym');
if(!$con){ die('db fail'); }
$tables = [];
$tq = mysqli_query($con, "SHOW TABLES");
while($tr=mysqli_fetch_row($tq)){ $tables[]=$tr[0]; }
echo "has products table: ".(in_array('products',$tables)?'yes':'no')."\n";
if(in_array('products',$tables)){
  $q = mysqli_query($con,"SELECT id, product_name, image FROM products ORDER BY id DESC LIMIT 20");
  while($r=mysqli_fetch_assoc($q)){
    echo $r['id']." | ".$r['product_name']." | ".$r['image']."\n";
  }
}
?>
