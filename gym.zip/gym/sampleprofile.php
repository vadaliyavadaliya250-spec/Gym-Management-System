﻿<?php
session_start();
$con = mysqli_connect("localhost","root","","gym");
if(!$con){ die("Database connection failed"); }

$db_name_row = mysqli_fetch_row(mysqli_query($con, "SELECT DATABASE()"));
$db_name = $db_name_row[0] ?? '';

$table_exists = function($table) use ($con){
    $table = mysqli_real_escape_string($con, $table);
    $q = mysqli_query($con, "SHOW TABLES LIKE '$table'");
    return $q && mysqli_num_rows($q) > 0;
};

$has_col = function($table, $col) use ($con, $db_name){
    $db = mysqli_real_escape_string($con, (string)$db_name);
    $table = mysqli_real_escape_string($con, $table);
    $col = mysqli_real_escape_string($con, $col);
    $q = mysqli_query($con, "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$db' AND TABLE_NAME='$table' AND COLUMN_NAME='$col' LIMIT 1");
    return $q && mysqli_num_rows($q) > 0;
};

function resolve_profile_product_image(?string $rawImage, string $productName = ''): string
{
    static $cache = [];
    static $indexedFiles = null;

    $raw = trim((string)$rawImage);
    $productName = trim((string)$productName);
    $cacheKey = strtolower($raw . '|' . $productName);
    if (isset($cache[$cacheKey])) {
        return $cache[$cacheKey];
    }

    if ($indexedFiles === null) {
        $indexedFiles = [];
        $scanDirs = ['uploads/products', 'uploads'];
        foreach ($scanDirs as $dir) {
            $absDir = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $dir);
            if (!is_dir($absDir)) continue;
            $items = scandir($absDir);
            if (!is_array($items)) continue;
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') continue;
                $absFile = $absDir . DIRECTORY_SEPARATOR . $item;
                if (is_file($absFile)) {
                    $indexedFiles[] = str_replace('\\', '/', $dir . '/' . $item);
                }
            }
        }
    }

    $exists_rel = function(string $rel): bool {
        $rel = trim(str_replace('\\', '/', $rel));
        if ($rel === '') return false;
        $abs = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        return is_file($abs);
    };

    if ($raw !== '' && preg_match('#^https?://#i', $raw)) {
        $cache[$cacheKey] = $raw;
        return $raw;
    }

    $candidates = [];
    if ($raw !== '') {
        $rawNorm = ltrim(str_replace('\\', '/', $raw), '/');
        if ($rawNorm !== '') {
            $candidates[] = $rawNorm;
            if (stripos($rawNorm, 'uploads/') === 0) {
                $candidates[] = $rawNorm;
            }
            if (stripos($rawNorm, 'products/') === 0) {
                $candidates[] = 'uploads/' . $rawNorm;
            }
            $base = basename($rawNorm);
            if ($base !== '') {
                $candidates[] = 'uploads/products/' . $base;
                $candidates[] = 'uploads/' . $base;
            }
        }
    }

    $candidates = array_values(array_unique(array_filter($candidates)));
    foreach ($candidates as $cand) {
        if ($exists_rel($cand)) {
            $cache[$cacheKey] = str_replace('\\', '/', $cand);
            return $cache[$cacheKey];
        }
    }

    $terms = [];
    if ($raw !== '') {
        $baseStem = pathinfo(str_replace('\\', '/', $raw), PATHINFO_FILENAME);
        $baseStem = strtolower(preg_replace('/[^a-z0-9]+/i', '', (string)$baseStem));
        if ($baseStem !== '') $terms[] = $baseStem;
    }
    if ($productName !== '') {
        $p1 = strtolower(preg_replace('/[^a-z0-9]+/i', '', $productName));
        if ($p1 !== '') $terms[] = $p1;
        $parts = preg_split('/\s+/', strtolower($productName));
        if (is_array($parts)) {
            foreach ($parts as $pt) {
                $pt = preg_replace('/[^a-z0-9]+/i', '', (string)$pt);
                if (strlen($pt) >= 4) $terms[] = $pt;
            }
        }
    }
    $terms = array_values(array_unique(array_filter($terms)));

    if (!empty($terms) && is_array($indexedFiles)) {
        foreach ($terms as $term) {
            foreach ($indexedFiles as $relFile) {
                $nameStem = strtolower(pathinfo($relFile, PATHINFO_FILENAME));
                $nameStem = preg_replace('/[^a-z0-9]+/i', '', (string)$nameStem);
                if ($nameStem === '') continue;
                if (strpos($nameStem, $term) !== false || strpos($term, $nameStem) !== false) {
                    $cache[$cacheKey] = $relFile;
                    return $relFile;
                }
            }
        }
    }

    $cache[$cacheKey] = '';
    return '';
}

function resolve_profile_photo_path(?string $rawPhoto): string
{
    $raw = trim((string)$rawPhoto);
    if ($raw === '') return '';

    if (preg_match('#^https?://#i', $raw)) {
        return $raw;
    }

    $exists_rel = function(string $rel): bool {
        $rel = trim(str_replace('\\', '/', $rel));
        if ($rel === '') return false;
        $abs = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        return is_file($abs);
    };

    $rawNorm = ltrim(str_replace('\\', '/', $raw), '/');
    $candidates = [];
    if ($rawNorm !== '') {
        $candidates[] = $rawNorm;
        if (stripos($rawNorm, 'uploads/') !== 0) {
            $candidates[] = 'uploads/' . $rawNorm;
        }
        $base = basename($rawNorm);
        if ($base !== '') {
            $candidates[] = 'uploads/' . $base;
        }
    }

    $candidates = array_values(array_unique(array_filter($candidates)));
    foreach ($candidates as $cand) {
        if ($exists_rel($cand)) {
            return str_replace('\\', '/', $cand);
        }
    }

    // Fallback: case-insensitive basename match inside /uploads
    $base = basename($rawNorm);
    if ($base !== '') {
        $uploadsDir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';
        if (is_dir($uploadsDir)) {
            $items = scandir($uploadsDir);
            if (is_array($items)) {
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') continue;
                    if (strcasecmp($item, $base) === 0 && is_file($uploadsDir . DIRECTORY_SEPARATOR . $item)) {
                        return 'uploads/' . $item;
                    }
                }
            }
        }
    }

    return '';
}

// Require login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Get user base info
$stmt = mysqli_prepare($con, "SELECT * FROM user_table WHERE username = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$uRes = mysqli_stmt_get_result($stmt);
$userInfo = mysqli_fetch_assoc($uRes) ?: [];
$user_id = $userInfo['id'] ?? 0;

// Load profile
$stmt = mysqli_prepare($con, "SELECT * FROM user_details WHERE username = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$pRes = mysqli_stmt_get_result($stmt);
$profileData = mysqli_fetch_assoc($pRes) ?: null;

/* ===== SAVE PROFILE ===== */
if (isset($_POST['save'])) {
    $fullname = trim($_POST['fullname']);
    $age      = (int)$_POST['age'];
    $gender   = trim($_POST['gender']);
    $height   = trim($_POST['height']);
    $weight   = trim($_POST['weight']);
    $medical  = trim($_POST['medical']);

    if ($fullname === '') {
        $error = "Full name is required";
    } elseif ($age < 1 || $age > 150) {
        $error = "Age must be between 1 and 150";
    } elseif ($gender === '') {
        $error = "Please select a gender";
    } else {
        $photo = $profileData['photo'] ?? null;
        if (!empty($_FILES['photo']['name'])) {
            $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
            if (!in_array($_FILES['photo']['type'], $allowed)) {
                $error = "Invalid file type. Only JPEG, PNG, GIF, WebP.";
            } elseif ($_FILES['photo']['size'] > 5*1024*1024) {
                $error = "File too large. Max 5MB.";
            } else {
                if (!is_dir("uploads")) mkdir("uploads",0755,true);
                $ext   = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
                $photo = "uploads/".time()."_".bin2hex(random_bytes(5)).".".$ext;
                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photo)) {
                    $error = "Failed to upload photo.";
                }
            }
        }

        if (!isset($error)) {
            if ($profileData) {
                $stmt = mysqli_prepare($con, "UPDATE user_details SET fullname=?, age=?, gender=?, height=?, weight=?, medical=?, photo=? WHERE username=?");
                mysqli_stmt_bind_param($stmt, "sissssss", $fullname, $age, $gender, $height, $weight, $medical, $photo, $username);
                mysqli_stmt_execute($stmt);
                $success = "Profile updated";
            } else {
                $stmt = mysqli_prepare($con, "INSERT INTO user_details(username, fullname, age, gender, height, weight, medical, photo) VALUES(?,?,?,?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt, "ssisssss", $username, $fullname, $age, $gender, $height, $weight, $medical, $photo);
                mysqli_stmt_execute($stmt);
                $success = "Profile created";
            }
            // reload profile
            $stmt = mysqli_prepare($con, "SELECT * FROM user_details WHERE username = ? LIMIT 1");
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $pRes = mysqli_stmt_get_result($stmt);
            $profileData = mysqli_fetch_assoc($pRes) ?: null;
        }
    }
}

/* ===== MEMBERSHIP ===== */
$membership = null; $pending_membership = null; $membership_cancelled = false;
// Read legacy user_memberships first (if present).
$um_res = mysqli_query($con, "SHOW TABLES LIKE 'user_memberships'");
if(mysqli_num_rows($um_res)>0 && $user_id){
    $res = mysqli_query($con, "SELECT um.*, mp.plan_name, mp.price 
                               FROM user_memberships um 
                               LEFT JOIN membership_plans mp ON mp.id = um.plan_id
                               WHERE um.user_id='$user_id' AND um.status='approved'
                               ORDER BY um.purchase_date DESC LIMIT 1");
    if(mysqli_num_rows($res)>0) $membership = mysqli_fetch_assoc($res);

    $res = mysqli_query($con, "SELECT um.*, mp.plan_name, mp.price 
                               FROM user_memberships um 
                               LEFT JOIN membership_plans mp ON mp.id = um.plan_id
                               WHERE um.user_id='$user_id' AND um.status='pending'
                               ORDER BY um.purchase_date DESC LIMIT 1");
    if(mysqli_num_rows($res)>0) $pending_membership = mysqli_fetch_assoc($res);
}

// Always reconcile with membership_purchases because admin approvals/cancellations happen there.
$mp_membership = null;
$mp_pending_membership = null;

$stmt = mysqli_prepare($con, "SELECT * FROM membership_purchases WHERE username=? AND status='approved' ORDER BY purchase_date DESC, id DESC LIMIT 1");
if($stmt){
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res && mysqli_num_rows($res)>0) $mp_membership = mysqli_fetch_assoc($res);
}

$stmt = mysqli_prepare($con, "SELECT * FROM membership_purchases WHERE username=? AND status='pending' ORDER BY purchase_date DESC, id DESC LIMIT 1");
if($stmt){
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res && mysqli_num_rows($res)>0) $mp_pending_membership = mysqli_fetch_assoc($res);
}

// If purchase row is approved, show Active even when legacy table still says pending.
if($mp_membership){
    $membership = $mp_membership;
    $pending_membership = null;
} elseif(!$membership && $mp_pending_membership){
    $pending_membership = $mp_pending_membership;
}

// Source-of-truth override: if latest purchase request is cancelled, hide active/pending membership on profile.
$stmt = mysqli_prepare($con, "SELECT status FROM membership_purchases WHERE username=? ORDER BY purchase_date DESC, id DESC LIMIT 1");
if($stmt){
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $latest_res = mysqli_stmt_get_result($stmt);
    if($latest_res && mysqli_num_rows($latest_res) > 0){
        $latest = mysqli_fetch_assoc($latest_res);
        $latest_status = strtolower(trim((string)($latest['status'] ?? '')));
        if($latest_status === 'canceled') $latest_status = 'cancelled';
        if($latest_status === 'cancelled'){
            $membership = null;
            $pending_membership = null;
            $membership_cancelled = true;
        }
    }
}

/* ===== MEMBERSHIP RECEIPTS ===== */
$membership_receipts = [];
$latest_membership_receipt = null;

if($table_exists('membership_purchases')){
    $receipt_date_col = 'id';
    if($has_col('membership_purchases','purchase_date')){
        $receipt_date_col = 'purchase_date';
    } elseif($has_col('membership_purchases','created_at')){
        $receipt_date_col = 'created_at';
    }

    $receipt_sql = "SELECT id, plan_name, amount, duration, txn, status, {$receipt_date_col} AS receipt_date
                    FROM membership_purchases
                    WHERE username=?
                    ORDER BY {$receipt_date_col} DESC, id DESC
                    LIMIT 8";
    $stmt = mysqli_prepare($con, $receipt_sql);
    if($stmt){
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $receipt_res = mysqli_stmt_get_result($stmt);
        if($receipt_res){
            while($rc = mysqli_fetch_assoc($receipt_res)){
                $membership_receipts[] = $rc;
            }
        }
    }
}

if(!empty($membership_receipts)){
    $latest_membership_receipt = $membership_receipts[0];
}

/* ===== FREE MEMBERSHIP ITEMS ===== */
$free_item_row = null;
$free_item_state = 'none'; // none | pending | eligible
$free_item_overall = 'Not Eligible';

$fi_table = mysqli_query($con, "SHOW TABLES LIKE 'free_membership_items'");
if($fi_table && mysqli_num_rows($fi_table) > 0){
    $stmt = mysqli_prepare($con, "SELECT * FROM free_membership_items WHERE username=? ORDER BY updated_at DESC, id DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $fi_res = mysqli_stmt_get_result($stmt);
    if($fi_res && mysqli_num_rows($fi_res) > 0){
        $free_item_row = mysqli_fetch_assoc($fi_res);
    }
}

if($membership){
    $free_item_state = 'eligible';
    if($free_item_row){
        $got_bag = (($free_item_row['gymbag_status'] ?? '') === 'given');
        $got_bottle = (($free_item_row['bottle_status'] ?? '') === 'given');
        if($got_bag && $got_bottle){
            $free_item_overall = 'Collected';
        } elseif($got_bag || $got_bottle){
            $free_item_overall = 'Partially Collected';
        } else {
            $free_item_overall = 'Not Collected';
        }
    } else {
        // Membership is active but admin has not updated free item status yet.
        $free_item_overall = 'Not Collected';
    }
} elseif($pending_membership){
    $free_item_state = 'pending';
    $free_item_overall = 'After Approval';
}

/* ===== EVENT JOIN HISTORY ===== */
$event_history = [];
$event_counts = ['approved' => 0, 'pending' => 0, 'cancelled' => 0];
$event_total_requests = 0;
$event_join_state = 'Not Joined';
$event_pill_class = 'bad';
$event_latest_label = 'No event request yet';

if($table_exists('event_registrations') && $table_exists('events')){
    $event_filters = [];
    if(!empty($profileData['id'])){
        $member_profile_id = (int)$profileData['id'];
        $event_filters[] = "er.user_id='$member_profile_id'";
    }
    $username_esc = mysqli_real_escape_string($con, $username);
    $event_filters[] = "er.username='$username_esc'";

    $event_where = implode(" OR ", array_filter($event_filters));
    if($event_where !== ''){
        $event_q = mysqli_query($con, "
            SELECT er.id, er.status, er.registered_at, er.phone, er.fullname,
                   e.title, e.event_date, e.event_time, e.location
            FROM event_registrations er
            LEFT JOIN events e ON e.id=er.event_id
            WHERE ($event_where)
            ORDER BY er.registered_at DESC, er.id DESC
            LIMIT 30
        ");

        if($event_q){
            while($er = mysqli_fetch_assoc($event_q)){
                $status_key = strtolower(trim((string)($er['status'] ?? 'pending')));
                if($status_key === 'canceled') $status_key = 'cancelled';
                if(!isset($event_counts[$status_key])) $event_counts[$status_key] = 0;
                $event_counts[$status_key]++;
                $event_history[] = $er;
            }
        }
    }
}

$event_total_requests = count($event_history);
$event_latest = $event_total_requests > 0 ? $event_history[0] : null;

if(($event_counts['approved'] ?? 0) > 0){
    $event_join_state = 'Joined';
    $event_pill_class = 'good';
} elseif(($event_counts['pending'] ?? 0) > 0){
    $event_join_state = 'Pending';
    $event_pill_class = 'warn';
} elseif($event_total_requests > 0){
    $event_join_state = 'Not Approved';
    $event_pill_class = 'bad';
}

if($event_latest){
    $latest_event_name = trim((string)($event_latest['title'] ?? 'Event'));
    $latest_event_status = ucfirst(strtolower((string)($event_latest['status'] ?? 'pending')));
    $event_latest_label = $latest_event_name . ' (' . $latest_event_status . ')';
}

/* ===== PRODUCT ORDER HISTORY ===== */
$order_history = [];
$order_total_orders = 0;
$order_total_items = 0;
$order_total_spent = 0.0;
$order_latest_status = 'No Orders';
$order_latest_status_class = 'red';
$order_status_counts = ['pending' => 0, 'processing' => 0, 'completed' => 0, 'delivered' => 0, 'cancelled' => 0];
$order_table_mode = 'none';

if($user_id && $table_exists('orders')){
    $has_order_user_id = $has_col('orders','user_id');
    if(!$has_order_user_id){
        $order_table_mode = 'none';
    } else {
    $has_order_product_id = $has_col('orders','product_id');
    $has_order_variant_id = $has_col('orders','variant_id');
    $has_order_qty = $has_col('orders','qty');
    $has_order_total = $has_col('orders','total');
    $has_order_unit_price = $has_col('orders','unit_price');
    $has_order_status = $has_col('orders','status');
    $has_order_created_at = $has_col('orders','created_at');
    $has_order_payment = $has_col('orders','payment_method');
    $has_order_address = $has_col('orders','address');
    $has_order_items = $has_col('orders','items');
    $has_variant_name = $table_exists('product_variants') && $has_col('product_variants','variant_name');
    $has_variant_sku = $table_exists('product_variants') && $has_col('product_variants','sku');
    $has_variant_stock = $table_exists('product_variants') && $has_col('product_variants','stock');
    $has_variant_status = $table_exists('product_variants') && $has_col('product_variants','status');
    $has_variant_final_price = $table_exists('product_variants') && $has_col('product_variants','final_price');
    $has_product_description = $table_exists('products_new') && $has_col('products_new','description');
    $has_product_status = $table_exists('products_new') && $has_col('products_new','status');
    $has_product_price = $table_exists('products_new') && $has_col('products_new','price');
    $has_product_discount = $table_exists('products_new') && $has_col('products_new','discount');
    $has_product_final_price = $table_exists('products_new') && $has_col('products_new','final_price');
    $has_product_category_id = $table_exists('products_new') && $has_col('products_new','category_id');
    $has_category_name = $table_exists('product_categories') && $has_col('product_categories','category_name');

    $sort_order = $has_order_created_at ? "o.created_at DESC" : "o.id DESC";
    $seen_order_ids = [];

    if($has_order_product_id && $has_order_variant_id && $has_order_qty){
        $order_table_mode = 'modern';
        $variant_select = $has_variant_name ? "pv.variant_name AS variant_name" : "NULL AS variant_name";
        $variant_sku_select = $has_variant_sku ? "pv.sku AS variant_sku" : "NULL AS variant_sku";
        $variant_stock_select = $has_variant_stock ? "pv.stock AS variant_stock" : "NULL AS variant_stock";
        $variant_status_select = $has_variant_status ? "pv.status AS variant_status" : "NULL AS variant_status";
        $variant_final_price_select = $has_variant_final_price ? "pv.final_price AS variant_final_price" : "NULL AS variant_final_price";
        $product_desc_select = $has_product_description ? "p.description AS product_description" : "NULL AS product_description";
        $product_status_select = $has_product_status ? "p.status AS product_status" : "NULL AS product_status";
        $product_price_select = $has_product_price ? "p.price AS product_base_price" : "NULL AS product_base_price";
        $product_discount_select = $has_product_discount ? "p.discount AS product_discount" : "NULL AS product_discount";
        $product_final_price_select = $has_product_final_price ? "p.final_price AS product_final_price" : "NULL AS product_final_price";
        $category_name_select = $has_category_name ? "pc.category_name AS category_name" : "NULL AS category_name";
        $category_join = ($has_product_category_id && $has_category_name) ? "LEFT JOIN product_categories pc ON pc.id=p.category_id" : "";

        $orders_q = mysqli_query($con, "
            SELECT o.*, p.id as product_ref_id, p.product_name, p.image,
                   $variant_select, $variant_sku_select, $variant_stock_select, $variant_status_select, $variant_final_price_select,
                   $product_desc_select, $product_status_select, $product_price_select, $product_discount_select, $product_final_price_select,
                   $category_name_select
            FROM orders o
            LEFT JOIN products_new p ON p.id=o.product_id
            LEFT JOIN product_variants pv ON pv.id=o.variant_id
            $category_join
            WHERE o.user_id='$user_id'
            ORDER BY $sort_order
            LIMIT 120
        ");

        if($orders_q){
            while($o = mysqli_fetch_assoc($orders_q)){
                $order_id_row = (int)($o['id'] ?? 0);
                if(!isset($seen_order_ids[$order_id_row])){
                    $seen_order_ids[$order_id_row] = true;
                    $order_total_orders++;
                }

                $status_key = $has_order_status ? strtolower(trim((string)($o['status'] ?? 'pending'))) : 'pending';
                if($status_key === 'canceled') $status_key = 'cancelled';
                if($status_key === '') $status_key = 'pending';
                if(!isset($order_status_counts[$status_key])) $order_status_counts[$status_key] = 0;
                $order_status_counts[$status_key]++;
                if($order_latest_status === 'No Orders') $order_latest_status = ucfirst($status_key);

                $qty = max(1, (int)($o['qty'] ?? 1));
                $unit_price = $has_order_unit_price ? (float)($o['unit_price'] ?? 0) : 0.0;
                $line_total = $has_order_total ? (float)($o['total'] ?? 0) : ($unit_price * $qty);
                if($line_total <= 0 && $unit_price > 0) $line_total = $unit_price * $qty;

                $order_total_items += $qty;
                $order_total_spent += $line_total;

                $order_history[] = [
                    'order_id' => $order_id_row,
                    'created_at' => $o['created_at'] ?? null,
                    'product_name' => $o['product_name'] ?? ('Product #'.($o['product_id'] ?? '-')),
                    'product_ref_id' => (int)($o['product_ref_id'] ?? 0),
                    'image' => $o['image'] ?? '',
                    'variant_name' => $o['variant_name'] ?? ('Variant #'.($o['variant_id'] ?? '-')),
                    'variant_sku' => $o['variant_sku'] ?? '',
                    'variant_stock' => $o['variant_stock'] ?? null,
                    'variant_status' => $o['variant_status'] ?? '',
                    'variant_final_price' => $o['variant_final_price'] ?? null,
                    'product_description' => $o['product_description'] ?? '',
                    'product_status' => $o['product_status'] ?? '',
                    'product_base_price' => $o['product_base_price'] ?? null,
                    'product_discount' => $o['product_discount'] ?? null,
                    'product_final_price' => $o['product_final_price'] ?? null,
                    'category_name' => $o['category_name'] ?? '',
                    'qty' => $qty,
                    'unit_price' => $unit_price,
                    'line_total' => $line_total,
                    'order_total' => $has_order_total ? ($o['total'] ?? $line_total) : $line_total,
                    'payment_method' => $has_order_payment ? ($o['payment_method'] ?? '-') : '-',
                    'order_address' => $has_order_address ? ($o['address'] ?? '') : '',
                    'status' => $status_key,
                    'order_mode' => 'modern'
                ];
            }
        }
    } else {
        $order_table_mode = 'legacy';
        $orders_q = mysqli_query($con, "
            SELECT o.*
            FROM orders o
            WHERE o.user_id='$user_id'
            ORDER BY $sort_order
            LIMIT 60
        ");

        if($orders_q){
            while($o = mysqli_fetch_assoc($orders_q)){
                $order_id_row = (int)($o['id'] ?? 0);
                if(!isset($seen_order_ids[$order_id_row])){
                    $seen_order_ids[$order_id_row] = true;
                    $order_total_orders++;
                    if($has_order_total){
                        $order_total_spent += (float)($o['total'] ?? 0);
                    }
                }

                $status_key = $has_order_status ? strtolower(trim((string)($o['status'] ?? 'pending'))) : 'pending';
                if($status_key === 'canceled') $status_key = 'cancelled';
                if($status_key === '') $status_key = 'pending';
                if(!isset($order_status_counts[$status_key])) $order_status_counts[$status_key] = 0;
                $order_status_counts[$status_key]++;
                if($order_latest_status === 'No Orders') $order_latest_status = ucfirst($status_key);

                $payment_method = $has_order_payment ? ($o['payment_method'] ?? '-') : '-';
                $created_at = $o['created_at'] ?? null;
                $decoded_items = [];

                if($has_order_items && !empty($o['items'])){
                    $tmp = json_decode($o['items'], true);
                    if(is_array($tmp)) $decoded_items = $tmp;
                }

                if(count($decoded_items) > 0){
                    foreach($decoded_items as $it){
                        $item_qty = max(1, (int)($it['qty'] ?? 1));
                        $item_price = (float)($it['price'] ?? 0);
                        $item_total = $item_price * $item_qty;
                        $order_total_items += $item_qty;

                        $order_history[] = [
                            'order_id' => $order_id_row,
                            'created_at' => $created_at,
                            'product_name' => trim((string)($it['name'] ?? 'Cart Item')),
                            'product_ref_id' => 0,
                            'image' => $it['image'] ?? '',
                            'variant_name' => 'Cart Item',
                            'variant_sku' => '',
                            'variant_stock' => null,
                            'variant_status' => '',
                            'variant_final_price' => null,
                            'product_description' => '',
                            'product_status' => '',
                            'product_base_price' => null,
                            'product_discount' => null,
                            'product_final_price' => null,
                            'category_name' => '',
                            'qty' => $item_qty,
                            'unit_price' => $item_price,
                            'line_total' => $item_total,
                            'order_total' => $has_order_total ? ((float)($o['total'] ?? 0)) : $item_total,
                            'payment_method' => $payment_method,
                            'order_address' => $has_order_address ? ($o['address'] ?? '') : '',
                            'status' => $status_key,
                            'order_mode' => 'legacy'
                        ];
                    }
                } else {
                    $order_total_items++;
                    $line_total = $has_order_total ? (float)($o['total'] ?? 0) : 0;
                    $order_history[] = [
                        'order_id' => $order_id_row,
                        'created_at' => $created_at,
                        'product_name' => 'Order Item',
                        'product_ref_id' => 0,
                        'image' => '',
                        'variant_name' => '—',
                        'variant_sku' => '',
                        'variant_stock' => null,
                        'variant_status' => '',
                        'variant_final_price' => null,
                        'product_description' => '',
                        'product_status' => '',
                        'product_base_price' => null,
                        'product_discount' => null,
                        'product_final_price' => null,
                        'category_name' => '',
                        'qty' => 1,
                        'unit_price' => 0,
                        'line_total' => $line_total,
                        'order_total' => $line_total,
                        'payment_method' => $payment_method,
                        'order_address' => $has_order_address ? ($o['address'] ?? '') : '',
                        'status' => $status_key,
                        'order_mode' => 'legacy'
                    ];
                }
            }
        }
    }
    }
}

if(strtolower($order_latest_status) === 'delivered' || strtolower($order_latest_status) === 'completed'){
    $order_latest_status_class = 'green';
} elseif(strtolower($order_latest_status) === 'pending' || strtolower($order_latest_status) === 'processing'){
    $order_latest_status_class = 'amber';
} elseif(strtolower($order_latest_status) === 'no orders'){
    $order_latest_status_class = 'red';
} else {
    $order_latest_status_class = 'red';
}

/* ===== ATTENDANCE ===== */
$attendance_list=[]; $att_present=0; $att_absent=0; $att_total_pages=1; $att_page=1; $att_years=[]; $att_month=0; $att_year=0;
if ($profileData && $profileData['id']) {
    $memberId = (int)$profileData['id'];
    $att_month = isset($_GET['att_month']) ? (int)$_GET['att_month'] : 0;
    $att_year  = isset($_GET['att_year'])  ? (int)$_GET['att_year']  : 0;
    $att_page  = isset($_GET['att_page'])  ? max(1,(int)$_GET['att_page']) : 1;
    $att_per_page = 20;
    $att_offset   = ($att_page-1)*$att_per_page;

    $att_where = "";
    if($att_month>0) $att_where .= " AND MONTH(a.date)='$att_month'";
    if($att_year>0)  $att_where .= " AND YEAR(a.date)='$att_year'";

    $count_res = mysqli_query($con, "SELECT COUNT(*) as c FROM attendance a WHERE a.member_id='$memberId' $att_where");
    $att_total = mysqli_fetch_assoc($count_res)['c'] ?? 0;
    $att_total_pages = max(1, ceil($att_total / $att_per_page));

    $stat_res = mysqli_query($con, "SELECT status, COUNT(*) as cnt FROM attendance a WHERE a.member_id='$memberId' $att_where GROUP BY status");
    while($sr = mysqli_fetch_assoc($stat_res)){
        if(strtolower($sr['status'])=='present') $att_present = $sr['cnt']; else $att_absent += $sr['cnt'];
    }

    $years_res = mysqli_query($con, "SELECT DISTINCT YEAR(date) as yr FROM attendance WHERE member_id='$memberId' ORDER BY yr DESC");
    while($yr = mysqli_fetch_assoc($years_res)) $att_years[] = $yr['yr'];

    $att_res = mysqli_query($con, "SELECT a.*, b.batch_name FROM attendance a LEFT JOIN batches b ON b.id=a.batch_id WHERE a.member_id='$memberId' $att_where ORDER BY a.date DESC LIMIT $att_per_page OFFSET $att_offset");
    while($row = mysqli_fetch_assoc($att_res)) $attendance_list[] = $row;
}

/* ===== TRAINER, BATCH, DIET ===== */
$trainer = null; $batch=null; $diet=null;
if ($profileData && $profileData['id']) {
    $memberId = (int)$profileData['id'];
    $res = mysqli_query($con, "SELECT t.* FROM trainers t JOIN assign_trainer at ON t.id=at.trainer_id WHERE at.member_id='$memberId' AND t.type='personal' LIMIT 1");
    if(mysqli_num_rows($res)>0) $trainer = mysqli_fetch_assoc($res);

    if(!empty($profileData['batch_id'])){
        $bid = (int)$profileData['batch_id'];
        $res = mysqli_query($con, "SELECT b.*, t.name as trainer_name, t.phone as trainer_phone FROM batches b LEFT JOIN trainers t ON b.trainer_id=t.id WHERE b.id='$bid' LIMIT 1");
        if(mysqli_num_rows($res)>0) $batch = mysqli_fetch_assoc($res);
    }

    $res = mysqli_query($con, "SELECT d.*, t.name as trainer_name FROM diet_plans d LEFT JOIN trainers t ON d.trainer_id=t.id WHERE d.member_id='$memberId' ORDER BY d.created_at DESC LIMIT 1");
    if(mysqli_num_rows($res)>0) $diet = mysqli_fetch_assoc($res);
}

$profile_photo_src = resolve_profile_photo_path($profileData['photo'] ?? '');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Unique Gym</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        :root{
            --primary:#e63946;
            --ink:#111827;
            --muted:#6b7280;
            --line:#e5e7eb;
            --soft:#f4f6fb;
            --card:#ffffff;
            --tint-rose:#fff6f8;
            --tint-blue:#f2f8ff;
            --tint-mint:#f1fbf7;
            --tint-amber:#fff9ef;
            --tint-lilac:#f6f3ff;
            --tint-cyan:#effbff;
        }
        body{
            font-family:'Segoe UI',Arial,sans-serif;
            background:linear-gradient(180deg,#f9fbff 0%, #f3f7fe 100%);
            color:var(--ink);
        }
        a{text-decoration:none;color:inherit;}
        .shell{max-width:1240px;margin:18px auto;padding:0 20px;}
        .hero{
            background:linear-gradient(120deg,#ffffff 0%, #f4f9ff 52%, #ffffff 100%);
            border:1px solid #dde6f3;
            border-radius:14px;
            padding:14px 16px;
            display:flex;
            justify-content:space-between;
            gap:16px;
            align-items:center;
            box-shadow:none;
        }
        .hero-main{display:flex;gap:16px;align-items:center;min-width:0;}
        .avatar{
            width:94px;height:94px;border-radius:16px;overflow:hidden;background:#111827;border:3px solid #fff;box-shadow:0 8px 18px rgba(0,0,0,0.15);
            flex-shrink:0;
        }
        .avatar img{width:100%;height:100%;object-fit:cover;}
        .hero-info h1{margin:0;font-size:28px;line-height:1.15;}
        .hero-sub{margin-top:6px;color:var(--muted);font-size:13px;}
        .meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;}
        .pill{
            background:#f8fafc;color:#374151;padding:6px 10px;border-radius:999px;font-weight:700;font-size:12px;border:1px solid #e5e7eb;
        }
        .pill.good{background:#e8f5e9;color:#1f9d55;border-color:#ccebd4;}
        .pill.warn{background:#fff8e6;color:#d97706;border-color:#f2deb3;}
        .pill.bad{background:#fee2e2;color:#b91c1c;border-color:#fecaca;}
        .hero-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end;}
        .btn-light,.btn-outline,.btn-primary{
            padding:10px 15px;border-radius:10px;font-weight:700;cursor:pointer;border:1px solid transparent;font-size:13px;
        }
        .btn-light{background:#111827;color:#fff;}
        .btn-outline{background:#fff;color:#111827;border-color:#d1d5db;}
        .btn-primary{background:var(--primary);color:#fff;border:none;}
        .grid{display:grid;gap:14px;}
        .grid-4{grid-template-columns:1fr;margin:14px 0;}
        .grid-3{grid-template-columns:repeat(auto-fit,minmax(220px,1fr));margin:16px 0;}
        .card{
            background:var(--card);
            border-radius:12px;
            padding:14px 16px;
            box-shadow:none;
            border:1px solid #dfe7f3;
            margin-bottom:10px;
        }
        .card h3{margin-bottom:10px;font-size:16px;}
        .stat-val{font-size:26px;font-weight:800;line-height:1.1;}
        .stat-sub{color:var(--muted);font-size:12px;margin-top:4px;}
        .split{display:block;}
        .att-count{
            padding:10px 12px;
            border:1px dashed #d8e0ed;
            border-radius:10px;
            background:rgba(255,255,255,0.72);
        }
        .summary-strip .card:nth-child(1){background:linear-gradient(135deg,var(--tint-blue),#ffffff);border-left:4px solid #3b82f6;}
        .summary-strip .card:nth-child(2){background:linear-gradient(135deg,var(--tint-rose),#ffffff);border-left:4px solid #ef4444;}
        .summary-strip .card:nth-child(3){background:linear-gradient(135deg,var(--tint-mint),#ffffff);border-left:4px solid #10b981;}
        .summary-strip .card:nth-child(4){background:linear-gradient(135deg,var(--tint-cyan),#ffffff);border-left:4px solid #06b6d4;}
        .summary-strip .card:nth-child(5){background:linear-gradient(135deg,var(--tint-lilac),#ffffff);border-left:4px solid #8b5cf6;}
        .section-stack .card:nth-child(1){background:linear-gradient(135deg,var(--tint-rose),#ffffff);border-left:4px solid #ef4444;}
        .section-stack .card:nth-child(2){background:linear-gradient(135deg,var(--tint-mint),#ffffff);border-left:4px solid #10b981;}
        .section-stack .card:nth-child(3){background:linear-gradient(135deg,var(--tint-blue),#ffffff);border-left:4px solid #3b82f6;}
        .section-stack .card:nth-child(4){background:linear-gradient(135deg,var(--tint-lilac),#ffffff);border-left:4px solid #8b5cf6;}
        .section-stack .card:nth-child(5){background:linear-gradient(135deg,var(--tint-amber),#ffffff);border-left:4px solid #f59e0b;}
        .section-stack .card:nth-child(6){background:linear-gradient(135deg,var(--tint-cyan),#ffffff);border-left:4px solid #06b6d4;}
        .section-stack .card:nth-child(7){background:linear-gradient(135deg,#f4f7ff,#ffffff);border-left:4px solid #6366f1;}
        .panel-events{background:linear-gradient(135deg,var(--tint-cyan),#ffffff);border-left:4px solid #06b6d4;}
        .panel-orders{background:linear-gradient(135deg,var(--tint-mint),#ffffff);border-left:4px solid #10b981;}
        .panel-attendance{background:linear-gradient(135deg,var(--tint-amber),#ffffff);border-left:4px solid #f59e0b;}
        .panel-edit{background:linear-gradient(135deg,var(--tint-rose),#ffffff);border-left:4px solid #ef4444;}
        .list{list-style:none;margin:0;padding:0;display:grid;gap:8px;}
        .list li{
            display:flex;justify-content:space-between;gap:10px;align-items:center;padding:10px;border:1px solid #eef1f7;border-radius:10px;background:#fbfcfe;
        }
        .list li span:first-child{color:#6b7280;font-weight:600;}
        .badge{padding:6px 10px;border-radius:8px;font-weight:700;font-size:12px;display:inline-block;}
        .badge.green{background:#e8f5e9;color:#1f9d55;}
        .badge.amber{background:#fff7e6;color:#d97706;}
        .badge.red{background:#fee2e2;color:#b91c1c;}
        .table-wrap{overflow-x:auto;border:1px solid #eef1f7;border-radius:12px;}
        table{width:100%;border-collapse:collapse;font-size:13px;background:#fff;}
        th,td{padding:10px;border-bottom:1px solid #eef1f7;text-align:left;}
        th{color:#6b7280;font-weight:700;background:#f9fafb;text-transform:uppercase;font-size:12px;}
        .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;}
        input,select,textarea{
            width:100%;padding:11px 12px;border-radius:10px;border:1px solid #d9deea;font-size:14px;outline:none;background:#fff;
        }
        input:focus,select:focus,textarea:focus{border-color:#f0a2a9;box-shadow:0 0 0 3px rgba(230,57,70,0.1);}
        .alert{padding:12px 14px;border-radius:10px;margin-bottom:14px;font-weight:700;}
        .alert.success{background:#e8f5e9;color:#1f9d55;}
        .alert.error{background:#fee2e2;color:#b91c1c;}
        .muted{color:#6b7280;}
        .gift-row{display:flex;gap:10px;flex-wrap:wrap;margin-top:8px;}
        .gift-pill{padding:7px 10px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid #e5e7eb;background:#f8fafc;}
        .gift-pill.ok{background:#e8f5e9;color:#1f9d55;border-color:#ccebd4;}
        .gift-pill.no{background:#fee2e2;color:#b91c1c;border-color:#fecaca;}
        .badge.blue{background:#e8f0ff;color:#1d4ed8;}
        .tiny{font-size:12px;color:#6b7280;}
        .section-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;}
        .status-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;}
        .prod-cell{display:flex;align-items:center;gap:8px;min-width:220px;}
        .thumb-mini{
            width:40px;height:40px;border-radius:8px;object-fit:cover;background:#eef1f7;flex-shrink:0;
            border:1px solid #e5e7eb;
        }
        .empty-note{color:#6b7280;text-align:center;padding:14px;}
        .btn-sm{
            padding:7px 10px;
            border-radius:8px;
            border:1px solid #d1d5db;
            background:#fff;
            font-size:12px;
            font-weight:700;
            color:#111827;
            cursor:pointer;
        }
        .btn-sm:hover{border-color:#e63946;color:#e63946;}
        .modal-overlay{
            position:fixed;
            inset:0;
            background:rgba(17,24,39,.56);
            display:none;
            align-items:center;
            justify-content:center;
            padding:14px;
            z-index:9999;
        }
        .modal-card{
            width:min(760px, 100%);
            max-height:92vh;
            overflow:auto;
            background:#fff;
            border-radius:14px;
            border:1px solid #e5e7eb;
            box-shadow:0 20px 48px rgba(0,0,0,.2);
            padding:18px;
        }
        .modal-top{
            display:flex;
            justify-content:space-between;
            gap:10px;
            align-items:flex-start;
            margin-bottom:12px;
        }
        .modal-grid{
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
            gap:10px;
        }
        .kv{
            border:1px solid #eef1f7;
            border-radius:10px;
            background:#fbfcfe;
            padding:10px;
        }
        .kv .k{display:block;font-size:11px;color:#6b7280;margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px;}
        .kv .v{display:block;font-size:13px;color:#111827;font-weight:700;word-break:break-word;}
        .modal-image{
            width:100%;
            max-width:220px;
            border-radius:10px;
            border:1px solid #e5e7eb;
            background:#f8fafc;
            object-fit:cover;
        }
        @media(max-width:900px){
            .hero{flex-direction:column;align-items:flex-start;}
            .hero-actions{justify-content:flex-start;}
        }
    </style>
</head>
<body>
<div class="shell">
    <?php if(isset($error)): ?><div class="alert error"><?php echo $error; ?></div><?php elseif(isset($success)): ?><div class="alert success"><?php echo $success; ?></div><?php endif; ?>

    <div class="hero">
        <div class="hero-main">
            <div class="avatar">
                <?php if($profile_photo_src !== ''): ?>
                    <img src="<?php echo htmlspecialchars($profile_photo_src); ?>" alt="Profile photo">
                <?php else: ?>
                    <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:36px;font-weight:800;color:#fff;">
                        <?php echo strtoupper(substr($username,0,1)); ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="hero-info">
                <h1><?php echo htmlspecialchars($profileData['fullname'] ?? $userInfo['fullname'] ?? $username); ?></h1>
                <div class="hero-sub">Member Account Dashboard</div>
                <div class="meta">
                    <span class="pill">Username: <?php echo htmlspecialchars($username); ?></span>
                    <span class="pill">Age: <?php echo htmlspecialchars($profileData['age'] ?? 'N/A'); ?></span>
                    <span class="pill">Height: <?php echo htmlspecialchars($profileData['height'] ?? 'N/A'); ?></span>
                    <span class="pill">Weight: <?php echo htmlspecialchars($profileData['weight'] ?? 'N/A'); ?></span>
                    <span class="pill">Gender: <?php echo htmlspecialchars($profileData['gender'] ?? 'N/A'); ?></span>
                    <?php if($membership): ?><span class="pill good">Active Membership</span>
                    <?php elseif($pending_membership): ?><span class="pill warn">Membership Pending</span>
                    <?php else: ?><span class="pill bad">No Membership</span><?php endif; ?>
                    <span class="pill <?php echo $event_pill_class; ?>">Event: <?php echo htmlspecialchars($event_join_state); ?></span>
                    <?php if($order_total_orders > 0): ?>
                        <span class="pill good">Orders: <?php echo (int)$order_total_orders; ?></span>
                    <?php else: ?>
                        <span class="pill">Orders: 0</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="hero-actions">
            <button class="btn-light" onclick="location.href='newhome.php'">Back to Home</button>
            <button class="btn-outline" onclick="location.href='products.php'">Shop Products</button>
            <button class="btn-primary" onclick="document.getElementById('edit-form').scrollIntoView({behavior:'smooth'});">Edit Profile</button>
        </div>
    </div>

    <div class="grid grid-4 summary-strip">
        <div class="card"><div class="stat-val"><?php echo $att_present; ?> / <?php echo ($att_present+$att_absent); ?></div><div class="stat-sub">Attendance (present / total)</div></div>
        <div class="card">
            <div class="stat-val">
                <?php echo $membership ? 'Active' : ($pending_membership ? 'Pending' : 'No Plan'); ?>
            </div>
            <div class="stat-sub">Plan: <?php echo $membership ? htmlspecialchars($membership['plan_name']) : ($pending_membership['plan_name'] ?? '—'); ?></div>
        </div>
        <div class="card">
            <div class="stat-val"><?php echo htmlspecialchars($free_item_overall); ?></div>
            <div class="stat-sub">Free Items (Gym Bag + Bottle)</div>
        </div>
        <div class="card">
            <div class="stat-val"><?php echo htmlspecialchars($event_join_state); ?></div>
            <div class="stat-sub">
                Event Requests: <?php echo (int)$event_total_requests; ?>
                (Approved: <?php echo (int)($event_counts['approved'] ?? 0); ?>, Pending: <?php echo (int)($event_counts['pending'] ?? 0); ?>)
            </div>
        </div>
        <div class="card">
            <div class="stat-val"><?php echo (int)$order_total_orders; ?></div>
            <div class="stat-sub">
                Orders | Items: <?php echo (int)$order_total_items; ?> |
                Latest: <?php echo htmlspecialchars($order_latest_status); ?> |
                Spent: Rs <?php echo number_format($order_total_spent, 2); ?>
            </div>
        </div>
    </div>

    <div class="split section-stack">
        <div class="card">
            <h3>Membership</h3>
            <?php if($membership): ?>
                <?php
                    $plan   = htmlspecialchars($membership['plan_name'] ?? '—');
                    $start_raw = $membership['start_date'] ?? $membership['purchase_date'] ?? null;
                    $start  = $start_raw ? date('d M Y', strtotime($start_raw)) : '—';
                    $duration_days_calc = 0;
                    if(!empty($membership['duration_days'])){
                        $duration_days_calc = (int)$membership['duration_days'];
                    } elseif(!empty($membership['duration'])) {
                        $duration_text = trim((string)$membership['duration']);
                        if(is_numeric($duration_text)){
                            $duration_days_calc = (int)$duration_text;
                        } elseif(preg_match('/(\d+)/', $duration_text, $mm)) {
                            $duration_days_calc = (int)$mm[1];
                        }
                    }
                    if(!empty($membership['end_date'])){
                        $end = date('d M Y', strtotime($membership['end_date']));
                    } elseif(!empty($start_raw) && $duration_days_calc > 0) {
                        $end = date('d M Y', strtotime($start_raw." +".$duration_days_calc." days"));
                    } else {
                        $end = '—';
                    }
                ?>
                <ul class="list">
                    <li><span>Plan</span><strong><?php echo $plan; ?></strong></li>
                    <li><span>Start</span><strong><?php echo $start; ?></strong></li>
                    <li><span>End</span><strong><?php echo $end; ?></strong></li>
                    <li><span>Status</span><span class="badge green">Active</span></li>
                </ul>
            <?php elseif($pending_membership): ?>
                <div class="badge amber">Pending approval</div>
                <p style="margin-top:8px;color:#6b7280;">Plan: <?php echo htmlspecialchars($pending_membership['plan_name']); ?></p>
            <?php else: ?>
                <?php if($membership_cancelled): ?>
                    <span class="badge red">Membership Cancelled</span>
                    <p style="margin-top:8px;color:#6b7280;">Your previous membership was cancelled or expired.</p>
                    <p style="margin-top:8px;">Please buy membership first. <a href="mmm.php" style="color:#e63946;font-weight:700;">Buy a plan →</a></p>
                <?php else: ?>
                    <p>No membership found. <a href="mmm.php" style="color:#e63946;font-weight:700;">Buy a plan →</a></p>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($latest_membership_receipt): ?>
                <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
                    <a href="membership_receipt.php?id=<?php echo (int)$latest_membership_receipt['id']; ?>" class="btn-sm" style="text-decoration:none;">View Latest Receipt</a>
                    <a href="membership_receipt.php?id=<?php echo (int)$latest_membership_receipt['id']; ?>&download=1" class="btn-sm" style="text-decoration:none;">Download Latest Receipt</a>
                </div>
            <?php endif; ?>

            <?php if(!empty($membership_receipts)): ?>
                <div style="margin-top:12px;">
                    <div class="tiny" style="font-weight:700;color:#4b5563;margin-bottom:6px;">Recent Membership Receipts</div>
                    <div style="display:flex;flex-direction:column;gap:6px;">
                        <?php foreach($membership_receipts as $rc): ?>
                            <?php
                                $rc_status = strtolower(trim((string)($rc['status'] ?? 'pending')));
                                if($rc_status === 'canceled') $rc_status = 'cancelled';
                                $rc_badge = $rc_status === 'approved' ? 'green' : ($rc_status === 'pending' ? 'amber' : 'red');
                                $rc_date = !empty($rc['receipt_date']) ? date('d M Y', strtotime($rc['receipt_date'])) : '—';
                            ?>
                            <div style="border:1px solid #eceff5;border-radius:8px;padding:8px 10px;background:#fafbff;">
                                <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap;">
                                    <div style="font-size:12px;">
                                        <strong><?php echo htmlspecialchars($rc['plan_name'] ?? 'Membership Plan'); ?></strong>
                                        | Rs <?php echo number_format((float)($rc['amount'] ?? 0), 2); ?>
                                        | <?php echo $rc_date; ?>
                                    </div>
                                    <span class="badge <?php echo $rc_badge; ?>"><?php echo ucfirst($rc_status); ?></span>
                                </div>
                                <div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap;">
                                    <a href="membership_receipt.php?id=<?php echo (int)$rc['id']; ?>" class="btn-sm" style="text-decoration:none;">View</a>
                                    <a href="membership_receipt.php?id=<?php echo (int)$rc['id']; ?>&download=1" class="btn-sm" style="text-decoration:none;">Download</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>Free Membership Items</h3>
            <?php if($free_item_state === 'eligible'): ?>
                <?php
                    $gymbag_given = (($free_item_row['gymbag_status'] ?? 'not_given') === 'given');
                    $bottle_given = (($free_item_row['bottle_status'] ?? 'not_given') === 'given');
                    $overall_class = ($gymbag_given && $bottle_given) ? 'green' : (($gymbag_given || $bottle_given) ? 'amber' : 'red');
                ?>
                <span class="badge <?php echo $overall_class; ?>"><?php echo htmlspecialchars($free_item_overall); ?></span>
                <div class="gift-row">
                    <span class="gift-pill <?php echo $gymbag_given ? 'ok' : 'no'; ?>">Gym Bag: <?php echo $gymbag_given ? 'Collected' : 'Not Collected'; ?></span>
                    <span class="gift-pill <?php echo $bottle_given ? 'ok' : 'no'; ?>">Bottle: <?php echo $bottle_given ? 'Collected' : 'Not Collected'; ?></span>
                </div>
                <?php if(!empty($free_item_row['note'])): ?>
                    <p class="muted" style="margin-top:10px;">Admin Note: <?php echo htmlspecialchars($free_item_row['note']); ?></p>
                <?php endif; ?>
            <?php elseif($free_item_state === 'pending'): ?>
                <span class="badge amber">Available After Approval</span>
                <p class="muted" style="margin-top:8px;">Your membership request is pending. Free item status will be visible after approval.</p>
            <?php else: ?>
                <span class="badge red">Not Available Yet</span>
                <p class="muted" style="margin-top:8px;">Buy membership first to get free Gym Bag and Bottle.</p>
                <p style="margin-top:10px;"><a href="mmm.php" style="color:#e63946;font-weight:700;">View Membership Plans</a></p>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>Personal Trainer</h3>
            <?php if($trainer): ?>
                <ul class="list">
                    <li><span>Name</span><strong><?php echo htmlspecialchars($trainer['name']); ?></strong></li>
                    <li><span>Phone</span><strong><?php echo htmlspecialchars($trainer['phone']); ?></strong></li>
                    <?php if(!empty($trainer['type'])): ?><li><span>Type</span><strong><?php echo htmlspecialchars($trainer['type']); ?></strong></li><?php endif; ?>
                </ul>
            <?php else: ?><p>No personal trainer assigned.</p><?php endif; ?>
        </div>

        <div class="card">
            <h3>Batch</h3>
            <?php if($batch): ?>
                <?php
                    $start = !empty($batch['start_time']) ? date('h:i A', strtotime($batch['start_time'])) : null;
                    $end   = !empty($batch['end_time'])   ? date('h:i A', strtotime($batch['end_time']))   : null;
                    $time_str = ($start && $end) ? "$start - $end" : ($start ?: ($end ?: 'Not set'));
                ?>
                <ul class="list">
                    <li><span>Batch</span><strong><?php echo htmlspecialchars($batch['batch_name']); ?></strong></li>
                    <li><span>Timing</span><strong><?php echo $time_str; ?></strong></li>
                    <?php if(!empty($batch['trainer_name'])): ?><li><span>Batch Trainer</span><strong><?php echo htmlspecialchars($batch['trainer_name']); ?></strong></li><?php endif; ?>
                </ul>
            <?php else: ?><p>No batch assigned.</p><?php endif; ?>
        </div>

        <div class="card">
            <h3>Diet Plan</h3>
            <?php if($diet): ?>
                <p><strong><?php echo htmlspecialchars($diet['title'] ?? 'Latest plan'); ?></strong></p>
                <p style="color:#6b7280;">Prepared by <?php echo htmlspecialchars($diet['trainer_name'] ?? 'Trainer'); ?> on <?php echo date('d M Y', strtotime($diet['created_at'])); ?></p>
                <p style="white-space:pre-line;">
                    <?php echo nl2br(htmlspecialchars($diet['plan_text'] ?? $diet['description'] ?? '')); ?>
                </p>
            <?php else: ?><p>No diet plan assigned yet.</p><?php endif; ?>
        </div>

        <div class="card">
            <h3>Event Join Status</h3>
            <div class="status-row">
                <span class="badge <?php echo $event_pill_class === 'good' ? 'green' : ($event_pill_class === 'warn' ? 'amber' : 'red'); ?>">
                    <?php echo htmlspecialchars($event_join_state); ?>
                </span>
                <span class="badge blue">Total Requests: <?php echo (int)$event_total_requests; ?></span>
            </div>
            <?php if(!$profileData): ?>
                <p class="muted" style="margin-top:8px;">Complete your profile details first to join events.</p>
            <?php endif; ?>
            <ul class="list" style="margin-top:10px;">
                <li><span>Approved</span><strong><?php echo (int)($event_counts['approved'] ?? 0); ?></strong></li>
                <li><span>Pending</span><strong><?php echo (int)($event_counts['pending'] ?? 0); ?></strong></li>
                <li><span>Cancelled</span><strong><?php echo (int)($event_counts['cancelled'] ?? 0); ?></strong></li>
                <li><span>Latest</span><strong><?php echo htmlspecialchars($event_latest_label); ?></strong></li>
            </ul>
        </div>

        <div class="card">
            <h3>Product Purchase Status</h3>
            <div class="status-row">
                <span class="badge <?php echo $order_latest_status_class; ?>">Latest: <?php echo htmlspecialchars($order_latest_status); ?></span>
                <span class="badge blue"><?php echo strtoupper($order_table_mode); ?> Order Mode</span>
            </div>
            <ul class="list" style="margin-top:10px;">
                <li><span>Total Orders</span><strong><?php echo (int)$order_total_orders; ?></strong></li>
                <li><span>Total Items</span><strong><?php echo (int)$order_total_items; ?></strong></li>
                <li><span>Total Spent</span><strong>Rs <?php echo number_format($order_total_spent,2); ?></strong></li>
                <li><span>Delivered/Completed</span><strong><?php echo (int)(($order_status_counts['delivered'] ?? 0) + ($order_status_counts['completed'] ?? 0)); ?></strong></li>
            </ul>
        </div>
    </div>

    <div class="card panel-events" style="margin-top:14px;">
        <div class="section-head">
            <div>
                <h3 style="margin:0;">Event Join History</h3>
                <p class="tiny" style="margin-top:4px;">Track all event join requests and approval status.</p>
            </div>
            <div class="status-row">
                <span class="badge blue">Requests: <?php echo (int)$event_total_requests; ?></span>
                <button class="btn-outline" type="button" onclick="location.href='newhome.php#events'">Join New Event</button>
            </div>
        </div>

        <div class="table-wrap" style="margin-top:12px;">
            <table>
                <tr><th>#</th><th>Event</th><th>Event Date</th><th>Requested On</th><th>Contact</th><th>Status</th></tr>
                <?php if(count($event_history) > 0): foreach($event_history as $ev): ?>
                    <?php
                        $event_status = strtolower(trim((string)($ev['status'] ?? 'pending')));
                        if($event_status === 'canceled') $event_status = 'cancelled';
                        $event_badge = $event_status === 'approved' ? 'badge green' : ($event_status === 'pending' ? 'badge amber' : 'badge red');
                        $event_dt = !empty($ev['event_date']) ? date('d M Y', strtotime($ev['event_date'])) : '—';
                        if(!empty($ev['event_time'])){
                            $event_dt .= " | " . date('h:i A', strtotime($ev['event_time']));
                        }
                        $registered_on = !empty($ev['registered_at']) ? date('d M Y H:i', strtotime($ev['registered_at'])) : '—';
                    ?>
                    <tr>
                        <td>#<?php echo (int)$ev['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($ev['title'] ?? 'Event'); ?></strong>
                            <?php if(!empty($ev['location'])): ?><div class="tiny"><?php echo htmlspecialchars($ev['location']); ?></div><?php endif; ?>
                        </td>
                        <td><?php echo $event_dt; ?></td>
                        <td><?php echo $registered_on; ?></td>
                        <td>
                            <?php echo htmlspecialchars($ev['phone'] ?? '—'); ?>
                            <?php if(!empty($ev['fullname'])): ?><div class="tiny"><?php echo htmlspecialchars($ev['fullname']); ?></div><?php endif; ?>
                        </td>
                        <td><span class="<?php echo $event_badge; ?>"><?php echo ucfirst($event_status); ?></span></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="6" class="empty-note">No event join history found yet.</td></tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <div class="card panel-orders" style="margin-top:14px;">
        <div class="section-head">
            <div>
                <h3 style="margin:0;">Product Purchase History</h3>
                <p class="tiny" style="margin-top:4px;">Detailed order lines including product, quantity, payment and status.</p>
            </div>
            <div class="status-row">
                <span class="badge blue">Orders: <?php echo (int)$order_total_orders; ?></span>
                <span class="badge blue">Spent: Rs <?php echo number_format($order_total_spent,2); ?></span>
                <button class="btn-outline" type="button" onclick="location.href='products.php'">Buy Products</button>
            </div>
        </div>

        <div class="table-wrap" style="margin-top:12px;">
            <table>
                <tr><th>Order ID</th><th>Date</th><th>Product</th><th>Variant</th><th>Qty</th><th>Unit Price</th><th>Total</th><th>Payment</th><th>Status</th><th>Details</th></tr>
                <?php if(count($order_history) > 0): foreach($order_history as $oh): ?>
                    <?php
                        $order_status = strtolower(trim((string)($oh['status'] ?? 'pending')));
                        if($order_status === 'canceled') $order_status = 'cancelled';
                        $order_badge = in_array($order_status, ['completed','delivered'], true)
                            ? 'badge green'
                            : (in_array($order_status, ['pending','processing'], true) ? 'badge amber' : 'badge red');

                        $order_date = !empty($oh['created_at']) ? date('d M Y H:i', strtotime($oh['created_at'])) : '—';
                        $product_name = trim((string)($oh['product_name'] ?? 'Product'));
                        $variant_name = trim((string)($oh['variant_name'] ?? '—'));
                        $qty = (int)($oh['qty'] ?? 1);
                        $unit_price = (float)($oh['unit_price'] ?? 0);
                        $line_total = (float)($oh['line_total'] ?? 0);
                        $image_raw = trim((string)($oh['image'] ?? ''));
                        $image_src = resolve_profile_product_image($image_raw, $product_name);
                        $product_link = (int)($oh['product_ref_id'] ?? 0) > 0 ? ('product_detail.php?id='.(int)$oh['product_ref_id']) : '';
                        $details_payload = json_encode([
                            'order_id' => (int)($oh['order_id'] ?? 0),
                            'order_date' => $order_date,
                            'order_date_only' => !empty($oh['created_at']) ? date('d M Y', strtotime($oh['created_at'])) : '',
                            'order_time_only' => !empty($oh['created_at']) ? date('h:i A', strtotime($oh['created_at'])) : '',
                            'status' => ucfirst($order_status),
                            'payment_method' => (string)($oh['payment_method'] ?? '-'),
                            'qty' => $qty,
                            'unit_price' => number_format($unit_price, 2),
                            'line_total' => number_format($line_total, 2),
                            'order_total' => number_format((float)($oh['order_total'] ?? $line_total), 2),
                            'order_address' => trim((string)($oh['order_address'] ?? '')),
                            'order_mode' => strtoupper((string)($oh['order_mode'] ?? $order_table_mode)),
                            'product_name' => $product_name,
                            'product_link' => $product_link,
                            'image_src' => $image_src,
                            'category_name' => trim((string)($oh['category_name'] ?? '')),
                            'product_status' => trim((string)($oh['product_status'] ?? '')),
                            'product_description' => trim((string)($oh['product_description'] ?? '')),
                            'product_base_price' => isset($oh['product_base_price']) && $oh['product_base_price'] !== null ? number_format((float)$oh['product_base_price'], 2) : '',
                            'product_discount' => isset($oh['product_discount']) && $oh['product_discount'] !== null ? (string)$oh['product_discount'] : '',
                            'product_final_price' => isset($oh['product_final_price']) && $oh['product_final_price'] !== null ? number_format((float)$oh['product_final_price'], 2) : '',
                            'variant_name' => $variant_name,
                            'variant_sku' => trim((string)($oh['variant_sku'] ?? '')),
                            'variant_stock' => ($oh['variant_stock'] ?? '') === '' ? '' : (string)$oh['variant_stock'],
                            'variant_status' => trim((string)($oh['variant_status'] ?? '')),
                            'variant_final_price' => isset($oh['variant_final_price']) && $oh['variant_final_price'] !== null ? number_format((float)$oh['variant_final_price'], 2) : ''
                        ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
                        $details_payload_b64 = base64_encode((string)$details_payload);
                    ?>
                    <tr>
                        <td>#<?php echo (int)$oh['order_id']; ?></td>
                        <td><?php echo $order_date; ?></td>
                        <td>
                            <div class="prod-cell">
                                <?php if($image_src !== ''): ?>
                                    <img src="<?php echo htmlspecialchars($image_src); ?>" alt="Product" class="thumb-mini">
                                <?php else: ?>
                                    <div class="thumb-mini" style="display:flex;align-items:center;justify-content:center;">IMG</div>
                                <?php endif; ?>
                                <div>
                                    <?php if((int)($oh['product_ref_id'] ?? 0) > 0): ?>
                                        <a href="product_detail.php?id=<?php echo (int)$oh['product_ref_id']; ?>" style="font-weight:700;color:#111827;"><?php echo htmlspecialchars($product_name); ?></a>
                                    <?php else: ?>
                                        <strong><?php echo htmlspecialchars($product_name); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td><?php echo htmlspecialchars($variant_name !== '' ? $variant_name : '—'); ?></td>
                        <td><?php echo $qty; ?></td>
                        <td>Rs <?php echo number_format($unit_price,2); ?></td>
                        <td>Rs <?php echo number_format($line_total,2); ?></td>
                        <td><?php echo htmlspecialchars($oh['payment_method'] ?? '-'); ?></td>
                        <td><span class="<?php echo $order_badge; ?>"><?php echo ucfirst($order_status); ?></span></td>
                        <td>
                            <button type="button" class="btn-sm" data-details-b64="<?php echo htmlspecialchars((string)$details_payload_b64, ENT_QUOTES); ?>" onclick="openOrderDetails(this)">
                                View
                            </button>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="10" class="empty-note">No product purchase history found yet.</td></tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <div id="orderDetailModal" class="modal-overlay" onclick="closeOrderDetails(event)">
        <div class="modal-card" onclick="event.stopPropagation();">
            <div class="modal-top">
                <div>
                    <h3 style="margin:0;">Order Item Details</h3>
                    <p class="tiny" style="margin-top:4px;">Complete status and product information for selected item.</p>
                </div>
                <button type="button" class="btn-sm" onclick="closeOrderDetails()">Close</button>
            </div>

            <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap;margin-bottom:12px;">
                <img id="od-image" class="modal-image" src="" alt="Product">
                <div style="flex:1;min-width:240px;">
                    <h4 id="od-product" style="margin:0 0 6px;"></h4>
                    <div class="status-row">
                        <span id="od-status-badge" class="badge amber">Pending</span>
                        <span id="od-mode-badge" class="badge blue">MODE</span>
                    </div>
                    <p id="od-description" class="tiny" style="margin-top:8px;line-height:1.6;"></p>
                    <p id="od-product-link-wrap" class="tiny" style="margin-top:8px;"></p>
                </div>
            </div>

            <div class="modal-grid">
                <div class="kv"><span class="k">Order ID</span><span class="v" id="od-order-id">-</span></div>
                <div class="kv"><span class="k">Order Date</span><span class="v" id="od-date-only">-</span></div>
                <div class="kv"><span class="k">Order Time</span><span class="v" id="od-time-only">-</span></div>
                <div class="kv"><span class="k">Payment Method</span><span class="v" id="od-payment">-</span></div>
                <div class="kv"><span class="k">Order Address</span><span class="v" id="od-address">-</span></div>
                <div class="kv"><span class="k">Quantity</span><span class="v" id="od-qty">-</span></div>
                <div class="kv"><span class="k">Unit Price</span><span class="v" id="od-unit">-</span></div>
                <div class="kv"><span class="k">Line Total</span><span class="v" id="od-line">-</span></div>
                <div class="kv"><span class="k">Order Total</span><span class="v" id="od-order-total">-</span></div>
                <div class="kv"><span class="k">Category</span><span class="v" id="od-category">-</span></div>
                <div class="kv"><span class="k">Product Status</span><span class="v" id="od-product-status">-</span></div>
                <div class="kv"><span class="k">Product Base Price</span><span class="v" id="od-base-price">-</span></div>
                <div class="kv"><span class="k">Product Final Price</span><span class="v" id="od-final-price">-</span></div>
                <div class="kv"><span class="k">Product Discount</span><span class="v" id="od-discount">-</span></div>
                <div class="kv"><span class="k">Variant</span><span class="v" id="od-variant">-</span></div>
                <div class="kv"><span class="k">Variant SKU</span><span class="v" id="od-sku">-</span></div>
                <div class="kv"><span class="k">Variant Stock</span><span class="v" id="od-stock">-</span></div>
                <div class="kv"><span class="k">Variant Status</span><span class="v" id="od-variant-status">-</span></div>
                <div class="kv"><span class="k">Variant Final Price</span><span class="v" id="od-variant-price">-</span></div>
            </div>
        </div>
    </div>

    <div class="card panel-attendance" style="margin-top:14px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap;">
            <div>
                <h3 style="margin:0;">Attendance</h3>
                <p style="color:#6b7280;margin:4px 0 0;">Filter by month/year and track presence.</p>
            </div>
            <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                <select name="att_month">
                    <option value="">Month</option>
                    <?php for($m=1;$m<=12;$m++): ?>
                        <option value="<?php echo $m; ?>" <?php echo ($att_month==$m)?'selected':''; ?>><?php echo date('F', mktime(0,0,0,$m,1)); ?></option>
                    <?php endfor; ?>
                </select>
                <select name="att_year">
                    <option value="">Year</option>
                    <?php foreach($att_years as $yr): ?>
                        <option value="<?php echo $yr; ?>" <?php echo ($att_year==$yr)?'selected':''; ?>><?php echo $yr; ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="btn-primary" type="submit">Filter</button>
            </form>
        </div>

        <div class="grid grid-3" style="margin-top:14px;">
            <div class="att-count">
                <div class="stat-val"><?php echo $att_present; ?></div>
                <div class="stat-sub">Present</div>
            </div>
            <div class="att-count">
                <div class="stat-val"><?php echo $att_absent; ?></div>
                <div class="stat-sub">Absent</div>
            </div>
            <div class="att-count">
                <div class="stat-val"><?php echo ($att_present+$att_absent); ?></div>
                <div class="stat-sub">Sessions counted</div>
            </div>
        </div>

        <div class="table-wrap" style="margin-top:12px;">
            <table>
                <tr><th>Date</th><th>Status</th><th>Batch</th></tr>
                <?php if(count($attendance_list)>0): foreach($attendance_list as $a): ?>
                    <tr>
                        <td><?php echo date('d M Y', strtotime($a['date'])); ?></td>
                        <td><?php $cls=strtolower($a['status'])=='present'?'badge green':'badge red'; echo '<span class="'.$cls.'">'.ucfirst($a['status']).'</span>'; ?></td>
                        <td><?php echo htmlspecialchars($a['batch_name'] ?? '—'); ?></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="3" style="text-align:center;color:#6b7280;">No attendance records.</td></tr>
                <?php endif; ?>
            </table>
        </div>
        <?php if($att_total_pages > 1): ?>
            <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
                <?php for($p=1;$p<=$att_total_pages;$p++): ?>
                    <a class="pill" style="background:<?php echo $p==$att_page?'#e63946':'#f3f4f6'; ?>;color:<?php echo $p==$att_page?'#fff':'#111'; ?>;" href="?att_page=<?php echo $p; ?>&att_month=<?php echo $att_month; ?>&att_year=<?php echo $att_year; ?>">
                        <?php echo $p; ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="card panel-edit" id="edit-form" style="margin:14px 0 24px;">
        <h3>Edit Profile</h3>
        <form method="POST" enctype="multipart/form-data" class="form-grid">
            <div><label>Full Name</label><input type="text" name="fullname" value="<?php echo htmlspecialchars($profileData['fullname'] ?? $userInfo['fullname'] ?? ''); ?>" required></div>
            <div><label>Age</label><input type="number" name="age" value="<?php echo htmlspecialchars($profileData['age'] ?? ''); ?>" min="1" max="150" required></div>
            <div><label>Gender</label>
                <select name="gender" required>
                    <option value="">Select</option>
                    <?php $g=$profileData['gender']??''; ?>
                    <option value="Male" <?php echo $g=='Male'?'selected':''; ?>>Male</option>
                    <option value="Female" <?php echo $g=='Female'?'selected':''; ?>>Female</option>
                    <option value="Other" <?php echo $g=='Other'?'selected':''; ?>>Other</option>
                </select>
            </div>
            <div><label>Height (cm)</label><input type="number" name="height" value="<?php echo htmlspecialchars($profileData['height'] ?? ''); ?>" step="0.1"></div>
            <div><label>Weight (kg)</label><input type="number" name="weight" value="<?php echo htmlspecialchars($profileData['weight'] ?? ''); ?>" step="0.1"></div>
            <div><label>Medical Notes</label><textarea name="medical" rows="3"><?php echo htmlspecialchars($profileData['medical'] ?? ''); ?></textarea></div>
            <div><label>Photo</label><input type="file" name="photo" accept="image/*"></div>
            <div style="grid-column:1/-1;display:flex;justify-content:flex-end;"><button class="btn-primary" type="submit" name="save">Save Profile</button></div>
        </form>
    </div>
</div>
<script>
function setText(id, value){
    const el = document.getElementById(id);
    if(!el) return;
    const out = (value === null || value === undefined || String(value).trim() === '') ? '-' : String(value);
    el.textContent = out;
}

function decodeB64Utf8(input){
    if(!input) return '';
    try{
        const binary = atob(input);
        const bytes = Uint8Array.from(binary, function(ch){ return ch.charCodeAt(0); });
        if(typeof TextDecoder !== 'undefined'){
            return new TextDecoder('utf-8').decode(bytes);
        }
        let escaped = '';
        for(let i=0; i<bytes.length; i++){
            escaped += '%' + ('00' + bytes[i].toString(16)).slice(-2);
        }
        return decodeURIComponent(escaped);
    }catch(e){
        return '';
    }
}

function openOrderDetails(button){
    if(!button) return;
    const b64 = button.getAttribute('data-details-b64') || '';
    if(!b64){
        alert('Order details are missing for this row.');
        return;
    }

    const raw = decodeB64Utf8(b64);
    if(!raw){
        alert('Unable to read order details.');
        return;
    }

    let data = null;
    try {
        data = JSON.parse(raw);
    } catch (e) {
        alert('Unable to open order details right now.');
        return;
    }
    if(!data) return;

    const modal = document.getElementById('orderDetailModal');
    const image = document.getElementById('od-image');
    const productLinkWrap = document.getElementById('od-product-link-wrap');
    const statusBadge = document.getElementById('od-status-badge');
    const modeBadge = document.getElementById('od-mode-badge');

    setText('od-product', data.product_name);
    setText('od-description', data.product_description || 'No extra description available for this order item.');

    if(image){
        if(data.image_src && String(data.image_src).trim() !== ''){
            image.src = String(data.image_src);
            image.style.display = 'block';
        } else {
            const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="220"><rect width="100%" height="100%" fill="#eef1f7"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#6b7280" font-family="Segoe UI, Arial" font-size="16">No Product Image</text></svg>';
            image.src = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
            image.style.display = 'block';
        }
    }

    if(productLinkWrap){
        if(data.product_link && String(data.product_link).trim() !== ''){
            productLinkWrap.innerHTML = '<a href="' + String(data.product_link).replace(/"/g, '&quot;') + '" style="color:#e63946;font-weight:700;">Open product page</a>';
        } else {
            productLinkWrap.textContent = 'No direct product page link for this item.';
        }
    }

    if(statusBadge){
        const status = (data.status || 'Pending').toLowerCase();
        statusBadge.className = 'badge ' + ((status === 'delivered' || status === 'completed') ? 'green' : ((status === 'pending' || status === 'processing') ? 'amber' : 'red'));
        statusBadge.textContent = data.status || 'Pending';
    }
    if(modeBadge){
        modeBadge.className = 'badge blue';
        modeBadge.textContent = data.order_mode || 'ORDER';
    }

    setText('od-order-id', '#' + (data.order_id || '-'));
    setText('od-date-only', data.order_date_only || data.order_date);
    setText('od-time-only', data.order_time_only || '-');
    setText('od-payment', data.payment_method);
    setText('od-address', data.order_address);
    setText('od-qty', data.qty);
    setText('od-unit', data.unit_price ? ('Rs ' + data.unit_price) : '-');
    setText('od-line', data.line_total ? ('Rs ' + data.line_total) : '-');
    setText('od-order-total', data.order_total ? ('Rs ' + data.order_total) : '-');
    setText('od-category', data.category_name);
    setText('od-product-status', data.product_status);
    setText('od-base-price', data.product_base_price ? ('Rs ' + data.product_base_price) : '-');
    setText('od-final-price', data.product_final_price ? ('Rs ' + data.product_final_price) : '-');
    setText('od-discount', data.product_discount);
    setText('od-variant', data.variant_name);
    setText('od-sku', data.variant_sku);
    setText('od-stock', data.variant_stock);
    setText('od-variant-status', data.variant_status);
    setText('od-variant-price', data.variant_final_price ? ('Rs ' + data.variant_final_price) : '-');

    if(modal) modal.style.display = 'flex';
}

function closeOrderDetails(ev){
    if(ev && ev.target && ev.target.id !== 'orderDetailModal') return;
    const modal = document.getElementById('orderDetailModal');
    if(modal) modal.style.display = 'none';
}

document.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){
        closeOrderDetails();
    }
});
</script>
</body>
</html>
