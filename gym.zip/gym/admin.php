<?php
$con = mysqli_connect('localhost','root','','gym');
/* ================= MEMBERSHIP PURCHASE APPROVAL ================= */

// APPROVE
if(isset($_GET['approve_purchase'])){
    $id = (int)$_GET['approve_purchase'];
    $approve_user = '';
    $rq = mysqli_query($con,"SELECT username FROM membership_purchases WHERE id='$id' LIMIT 1");
    if($rq && mysqli_num_rows($rq) > 0){
        $approve_row = mysqli_fetch_assoc($rq);
        $approve_user = trim((string)($approve_row['username'] ?? ''));
    }

    mysqli_query($con,"UPDATE membership_purchases SET status='approved' WHERE id='$id'");

    // Keep legacy user_memberships status in sync when available.
    if($approve_user !== ''){
        $um_tbl = mysqli_query($con, "SHOW TABLES LIKE 'user_memberships'");
        if($um_tbl && mysqli_num_rows($um_tbl) > 0){
            $u = mysqli_real_escape_string($con, $approve_user);
            $uq = mysqli_query($con, "SELECT id FROM user_table WHERE username='$u' LIMIT 1");
            if($uq && mysqli_num_rows($uq) > 0){
                $uid = (int)(mysqli_fetch_assoc($uq)['id'] ?? 0);
                if($uid > 0){
                    mysqli_query($con,"UPDATE user_memberships SET status='approved' WHERE user_id='$uid' AND status IN ('pending','cancelled','canceled') ORDER BY id DESC LIMIT 1");
                }
            }
        }
    }

    header("Location: admin.php");
}

// CANCEL
if(isset($_GET['cancel_purchase'])){
    $id = (int)$_GET['cancel_purchase'];
    $cancel_user = '';
    $rq = mysqli_query($con,"SELECT username FROM membership_purchases WHERE id='$id' LIMIT 1");
    if($rq && mysqli_num_rows($rq) > 0){
        $cancel_row = mysqli_fetch_assoc($rq);
        $cancel_user = trim((string)($cancel_row['username'] ?? ''));
    }

    mysqli_query($con,"UPDATE membership_purchases SET status='cancelled' WHERE id='$id'");

    // Remove free-items row when membership is cancelled.
    mysqli_query($con,"DELETE FROM free_membership_items WHERE purchase_id='$id'");

    // Sync legacy user_memberships table if present.
    if($cancel_user !== ''){
        $um_tbl = mysqli_query($con, "SHOW TABLES LIKE 'user_memberships'");
        if($um_tbl && mysqli_num_rows($um_tbl) > 0){
            $u = mysqli_real_escape_string($con, $cancel_user);
            $uq = mysqli_query($con, "SELECT id FROM user_table WHERE username='$u' LIMIT 1");
            if($uq && mysqli_num_rows($uq) > 0){
                $uid = (int)(mysqli_fetch_assoc($uq)['id'] ?? 0);
                if($uid > 0){
                    mysqli_query($con,"UPDATE user_memberships SET status='cancelled' WHERE user_id='$uid' AND status='approved'");
                }
            }
        }
    }

    header("Location: admin.php");
}
/* ================= MEMBERSHIP SECTION ================= */

$editMembership = null;

/* DELETE MEMBERSHIP */
if(isset($_GET['delete_membership'])){
    mysqli_query($con,"DELETE FROM membership_plans WHERE id=".$_GET['delete_membership']);
    header("Location: admin.php");
}

/* EDIT FETCH MEMBERSHIP */
if(isset($_GET['edit_membership'])){
    $q = mysqli_query($con,"SELECT * FROM membership_plans WHERE id=".$_GET['edit_membership']);
    $editMembership = mysqli_fetch_assoc($q);
}

/* ADD MEMBERSHIP */
if(isset($_POST['add_membership'])){

    $name = $_POST['plan_name'];
    $duration = $_POST['duration'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $features = isset($_POST['features']) ? implode(",", $_POST['features']) : "";
    $status = $_POST['status'];

    mysqli_query($con,"INSERT INTO membership_plans
    (plan_name,duration,price,description,features,status)
    VALUES
    ('$name','$duration','$price','$description','$features','$status')");
}

/* UPDATE MEMBERSHIP */
if(isset($_POST['update_membership'])){

    $id = $_POST['id'];
    $name = $_POST['plan_name'];
    $duration = $_POST['duration'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $status = $_POST['status'];
    $features = isset($_POST['features']) ? implode(",", $_POST['features']) : "";

    mysqli_query($con,"UPDATE membership_plans SET
        plan_name='$name',
        duration='$duration',
        price='$price',
        description='$description',
        features='$features',
        status='$status'
        WHERE id='$id'
    ");

    header("Location: admin.php");
}











$editData = null;

if(isset($_GET['edit'])){
    $id = $_GET['edit'];
    $q = mysqli_query($con,"SELECT * FROM products WHERE id='$id'");
    $editData = mysqli_fetch_assoc($q);
}


$cat = $_POST['category'] ?? ($editData['category'] ?? '');
$product = $_POST['product'] ?? ($editData['product_name'] ?? '');


/* DELETE */
if(isset($_GET['delete'])){
    mysqli_query($con,"DELETE FROM products WHERE id=".$_GET['delete']);
    header("Location: admin_products.php");
}

if(isset($_POST['add'])){

    $category = $_POST['category'];
    $product  = $_POST['product'];
    $desc     = $_POST['description'];

    $kg     = $_POST['kg'] ?? '';
    $flav   = $_POST['flavour'] ?? '';
    $mm     = $_POST['mm'] ?? '';
    $size   = $_POST['size'] ?? '';
    $liter  = $_POST['liter'] ?? '';

    $stock = $_POST['stock'];
    $price = $_POST['price'];
    $dis   = $_POST['discount'];

    $final = $price - ($price * $dis / 100);

    // category wise cleanup
    if($category=="Equipments"){
        $flav = $liter = $size = '';
    }
    if($category=="Supplements"){
        $mm = $liter = $size = '';
    }
    if($category=="Merchandise"){
        $kg = $mm = $flav = '';
    }

    $img = time().$_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$img);

    mysqli_query($con,"INSERT INTO products
    (category, product_name, image, description, weight_kg, flavour, thickness_mm, size, liter, stock, price, discount, final_price)
    VALUES
    ('$category','$product','$img','$desc','$kg','$flav','$mm','$size','$liter','$stock','$price','$dis','$final')");
}


/* EDIT FETCH */
$edit = null;
if(isset($_GET['edit'])){
    $q = mysqli_query($con,"SELECT * FROM products WHERE id=".$_GET['edit']);
    $edit = mysqli_fetch_assoc($q);
}

if(isset($_POST['update'])){

    $id = $_POST['id'];

    $category = $_POST['category'];
    $product  = $_POST['product'];
    $desc     = $_POST['description'];

    $kg     = $_POST['kg'] ?? '';
    $flav   = $_POST['flavour'] ?? '';
    $mm     = $_POST['mm'] ?? '';
    $size   = $_POST['size'] ?? '';
    $liter  = $_POST['liter'] ?? '';

    $stock = $_POST['stock'];
    $price = $_POST['price'];
    $dis   = $_POST['discount'];

    $final = $price - ($price * $dis / 100);

   if(!empty($_FILES['image']['name'])){
    $image = $_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$image);
}else{
    $image = $_POST['old_image']; // old image keep
}


    mysqli_query($con,"UPDATE products SET
        category='$category',
        product_name='$product',
        description='$desc',
        weight_kg='$kg',
        flavour='$flav',
        thickness_mm='$mm',
        size='$size',
        liter='$liter',
        stock='$stock',
        price='$price',
        discount='$dis',
        final_price='$final'
        $imgSQL
        WHERE id='$id'
    ");

    header("Location: admin.php");
}

if(isset($_POST['add_trainer'])) {
    $full_name  = $_POST['full_name'];
    $username   = $_POST['username'];
    $email      = $_POST['email'];
    $phone      = $_POST['phone'];
    $specialty  = $_POST['specialty'];
    $experience = $_POST['experience'];
    $gender     = $_POST['gender'];
    $status     = $_POST['status'];

    // Optional: Check if username or email already exists
    $check = mysqli_query($con, "SELECT * FROM trainers WHERE username='$username' OR email='$email'");
    if(mysqli_num_rows($check) > 0){
        $message = "Username or Email already exists!";
    } else {
        $insert = mysqli_query($con, "INSERT INTO trainers (full_name, username, email, phone, specialty, experience, gender, status) 
            VALUES ('$full_name', '$username', '$email', '$phone', '$specialty', '$experience', '$gender', '$status')");
        if($insert){
            $message = "Trainer added successfully!";
        } else {
            $message = "Error: " . mysqli_error($con);
        }
    }
}

$result = mysqli_query($con, "SELECT * FROM contact_messages ORDER BY id DESC");
$count = mysqli_num_rows($result);









$members = mysqli_query($con,"
SELECT DISTINCT username 
FROM membership_purchases
WHERE status='approved'
");

if(isset($_POST['save_attendance'])){

    $date = $_POST['attendance_date'];
    $time = $_POST['check_time'];

    foreach($_POST['status'] as $username => $status){

        mysqli_query($con,"
        INSERT INTO attendance 
        (username, attendance_date, check_time, status)
        VALUES 
        ('$username','$date','$time','$status')
        ");
    }

    echo "<script>alert('Attendance Saved Successfully');</script>";
}





if(isset($_POST['assign_trainer'])){

    $member_id = $_POST['member_id'];
    $trainer_id = $_POST['trainer_id'];
    $date = date("Y-m-d");

    $check = mysqli_query($con,"
        SELECT * FROM trainer_assignments
        WHERE member_id='$member_id'
    ");

    if(mysqli_num_rows($check) > 0){

        mysqli_query($con,"
            UPDATE trainer_assignments
            SET trainer_id='$trainer_id',
                assigned_date='$date'
            WHERE member_id='$member_id'
        ");

        echo "<script>alert('Trainer Updated Successfully');</script>";

    } else {

        mysqli_query($con,"
            INSERT INTO trainer_assignments
            (member_id, trainer_id, assigned_date)
            VALUES
            ('$member_id','$trainer_id','$date')
        ");

        echo "<script>alert('Trainer Assigned Successfully');</script>";
    }
}



$approvedMembers = mysqli_query($con,"
SELECT DISTINCT username
FROM membership_purchases
WHERE status='approved'
");

$activeTrainers = mysqli_query($con,"
SELECT * FROM trainers
WHERE status='active'
");


?>
<!DOCTYPE html>
<html>
<head>
<title>Simple Admin</title>
<style>
body{margin:0;font-family:Arial;background:#f2f2f2}
.sidebar{width:200px;height:100vh;position:fixed;background:#111;color:#fff}
.sidebar h2{text-align:center;padding:20px}
.sidebar a{display:block;padding:15px;color:#fff;text-decoration:none}
.sidebar a:hover{background:#333}

.main{margin-left:200px;padding:30px}
input,select,textarea{width:100%;padding:8px;margin:8px 0}
button{padding:10px 20px;background:black;color:white;border:none}

table{width:100%;margin-top:30px;background:white;border-collapse:collapse}
th,td{border:1px solid #ccc;padding:10px;text-align:center}
img{width:60px}
.action-btn{
    padding:6px 14px;
    border-radius:4px;
    text-decoration:none;
    font-size:14px;
    font-weight:600;
    display:inline-block;
    margin:2px;
}

.edit-btn{
    background:#007bff;
    color:#fff;
}

.edit-btn:hover{
    background:#0056b3;
}

.delete-btn{
    background:#dc3545;
    color:#fff;
}

.delete-btn:hover{
    background:#b02a37;
}

</style>
</head>

<body onload="autoOpenProducts()">

<div class="sidebar">
<h2>ADMIN</h2>
<a href="#" onclick="showDashboard()">Dashboard</a>
<a href="#" onclick="AddTrainer()">Add Trainer</a>
<a href="#" onclick="showProducts()">Product</a>

<a href="#" onclick="loadAssignTrainer()">Assign Trainer</a>
<a href="#" onclick="showMembership()">Membership</a>
<a href="#" onclick="showPurchaseRequests()">Membership Requests</a>
<a href="#" onclick="attendance()">Attendance</a>
<a href="#" onclick="contactus()">Contact Us</a>

</div>

<div class="main">







<div id="dashboard">
    <h1>Dashboard</h1>
</div>

<div id="attendance" style="display:none;">
    <h2>📅 Mark Attendance</h2>

<form method="POST">
    
    <label>Select Date</label>
    <input type="date" name="attendance_date" required>

    <label>Select Time</label>
    <input type="time" name="check_time" required>

    <table border="1" cellpadding="8">
        <tr>
            <th>Member</th>
            <th>Status</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($members)): ?>
        <tr>
            <td><?= $row['username'] ?></td>
            <td>
                <select name="status[<?= $row['username'] ?>]">
                    <option value="present">Present</option>
                    <option value="absent">Absent</option>
                </select>
            </td>
        </tr>
        <?php endwhile; ?>

    </table>

    <br>
    <button type="submit" name="save_attendance">Save Attendance</button>
</form>
    
</div>

<div id="contactus" style="display:none;">
    <div class="container mt-5">
    <h2 class="mb-4 text-center">📩 Contact Messages</h2>

    <div class="card shadow">
        <div class="card-body">
            <table class="table table-bordered table-hover align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Message</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['name']}</td>
                                <td>{$row['email']}</td>
                                <td style='text-align:left'>{$row['message']}</td>
                                <td>{$row['created_at']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr>
                            <td colspan='5'>No messages found</td>
                          </tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>

<div id="addtrainer" style="display:none;">
    <h2>Add Trainer</h2>

<form method="post">
    <input type="text" name="full_name" placeholder="Full Name" required>
    <input type="text" name="username" placeholder="Username" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="phone" placeholder="Phone Number" required>
    <input type="text" name="specialty" placeholder="Specialization" required>
    <input type="number" name="experience" placeholder="Experience (Years)" required>
    <select name="gender" required>
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        <option value="Other">Other</option>
    </select>
    <select name="status" required>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
    </select>
    <button type="submit" name="add_trainer">Add Trainer</button>
</form>
</div>









<div id="assignTrainer" style="display:none;">

    <h2>Assign Trainer To Member</h2>

    <form method="POST">

        <label>Select Member</label>
        <select name="member_username" required>
            <option value="">-- Select Member --</option>

            <?php while($m = mysqli_fetch_assoc($approvedMembers)){ ?>
                <option value="<?= $m['username'] ?>">
                    <?= $m['username'] ?>
                </option>
            <?php } ?>
        </select>

        <br>

        <label>Select Trainer</label>
        <select name="trainer_id" required>
            <option value="">-- Select Trainer --</option>

            <?php while($t = mysqli_fetch_assoc($activeTrainers)){ ?>
                <option value="<?= $t['id'] ?>">
                    <?= $t['full_name'] ?> (<?= $t['specialty'] ?>)
                </option>
            <?php } ?>
        </select>

        <br><br>

        <button type="submit" name="assign_trainer">
            Assign Trainer
        </button>

    </form>

</div>










<div id="products" style="display:none;">
<h2>Add Product</h2>

<form method="post" enctype="multipart/form-data">

<!-- CATEGORY -->
<select name="category" onchange="this.form.submit()" required>
    <option value="">Select Category</option>
    <option value="Equipments" <?=($cat=="Equipments")?"selected":""?>>Equipments</option>
    <option value="Supplements" <?=($cat=="Supplements")?"selected":""?>>Supplements</option>
    <option value="Merchandise" <?=($cat=="Merchandise")?"selected":""?>>Merchandise</option>
</select>

<?php if($cat!=""){ ?>
<!-- PRODUCT -->
<select name="product" onchange="this.form.submit()" required>
    <option value="">Select Product</option>

    <?php if($cat=="Equipments"){ ?>
        <option value="Dumbbells" <?=($product=="Dumbbells")?"selected":""?>>Dumbbells</option>
        <option value="Barbells" <?=($product=="Barbells")?"selected":""?>>Barbells</option>
        <option value="Yoga Mats" <?=($product=="Yoga Mats")?"selected":""?>>Yoga Mats</option>
    <?php } ?>

    <?php if($cat=="Supplements"){ ?>
        <option value="Protein Powder" <?=($product=="Protein Powder")?"selected":""?>>Protein Powder</option>
    <?php } ?>

    <?php if($cat=="Merchandise"){ ?>
        <option value="Gym T-Shirt" <?=($product=="Gym T-Shirt")?"selected":""?>>Gym T-Shirt</option>
        <option value="Gym Shorts" <?=($product=="Gym Shorts")?"selected":""?>>Gym Shorts</option>
        <option value="Bottle" <?=($product=="Bottle")?"selected":""?>>Bottle</option>
    <?php } ?>
</select>
<?php } ?>

<textarea name="description" placeholder="Description"><?= $editData['description'] ?? '' ?></textarea>

<label>Product Image</label><br>

<?php if(!empty($editData['image'])){ ?>
    <img src="uploads/<?= $editData['image'] ?>" width="120" style="margin-bottom:10px;"><br>
<?php } ?>

<input type="file" name="image">

<!-- Old image hidden field -->
<input type="hidden" name="old_image" value="<?= $editData['image'] ?? '' ?>">

<?php
// DYNAMIC FIELDS (EDIT + ADD both)
if($product=="Dumbbells" || $product=="Barbells"){
    echo '<input name="kg" placeholder="Weight (KG)"
    value="'.($editData['weight_kg'] ?? '').'">';
}

if($product=="Protein Powder"){
    echo '<input name="kg" placeholder="Weight (KG)"
    value="'.($editData['weight_kg'] ?? '').'">';

    echo '<input name="flavour" placeholder="Flavour"
    value="'.($editData['flavour'] ?? '').'">';
}

if($product=="Yoga Mats"){
    echo '<input name="mm" placeholder="Thickness (MM)"
    value="'.($editData['thickness_mm'] ?? '').'">';
}

if($product=="Gym T-Shirt" || $product=="Gym Shorts"){
    echo '<input name="size" placeholder="Size"
    value="'.($editData['size'] ?? '').'">';
}

if($product=="Bottle"){
    echo '<input name="liter" placeholder="Liter"
    value="'.($editData['liter'] ?? '').'">';
}
?>

<input type="number" name="stock" placeholder="Stock"
value="<?= $editData['stock'] ?? '' ?>" required>

<input type="number" name="price" placeholder="Price"
value="<?= $editData['price'] ?? '' ?>" required>

<input type="number" name="discount" placeholder="Discount %"
value="<?= $editData['discount'] ?? '' ?>">

<button type="submit" name="<?= $editData ? 'update' : 'add' ?>">
    <?= $editData ? 'Update Product' : 'Add Product' ?>
</button>

</form>


<!-- PRODUCT LIST -->
<table border="1" cellpadding="8">
<tr>
    <th>Category</th>
    <th>Name</th>
    <th>Description</th>
    <th>Weight (KG)</th>
    <th>Flavour</th>
    <th>Thickness (MM)</th>
    <th>Size</th>
    <th>Liter</th>
    <th>Image</th>
    <th>Stock</th>
    <th>Price</th>
    <th>Discount</th>
    <th>Total Price</th>
    <th>Action</th>
</tr>

<?php
$res = mysqli_query($con,"SELECT * FROM products");
while($r = mysqli_fetch_assoc($res)){
?>
<tr>
    <td><?= $r['category'] ?></td>
    <td><?= $r['product_name'] ?></td>

    <!-- Description (TEXT) -->
    <td><?= (isset($r['description']) && trim($r['description']) !== '') ? $r['description'] : '-' ?></td>

    <!-- Weight (NUMBER) -->
    <td><?= (isset($r['weight_kg']) && $r['weight_kg'] !== '') ? $r['weight_kg'].' KG' : '-' ?></td>

<td><?= (isset($r['flavour']) && trim($r['flavour']) !== '') ? $r['flavour'] : '-' ?></td>

<td><?= (isset($r['thickness_mm']) && $r['thickness_mm'] !== '') ? $r['thickness_mm'].' MM' : '-' ?></td>

<td><?= (isset($r['size']) && $r['size'] !== '') ? $r['size'] : '-' ?></td>

<td><?= (isset($r['liter']) && $r['liter'] !== '') ? $r['liter'].' L' : '-' ?></td>

    <!-- Image -->
    <td>
        <?php if(isset($r['image']) && $r['image'] != ''){ ?>
            <img src="uploads/<?= $r['image'] ?>" width="60">
        <?php } else { echo "-"; } ?>
    </td>

    <!-- Stock -->
    <td><?= (isset($r['stock']) && $r['stock'] !== '') ? $r['stock'] : '-' ?></td>

    <!-- Price -->
    <td>₹<?= $r['price'] ?></td>

    <!-- Discount -->
    <td><?= (isset($r['discount']) && $r['discount'] !== '') ? $r['discount'].'%' : '-' ?></td>

<?php
$final_price = $r['price'] - ($r['price'] * $r['discount'] / 100);
?>

<td>₹<?= number_format($final_price, 2) ?></td>


    <td>
    <a href="?edit=<?= $r['id'] ?>" class="action-btn edit-btn">Edit</a>
    <a href="?delete=<?= $r['id'] ?>"
       class="action-btn delete-btn"
       onclick="return confirm('Delete this product?')">
       Delete
    </a>
</td>

</tr>

<?php } ?>
</table>
        </div>













        <div id="membership" style="display:none;">
<h2>Add Membership Plan</h2>

<form method="post">

<input type="hidden" name="id" value="<?= $editMembership['id'] ?? '' ?>">

<input type="text" name="plan_name" placeholder="Plan Name"
value="<?= $editMembership['plan_name'] ?? '' ?>" required>

<input type="number" name="duration" placeholder="Duration (Days)"
value="<?= $editMembership['duration'] ?? '' ?>" required>

<input type="number" step="0.01" name="price" placeholder="Price"
value="<?= $editMembership['price'] ?? '' ?>" required>

<textarea name="description" placeholder="Description"><?= $editMembership['description'] ?? '' ?></textarea>

<?php
// All Available Features
$allFeatures = [
    "Gym Equipment Access",
    "Cardio Section Access",
    "Weight Training Section",
    "Locker Facility",
    "Free Diet Plan",
    "Personal Trainer Support",
    "Group Classes (Zumba/Yoga)",
    "Body Composition Analysis",
    "Steam Bath Access",
    "Sauna Access",
    "Shower Facility",
    "24/7 Access"
];

// For Edit Mode
$selectedFeatures = [];
if(isset($editMembership['features']) && $editMembership['features'] != ''){
    $selectedFeatures = explode(",", $editMembership['features']);
}
?>

<label><b>Select Features:</b></label><br><br>

<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:5px;">
<?php foreach($allFeatures as $feature){ ?>
    <label>
        <input type="checkbox"
               name="features[]"
               value="<?= $feature ?>"
               <?= in_array($feature, $selectedFeatures) ? 'checked' : '' ?>>
        <?= $feature ?>
    </label>
<?php } ?>
</div>

<select name="status" required>
    <option value="active" <?= (isset($editMembership['status']) && $editMembership['status']=="active")?"selected":"" ?>>Active</option>
    <option value="inactive" <?= (isset($editMembership['status']) && $editMembership['status']=="inactive")?"selected":"" ?>>Inactive</option>
</select>

<button type="submit" name="<?= $editMembership ? 'update_membership' : 'add_membership' ?>">
    <?= $editMembership ? 'Update Plan' : 'Add Plan' ?>
</button>

</form>

<!-- MEMBERSHIP TABLE -->
<table>
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Duration</th>
    <th>Price</th>
    <th>Description</th>
    <th>Features</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php
$res = mysqli_query($con,"SELECT * FROM membership_plans");
while($m = mysqli_fetch_assoc($res)){
?>

<tr>
<td><?= $m['id'] ?></td>
<td><?= $m['plan_name'] ?></td>
<td><?= $m['duration'] ?> Days</td>
<td>₹<?= $m['price'] ?></td>
<td><?= $m['description'] ?></td>
<td>
 <?php
 $featureList = explode(",", $m['features']);
 foreach($featureList as $f){
    echo "✔ ".$f."<br>";
 }
 ?>
 </td>

<td><?= $m['status'] ?></td>

<td>
<a href="?edit_membership=<?= $m['id'] ?>" class="action-btn edit-btn">Edit</a>

<a href="?delete_membership=<?= $m['id'] ?>"
class="action-btn delete-btn"
onclick="return confirm('Delete this plan?')">
Delete
</a>
</td>

</tr>

<?php } ?>

</table>

</div>
<div id="purchaseRequests" style="display:none;">
<h2>Membership Purchase Requests</h2>

<table>
<tr>
    <th>ID</th>
    <th>Plan</th>
    <th>Amount</th>
    <th>Txn</th>
    <th>Status</th>
    <th>Date</th>
    <th>Action</th>
</tr>

<?php
$res = mysqli_query($con,"SELECT * FROM membership_purchases ORDER BY id DESC");
while($p = mysqli_fetch_assoc($res)){
?>

<tr>
<td><?= $p['id'] ?></td>
<td><?= $p['plan_name'] ?></td>
<td>₹<?= $p['amount'] ?></td>
<td><?= $p['txn'] ?></td>
<td><?= $p['status'] ?></td>
<td><?= $p['purchase_date'] ?></td>

<td>
    <?php
    if($p['status']=="approved"){
        echo "<span style='color:green;font-weight:bold;'>Approved</span>";
    }
    elseif($p['status']=="cancelled"){
        echo "<span style='color:red;font-weight:bold;'>Cancelled</span>";
    }
    else{
        echo "<span style='color:orange;font-weight:bold;'>Pending</span>";
    }
    ?>

    <br>

    <?php if($p['status']=="pending"){ ?>
    <a href="?approve_purchase=<?= $p['id'] ?>" class="action-btn edit-btn">Approve</a>
    <a href="?cancel_purchase=<?= $p['id'] ?>" class="action-btn delete-btn" onclick="return confirm('Cancel this request?')">Cancel</a>
    <?php } elseif($p['status']=="approved"){ ?>
    <a href="?cancel_purchase=<?= $p['id'] ?>" class="action-btn delete-btn" onclick="return confirm('Cancel this approved membership?')">Cancel</a>
    <?php } elseif($p['status']=="cancelled"){ ?>
    <a href="?approve_purchase=<?= $p['id'] ?>" class="action-btn edit-btn" onclick="return confirm('Approve this cancelled membership again?')">Approve</a>
    <?php } else { ?>
    <span style="color:#aaa;font-size:12px;">Done</span>
    <?php } ?>
</td>

</tr>

<?php } ?>
</table>
</div>
<script>

function showDashboard(){
    document.getElementById("products").style.display="none";
    document.getElementById("addtrainer").style.display="none";
    document.getElementById("attendance").style.display="none";
    document.getElementById("contactus").style.display="none";
    document.getElementById("assignTrainer").style.display="none";
    document.getElementById("dashboard").style.display="block";
}




function showProducts(){
    document.getElementById("dashboard").style.display="none";
    document.getElementById("addtrainer").style.display="none";
    document.getElementById("attendance").style.display="none";
    document.getElementById("contactus").style.display="none";
    document.getElementById("products").style.display="block";
}

function showMembership(){
    document.getElementById("dashboard").style.display="none";
    document.getElementById("products").style.display="none";
    document.getElementById("addtrainer").style.display="none";
    document.getElementById("attendance").style.display="none";
    document.getElementById("contactus").style.display="none";
    document.getElementById("membership").style.display="block";
}

function AddTrainer(){
    document.getElementById("dashboard").style.display="none";
    document.getElementById("products").style.display="none";
    document.getElementById("attendance").style.display="none";
    document.getElementById("contactus").style.display="none";
    document.getElementById("addtrainer").style.display="block";
}

function attendance(){
    document.getElementById("dashboard").style.display="none";
    document.getElementById("products").style.display="none";
    document.getElementById("addtrainer").style.display="none";
    document.getElementById("membership").style.display="none";
    document.getElementById("contactus").style.display="none";
    document.getElementById("attendance").style.display="block";
}

function contactus(){
    document.getElementById("dashboard").style.display="none";
    document.getElementById("products").style.display="none";
    document.getElementById("addtrainer").style.display="none";
    document.getElementById("membership").style.display="none";
    document.getElementById("attendance").style.display="none";
    document.getElementById("contactus").style.display="block";
}
function showPurchaseRequests(){
    document.getElementById("dashboard").style.display="none";
    document.getElementById("products").style.display="none";
    document.getElementById("addtrainer").style.display="none";
    document.getElementById("attendance").style.display="none";
    document.getElementById("contactus").style.display="none";
    document.getElementById("membership").style.display="none";
    document.getElementById("purchaseRequests").style.display="block";
}
function autoOpenProducts(){

<?php if(isset($_GET['edit_membership'])){ ?>
    showMembership();
<?php } ?>

    <?php if(!empty($cat) || isset($_GET['edit'])){ ?>
        showProducts();
    <?php } ?>
}


function loadAssignTrainer(){

    document.getElementById("dashboard").style.display="none";
    document.getElementById("products").style.display="none";
    document.getElementById("addtrainer").style.display="none";
    document.getElementById("attendance").style.display="none";
    document.getElementById("contactus").style.display="none";
    document.getElementById("membership").style.display="none";
    document.getElementById("purchaseRequests").style.display="none";

    document.getElementById("assignTrainer").style.display="block";

    var xhr = new XMLHttpRequest();
    xhr.open("GET","assign_trainer_data.php",true);
    xhr.onload = function(){
        if(this.status == 200){
            document.getElementById("assignTrainer").innerHTML = this.responseText;
        }
    }
    xhr.send();
}



</script>


</div>
</body>
</html>
