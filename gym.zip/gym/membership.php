<?php
$conn = mysqli_connect("localhost","root","","gym");

if(!$conn){
    die("Connection Failed");
}

/* Fetch Active Plans */
$result = mysqli_query($conn,"SELECT * FROM membership_plans WHERE status='active'");
$plans = [];
while($row = mysqli_fetch_assoc($result)){
    $plans[] = $row;
}

/* Handle Comparison */
$comparePlans = [];
if(isset($_POST['compare'])){
    $selectedIds = $_POST['compare_ids'] ?? [];

    if(count($selectedIds) >= 2){
        $idList = implode(",", $selectedIds);
        $res = mysqli_query($conn,"SELECT * FROM membership_plans WHERE id IN ($idList)");
        while($row = mysqli_fetch_assoc($res)){
            $comparePlans[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Elite Membership</title>

<style>
body{
    margin:0;
    font-family: 'Segoe UI', sans-serif;
    background:#000;
    color:white;
}

/* HERO SECTION */
.hero{
    background:url('https://images.unsplash.com/photo-1583454110551-21f2fa2afe61') no-repeat center center/cover;
    padding:80px 20px;
    text-align:center;
    position:relative;
}

.hero::after{
    content:'';
    position:absolute;
    top:0; left:0;
    width:100%; height:100%;
    background:rgba(0,0,0,0.7);
}

.hero-content{
    position:relative;
    z-index:2;
}

.hero h1{
    font-size:40px;
    margin-bottom:10px;
}

.hero p{
    color:#ccc;
}

/* MEMBERSHIP CARDS */
.container{
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    gap:30px;
    padding:60px 20px;
}

.card{
    background:#111;
    width:320px;
    padding:25px;
    border:1px solid #222;
    border-radius:12px;
    transition:0.3s;
    position:relative;
}

.card:hover{
    transform:translateY(-10px);
    border:1px solid red;
}

.card h3{
    font-size:22px;
    margin-bottom:10px;
}

.price-box{
    border:2px solid red;
    padding:15px;
    text-align:center;
    margin:20px 0;
}

.price{
    font-size:28px;
    color:red;
    font-weight:bold;
}

.duration{
    font-size:14px;
    color:#ccc;
}

.features p{
    font-size:14px;
    margin:6px 0;
    color:#ddd;
}

.add-btn{
    width:100%;
    padding:12px;
    background:transparent;
    border:2px solid red;
    color:white;
    cursor:pointer;
    font-size:16px;
    transition:0.3s;
}

.add-btn:hover{
    background:red;
}

.compare-check{
    position:absolute;
    top:15px;
    right:15px;
}

.compare-btn{
    display:block;
    margin:30px auto;
    padding:12px 30px;
    background:red;
    color:white;
    border:none;
    cursor:pointer;
    font-size:16px;
}

.compare-btn:hover{
    background:#cc0000;
}

/* COMPARISON TABLE */
.compare-section{
    padding:40px;
    background:#111;
}

.compare-section h2{
    text-align:center;
    margin-bottom:20px;
}

table{
    width:100%;
    border-collapse:collapse;
    background:#000;
}

table th, table td{
    border:1px solid #333;
    padding:12px;
    text-align:center;
}

table th{
    background:red;
}

.yes{
    color:#00ff88;
    font-weight:bold;
}

.no{
    color:red;
}
</style>
</head>

<body>
<?php include 'header.php'; ?>
<div class="hero">
    <div class="hero-content">
        <h1>Elite Coaching Program</h1>
        <p>Select plans and compare features professionally</p>
    </div>
</div>

<form method="POST">

<div class="container">

<?php foreach($plans as $plan){ ?>
<div class="card">

<div class="compare-check">
<input type="checkbox" name="compare_ids[]" value="<?= $plan['id'] ?>">
</div>

<h3><?= $plan['plan_name'] ?></h3>

<div class="price-box">
<div class="price">₹<?= $plan['price'] ?></div>
<div class="duration"><?= $plan['duration'] ?> Days</div>
</div>

<div class="features">
<?php
$featureList = explode(",", $plan['features']);
foreach($featureList as $f){
    echo "<p>✔ ".$f."</p>";
}
?>
</div>

<button type="button" class="add-btn">Buy</button>

</div>
<?php } ?>

</div>

<button type="submit" name="compare" class="compare-btn">
Compare Selected Plans
</button>

</form>

<?php if(!empty($comparePlans)){ ?>

<div class="compare-section">
<h2>Plan Comparison</h2>

<table>
<tr>
<th>Feature</th>
<?php foreach($comparePlans as $plan){ ?>
<th><?= $plan['plan_name'] ?></th>
<?php } ?>
</tr>

<tr>
<td>Price</td>
<?php foreach($comparePlans as $plan){ ?>
<td>₹<?= $plan['price'] ?></td>
<?php } ?>
</tr>

<tr>
<td>Duration</td>
<?php foreach($comparePlans as $plan){ ?>
<td><?= $plan['duration'] ?> Days</td>
<?php } ?>
</tr>

<?php
$allFeatures = [
    "Gym Equipment Access",
    "Cardio Section Access",
    "Weight Training Section",
    "Locker Facility",
    "Free Diet Plan",
    "Personal Trainer Support",
    "Group Classes (Zumba/Yoga)",
    "Body Composition Analysis",
    "Steam Bath Access",
    "Sauna Access",
    "Shower Facility",
    "24/7 Access"
];

foreach($allFeatures as $feature){
echo "<tr>";
echo "<td>".$feature."</td>";

foreach($comparePlans as $plan){
    $planFeatures = explode(",", $plan['features']);
    if(in_array($feature,$planFeatures)){
        echo "<td class='yes'>✔</td>";
    } else {
        echo "<td class='no'>✖</td>";
    }
}

echo "</tr>";
}
?>

</table>
</div>

<?php } ?>

<script>
// Prevent comparing less than 2 plans
document.querySelector("form").addEventListener("submit", function(e){
    let checked = document.querySelectorAll("input[name='compare_ids[]']:checked");

    if(checked.length < 2){
        alert("Please select at least 2 plans to compare.");
        e.preventDefault();
    }
});
</script>

</body>
</html>
