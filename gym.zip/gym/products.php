﻿<?php
include "db.php";
include "header.php";

$cat_filter = (int)($_GET['cat'] ?? 0);
$search     = mysqli_real_escape_string($con, trim($_GET['q'] ?? ''));

$where = "WHERE p.status='active'";
if($cat_filter) $where .= " AND p.category_id='$cat_filter'";
if($search)     $where .= " AND p.product_name LIKE '%$search%'";

$res = mysqli_query($con,"
    SELECT p.id, p.product_name, p.image, p.description, pc.category_name,
           COUNT(pv.id) AS variant_count,
           COALESCE(SUM(pv.stock),0) AS total_stock,
           MIN(pv.final_price) AS min_price,
           MAX(pv.final_price) AS max_price
    FROM products_new p
    JOIN product_categories pc ON pc.id = p.category_id
    LEFT JOIN product_variants pv ON pv.product_id = p.id
    $where
    GROUP BY p.id
    ORDER BY p.created_at DESC
");
$cats = mysqli_query($con,"SELECT * FROM product_categories WHERE status='active' ORDER BY category_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Products - Unique Gym</title>
<style>
:root{--primary:#e63946;--soft:#f4f6fb;--ink:#1a1a2e;}
body{background:var(--soft);}
.shop-hero{padding:50px 60px 20px;}
.shop-hero h1{margin:0;font-size:32px;color:var(--ink);} .shop-hero p{color:#606775;margin-top:6px;}
.filters{display:flex;gap:10px;flex-wrap:wrap;margin:10px 60px 0;}
.filters input,.filters select{padding:10px 12px;border:1px solid #d9deea;border-radius:10px;font-size:14px;}
.filters button,.filters a.btn-reset{padding:10px 16px;border-radius:10px;border:none;font-weight:700;cursor:pointer;}
.filters button{background:var(--primary);color:#fff;}
.filters a.btn-reset{background:#fff;color:#111;border:1px solid #e5e7eb;text-decoration:none;}
.prod-grid{padding:20px 60px 60px;display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;}
.card{background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 10px 22px rgba(0,0,0,0.06);border:1px solid #e9edf5;display:flex;flex-direction:column;text-decoration:none;color:inherit;}
.card-img{height:200px;background:#f7f8fb;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden;}
.card-img img{max-width:100%;max-height:100%;object-fit:contain;transition:transform .2s;}
.card:hover .card-img img{transform:scale(1.02);}
.card-body{padding:14px;display:flex;flex-direction:column;gap:6px;flex:1;}
.cat{display:inline-block;padding:4px 10px;border-radius:10px;background:#f8e7ea;color:#c42431;font-size:11px;font-weight:700;}
.title{font-size:16px;font-weight:800;color:var(--ink);} .desc{color:#6b7280;font-size:13px;line-height:1.4;max-height:3.2em;overflow:hidden;}
.price-row{display:flex;align-items:center;gap:8px;font-weight:800;color:var(--primary);} .price-range{color:#6b7280;font-size:12px;}
.stock-ok{color:#1f9d55;font-weight:700;font-size:12px;} .stock-bad{color:#b91c1c;font-weight:700;font-size:12px;}
.cta{margin-top:auto;display:flex;gap:8px;} .btn-view{flex:1;text-align:center;padding:10px;border-radius:10px;border:1px solid var(--primary);color:var(--primary);font-weight:700;text-decoration:none;} .btn-view:hover{background:var(--primary);color:#fff;}
@media(max-width:900px){.shop-hero{padding:30px 20px;}.filters{margin:0 20px;}.prod-grid{padding:20px;}}
</style>
</head>
<body>
<div class="shop-hero">
  <h1>Shop Products</h1>
  <p>Browse equipment, supplements, and merch. Choose variants on the detail page.</p>
</div>

<form class="filters" method="GET">
  <input type="text" name="q" placeholder="Search product..." value="<?php echo htmlspecialchars($_GET['q']??''); ?>">
  <select name="cat">
    <option value="">All Categories</option>
    <?php while($c=mysqli_fetch_assoc($cats)): ?>
      <option value="<?php echo $c['id']; ?>" <?php echo $cat_filter==$c['id']?'selected':''; ?>><?php echo htmlspecialchars($c['category_name']); ?></option>
    <?php endwhile; ?>
  </select>
  <button type="submit">Filter</button>
  <a class="btn-reset" href="products.php">Reset</a>
</form>

<div class="prod-grid">
<?php if(mysqli_num_rows($res)>0): while($r=mysqli_fetch_assoc($res)): ?>
  <a class="card" href="product_detail.php?id=<?php echo $r['id']; ?>">
    <div class="card-img">
      <?php if($r['image']): ?>
        <img src="uploads/products/<?php echo htmlspecialchars($r['image']); ?>" alt="<?php echo htmlspecialchars($r['product_name']); ?>">
      <?php else: ?>
        <div style="width:100%;height:100%;display:grid;place-items:center;font-size:48px;color:#9ca3af;">📦</div>
      <?php endif; ?>
    </div>
    <div class="card-body">
      <span class="cat"><?php echo htmlspecialchars($r['category_name']); ?></span>
      <div class="title"><?php echo htmlspecialchars($r['product_name']); ?></div>
      <div class="price-row">
        <span>₹<?php echo number_format($r['min_price'],2); ?></span>
        <?php if($r['min_price']!=$r['max_price']): ?><span class="price-range">to ₹<?php echo number_format($r['max_price'],2); ?></span><?php endif; ?>
      </div>
      <div class="<?php echo $r['total_stock']>0?'stock-ok':'stock-bad'; ?>">
        <?php echo $r['total_stock']>0?'In stock':'Out of stock'; ?>
      </div>
      <div class="cta"><span class="btn-view">View details</span></div>
    </div>
  </a>
<?php endwhile; else: ?>
  <div style="grid-column:1/-1;color:#6b7280;text-align:center;">No products found.</div>
<?php endif; ?>
</div>
<?php include "footer.php"; ?>
</body>
</html>
