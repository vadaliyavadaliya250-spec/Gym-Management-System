<!DOCTYPE html>
<html>
<head>
    <title>Save Name to JSON</title>
</head>
<body>

<h2>Add Name</h2>

<form action="save.php" method="POST">
    Name:
    <input type="text" name="name" required>
    <br><br>
    <button type="submit">Submit</button>
</form>

</body>
</html>
