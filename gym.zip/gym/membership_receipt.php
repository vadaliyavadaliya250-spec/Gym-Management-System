<?php
session_start();

$con = mysqli_connect("localhost", "root", "", "gym");
if(!$con){
    http_response_code(500);
    die("Database connection failed.");
}
mysqli_set_charset($con, "utf8mb4");

$is_admin = isset($_SESSION['admin'])
    || (($_SESSION['username'] ?? '') === 'admin')
    || (($_SESSION['role'] ?? '') === 'admin');
$current_user = trim((string)($_SESSION['username'] ?? ''));

if(!$is_admin && $current_user === ''){
    header("Location: login.php");
    exit;
}

$receipt_id = (int)($_GET['id'] ?? 0);
if($receipt_id <= 0){
    http_response_code(400);
    die("Invalid receipt id.");
}

$table_check = mysqli_query($con, "SHOW TABLES LIKE 'membership_purchases'");
if(!$table_check || mysqli_num_rows($table_check) === 0){
    http_response_code(404);
    die("Membership purchase table not found.");
}

$db_row = mysqli_fetch_row(mysqli_query($con, "SELECT DATABASE()"));
$db_name = $db_row[0] ?? '';
$db_name_esc = mysqli_real_escape_string($con, (string)$db_name);

$has_col = function(string $col) use ($con, $db_name_esc): bool {
    $col_esc = mysqli_real_escape_string($con, $col);
    $q = mysqli_query(
        $con,
        "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA='{$db_name_esc}'
           AND TABLE_NAME='membership_purchases'
           AND COLUMN_NAME='{$col_esc}'
         LIMIT 1"
    );
    return $q && mysqli_num_rows($q) > 0;
};

$date_col = $has_col('purchase_date') ? 'purchase_date' : ($has_col('created_at') ? 'created_at' : '');
$duration_col = $has_col('duration') ? 'duration' : ($has_col('duration_days') ? 'duration_days' : '');
$plan_col = $has_col('plan_name') ? 'plan_name' : '';
$amount_col = $has_col('amount') ? 'amount' : '';
$txn_col = $has_col('txn') ? 'txn' : '';
$status_col = $has_col('status') ? 'status' : '';
$plan_id_col = $has_col('plan_id') ? 'plan_id' : '';

$select_parts = [
    "mp.id",
    "mp.username",
    ($plan_col !== '' ? "mp.{$plan_col} AS plan_name" : "'' AS plan_name"),
    ($amount_col !== '' ? "mp.{$amount_col} AS amount" : "0 AS amount"),
    ($duration_col !== '' ? "mp.{$duration_col} AS duration" : "'' AS duration"),
    ($txn_col !== '' ? "mp.{$txn_col} AS txn" : "'' AS txn"),
    ($status_col !== '' ? "mp.{$status_col} AS status" : "'pending' AS status"),
    ($plan_id_col !== '' ? "mp.{$plan_id_col} AS plan_id" : "0 AS plan_id"),
    ($date_col !== '' ? "mp.{$date_col} AS receipt_date" : "NOW() AS receipt_date"),
    "ud.fullname AS member_name"
];

$sql = "SELECT " . implode(", ", $select_parts) . "
        FROM membership_purchases mp
        LEFT JOIN user_details ud ON ud.username = mp.username
        WHERE mp.id = ?
        LIMIT 1";
$stmt = mysqli_prepare($con, $sql);
if(!$stmt){
    http_response_code(500);
    die("Unable to prepare receipt query.");
}
mysqli_stmt_bind_param($stmt, "i", $receipt_id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$receipt = $res ? mysqli_fetch_assoc($res) : null;

if(!$receipt){
    http_response_code(404);
    die("Receipt not found.");
}

if(!$is_admin && strcasecmp((string)$receipt['username'], $current_user) !== 0){
    http_response_code(403);
    die("You are not allowed to view this receipt.");
}

$download = isset($_GET['download']) && $_GET['download'] === '1';
$status = strtolower(trim((string)($receipt['status'] ?? 'pending')));
if($status === 'canceled') $status = 'cancelled';
$status_label = ucfirst($status);
$status_class = $status === 'approved' ? 'approved' : ($status === 'pending' ? 'pending' : 'cancelled');

$receipt_date = !empty($receipt['receipt_date']) ? date('d M Y, h:i A', strtotime((string)$receipt['receipt_date'])) : date('d M Y, h:i A');
$member_name = trim((string)($receipt['member_name'] ?? ''));
if($member_name === '') $member_name = (string)$receipt['username'];
$amount = (float)($receipt['amount'] ?? 0);

if($download){
    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="membership-receipt-' . (int)$receipt['id'] . '.html"');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Receipt #<?php echo (int)$receipt['id']; ?></title>
    <style>
        body{margin:0;background:#f3f5fa;font-family:Arial,sans-serif;color:#1f2937;padding:24px;}
        .receipt{max-width:860px;margin:0 auto;background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 10px 28px rgba(15,23,42,0.08);overflow:hidden;}
        .head{background:linear-gradient(135deg,#0f766e,#155e75);color:#fff;padding:20px 24px;}
        .head h1{margin:0;font-size:28px;}
        .head p{margin:6px 0 0;color:#dbeafe;font-size:14px;}
        .wrap{padding:20px 24px;}
        .status{display:inline-block;padding:6px 10px;border-radius:20px;font-size:12px;font-weight:700;}
        .status.approved{background:#dcfce7;color:#166534;}
        .status.pending{background:#fef3c7;color:#92400e;}
        .status.cancelled{background:#fee2e2;color:#991b1b;}
        table{width:100%;border-collapse:collapse;margin-top:14px;}
        th,td{border:1px solid #e5e7eb;padding:10px 12px;text-align:left;font-size:14px;}
        th{background:#f9fafb;width:34%;}
        .amt{font-size:24px;font-weight:800;color:#0f766e;}
        .actions{max-width:860px;margin:14px auto 0;display:flex;gap:10px;flex-wrap:wrap;}
        .btn{display:inline-block;text-decoration:none;border:none;border-radius:8px;padding:10px 14px;background:#111827;color:#fff;font-size:13px;cursor:pointer;}
        .btn.alt{background:#0f766e;}
        .note{margin-top:14px;padding:12px;border:1px dashed #d1d5db;border-radius:8px;color:#4b5563;font-size:13px;}
        @media print{
            body{background:#fff;padding:0;}
            .actions{display:none!important;}
            .receipt{box-shadow:none;border:none;border-radius:0;max-width:100%;}
        }
    </style>
</head>
<body>
    <div class="receipt">
        <div class="head">
            <h1>Membership Purchase Receipt</h1>
            <p>Elite Gym and Fitness Center</p>
        </div>
        <div class="wrap">
            <span class="status <?php echo $status_class; ?>"><?php echo htmlspecialchars($status_label); ?></span>
            <table>
                <tr><th>Receipt Number</th><td>#<?php echo (int)$receipt['id']; ?></td></tr>
                <tr><th>Member Username</th><td><?php echo htmlspecialchars((string)$receipt['username']); ?></td></tr>
                <tr><th>Member Name</th><td><?php echo htmlspecialchars($member_name); ?></td></tr>
                <tr><th>Plan Name</th><td><?php echo htmlspecialchars((string)($receipt['plan_name'] ?? 'Membership Plan')); ?></td></tr>
                <tr><th>Duration</th><td><?php echo htmlspecialchars((string)($receipt['duration'] ?? '-')); ?> days</td></tr>
                <tr><th>Transaction ID</th><td><?php echo htmlspecialchars((string)($receipt['txn'] ?? '-')); ?></td></tr>
                <tr><th>Purchase Date</th><td><?php echo htmlspecialchars($receipt_date); ?></td></tr>
                <tr><th>Amount Paid</th><td><span class="amt">Rs <?php echo number_format($amount, 2); ?></span></td></tr>
            </table>
            <div class="note">
                This is a system generated receipt. Keep it for your records.
            </div>
        </div>
    </div>

    <div class="actions">
        <button class="btn" onclick="window.print()">Print Receipt</button>
        <a class="btn alt" href="membership_receipt.php?id=<?php echo (int)$receipt['id']; ?>&download=1">Download</a>
        <?php if($is_admin): ?>
            <a class="btn" href="admin/view_receipts.php">Back to Admin Receipts</a>
        <?php else: ?>
            <a class="btn" href="sampleprofile.php">Back to Profile</a>
        <?php endif; ?>
    </div>
</body>
</html>
