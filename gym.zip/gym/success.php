<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Status</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; text-align: center; padding: 50px; background: #f4f4f4; }
        .container { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); display: inline-block; }
        h1 { color: #333; }
        .success { color: green; }
        .failure { color: red; }
        p { color: #666; }
        a { display: inline-block; margin-top: 20px; text-decoration: none; background: #007bff; color: white; padding: 10px 20px; border-radius: 5px; }
    </style>
</head>
<body>

<div class="container">
    <?php
    if (isset($_POST['code']) && $_POST['code'] == 'PAYMENT_SUCCESS') {
        echo '<h1 class="success">Payment Successful!</h1>';
        echo '<p>Transaction ID: ' . htmlspecialchars($_POST['transactionId']) . '</p>';
        echo '<p>Amount: ' . (isset($_POST['amount']) ? $_POST['amount'] / 100 : 'N/A') . ' INR</p>';
    } else {
        echo '<h1 class="failure">Payment Failed or Pending</h1>';
        echo '<p>If your money was deducted, it will be refunded shortly.</p>';
    }
    ?>
    <a href="index.php">Go Back to Home</a>
</div>

</body>
</html>
