<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Whey Protein - Gymness</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;}
body{background:#f6f6f6;}

/* HEADER */
.navbar{
    padding:20px 60px;
    background:#fff;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 10px rgba(0,0,0,0.1);
}
.logo{font-size:26px;font-weight:800;}
.nav-menu{list-style:none;display:flex;gap:30px;}
.nav-menu a{text-decoration:none;color:#000;font-weight:600;cursor:pointer}

/* PRODUCT */
.container{
    max-width:1200px;
    margin:50px auto;
    background:#fff;
    padding:40px;
    border-radius:10px;
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:40px;
}
.product-img img{width:100%;border-radius:10px;}
.product-title{font-size:30px;font-weight:800;}
.desc{color:#555;margin:10px 0;}
.price-box{margin:15px 0;}
.original-price{text-decoration:line-through;color:#777;}
.discount-price{color:#c82027;font-size:28px;font-weight:800;margin-left:10px;}
.discount-badge{
    background:#c82027;color:#fff;padding:6px 12px;
    border-radius:20px;display:inline-block;margin-bottom:10px;
}

/* OPTIONS */
.option-box{margin:20px 0;}
.options{display:flex;gap:15px;}
.options button{
    padding:10px 18px;border:1px solid #ccc;
    background:#fff;cursor:pointer;border-radius:6px;
}
.options button.active{border:2px solid #c82027;color:#c82027;}

/* BUTTON */
.buy-btn{
    margin-top:15px;padding:15px;width:100%;
    background:#c82027;color:#fff;border:none;
    font-size:18px;border-radius:8px;cursor:pointer;
}

/* CART */
.cart{
    position: fixed;
    top: 90px;              /* navbar ni niche */
    right: 40px;
    width: 350px;
    background:#fff;
    padding:30px;
    border-radius:10px;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
    display:none;
    z-index: 999;
}

.cart h2{
    margin-bottom:15px;
}

.cart-item{
    border:1px solid #eee;
    padding:15px;
    border-radius:8px;
    margin-bottom:15px;
}

.cart-item p{
    margin:6px 0;
    font-size:14px;
}

.cart-total{
    font-weight:800;
    margin-top:10px;
    font-size:16px;
}

.cart-actions{
    display:flex;
    gap:10px;
    margin-top:15px;
}

.remove-btn{
    flex:1;
    padding:10px;
    border:none;
    background:#ddd;
    border-radius:6px;
    cursor:pointer;
    font-weight:600;
}

.buy-btn-cart{
    flex:1;
    padding:10px;
    border:none;
    background:#c82027;
    color:#fff;
    border-radius:6px;
    cursor:pointer;
    font-weight:700;
}

.footer{
    margin-top:60px;background:#000;color:#aaa;
    text-align:center;padding:20px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="navbar">
    <div class="logo">GYMNESS</div>
    <ul class="nav-menu">
        <li><a href="newhome.php">Home</a></li>
        <li><a onclick="toggleCart()">🛒 Cart (<span id="cartCount">0</span>)</a></li>
        <li><a href="newhome.php#contact">Contact</a></li>
    </ul>
</div>

<!-- CART (TOP) -->
<div class="cart" id="cartBox">
    <h2>Your Cart</h2>
    <div id="cartItems" style="margin-top:15px;color:#777;">Cart is empty</div>
</div>

<!-- PRODUCT -->
<div class="container">
    <div class="product-img">
        <img src="https://images.unsplash.com/photo-1598970434795-0c54fe7c0648">
    </div>

    <div>
        <span class="discount-badge">30% OFF</span>
        <div class="product-title">Gold Standard Whey Protein</div>

        <p class="desc">
            Premium whey protein for muscle growth, recovery and strength.
        </p>

        <div class="price-box">
            <span class="original-price" id="originalPrice">₹4000</span>
            <span class="discount-price" id="finalPrice">₹2800</span>
        </div>

        <div><b>Stock:</b> <span id="stockCount">10</span></div>

        <!-- WEIGHT -->
        <div class="option-box">
            <h4>Select Weight</h4>
            <div class="options">
                <button class="active" onclick="changeWeight(1)">1 KG</button>
                <button onclick="changeWeight(2)">2 KG</button>
                <button onclick="changeWeight(3)">3 KG</button>
            </div>
        </div>

        <!-- FLAVOUR -->
        <div class="option-box">
            <h4>Select Flavour</h4>
            <div class="options">
                <button class="active" onclick="changeFlavour(0)">Chocolate</button>
                <button onclick="changeFlavour(200)">Vanilla</button>
                <button onclick="changeFlavour(300)">Strawberry</button>
            </div>
        </div>

        <button class="buy-btn" onclick="addToCart()">Add to Cart</button>
    </div>
</div>

<!-- FOOTER -->
<div class="footer">© 2024 Gymness. All rights reserved.</div>

<script>
let basePrice = 2800;
let baseOriginal = 4000;
let extraFlavour = 0;
let weight = 1;
let stock = 10;
let cartQty = 0;

/* PRICE */
function changeWeight(w)
{
    weight=w;updatePrice();
    setActive(event);
}
function changeFlavour(e){extraFlavour=e;updatePrice();setActive(event);}
function updatePrice(){
    finalPrice.innerText="₹"+(basePrice*weight+extraFlavour);
    originalPrice.innerText="₹"+(baseOriginal*weight);
}
function setActive(e){
    let b=e.target.parentElement.querySelectorAll("button");
    b.forEach(x=>x.classList.remove("active"));
    e.target.classList.add("active");
}

/* CART */
function addToCart(){
    if(stock<=0){alert("Out of Stock");return;}
    stock--; cartQty++;
    stockCount.innerText=stock;
    cartCount.innerText=cartQty;
    renderCart();
}
function removeFromCart(){
    cartQty--; stock++;
    stockCount.innerText=stock;
    cartCount.innerText=cartQty;
    renderCart();
}
function renderCart(){
    if(cartQty==0){
        cartItems.innerHTML="Cart is empty";
        return;
    }

    let total = (basePrice*weight + extraFlavour) * cartQty;

    cartItems.innerHTML = `
        <div class="cart-item">
            <b>Gold Standard Whey Protein</b>
            <p>Weight: ${weight} KG</p>
            <p>Flavour: ${extraFlavour==0?"Chocolate":extraFlavour==200?"Vanilla":"Strawberry"}</p>
            <p>Quantity: ${cartQty}</p>
            <div class="cart-total">Total: ₹${total}</div>

            <div class="cart-actions">
                <button class="remove-btn" onclick="removeFromCart()">Remove</button>
                <button class="buy-btn-cart" onclick="buyNow()">Buy Now</button>
            </div>
        </div>
    `;
}

function buyNow(){
    if(cartQty == 0){
        alert("Cart is empty");
        return;
    }

    let checkoutData = {
        weight: weight,
        flavour: extraFlavour,
        qty: cartQty,
        price: (basePrice * weight + extraFlavour),
        original: (baseOriginal * weight)
    };

    localStorage.setItem("checkoutData", JSON.stringify(checkoutData));

    // redirect to checkout page
    window.location.href = "checkout.html";
}


/* SHOW / HIDE CART */
function toggleCart(){
    cartBox.style.display =
        cartBox.style.display==="none" ? "block" : "none";
}
</script>

</body>
</html>
