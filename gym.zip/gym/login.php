<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login | Gymness</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; font-family:Arial, Helvetica, sans-serif; }

body { 
    height:100vh; 
    overflow:hidden;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.login-container {
    position:absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    width:100%;
    max-width:420px;
    z-index:10;
}

.login-card {
    background:rgba(255,255,255,0.95);
    backdrop-filter: blur(20px);
    border-radius:20px;
    padding:40px;
    box-shadow:0 25px 50px rgba(0,0,0,0.2);
    border:1px solid rgba(255,255,255,0.3);
}

.logo {
    text-align:center;
    margin-bottom:30px;
}

.logo h1 {
    background: linear-gradient(135deg, #c82027, #ff4757);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-size:32px;
    font-weight:800;
}

.form-floating {
    margin-bottom:20px;
}

.form-floating input {
    border-radius:12px;
    border:2px solid #e9ecef;
    padding:15px 15px 15px 15px;
    font-size:16px;
    transition:all 0.3s;
}

.form-floating input:focus {
    border-color:#c82027;
    box-shadow:0 0 0 0.2rem rgba(200,32,39,0.25);
}

.btn-login {
    background:linear-gradient(135deg, #c82027, #ff4757);
    border:none;
    border-radius:12px;
    padding:15px;
    font-size:18px;
    font-weight:600;
    width:100%;
    transition:all 0.3s;
}

.btn-login:hover {
    transform:translateY(-2px);
    box-shadow:0 10px 25px rgba(200,32,39,0.4);
}

.bottom-text {
    text-align:center;
    margin-top:25px;
    color:#666;
}

.bottom-text a {
    color:#c82027;
    font-weight:600;
    text-decoration:none;
}

.bottom-text a:hover {
    color:#a81c22;
}

.alert-custom {
    border-radius:12px;
    border:none;
}
</style>
</head>

<body>

<div class="login-container">
    <div class="login-card">
        <div class="logo">
            <h1>GYMNESS</h1>
            <p class="text-muted mb-0">Welcome Back</p>
        </div>

        <?php
        $error = '';
       if(isset($_POST['btn'])) {

    $uname = $_POST['n1'];
    $pass = $_POST['n2'];

    // 🔥 FIRST CHECK ADMIN DIRECTLY
    if($uname == "admin" && $pass == "123"){
        $_SESSION['username'] = "admin";
        $_SESSION['role'] = "admin";
        header("Location: admin.php");
        exit;
    }

    // 🔥 THEN CHECK DATABASE USERS
    $con = mysqli_connect("localhost","root","","gym");

    if (!$con) {
        $error = "Database connection failed!";
    } else {

        $sql = "SELECT * FROM user_table WHERE username='$uname' AND password='$pass'";
        $res = mysqli_query($con, $sql);

        if(mysqli_num_rows($res)==1) {
            $row = mysqli_fetch_assoc($res);

            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];

            if(strtolower($row['role'])=="trainer" || strtolower($row['role'])=="expert") {
                header("Location: trainer.php");
            } else {
                header("Location: newhome.php");
            }
            exit;
        } else {
            $error = "Invalid Username or Password!";
        }
    }
}   
        ?>

        <?php if($error): ?>
            <div class="alert alert-danger alert-custom">
                <i class="bi bi-exclamation-triangle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form name="loginForm" method="POST" onsubmit="return validateForm()">
            <div class="form-floating">
                <input type="text" class="form-control" id="username" name="n1" placeholder="Username" required value="<?php echo isset($_POST['n1']) ? $_POST['n1'] : ''; ?>">
                <label for="username">Username</label>
            </div>
            
            <div class="form-floating">
                <input type="password" class="form-control" id="password" name="n2" placeholder="Password" required>
                <label for="password">Password</label>
            </div>
            
            <button type="submit" class="btn btn-login text-white" name="btn">
                <i class="bi bi-box-arrow-in-right me-2"></i>Log In
            </button>
        </form>

        <div class="bottom-text">
            Don't have an account? <a href="signup.php">Sign Up</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function validateForm() {
    let u = document.forms["loginForm"]["n1"].value;
    let p = document.forms["loginForm"]["n2"].value;
    if(u === "" || p === "") {
        alert("All fields are required!");
        return false;
    }
    return true;
}
</script>
</body>
</html>
