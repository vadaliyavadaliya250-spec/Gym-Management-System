<?php
$conn = mysqli_connect("localhost","root","","gym");

/* Fetch Active Plans */
$result = mysqli_query($conn,"SELECT * FROM membership_plans WHERE status='active'");
$plans = [];
while($row = mysqli_fetch_assoc($result)){
    $plans[] = $row;
}

/* Handle QR Generate */
$upi_qr = "";
$amount = "";

if(isset($_POST['generate_qr'])){

    $name = urlencode($_POST['customer_name']);
    $upi_id = $_POST['customer_upi'];
    $amount = $_POST['amount'];

    $payment_link = "upi://pay?pa=$upi_id&pn=$name&am=$amount&cu=INR";

    $upi_qr = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=".$payment_link;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Elite Membership</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:#000;
    color:white;
}
.container{
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    gap:30px;
    padding:60px 20px;
}
.card{
    background:#111;
    width:320px;
    padding:25px;
    border:1px solid #222;
    border-radius:12px;
    transition:0.3s;
}
.card:hover{
    transform:translateY(-10px);
    border:1px solid red;
}
.price{
    font-size:26px;
    color:red;
    font-weight:bold;
}
.buy-btn{
    width:100%;
    padding:10px;
    background:transparent;
    border:2px solid red;
    color:white;
    cursor:pointer;
    margin-top:15px;
}
.buy-btn:hover{
    background:red;
}
.popup{
    display:none;
    position:fixed;
    top:0; left:0;
    width:100%; height:100%;
    background:rgba(0,0,0,0.8);
    justify-content:center;
    align-items:center;
}
.popup-content{
    background:#111;
    padding:30px;
    width:350px;
    border-radius:10px;
}
input{
    width:100%;
    padding:10px;
    margin:8px 0;
    background:#000;
    border:1px solid #444;
    color:white;
}
.generate-btn{
    width:100%;
    padding:10px;
    background:red;
    border:none;
    color:white;
    cursor:pointer;
}
.qr-section{
    text-align:center;
    padding:40px;
}
</style>

<script>
function openPopup(amount){
    document.getElementById("popup").style.display="flex";
    document.getElementById("amount").value = amount;
}

function closePopup(){
    document.getElementById("popup").style.display="none";
}
</script>

</head>
<body>

<h1 style="text-align:center;padding-top:30px;">Elite Membership Plans</h1>

<div class="container">

<?php foreach($plans as $plan){ ?>
<div class="card">

<h3><?= $plan['plan_name'] ?></h3>
<div class="price">₹<?= $plan['price'] ?></div>
<p><?= $plan['duration'] ?> Days</p>

<?php
$features = explode(",", $plan['features']);
foreach($features as $f){
    echo "<p>✔ ".$f."</p>";
}
?>

<button class="buy-btn" onclick="openPopup('<?= $plan['price'] ?>')">Buy</button>

</div>
<?php } ?>

</div>

<!-- POPUP FORM -->
<div class="popup" id="popup">
<div class="popup-content">
<h3>Enter Payment Details</h3>

<form method="POST">
<input type="text" name="customer_name" placeholder="Your Name" required>
<input type="text" name="customer_upi" placeholder="Your UPI ID" required>
<input type="text" name="amount" id="amount" readonly>

<button type="submit" name="generate_qr" class="generate-btn">Generate QR</button>
<button type="button" onclick="closePopup()" class="buy-btn">Cancel</button>
</form>

</div>
</div>

<?php if($upi_qr != ""){ ?>
<div class="qr-section">
<h2>Scan & Pay</h2>
<h3>Amount: ₹<?= $amount ?></h3>
<img src="<?= $upi_qr ?>" alt="QR Code">
<p style="color:#ccc;">Scan using any UPI App</p>
</div>
<?php } ?>

</body>
</html>
