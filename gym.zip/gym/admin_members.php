<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Management | Gymness</title>
    <link rel="stylesheet" href="admin_style.css">
</head>
<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h2>GYMNESS</h2>
        <ul>
            <li><a href="admin.php">Dashboard</a></li>
            <li><a href="admin_members.php">Members</a></li>
            <li><a href="#">Trainers</a></li>
            <li><a href="#">Products</a></li>
            <li><a href="#">Payments</a></li>
        </ul>
        <div class="logout">
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        
        <div class="header">
            <h1>Members Management</h1>
            <div class="user-info">
                Admin Panel
            </div>
        </div>

        <!-- MEMBERS TABLE -->
        <div class="table-container">
            <h2>All Registered Members</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Password (Encrypted)</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $con = mysqli_connect("localhost","root","","gym");
                    $sql = "SELECT * FROM user WHERE role != 'admin'";
                    $res = mysqli_query($con, $sql);

                    while($row = mysqli_fetch_assoc($res)) {
                        echo "<tr>
                                <td>".$row['id']."</td>
                                <td>".$row['username']."</td>
                                <td>".$row['email']."</td>
                                <td>".$row['password']."</td>
                                <td>".$row['role']."</td>
                                <td>
                                    <button style='padding:5px 10px; background:red; color:white; border:none; cursor:pointer; border-radius:4px;'>Delete</button>
                                </td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>

</body>
</html>
