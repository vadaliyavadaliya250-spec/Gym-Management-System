<?php
$bmi = "";
$category = "";
$dietChart = "";
$color = "";

if(isset($_POST['calculate'])){

    $weight = $_POST['weight'];
    $height = $_POST['height'] / 100;

    if($weight > 0 && $height > 0){

        $bmi = round($weight / ($height * $height), 2);

        if($bmi < 18.5){
            $category = "Underweight";
            $color = "#3498db";

            $dietChart = "
            <table>
                <tr><th>Time</th><th>Meal</th></tr>
                <tr><td>Morning</td><td>Milk + Banana Shake</td></tr>
                <tr><td>Breakfast</td><td>Eggs + Peanut Butter Bread</td></tr>
                <tr><td>Lunch</td><td>Rice + Chicken + Salad</td></tr>
                <tr><td>Evening</td><td>Dry Fruits + Juice</td></tr>
                <tr><td>Dinner</td><td>Chapati + Vegetables</td></tr>
            </table>";
        }
        elseif($bmi < 25){
            $category = "Normal Weight";
            $color = "#2ecc71";

            $dietChart = "
            <table>
                <tr><th>Time</th><th>Meal</th></tr>
                <tr><td>Morning</td><td>Warm Water + Lemon</td></tr>
                <tr><td>Breakfast</td><td>Oats + Fruits</td></tr>
                <tr><td>Lunch</td><td>Chapati + Dal + Salad</td></tr>
                <tr><td>Evening</td><td>Green Tea + Nuts</td></tr>
                <tr><td>Dinner</td><td>Light Vegetables + Soup</td></tr>
            </table>";
        }
        elseif($bmi < 30){
            $category = "Overweight";
            $color = "#f39c12";

            $dietChart = "
            <table>
                <tr><th>Time</th><th>Meal</th></tr>
                <tr><td>Morning</td><td>Warm Water + Honey</td></tr>
                <tr><td>Breakfast</td><td>Boiled Eggs + Brown Bread</td></tr>
                <tr><td>Lunch</td><td>Grilled Chicken + Salad</td></tr>
                <tr><td>Evening</td><td>Green Tea</td></tr>
                <tr><td>Dinner</td><td>Soup + Boiled Vegetables</td></tr>
            </table>";
        }
        else{
            $category = "Obese";
            $color = "#e74c3c";

            $dietChart = "
            <table>
                <tr><th>Time</th><th>Meal</th></tr>
                <tr><td>Morning</td><td>Warm Water + Lemon</td></tr>
                <tr><td>Breakfast</td><td>Oats + Apple</td></tr>
                <tr><td>Lunch</td><td>Boiled Vegetables + Salad</td></tr>
                <tr><td>Evening</td><td>Green Tea</td></tr>
                <tr><td>Dinner</td><td>Vegetable Soup</td></tr>
            </table>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Advanced BMI Calculator</title>

<style>
body{
    margin:0;
    font-family:Arial;
    background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
}

.container{
    background:white;
    padding:40px;
    width:500px;
    border-radius:20px;
    box-shadow:0 15px 40px rgba(0,0,0,0.4);
}

h1{
    text-align:center;
    margin-bottom:20px;
}

input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:10px;
    border:1px solid #ccc;
}

button{
    width:100%;
    padding:12px;
    background:#2c5364;
    color:white;
    border:none;
    border-radius:10px;
    font-size:16px;
    cursor:pointer;
}

button:hover{
    background:#203a43;
}

.result{
    margin-top:25px;
    padding:20px;
    border-radius:15px;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:15px;
}

table, th, td{
    border:1px solid #ddd;
}

th{
    background:#2c5364;
    color:white;
    padding:10px;
}

td{
    padding:10px;
    text-align:center;
}

tr:nth-child(even){
    background:#f2f2f2;
}
</style>

</head>
<body>

<div class="container">

<h1>BMI Calculator</h1>

<form method="POST">
    <input type="number" name="weight" placeholder="Enter Weight (kg)" required>
    <input type="number" name="height" placeholder="Enter Height (cm)" required>
    <button type="submit" name="calculate">Calculate BMI</button>
</form>

<?php if($bmi != ""){ ?>
<div class="result" style="border:3px solid <?php echo $color; ?>;">
    <h2>Your BMI: <?php echo $bmi; ?></h2>
    <h3 style="color:<?php echo $color; ?>;">Category: <?php echo $category; ?></h3>
    <h3>Recommended Diet Chart</h3>
    <?php echo $dietChart; ?>
</div>
<?php } ?>

</div>

</body>
</html>
