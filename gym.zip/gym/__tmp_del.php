﻿<?php
$files = [
    'c:/xampp1/htdocs/gym/__tmp_check.php',
    'c:/xampp1/htdocs/gym/__tmp_check2.php',
    'c:/xampp1/htdocs/gym/__tmp_check3.php'
];
foreach($files as $f){
    if(file_exists($f)){
        echo $f.' => ';
        var_export(@unlink($f));
        echo PHP_EOL;
    }
}
?>
