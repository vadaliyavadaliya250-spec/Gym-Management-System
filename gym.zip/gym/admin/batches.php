<?php include "header.php"; ?>

<?php
$success = '';
if(isset($_POST['add_batch'])){
    $name     = mysqli_real_escape_string($con,$_POST['batch_name']);
    $trainer  = (int)$_POST['trainer'];
    $start    = $_POST['start'];
    $end      = $_POST['end'];
    $capacity = (int)$_POST['capacity'];
    mysqli_query($con,"INSERT INTO batches(batch_name,trainer_id,start_time,end_time,capacity) VALUES('$name','$trainer','$start','$end','$capacity')");
    $success = "Batch added successfully!";
}

$res      = mysqli_query($con,"SELECT b.*,t.name as trainer_name FROM batches b LEFT JOIN trainers t ON b.trainer_id=t.id ORDER BY b.id DESC");
$trainers = mysqli_query($con,"SELECT * FROM trainers WHERE type='batch' AND status='active'");
?>

<div class="pg-title">Manage Batches</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>

<div class="card">
    <h2>Add New Batch</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Batch Name</label><input type="text" name="batch_name" required></div>
            <div class="fg"><label>Batch Trainer</label>
                <select name="trainer" required>
                    <option value="">Select Trainer</option>
                    <?php while($t=mysqli_fetch_assoc($trainers)): ?>
                    <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="fg"><label>Start Time</label><input type="time" name="start" required></div>
            <div class="fg"><label>End Time</label><input type="time" name="end" required></div>
            <div class="fg"><label>Capacity</label><input type="number" name="capacity" min="1" required></div>
        </div>
        <button type="submit" name="add_batch" class="btn btn-o">+ Add Batch</button>
    </form>
</div>

<div class="twrap">
    <div class="thead">📦 All Batches</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Batch Name</th><th>Trainer</th><th>Start Time</th><th>End Time</th><th>Capacity</th><th>Status</th><th>Action</th></tr>
        <?php if(mysqli_num_rows($res)>0): while($b=mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?php echo $b['id']; ?></td>
            <td><?php echo htmlspecialchars($b['batch_name']); ?></td>
            <td><?php echo htmlspecialchars($b['trainer_name'] ?? '-'); ?></td>
            <td><?php echo date('h:i A',strtotime($b['start_time'])); ?></td>
            <td><?php echo date('h:i A',strtotime($b['end_time'])); ?></td>
            <td><?php echo $b['capacity']; ?></td>
            <td><span class="bx <?php echo $b['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($b['status']); ?></span></td>
            <td style="white-space:nowrap;">
                <a href="edit_batch.php?id=<?php echo $b['id']; ?>" class="btn btn-b">Edit</a>
                <a href="delete_batch.php?id=<?php echo $b['id']; ?>" class="btn btn-r" onclick="return confirm('Delete batch?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" style="text-align:center;color:#888;padding:20px;">No batches found.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
