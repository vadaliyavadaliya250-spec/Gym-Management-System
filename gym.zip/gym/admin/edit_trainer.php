<?php
// ALL PHP LOGIC FIRST — before any HTML output
include "db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if(isset($_POST['update'])){
    $name   = mysqli_real_escape_string($con,$_POST['name']);
    $email  = mysqli_real_escape_string($con,$_POST['email']);
    $phone  = mysqli_real_escape_string($con,$_POST['phone']);
    $gender = mysqli_real_escape_string($con,$_POST['gender']);
    $spec   = mysqli_real_escape_string($con,$_POST['specialization']);
    $exp    = (int)$_POST['experience'];
    $addr   = mysqli_real_escape_string($con,$_POST['address']);
    $uname  = mysqli_real_escape_string($con,$_POST['username']);
    $pass   = mysqli_real_escape_string($con,$_POST['password']);
    $status = $_POST['status'];
    $type   = $_POST['type'];

    mysqli_query($con,"UPDATE trainers SET name='$name',email='$email',phone='$phone',gender='$gender',
        specialization='$spec',experience='$exp',address='$addr',username='$uname',password='$pass',
        status='$status',type='$type' WHERE id='$id'");

    header("Location: trainers.php");
    exit();
}

$q = mysqli_query($con,"SELECT * FROM trainers WHERE id='$id'");
$t = mysqli_fetch_assoc($q);
?>
<?php include "header.php"; ?>

<?php if(!$t): ?>
    <div class="al al-d">Trainer not found.</div>
<?php else: ?>

<div class="pg-title">Edit Trainer</div>
<div class="card">
    <h2>Edit Trainer — <?php echo htmlspecialchars($t['name']); ?></h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($t['name']); ?>" required></div>
            <div class="fg"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($t['email']); ?>" required></div>
            <div class="fg"><label>Phone</label><input type="text" name="phone" value="<?php echo htmlspecialchars($t['phone']); ?>"></div>
            <div class="fg"><label>Gender</label>
                <select name="gender">
                    <option value="Male"   <?php echo $t['gender']=='Male'?'selected':''; ?>>Male</option>
                    <option value="Female" <?php echo $t['gender']=='Female'?'selected':''; ?>>Female</option>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg"><label>Specialization</label><input type="text" name="specialization" value="<?php echo htmlspecialchars($t['specialization']); ?>"></div>
            <div class="fg"><label>Experience (Years)</label><input type="number" name="experience" value="<?php echo $t['experience']; ?>" min="0"></div>
            <div class="fg"><label>Username</label><input type="text" name="username" value="<?php echo htmlspecialchars($t['username']); ?>"></div>
            <div class="fg"><label>Password</label><input type="text" name="password" value="<?php echo htmlspecialchars($t['password']); ?>"></div>
        </div>
        <div class="frow">
            <div class="fg"><label>Trainer Type</label>
                <select name="type">
                    <option value="personal" <?php echo $t['type']=='personal'?'selected':''; ?>>Personal Trainer</option>
                    <option value="batch"    <?php echo $t['type']=='batch'?'selected':''; ?>>Batch Trainer</option>
                </select>
            </div>
            <div class="fg"><label>Status</label>
                <select name="status">
                    <option value="active"   <?php echo $t['status']=='active'?'selected':''; ?>>Active</option>
                    <option value="inactive" <?php echo $t['status']=='inactive'?'selected':''; ?>>Inactive</option>
                </select>
            </div>
            <div class="fg"><label>Address</label><input type="text" name="address" value="<?php echo htmlspecialchars($t['address']); ?>"></div>
        </div>
        <button type="submit" name="update" class="btn btn-o">💾 Update Trainer</button>
        <a href="trainers.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
    </form>
</div>

<?php endif; ?>
<?php include "footer.php"; ?>