<?php /* sidebar is now built inside header.php — this file kept for compatibility */ ?>
