﻿
<?php include "header.php"; ?>

<?php
if(isset($_GET['approve'])){
    $id = (int)$_GET['approve'];
    $approve_user = '';
    $rq = mysqli_query($con,"SELECT username FROM membership_purchases WHERE id='$id' LIMIT 1");
    if($rq && mysqli_num_rows($rq) > 0){
        $approve_row = mysqli_fetch_assoc($rq);
        $approve_user = trim((string)($approve_row['username'] ?? ''));
    }

    mysqli_query($con,"UPDATE membership_purchases SET status='approved' WHERE id='$id'");

    // Keep legacy user_memberships status in sync when available.
    if($approve_user !== ''){
        $um_tbl = mysqli_query($con, "SHOW TABLES LIKE 'user_memberships'");
        if($um_tbl && mysqli_num_rows($um_tbl) > 0){
            $u = mysqli_real_escape_string($con, $approve_user);
            $uq = mysqli_query($con, "SELECT id FROM user_table WHERE username='$u' LIMIT 1");
            if($uq && mysqli_num_rows($uq) > 0){
                $uid = (int)(mysqli_fetch_assoc($uq)['id'] ?? 0);
                if($uid > 0){
                    mysqli_query($con,"UPDATE user_memberships SET status='approved' WHERE user_id='$uid' AND status IN ('pending','cancelled','canceled') ORDER BY id DESC LIMIT 1");
                }
            }
        }
    }

    // Ensure free item table exists and insert approved member row
    mysqli_query($con,"
        CREATE TABLE IF NOT EXISTS free_membership_items (
            id INT(11) NOT NULL AUTO_INCREMENT,
            purchase_id INT(11) DEFAULT NULL,
            username VARCHAR(100) NOT NULL,
            member_name VARCHAR(150) DEFAULT NULL,
            plan_name VARCHAR(150) DEFAULT NULL,
            gymbag_status ENUM('not_given','given') DEFAULT 'not_given',
            bottle_status ENUM('not_given','given') DEFAULT 'not_given',
            note VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_purchase_id (purchase_id),
            KEY idx_username (username)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    mysqli_query($con,"
        INSERT INTO free_membership_items (purchase_id, username, member_name, plan_name)
        SELECT mp.id, mp.username, ud.fullname, mp.plan_name
        FROM membership_purchases mp
        LEFT JOIN user_details ud ON ud.username = mp.username
        LEFT JOIN free_membership_items fi ON fi.purchase_id = mp.id
        WHERE mp.id='$id' AND mp.status='approved' AND fi.id IS NULL
    ");

    header("Location: purchase_requests.php"); exit();
}
if(isset($_GET['cancel'])){
    $id = (int)$_GET['cancel'];
    $cancel_user = '';
    $rq = mysqli_query($con,"SELECT username FROM membership_purchases WHERE id='$id' LIMIT 1");
    if($rq && mysqli_num_rows($rq) > 0){
        $cancel_row = mysqli_fetch_assoc($rq);
        $cancel_user = trim((string)($cancel_row['username'] ?? ''));
    }

    mysqli_query($con,"UPDATE membership_purchases SET status='cancelled' WHERE id='$id'");
    mysqli_query($con,"DELETE FROM free_membership_items WHERE purchase_id='$id'");

    // If legacy user_memberships table exists, mark approved rows cancelled as well.
    if($cancel_user !== ''){
        $um_tbl = mysqli_query($con, "SHOW TABLES LIKE 'user_memberships'");
        if($um_tbl && mysqli_num_rows($um_tbl) > 0){
            $u = mysqli_real_escape_string($con, $cancel_user);
            $uq = mysqli_query($con, "SELECT id FROM user_table WHERE username='$u' LIMIT 1");
            if($uq && mysqli_num_rows($uq) > 0){
                $uid = (int)(mysqli_fetch_assoc($uq)['id'] ?? 0);
                if($uid > 0){
                    mysqli_query($con,"UPDATE user_memberships SET status='cancelled' WHERE user_id='$uid' AND status='approved'");
                }
            }
        }
    }

    header("Location: purchase_requests.php"); exit();
}

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$allowed_filters = ['all','pending','approved','cancelled'];
if(!in_array($filter, $allowed_filters, true)){
    $filter = 'all';
}

$where  = $filter != 'all' ? "WHERE status='$filter'" : '';
$res    = mysqli_query($con,"SELECT * FROM membership_purchases $where ORDER BY id DESC");

$qp = mysqli_query($con,"SELECT COUNT(*) as c FROM membership_purchases WHERE status='pending'");
$pending = mysqli_fetch_assoc($qp)['c'];
$qa = mysqli_query($con,"SELECT COUNT(*) as c FROM membership_purchases WHERE status='approved'");
$approved = mysqli_fetch_assoc($qa)['c'];
$qc = mysqli_query($con,"SELECT COUNT(*) as c FROM membership_purchases WHERE status='cancelled'");
$cancelled = mysqli_fetch_assoc($qc)['c'];
?>

<div class="pg-title">Purchase Requests</div>

<div class="sc-row">
    <div class="sc o"><div class="n"><?php echo $pending; ?></div><div class="l">Pending</div></div>
    <div class="sc g"><div class="n"><?php echo $approved; ?></div><div class="l">Approved</div></div>
    <div class="sc" style="border-left-color:#e74c3c;"><div class="n"><?php echo $cancelled; ?></div><div class="l">Cancelled</div></div>
</div>

<div style="margin-bottom:16px;">
    <a href="?filter=all"       class="btn <?php echo $filter=='all'?'btn-dk':'btn-b'; ?>" style="margin-right:6px;">All</a>
    <a href="?filter=pending"   class="btn <?php echo $filter=='pending'?'btn-dk':'btn-w'; ?>" style="margin-right:6px;">Pending</a>
    <a href="?filter=approved"  class="btn <?php echo $filter=='approved'?'btn-dk':'btn-g'; ?>" style="margin-right:6px;">Approved</a>
    <a href="?filter=cancelled" class="btn <?php echo $filter=='cancelled'?'btn-dk':'btn-r'; ?>">Cancelled</a>
</div>

<div class="twrap">
    <div class="thead">Membership Purchase Requests</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Username</th><th>Plan</th><th>Amount</th><th>Transaction ID</th><th>Status</th><th>Date</th><th>Action</th></tr>
        <?php $i=1; if(mysqli_num_rows($res)>0): while($r=mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['username']); ?></td>
            <td><?php echo htmlspecialchars($r['plan_name']); ?></td>
            <td>Rs <?php echo number_format($r['amount'],2); ?></td>
            <td><?php echo htmlspecialchars($r['txn']); ?></td>
            <td><span class="bx <?php echo $r['status']=='approved'?'bx-s':($r['status']=='cancelled'?'bx-d':'bx-w'); ?>"><?php echo ucfirst($r['status']); ?></span></td>
            <td><?php echo date('d M Y',strtotime($r['purchase_date'])); ?></td>
            <td style="white-space:nowrap;">
                <?php if($r['status']=='pending'): ?>
                <a href="?approve=<?php echo $r['id']; ?>" class="btn btn-g">Approve</a>
                <a href="?cancel=<?php echo $r['id']; ?>"  class="btn btn-r" onclick="return confirm('Cancel this request?')">Cancel</a>
                <?php elseif($r['status']=='approved'): ?>
                <a href="?cancel=<?php echo $r['id']; ?>"  class="btn btn-r" onclick="return confirm('Cancel this approved membership?')">Cancel</a>
                <?php elseif($r['status']=='cancelled'): ?>
                <a href="?approve=<?php echo $r['id']; ?>" class="btn btn-g" onclick="return confirm('Approve this cancelled membership again?')">Approve</a>
                <?php else: ?>
                <span style="color:#aaa;font-size:12px;">Done</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" style="text-align:center;color:#888;padding:20px;">No requests found.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
