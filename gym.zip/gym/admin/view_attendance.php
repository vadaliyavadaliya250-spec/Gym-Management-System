<?php include "header.php"; ?>

<?php
$q = mysqli_query($con,"SELECT a.*,ud.fullname,b.batch_name FROM attendance a
    JOIN user_details ud ON a.member_id=ud.id
    LEFT JOIN batches b ON a.batch_id=b.id
    ORDER BY a.date DESC");
?>

<div class="pg-title">View Attendance</div>
<div class="twrap">
    <div class="thead">📊 All Attendance Records</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Member</th><th>Batch</th><th>Date</th><th>Status</th></tr>
        <?php $i=1; if(mysqli_num_rows($q)>0): while($r=mysqli_fetch_assoc($q)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['fullname']); ?></td>
            <td><?php echo $r['batch_name'] ? htmlspecialchars($r['batch_name']) : '-'; ?></td>
            <td><?php echo date('d M Y',strtotime($r['date'])); ?></td>
            <td><span class="bx <?php echo strtolower($r['status'])=='present'?'bx-s':'bx-d'; ?>"><?php echo $r['status']; ?></span></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="5" style="text-align:center;color:#888;padding:20px;">No records.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
