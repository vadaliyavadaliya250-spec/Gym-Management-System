﻿<?php
session_start();
include "db.php";
if( !isset($_SESSION['admin']) && (($_SESSION['username'] ?? '') !== 'admin') && (($_SESSION['role'] ?? '') !== 'admin') ){
    // header("Location: ../admin.php");
    // exit();
}

$msg = $err = '';

// fetch trainers for dropdown
$trainers = mysqli_query($con,"SELECT id,name FROM trainers ORDER BY name");

// helper to detect column existence (used for member joins)
$has_col = function($table,$col) use ($con){
    $db = mysqli_fetch_row(mysqli_query($con,"SELECT DATABASE()"))[0];
    $db = mysqli_real_escape_string($con,$db);
    $col= mysqli_real_escape_string($con,$col);
    $q = mysqli_query($con,"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$db' AND TABLE_NAME='$table' AND COLUMN_NAME='$col' LIMIT 1");
    return mysqli_num_rows($q)>0;
};

if($_SERVER['REQUEST_METHOD']==='POST'){
    $title       = mysqli_real_escape_string($con, trim($_POST['title'] ?? ''));
    $event_date  = mysqli_real_escape_string($con, $_POST['event_date'] ?? '');
    $event_time  = mysqli_real_escape_string($con, $_POST['event_time'] ?? '');
    $location    = mysqli_real_escape_string($con, trim($_POST['location'] ?? ''));
    $trainer_id  = (int)($_POST['trainer_id'] ?? 0);
    $max_seats   = (int)($_POST['max_seats'] ?? 0);
    $description = mysqli_real_escape_string($con, trim($_POST['description'] ?? ''));
    $status      = mysqli_real_escape_string($con, $_POST['status'] ?? 'active');

    if(!$title || !$event_date){
        $err = "Title and Date are required.";
    } else {
        $ok = mysqli_query($con,"INSERT INTO events (title,event_date,event_time,location,trainer_id,max_seats,description,status)
                           VALUES('$title','$event_date','$event_time','$location',".($trainer_id?:'NULL').",'$max_seats','$description','$status')");
        if($ok){
            $msg = "Event created successfully.";
        } else {
            $err = "Could not create event.";
        }
    }
}

include "header.php";
?>

<div class="pg-title">Add Event</div>
<?php if($msg): ?><div class="al al-s"><?php echo $msg; ?></div><?php endif; ?>
<?php if($err): ?><div class="al al-d"><?php echo $err; ?></div><?php endif; ?>

<div class="card">
    <h2>Event Details</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Title *</label><input type="text" name="title" required></div>
            <div class="fg"><label>Date *</label><input type="date" name="event_date" required></div>
            <div class="fg"><label>Time</label><input type="time" name="event_time"></div>
        </div>
        <div class="frow">
            <div class="fg"><label>Location</label><input type="text" name="location" placeholder="Studio / Floor / Offsite"></div>
            <div class="fg"><label>Trainer</label>
                <select name="trainer_id">
                    <option value="">-- Select Trainer --</option>
                    <?php if($trainers): mysqli_data_seek($trainers,0); while($t=mysqli_fetch_assoc($trainers)): ?>
                        <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['name']); ?></option>
                    <?php endwhile; endif; ?>
                </select>
            </div>
            <div class="fg"><label>Max Seats (0 = unlimited)</label><input type="number" name="max_seats" min="0" value="0"></div>
        </div>
        <div class="frow">
            <div class="fg full-w"><label>Description / Notes</label><textarea name="description" rows="3" placeholder="What members should know"></textarea></div>
        </div>
        <div class="frow">
            <div class="fg"><label>Status</label>
                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
        </div>
        <button class="btn btn-o" type="submit">Save Event</button>
        <a class="btn btn-dk" href="events.php" style="margin-left:8px;">Back to Events</a>
    </form>
</div>

<?php
// list events with joined members
$memberCol = $has_col('event_registrations','member_id') ? 'member_id' : ($has_col('event_registrations','user_id') ? 'user_id' : ($has_col('event_registrations','username') ? 'username' : null));
$joinMembers = "LEFT JOIN event_registrations er ON er.event_id=e.id ";
if($memberCol==='username'){
    $joinMembers .= "LEFT JOIN user_details m ON m.username=er.username";
} else {
    $joinMembers .= $memberCol ? "LEFT JOIN user_details m ON m.id=er.$memberCol" : "LEFT JOIN user_details m ON 1=0";
}
$eventsTable = mysqli_query($con,"
    SELECT e.*, COUNT(er.id) as reg_cnt, GROUP_CONCAT(DISTINCT m.fullname SEPARATOR ', ') as member_names
    FROM events e
    $joinMembers
    GROUP BY e.id
    ORDER BY e.event_date DESC
");
?>

<div class="twrap">
    <div class="thead">Events with Joined Members</div>
    <div class="tscroll">
    <table>
        <tr>
            <th>#</th><th>Title</th><th>Date</th><th>Seats</th><th>Joined</th><th>Members</th><th>Status</th><th>Actions</th>
        </tr>
        <?php $i=1; if($eventsTable && mysqli_num_rows($eventsTable)>0): while($e=mysqli_fetch_assoc($eventsTable)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($e['title']); ?></td>
            <td><?php echo date('d M Y',strtotime($e['event_date'])); ?><?php if($e['event_time']) echo '<br><small>'.date('h:i A',strtotime($e['event_time'])).'</small>'; ?></td>
            <td><?php echo $e['max_seats']>0 ? $e['max_seats'] : 'Unlimited'; ?></td>
            <td><?php echo $e['reg_cnt']; ?></td>
            <td><?php echo $e['member_names'] ?: '-'; ?></td>
            <td><span class="bx <?php echo $e['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($e['status']); ?></span></td>
            <td style="white-space:nowrap;">
                <a href="edit_event.php?id=<?php echo $e['id']; ?>" class="btn btn-b">Update</a>
                <a href="events.php?delete=<?php echo $e['id']; ?>" class="btn btn-r" onclick="return confirm('Delete this event?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" style="text-align:center;color:#888;padding:14px;">No events yet.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
