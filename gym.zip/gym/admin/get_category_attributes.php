<?php
// get_category_attributes.php — AJAX: returns attributes + values for a category
include "db.php";
header('Content-Type: application/json');

$category_id = (int)($_GET['category_id'] ?? 0);
if(!$category_id){ echo json_encode(['attributes' => []]); exit; }

// Default fallback values per attribute key.
$seed = [
    'weight_kg' => ['0.5 KG','1 KG','2 KG','5 KG','10 KG','20 KG','25 KG','50 KG'],
    'flavour'   => ['Chocolate','Vanilla','Strawberry','Mango','Unflavoured','Coffee'],
    'size'      => ['XS','S','M','L','XL','XXL'],
    'liter'     => ['500 ml','750 ml','1 L','1.5 L','2 L']
];

$res = mysqli_query($con,"
    SELECT at.id, at.attribute_name, at.attribute_key, at.unit_label, at.input_type
    FROM category_attributes ca
    JOIN product_attribute_types at ON at.id = ca.attribute_id
    WHERE ca.category_id='$category_id'
    ORDER BY at.id
");
$attributes = [];
while($row = mysqli_fetch_assoc($res)){
    // If this attribute has no values, seed defaults for this attribute only.
    $cnt_q = mysqli_query($con, "SELECT COUNT(*) as c FROM attribute_values WHERE attribute_id='{$row['id']}'");
    $cnt = $cnt_q ? (int)(mysqli_fetch_assoc($cnt_q)['c'] ?? 0) : 0;
    if($cnt === 0){
        $key = $row['attribute_key'] ?? '';
        if(isset($seed[$key])){
            $sort = 1;
            foreach($seed[$key] as $label){
                $label_esc = mysqli_real_escape_string($con, $label);
                mysqli_query($con, "INSERT INTO attribute_values (attribute_id, value_label, sort_order) VALUES ('{$row['id']}', '$label_esc', '$sort')");
                $sort++;
            }
        }
    }

    $vres = mysqli_query($con,"SELECT id, value_label FROM attribute_values WHERE attribute_id='{$row['id']}' ORDER BY sort_order, value_label");
    $row['values'] = [];
    while($vr = mysqli_fetch_assoc($vres)) $row['values'][] = $vr;
    $attributes[] = $row;
}
echo json_encode(['attributes' => $attributes]);
