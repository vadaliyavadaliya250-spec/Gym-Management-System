<?php
include "db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if(isset($_POST['update'])){
    $fullname = mysqli_real_escape_string($con,$_POST['fullname']);
    $age      = (int)$_POST['age'];
    $gender   = $_POST['gender'];
    $height   = mysqli_real_escape_string($con,$_POST['height']);
    $weight   = mysqli_real_escape_string($con,$_POST['weight']);
    $medical  = mysqli_real_escape_string($con,$_POST['medical']);
    $batch    = !empty($_POST['batch']) ? (int)$_POST['batch'] : null;
    $bval     = $batch ? "'$batch'" : "NULL";

    $photo_sql = "";
    if(isset($_FILES['photo']) && $_FILES['photo']['error']==0){
        $fname = time().'_'.basename($_FILES['photo']['name']);
        if(move_uploaded_file($_FILES['photo']['tmp_name'],"../uploads/".$fname)){
            $photo_sql = ",photo='uploads/$fname'";
        }
    }

    mysqli_query($con,"UPDATE user_details SET fullname='$fullname',age='$age',gender='$gender',
        height='$height',weight='$weight',medical='$medical',batch_id=$bval $photo_sql WHERE id='$id'");

    header("Location: members.php");
    exit();
}

$q         = mysqli_query($con,"SELECT * FROM user_details WHERE id='$id'");
$m         = mysqli_fetch_assoc($q);
$batches_q = mysqli_query($con,"SELECT * FROM batches");
?>
<?php include "header.php"; ?>

<?php if(!$m): ?>
    <div class="al al-d">Member not found.</div>
<?php else: ?>

<div class="pg-title">Edit Member</div>
<div class="card">
    <h2>Edit — <?php echo htmlspecialchars($m['fullname']); ?></h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="frow">
            <div class="fg"><label>Username</label><input type="text" value="<?php echo htmlspecialchars($m['username']); ?>" disabled style="background:#f5f5f5;"></div>
            <div class="fg"><label>Full Name</label><input type="text" name="fullname" value="<?php echo htmlspecialchars($m['fullname']); ?>" required></div>
            <div class="fg"><label>Age</label><input type="number" name="age" value="<?php echo $m['age']; ?>"></div>
            <div class="fg"><label>Gender</label>
                <select name="gender">
                    <option value="Male"   <?php echo $m['gender']=='Male'?'selected':''; ?>>Male</option>
                    <option value="Female" <?php echo $m['gender']=='Female'?'selected':''; ?>>Female</option>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg"><label>Height (ft)</label><input type="text" name="height" value="<?php echo htmlspecialchars($m['height']); ?>"></div>
            <div class="fg"><label>Weight (kg)</label><input type="text" name="weight" value="<?php echo htmlspecialchars($m['weight']); ?>"></div>
            <div class="fg"><label>Medical Issue</label><input type="text" name="medical" value="<?php echo htmlspecialchars($m['medical']); ?>"></div>
            <div class="fg"><label>Batch</label>
                <select name="batch">
                    <option value="">No Batch</option>
                    <?php while($b=mysqli_fetch_assoc($batches_q)): ?>
                    <option value="<?php echo $b['id']; ?>" <?php echo $m['batch_id']==$b['id']?'selected':''; ?>><?php echo htmlspecialchars($b['batch_name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg">
                <label>Photo (leave blank to keep current)</label>
                <input type="file" name="photo" accept="image/*">
                <?php if($m['photo']): ?>
                <div style="margin-top:6px;"><img src="../<?php echo htmlspecialchars($m['photo']); ?>" style="width:50px;height:50px;border-radius:50%;object-fit:cover;"></div>
                <?php endif; ?>
            </div>
        </div>
        <button type="submit" name="update" class="btn btn-o">💾 Update Member</button>
        <a href="members.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
    </form>
</div>

<?php endif; ?>
<?php include "footer.php"; ?>