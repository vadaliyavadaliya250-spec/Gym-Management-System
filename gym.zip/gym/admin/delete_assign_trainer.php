<?php
include "db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id > 0) mysqli_query($con,"DELETE FROM assign_trainer WHERE id='$id'");
header("Location: assign_trainer.php"); exit();
