<?php
$con = mysqli_connect("localhost","root","","gym");
if(!$con){ die("Database connection failed: ".mysqli_connect_error()); }
?>
