<?php
include "db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if(isset($_POST['update'])){
    $batch = !empty($_POST['batch']) ? (int)$_POST['batch'] : null;
    $bval  = $batch ? "'$batch'" : "NULL";

    // Keep batch_members table in sync for trainer pages
    mysqli_query($con,"DELETE FROM batch_members WHERE member_id='$id'");
    mysqli_query($con,"UPDATE user_details SET batch_id=$bval WHERE id='$id'");
    if($batch){
        mysqli_query($con,"INSERT INTO batch_members(batch_id,member_id,joined_at) VALUES('$batch','$id',NOW())");
    }

    header("Location: assign_member_batch.php");
    exit();
}

$q         = mysqli_query($con,"SELECT * FROM user_details WHERE id='$id'");
$m         = mysqli_fetch_assoc($q);
$batches_q = mysqli_query($con,"SELECT * FROM batches");
?>
<?php include "header.php"; ?>

<?php if(!$m): ?>
    <div class="al al-d">Member not found.</div>
<?php else: ?>

<div class="pg-title">Change Member Batch</div>
<div class="card">
    <h2>Change Batch — <?php echo htmlspecialchars($m['fullname']); ?></h2>
    <form method="POST">
        <div class="fg" style="max-width:320px;">
            <label>Select New Batch</label>
            <select name="batch">
                <option value="">No Batch</option>
                <?php while($b=mysqli_fetch_assoc($batches_q)): ?>
                <option value="<?php echo $b['id']; ?>" <?php echo $m['batch_id']==$b['id']?'selected':''; ?>><?php echo htmlspecialchars($b['batch_name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <br>
        <button type="submit" name="update" class="btn btn-o">💾 Update Batch</button>
        <a href="assign_member_batch.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
    </form>
</div>

<?php endif; ?>
<?php include "footer.php"; ?>
