<?php include "header.php"; ?>

<?php
$q_members  = mysqli_query($con,"SELECT COUNT(*) as c FROM user_details");
$members    = mysqli_fetch_assoc($q_members)['c'];

$q_trainers = mysqli_query($con,"SELECT COUNT(*) as c FROM trainers WHERE status='active'");
$trainers   = mysqli_fetch_assoc($q_trainers)['c'];

$q_batches  = mysqli_query($con,"SELECT COUNT(*) as c FROM batches");
$batches    = mysqli_fetch_assoc($q_batches)['c'];

$q_pending  = mysqli_query($con,"SELECT COUNT(*) as c FROM membership_purchases WHERE status='pending'");
$pending    = mysqli_fetch_assoc($q_pending)['c'];

$q_approved = mysqli_query($con,"SELECT COUNT(*) as c FROM membership_purchases WHERE status='approved'");
$approved   = mysqli_fetch_assoc($q_approved)['c'];

$q_personal = mysqli_query($con,"SELECT COUNT(*) as c FROM trainers WHERE type='personal' AND status='active'");
$personal   = mysqli_fetch_assoc($q_personal)['c'];

$q_batch_t  = mysqli_query($con,"SELECT COUNT(*) as c FROM trainers WHERE type='batch' AND status='active'");
$batch_t    = mysqli_fetch_assoc($q_batch_t)['c'];

// Recent purchase requests
$recent = mysqli_query($con,"SELECT * FROM membership_purchases ORDER BY id DESC LIMIT 5");

// Recent members
$new_members = mysqli_query($con,"SELECT * FROM user_details ORDER BY id DESC LIMIT 5");
?>

<div class="pg-title">Dashboard</div>

<div class="sc-row">
    <div class="sc"><div class="n"><?php echo $members; ?></div><div class="l">👥 Total Members</div></div>
    <div class="sc g"><div class="n"><?php echo $trainers; ?></div><div class="l">🏋 Active Trainers</div></div>
    <div class="sc b"><div class="n"><?php echo $batches; ?></div><div class="l">📦 Batches</div></div>
    <div class="sc p"><div class="n"><?php echo $approved; ?></div><div class="l">✅ Approved Members</div></div>
    <div class="sc o"><div class="n"><?php echo $pending; ?></div><div class="l">⏳ Pending Requests</div></div>
</div>

<div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:22px;">
    <div class="sc" style="flex:1;min-width:140px;text-align:center;">
        <div class="n"><?php echo $personal; ?></div>
        <div class="l">Personal Trainers</div>
    </div>
    <div class="sc b" style="flex:1;min-width:140px;text-align:center;">
        <div class="n"><?php echo $batch_t; ?></div>
        <div class="l">Batch Trainers</div>
    </div>
</div>

<div style="display:flex;gap:20px;flex-wrap:wrap;">
    <div class="twrap" style="flex:1;min-width:300px;">
        <div class="thead">📋 Recent Purchase Requests</div>
        <div class="tscroll">
        <table>
            <tr><th>Username</th><th>Plan</th><th>Amount</th><th>Status</th><th>Date</th></tr>
            <?php if(mysqli_num_rows($recent)>0): while($r=mysqli_fetch_assoc($recent)): ?>
            <tr>
                <td><?php echo htmlspecialchars($r['username']); ?></td>
                <td><?php echo htmlspecialchars($r['plan_name']); ?></td>
                <td>₹<?php echo $r['amount']; ?></td>
                <td>
                    <span class="bx <?php echo $r['status']=='approved'?'bx-s':($r['status']=='cancelled'?'bx-d':'bx-w'); ?>">
                        <?php echo ucfirst($r['status']); ?>
                    </span>
                </td>
                <td><?php echo date('d M Y',strtotime($r['purchase_date'])); ?></td>
            </tr>
            <?php endwhile; else: ?>
            <tr><td colspan="5" style="text-align:center;color:#888;padding:18px;">No requests yet.</td></tr>
            <?php endif; ?>
        </table>
        </div>
    </div>

    <div class="twrap" style="flex:1;min-width:300px;">
        <div class="thead">👥 Recently Added Members</div>
        <div class="tscroll">
        <table>
            <tr><th>Username</th><th>Full Name</th><th>Gender</th><th>Age</th></tr>
            <?php if(mysqli_num_rows($new_members)>0): while($r=mysqli_fetch_assoc($new_members)): ?>
            <tr>
                <td><?php echo htmlspecialchars($r['username']); ?></td>
                <td><?php echo htmlspecialchars($r['fullname']); ?></td>
                <td><?php echo $r['gender']; ?></td>
                <td><?php echo $r['age']; ?></td>
            </tr>
            <?php endwhile; else: ?>
            <tr><td colspan="4" style="text-align:center;color:#888;padding:18px;">No members yet.</td></tr>
            <?php endif; ?>
        </table>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
