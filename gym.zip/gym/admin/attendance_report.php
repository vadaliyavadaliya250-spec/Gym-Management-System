<?php include "header.php"; ?>

<?php
$date_filter  = isset($_GET['date'])  ? $_GET['date']  : '';
$batch_filter = isset($_GET['batch']) ? (int)$_GET['batch'] : 0;

$where = "WHERE 1=1";
if($date_filter)  $where .= " AND a.date='$date_filter'";
if($batch_filter) $where .= " AND a.batch_id='$batch_filter'";

$q = mysqli_query($con,"SELECT a.*,ud.fullname,b.batch_name FROM attendance a
    JOIN user_details ud ON a.member_id=ud.id
    LEFT JOIN batches b ON a.batch_id=b.id
    $where ORDER BY a.date DESC");

$batches_q = mysqli_query($con,"SELECT * FROM batches");
?>

<div class="pg-title">Attendance Report</div>

<div class="card">
    <h2>Filter</h2>
    <form method="GET" style="display:flex;gap:14px;align-items:flex-end;flex-wrap:wrap;">
        <div class="fg" style="min-width:160px;margin-bottom:0;">
            <label>Date</label>
            <input type="date" name="date" value="<?php echo $date_filter; ?>">
        </div>
        <div class="fg" style="min-width:180px;margin-bottom:0;">
            <label>Batch</label>
            <select name="batch">
                <option value="0">All Batches</option>
                <?php while($b=mysqli_fetch_assoc($batches_q)): ?>
                <option value="<?php echo $b['id']; ?>" <?php echo $b['id']==$batch_filter?'selected':''; ?>><?php echo htmlspecialchars($b['batch_name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-b">Filter</button>
        <a href="attendance_report.php" class="btn btn-dk">Clear</a>
    </form>
</div>

<div class="twrap">
    <div class="thead">📊 Attendance Records</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Member</th><th>Batch</th><th>Date</th><th>Status</th></tr>
        <?php $i=1; if(mysqli_num_rows($q)>0): while($r=mysqli_fetch_assoc($q)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['fullname']); ?></td>
            <td><?php echo $r['batch_name'] ? htmlspecialchars($r['batch_name']) : '-'; ?></td>
            <td><?php echo date('d M Y',strtotime($r['date'])); ?></td>
            <td><span class="bx <?php echo strtolower($r['status'])=='present'?'bx-s':'bx-d'; ?>"><?php echo $r['status']; ?></span></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="5" style="text-align:center;color:#888;padding:20px;">No records found.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
