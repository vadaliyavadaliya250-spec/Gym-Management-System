<?php
session_start();
// If already logged in go to dashboard, else to login page
if(isset($_SESSION['admin'])){
    header("Location: dashboard.php");
} else {
    header("Location: ../gym/admin.php");
}
exit;
