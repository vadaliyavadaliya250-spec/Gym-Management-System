<?php
include "db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id > 0){
    mysqli_query($con,"DELETE FROM batch_members WHERE member_id='$id'");
    mysqli_query($con,"UPDATE user_details SET batch_id=NULL WHERE id='$id'");
}
header("Location: assign_member_batch.php"); exit();
