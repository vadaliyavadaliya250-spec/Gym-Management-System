<?php include "header.php"; ?>

<?php
$success = $error = '';

if(isset($_POST['assign'])){
    $member = (int)$_POST['member'];
    $batch  = (int)$_POST['batch'];

    $capRes  = mysqli_query($con,"SELECT capacity FROM batches WHERE id='$batch'");
    $capData = mysqli_fetch_assoc($capRes);
    $capacity = $capData['capacity'];

    $cntRes  = mysqli_query($con,"SELECT COUNT(*) as c FROM user_details WHERE batch_id='$batch'");
    $current = mysqli_fetch_assoc($cntRes)['c'];

    if($current >= $capacity){
        $error = "Batch is full! Cannot add more members (capacity: $capacity).";
    } else {
        // Keep batch_members table in sync for trainer pages
        mysqli_query($con,"DELETE FROM batch_members WHERE member_id='$member'");
        mysqli_query($con,"UPDATE user_details SET batch_id='$batch' WHERE id='$member'");
        mysqli_query($con,"INSERT INTO batch_members(batch_id,member_id,joined_at) VALUES('$batch','$member',NOW())");
        $success = "Member assigned to batch successfully!";
    }
}

$members_q = mysqli_query($con,"SELECT * FROM user_details ORDER BY fullname");
$batches_q = mysqli_query($con,"SELECT b.*,t.name as trainer_name FROM batches b LEFT JOIN trainers t ON b.trainer_id=t.id");
$list      = mysqli_query($con,"SELECT ud.*,b.batch_name FROM user_details ud LEFT JOIN batches b ON ud.batch_id=b.id ORDER BY ud.fullname");
?>

<div class="pg-title">Assign Members to Batches</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if($error):   ?><div class="al al-d">⚠ <?php echo $error; ?></div><?php endif; ?>

<div class="card">
    <h2>Assign Member to Batch</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Select Member</label>
                <select name="member" required>
                    <option value="">-- Select Member --</option>
                    <?php while($m=mysqli_fetch_assoc($members_q)): ?>
                    <option value="<?php echo $m['id']; ?>"><?php echo htmlspecialchars($m['fullname']); ?> (<?php echo htmlspecialchars($m['username']); ?>)</option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="fg"><label>Select Batch</label>
                <select name="batch" required>
                    <option value="">-- Select Batch --</option>
                    <?php while($b=mysqli_fetch_assoc($batches_q)): ?>
                    <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['batch_name']); ?> — <?php echo htmlspecialchars($b['trainer_name']??''); ?> (Cap: <?php echo $b['capacity']; ?>)</option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>
        <button type="submit" name="assign" class="btn btn-o">Assign to Batch</button>
    </form>
</div>

<div class="twrap">
    <div class="thead">➕ Member Batch List</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Member</th><th>Username</th><th>Batch</th><th>Action</th></tr>
        <?php if(mysqli_num_rows($list)>0): while($r=mysqli_fetch_assoc($list)): ?>
        <tr>
            <td><?php echo $r['id']; ?></td>
            <td><?php echo htmlspecialchars($r['fullname']); ?></td>
            <td><?php echo htmlspecialchars($r['username']); ?></td>
            <td><?php echo $r['batch_name'] ? '<span class="bx bx-i">'.htmlspecialchars($r['batch_name']).'</span>' : '<span style="color:#aaa;">No Batch</span>'; ?></td>
            <td style="white-space:nowrap;">
                <a href="edit_member_batch.php?id=<?php echo $r['id']; ?>" class="btn btn-b">Change Batch</a>
                <a href="remove_member_batch.php?id=<?php echo $r['id']; ?>" class="btn btn-r" onclick="return confirm('Remove from batch?')">Remove</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="5" style="text-align:center;color:#888;padding:20px;">No members found.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
