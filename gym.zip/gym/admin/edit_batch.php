<?php
include "db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if(isset($_POST['update_batch'])){
    $name     = mysqli_real_escape_string($con,$_POST['batch_name']);
    $trainer  = (int)$_POST['trainer'];
    $start    = $_POST['start'];
    $end      = $_POST['end'];
    $capacity = (int)$_POST['capacity'];
    $status   = $_POST['status'];

    mysqli_query($con,"UPDATE batches SET batch_name='$name',trainer_id='$trainer',start_time='$start',end_time='$end',capacity='$capacity',status='$status' WHERE id='$id'");

    header("Location: batches.php");
    exit();
}

$q = mysqli_query($con,"SELECT * FROM batches WHERE id='$id'");
$b = mysqli_fetch_assoc($q);
$trainers = mysqli_query($con,"SELECT * FROM trainers WHERE type='batch' AND status='active'");
?>
<?php include "header.php"; ?>

<?php if(!$b): ?>
    <div class="al al-d">Batch not found.</div>
<?php else: ?>

<div class="pg-title">Edit Batch</div>
<div class="card">
    <h2>Edit — <?php echo htmlspecialchars($b['batch_name']); ?></h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Batch Name</label><input type="text" name="batch_name" value="<?php echo htmlspecialchars($b['batch_name']); ?>" required></div>
            <div class="fg"><label>Trainer</label>
                <select name="trainer">
                    <option value="">Select Trainer</option>
                    <?php while($t=mysqli_fetch_assoc($trainers)): ?>
                    <option value="<?php echo $t['id']; ?>" <?php echo $t['id']==$b['trainer_id']?'selected':''; ?>><?php echo htmlspecialchars($t['name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="fg"><label>Start Time</label><input type="time" name="start" value="<?php echo $b['start_time']; ?>"></div>
            <div class="fg"><label>End Time</label><input type="time" name="end" value="<?php echo $b['end_time']; ?>"></div>
        </div>
        <div class="frow">
            <div class="fg"><label>Capacity</label><input type="number" name="capacity" value="<?php echo $b['capacity']; ?>" min="1"></div>
            <div class="fg"><label>Status</label>
                <select name="status">
                    <option value="active"   <?php echo $b['status']=='active'?'selected':''; ?>>Active</option>
                    <option value="inactive" <?php echo $b['status']=='inactive'?'selected':''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <button type="submit" name="update_batch" class="btn btn-o">💾 Update Batch</button>
        <a href="batches.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
    </form>
</div>

<?php endif; ?>
<?php include "footer.php"; ?>