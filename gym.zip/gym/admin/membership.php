<?php include "header.php"; ?>

<?php
$success = '';
if(isset($_POST['add'])){
    $name     = mysqli_real_escape_string($con,$_POST['plan_name']);
    $duration = (int)$_POST['duration'];
    $price    = (float)$_POST['price'];
    $desc     = mysqli_real_escape_string($con,$_POST['description']);
    $status   = $_POST['status'];
    $features = isset($_POST['features']) ? implode(",",$_POST['features']) : "";
    mysqli_query($con,"INSERT INTO membership_plans(plan_name,duration,price,description,features,status) VALUES('$name','$duration','$price','$desc','$features','$status')");
    $success = "Membership plan added!";
}

$res = mysqli_query($con,"SELECT * FROM membership_plans ORDER BY id DESC");
$all_features = ["Gym Equipment Access","Cardio Section Access","Weight Training","Locker Facility","Free Diet Plan","Personal Trainer","Group Classes","Steam Bath"];
?>

<div class="pg-title">Membership Plans</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>

<div class="card">
    <h2>Add Membership Plan</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Plan Name</label><input type="text" name="plan_name" placeholder="e.g. Monthly Plan" required></div>
            <div class="fg"><label>Duration (Days)</label><input type="number" name="duration" placeholder="30" required></div>
            <div class="fg"><label>Price (₹)</label><input type="number" name="price" placeholder="999" required></div>
            <div class="fg"><label>Status</label>
                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg full-w"><label>Description</label><textarea name="description" rows="3" placeholder="Plan description..."></textarea></div>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:6px;">Features</label>
            <div class="feat-grid">
                <?php foreach($all_features as $f): ?>
                <label><input type="checkbox" name="features[]" value="<?php echo $f; ?>"> <?php echo $f; ?></label>
                <?php endforeach; ?>
            </div>
        </div>
        <button type="submit" name="add" class="btn btn-o">+ Add Plan</button>
    </form>
</div>

<div class="twrap">
    <div class="thead">💳 All Membership Plans</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Plan Name</th><th>Duration</th><th>Price</th><th>Features</th><th>Status</th><th>Action</th></tr>
        <?php if(mysqli_num_rows($res)>0): while($m=mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?php echo $m['id']; ?></td>
            <td><?php echo htmlspecialchars($m['plan_name']); ?></td>
            <td><?php echo $m['duration']; ?> Days</td>
            <td>₹<?php echo number_format($m['price'],2); ?></td>
            <td><?php foreach(explode(",",$m['features']) as $f) echo "✔ ".htmlspecialchars(trim($f))."<br>"; ?></td>
            <td><span class="bx <?php echo $m['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($m['status']); ?></span></td>
            <td style="white-space:nowrap;">
                <a href="membership_edit.php?id=<?php echo $m['id']; ?>" class="btn btn-b">Edit</a>
                <a href="membership_delete.php?id=<?php echo $m['id']; ?>" class="btn btn-r" onclick="return confirm('Delete this plan?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="7" style="text-align:center;color:#888;padding:20px;">No plans yet.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
