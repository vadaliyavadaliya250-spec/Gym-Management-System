<?php include "header.php"; ?>

<?php
$success = $error = '';

if(isset($_POST['add_member'])){
    $username = mysqli_real_escape_string($con,$_POST['username']);
    $fullname = mysqli_real_escape_string($con,$_POST['fullname']);
    $age      = (int)$_POST['age'];
    $gender   = $_POST['gender'];
    $height   = mysqli_real_escape_string($con,$_POST['height']);
    $weight   = mysqli_real_escape_string($con,$_POST['weight']);
    $medical  = mysqli_real_escape_string($con,$_POST['medical']);
    $batch    = !empty($_POST['batch']) ? (int)$_POST['batch'] : 'NULL';

    // Check if username exists in user_table
    $chk = mysqli_query($con,"SELECT id FROM user_table WHERE username='$username'");
    if(mysqli_num_rows($chk) == 0){
        $error = "Username does not exist in user accounts. Member must register first.";
    } else {
        $path = 'NULL';
        if(isset($_FILES['photo']) && $_FILES['photo']['error']==0){
            $fname = time().'_'.basename($_FILES['photo']['name']);
            if(move_uploaded_file($_FILES['photo']['tmp_name'],"../uploads/".$fname)){
                $path = "'uploads/$fname'";
            }
        }
        $bval = ($batch === 'NULL') ? 'NULL' : "'$batch'";
        mysqli_query($con,"INSERT INTO user_details(username,fullname,age,gender,height,weight,medical,photo,batch_id)
            VALUES('$username','$fullname','$age','$gender','$height','$weight','$medical',$path,$bval)");
        $success = "Member added successfully!";
    }
}

$res = mysqli_query($con,"SELECT ud.*,b.batch_name FROM user_details ud LEFT JOIN batches b ON ud.batch_id=b.id ORDER BY ud.id DESC");
$batches_q = mysqli_query($con,"SELECT * FROM batches");
?>

<div class="pg-title">Members</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if($error):   ?><div class="al al-d">⚠ <?php echo $error; ?></div><?php endif; ?>

<div class="card">
    <h2>Add Member</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="frow">
            <div class="fg"><label>Username (must exist in user accounts)</label><input type="text" name="username" required></div>
            <div class="fg"><label>Full Name</label><input type="text" name="fullname" required></div>
            <div class="fg"><label>Age</label><input type="number" name="age" min="1"></div>
            <div class="fg"><label>Gender</label>
                <select name="gender">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg"><label>Height (ft)</label><input type="text" name="height" placeholder="e.g. 5.8"></div>
            <div class="fg"><label>Weight (kg)</label><input type="text" name="weight" placeholder="e.g. 70"></div>
            <div class="fg"><label>Medical Issue</label><input type="text" name="medical" placeholder="None"></div>
            <div class="fg"><label>Assign Batch (optional)</label>
                <select name="batch">
                    <option value="">No Batch</option>
                    <?php while($b=mysqli_fetch_assoc($batches_q)): ?>
                    <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['batch_name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg"><label>Photo</label><input type="file" name="photo" accept="image/*"></div>
        </div>
        <button type="submit" name="add_member" class="btn btn-o">+ Add Member</button>
    </form>
</div>

<div class="twrap">
    <div class="thead">👥 All Members</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Photo</th><th>Username</th><th>Full Name</th><th>Age</th><th>Gender</th><th>Height</th><th>Weight</th><th>Medical</th><th>Batch</th><th>Action</th></tr>
        <?php if(mysqli_num_rows($res)>0): while($m=mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?php echo $m['id']; ?></td>
            <td>
                <?php if($m['photo']): ?>
                <img src="../<?php echo htmlspecialchars($m['photo']); ?>" style="width:44px;height:44px;border-radius:50%;object-fit:cover;">
                <?php else: ?>
                <div style="width:44px;height:44px;border-radius:50%;background:#eee;display:inline-flex;align-items:center;justify-content:center;font-size:18px;">👤</div>
                <?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($m['username']); ?></td>
            <td><?php echo htmlspecialchars($m['fullname']); ?></td>
            <td><?php echo $m['age']; ?></td>
            <td><?php echo $m['gender']; ?></td>
            <td><?php echo $m['height'] ? $m['height'].' ft' : '-'; ?></td>
            <td><?php echo $m['weight'] ? $m['weight'].' kg' : '-'; ?></td>
            <td><?php echo $m['medical'] ? htmlspecialchars($m['medical']) : '-'; ?></td>
            <td><?php echo $m['batch_name'] ? '<span class="bx bx-i">'.htmlspecialchars($m['batch_name']).'</span>' : '-'; ?></td>
            <td style="white-space:nowrap;">
                <a href="edit_member.php?id=<?php echo $m['id']; ?>" class="btn btn-b">Edit</a>
                <a href="delete_member.php?id=<?php echo $m['id']; ?>" class="btn btn-r" onclick="return confirm('Delete this member?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="11" style="text-align:center;color:#888;padding:20px;">No members found.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
