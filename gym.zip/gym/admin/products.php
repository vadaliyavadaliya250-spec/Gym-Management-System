<?php include "header.php"; ?>
<?php
// ── products.php  (admin) ──────────────────────────────────────────────────
// Handles: list all products/variants, delete, quick stats

// Delete product
if(isset($_GET['delete'])){
    $did = (int)$_GET['delete'];
    mysqli_query($con,"DELETE FROM products_new WHERE id='$did'");
    if (ob_get_length()) { ob_clean(); }
    header("Location: products.php?msg=deleted"); exit();
}

$msg = $_GET['msg'] ?? '';

// Filters
$cat_filter = (int)($_GET['cat'] ?? 0);
$search     = mysqli_real_escape_string($con, trim($_GET['q'] ?? ''));

$where = "WHERE 1=1";
if($cat_filter) $where .= " AND p.category_id='$cat_filter'";
if($search)     $where .= " AND p.product_name LIKE '%$search%'";

$res = mysqli_query($con,"
    SELECT p.*, pc.category_name,
           COUNT(pv.id) AS variant_count,
           COALESCE(SUM(pv.stock),0) AS total_stock,
           MIN(pv.final_price) AS min_price,
           MAX(pv.final_price) AS max_price
    FROM products_new p
    JOIN product_categories pc ON pc.id = p.category_id
    LEFT JOIN product_variants pv ON pv.product_id = p.id
    $where
    GROUP BY p.id
    ORDER BY p.created_at DESC
");

$cats = mysqli_query($con,"SELECT * FROM product_categories WHERE status='active' ORDER BY category_name");

// Stats
$st = mysqli_fetch_assoc(mysqli_query($con,"
    SELECT COUNT(DISTINCT p.id) AS total_products,
           COALESCE(SUM(pv.stock),0) AS total_stock,
           SUM(CASE WHEN pv.stock=0 THEN 1 ELSE 0 END) AS out_stock,
           SUM(CASE WHEN pv.stock>0 AND pv.stock<=5 THEN 1 ELSE 0 END) AS low_stock
    FROM products_new p LEFT JOIN product_variants pv ON pv.product_id=p.id
"));
?>

<div class="pg-title">🛍 Products</div>

<?php if($msg=='deleted'): ?><div class="al al-s">✅ Product deleted.</div><?php endif; ?>

<!-- Stats -->
<div class="sc-row">
    <div class="sc"><div class="n"><?php echo $st['total_products']; ?></div><div class="l">Total Products</div></div>
    <div class="sc g"><div class="n"><?php echo $st['total_stock']; ?></div><div class="l">Total Stock Units</div></div>
    <div class="sc o"><div class="n"><?php echo $st['low_stock']; ?></div><div class="l">Low Stock (≤5)</div></div>
    <div class="sc" style="border-left-color:#e74c3c"><div class="n"><?php echo $st['out_stock']; ?></div><div class="l">Out of Stock</div></div>
</div>

<!-- Toolbar -->
<form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:16px;">
    <input type="text" name="q" placeholder="Search product..." value="<?php echo htmlspecialchars($_GET['q']??''); ?>"
           style="padding:8px 12px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;width:220px;">
    <select name="cat" style="padding:8px 12px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;">
        <option value="">All Categories</option>
        <?php while($c=mysqli_fetch_assoc($cats)): ?>
        <option value="<?php echo $c['id']; ?>" <?php echo $cat_filter==$c['id']?'selected':''; ?>><?php echo htmlspecialchars($c['category_name']); ?></option>
        <?php endwhile; ?>
    </select>
    <button type="submit" class="btn btn-dk">🔍 Filter</button>
    <a href="products.php" class="btn" style="background:#eee;color:#333;">Reset</a>
    <a href="add_product.php" class="btn btn-o" style="margin-left:auto;">+ Add Product</a>
</form>

<!-- Table -->
<div class="twrap">
    <div class="thead">📦 All Products</div>
    <div class="tscroll">
    <table>
        <tr>
            <th>#</th><th>Image</th><th>Product Name</th><th>Category</th>
            <th>Variants</th><th>Price Range</th><th>Total Stock</th><th>Action</th>
        </tr>
        <?php $i=1; if(mysqli_num_rows($res)>0): while($r=mysqli_fetch_assoc($res)): ?>
        <?php
            $sc = $r['total_stock']==0 ? 'color:#e74c3c;font-weight:700' : ($r['total_stock']<=5 ? 'color:#e67e22;font-weight:700' : 'color:#27ae60;font-weight:700');
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td>
                <?php if($r['image']): ?>
                <img src="../uploads/products/<?php echo htmlspecialchars($r['image']); ?>" style="width:46px;height:46px;object-fit:cover;border-radius:6px;">
                <?php else: ?>
                <div style="width:46px;height:46px;background:#eee;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;">📦</div>
                <?php endif; ?>
            </td>
            <td><strong><?php echo htmlspecialchars($r['product_name']); ?></strong></td>
            <td><span class="bx bx-i"><?php echo htmlspecialchars($r['category_name']); ?></span></td>
            <td style="text-align:center;"><?php echo $r['variant_count']; ?></td>
            <td>
                <?php if($r['min_price']==$r['max_price']): ?>
                    ₹<?php echo number_format($r['min_price'],2); ?>
                <?php else: ?>
                    ₹<?php echo number_format($r['min_price'],2); ?> – ₹<?php echo number_format($r['max_price'],2); ?>
                <?php endif; ?>
            </td>
            <td style="<?php echo $sc; ?>">
                <?php echo $r['total_stock']==0 ? 'Out of Stock' : $r['total_stock'].' units'; ?>
            </td>
            <td style="white-space:nowrap;">
                <a href="view_product.php?id=<?php echo $r['id']; ?>" class="btn btn-b" style="font-size:12px;padding:5px 10px;">👁 View</a>
                <a href="edit_product.php?id=<?php echo $r['id']; ?>" class="btn btn-w" style="font-size:12px;padding:5px 10px;">✏ Edit</a>
                <a href="manage_stock.php?id=<?php echo $r['id']; ?>" class="btn btn-g" style="font-size:12px;padding:5px 10px;">📦 Stock</a>
                <a href="?delete=<?php echo $r['id']; ?>" class="btn btn-r" style="font-size:12px;padding:5px 10px;" onclick="return confirm('Delete this product and all its variants?')">🗑 Del</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" style="text-align:center;color:#888;padding:30px;">
            No products found. <a href="add_product.php" style="color:#ff6600;">Add your first product →</a>
        </td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
