<?php
// PHP LOGIC FIRST — before any HTML/include that outputs HTML
include "db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if(isset($_POST['update'])){
    $name     = mysqli_real_escape_string($con, $_POST['plan_name']);
    $duration = (int)$_POST['duration'];
    $price    = (float)$_POST['price'];
    $desc     = mysqli_real_escape_string($con, $_POST['description']);
    $status   = $_POST['status'];
    $features = isset($_POST['features']) ? implode(",", $_POST['features']) : "";

    mysqli_query($con,"UPDATE membership_plans SET
        plan_name='$name',
        duration='$duration',
        price='$price',
        description='$desc',
        features='$features',
        status='$status'
        WHERE id='$id'");

    header("Location: membership.php");
    exit();
}

$q            = mysqli_query($con,"SELECT * FROM membership_plans WHERE id='$id'");
$d            = mysqli_fetch_assoc($q);
$sel_features = $d ? explode(",", $d['features']) : [];
$all_features = [
    "Gym Equipment Access",
    "Cardio Section Access",
    "Weight Training",
    "Locker Facility",
    "Free Diet Plan",
    "Personal Trainer",
    "Group Classes",
    "Steam Bath"
];
?>
<?php include "header.php"; ?>

<?php if(!$d): ?>
    <div class="al al-d">Plan not found. <a href="membership.php">Go back</a></div>
<?php else: ?>

<div class="pg-title">Edit Membership Plan</div>
<div class="card">
    <h2>Edit — <?php echo htmlspecialchars($d['plan_name']); ?></h2>
    <form method="POST">
        <div class="frow">
            <div class="fg">
                <label>Plan Name</label>
                <input type="text" name="plan_name" value="<?php echo htmlspecialchars($d['plan_name']); ?>" required>
            </div>
            <div class="fg">
                <label>Duration (Days)</label>
                <input type="number" name="duration" value="<?php echo $d['duration']; ?>" required>
            </div>
            <div class="fg">
                <label>Price (₹)</label>
                <input type="number" name="price" value="<?php echo $d['price']; ?>" step="0.01" required>
            </div>
            <div class="fg">
                <label>Status</label>
                <select name="status">
                    <option value="active"   <?php echo $d['status']=='active'  ?'selected':''; ?>>Active</option>
                    <option value="inactive" <?php echo $d['status']=='inactive'?'selected':''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg full-w">
                <label>Description</label>
                <textarea name="description" rows="3"><?php echo htmlspecialchars($d['description']); ?></textarea>
            </div>
        </div>
        <div style="margin-bottom:18px;">
            <label style="font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:8px;">Features</label>
            <div class="feat-grid">
                <?php foreach($all_features as $f): ?>
                <label>
                    <input type="checkbox" name="features[]" value="<?php echo $f; ?>"
                        <?php echo in_array(trim($f), array_map('trim',$sel_features)) ? 'checked' : ''; ?>>
                    <?php echo $f; ?>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <button type="submit" name="update" class="btn btn-o">💾 Update Plan</button>
        <a href="membership.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
    </form>
</div>

<?php endif; ?>
<?php include "footer.php"; ?>