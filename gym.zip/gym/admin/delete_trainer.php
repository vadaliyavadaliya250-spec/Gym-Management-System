<?php
include "db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id > 0) mysqli_query($con,"DELETE FROM trainers WHERE id='$id'");
header("Location: trainers.php"); exit();
