<?php include "header.php"; ?>

<?php
$success = $error = '';

if(isset($_POST['assign'])){
    $member_id  = (int)$_POST['member'];
    $trainer_id = (int)$_POST['trainer'];
    $chk = mysqli_query($con,"SELECT * FROM assign_trainer WHERE member_id='$member_id'");
    if(mysqli_num_rows($chk) > 0){
        $error = "This member already has a trainer assigned. Edit the existing assignment.";
    } else {
        mysqli_query($con,"INSERT INTO assign_trainer(member_id,trainer_id) VALUES('$member_id','$trainer_id')");
        $success = "Trainer assigned successfully!";
    }
}

$members  = mysqli_query($con,"SELECT ud.id,ud.fullname,mp.plan_name FROM user_details ud JOIN membership_purchases mp ON ud.username=mp.username WHERE mp.status='approved' GROUP BY ud.id");
$trainers = mysqli_query($con,"SELECT * FROM trainers WHERE status='active' AND type='personal'");
$assigns  = mysqli_query($con,"SELECT at.id,ud.fullname as member_name,t.name as trainer_name FROM assign_trainer at JOIN user_details ud ON at.member_id=ud.id JOIN trainers t ON at.trainer_id=t.id");
?>

<div class="pg-title">Assign Personal Trainer</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if($error):   ?><div class="al al-d">⚠ <?php echo $error; ?></div><?php endif; ?>

<div class="card">
    <h2>Assign Trainer to Member</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Select Member (Approved)</label>
                <select name="member" required>
                    <option value="">-- Select Member --</option>
                    <?php while($m=mysqli_fetch_assoc($members)): ?>
                    <option value="<?php echo $m['id']; ?>"><?php echo htmlspecialchars($m['fullname']); ?> — <?php echo $m['plan_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="fg"><label>Select Personal Trainer</label>
                <select name="trainer" required>
                    <option value="">-- Select Trainer --</option>
                    <?php while($t=mysqli_fetch_assoc($trainers)): ?>
                    <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['name']); ?> — <?php echo htmlspecialchars($t['specialization']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>
        <button type="submit" name="assign" class="btn btn-o">Assign Trainer</button>
    </form>
</div>

<div class="twrap">
    <div class="thead">🔗 Assigned Trainers</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Member</th><th>Trainer</th><th>Action</th></tr>
        <?php if(mysqli_num_rows($assigns)>0): while($a=mysqli_fetch_assoc($assigns)): ?>
        <tr>
            <td><?php echo $a['id']; ?></td>
            <td><?php echo htmlspecialchars($a['member_name']); ?></td>
            <td><?php echo htmlspecialchars($a['trainer_name']); ?></td>
            <td style="white-space:nowrap;">
                <a href="edit_assign_trainer.php?id=<?php echo $a['id']; ?>" class="btn btn-b">Edit</a>
                <a href="delete_assign_trainer.php?id=<?php echo $a['id']; ?>" class="btn btn-r" onclick="return confirm('Remove assignment?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="4" style="text-align:center;color:#888;padding:20px;">No assignments yet.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
