<?php include "header.php"; ?>
<?php
$id = (int)($_GET['id'] ?? 0);
$res = mysqli_query($con,"SELECT p.*, pc.category_name FROM products_new p JOIN product_categories pc ON pc.id=p.category_id WHERE p.id='$id'");
$p = mysqli_fetch_assoc($res);
if(!$p){ echo "<div class='al al-d'>Product not found.</div>"; include "footer.php"; exit(); }

$variants = mysqli_query($con,"
    SELECT pv.*,
           GROUP_CONCAT(CONCAT(at.attribute_name,': ',av.value_label) ORDER BY at.id SEPARATOR ' | ') AS attr_detail
    FROM product_variants pv
    LEFT JOIN variant_attributes va ON va.variant_id=pv.id
    LEFT JOIN attribute_values av ON av.id=va.value_id
    LEFT JOIN product_attribute_types at ON at.id=va.attribute_id
    WHERE pv.product_id='$id'
    GROUP BY pv.id ORDER BY pv.id
");
?>

<div class="pg-title">👁 View Product</div>

<div style="margin-bottom:16px;">
    <a href="edit_product.php?id=<?php echo $id; ?>" class="btn btn-w">✏ Edit</a>
    <a href="manage_stock.php?id=<?php echo $id; ?>" class="btn btn-g" style="margin-left:8px;">📦 Manage Stock</a>
    <a href="products.php" class="btn btn-dk" style="margin-left:8px;">← Back</a>
</div>

<div class="card">
    <div style="display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap;">
        <?php if($p['image']): ?>
        <img src="../uploads/products/<?php echo htmlspecialchars($p['image']); ?>" style="width:130px;height:130px;object-fit:cover;border-radius:10px;border:1px solid #eee;">
        <?php else: ?>
        <div style="width:130px;height:130px;background:#f0f0f0;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:3rem;">📦</div>
        <?php endif; ?>
        <div style="flex:1;min-width:200px;">
            <h2 style="font-size:1.3rem;margin-bottom:6px;"><?php echo htmlspecialchars($p['product_name']); ?></h2>
            <span class="bx bx-i"><?php echo htmlspecialchars($p['category_name']); ?></span>
            <p style="color:#666;font-size:13px;margin-top:10px;"><?php echo nl2br(htmlspecialchars($p['description']??'')); ?></p>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;">
                <div><span style="font-size:11px;color:#888;display:block;text-transform:uppercase;">Base Price</span><strong>₹<?php echo number_format($p['price'],2); ?></strong></div>
                <div><span style="font-size:11px;color:#888;display:block;text-transform:uppercase;">Discount</span><strong><?php echo $p['discount']; ?>%</strong></div>
                <div><span style="font-size:11px;color:#888;display:block;text-transform:uppercase;">Final Price</span><strong style="color:#27ae60;">₹<?php echo number_format($p['final_price'],2); ?></strong></div>
                <div><span style="font-size:11px;color:#888;display:block;text-transform:uppercase;">Status</span>
                    <span class="bx <?php echo $p['status']==='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($p['status']); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="twrap">
    <div class="thead">📦 Variants (<?php echo mysqli_num_rows($variants); ?>)</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Variant</th><th>Attributes</th><th>SKU</th><th>Final Price</th><th>Stock</th></tr>
        <?php $i=1; while($v=mysqli_fetch_assoc($variants)):
            $sc = $v['stock']==0 ? 'color:#e74c3c;font-weight:700' : ($v['stock']<=5 ? 'color:#e67e22;font-weight:700' : 'color:#27ae60;font-weight:700');
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><strong><?php echo htmlspecialchars($v['variant_name']); ?></strong></td>
            <td style="font-size:11px;color:#888;"><?php echo htmlspecialchars($v['attr_detail']??''); ?></td>
            <td style="font-family:monospace;font-size:11px;"><?php echo htmlspecialchars($v['sku']??''); ?></td>
            <td>₹<?php echo number_format($v['final_price'],2); ?></td>
            <td style="<?php echo $sc; ?>"><?php echo $v['stock']==0 ? 'Out of Stock' : $v['stock'].' units'; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
