<?php include "header.php"; ?>

<?php
$success = $error = '';

if(isset($_POST['add'])){
    $name   = mysqli_real_escape_string($con,$_POST['name']);
    $email  = mysqli_real_escape_string($con,$_POST['email']);
    $phone  = mysqli_real_escape_string($con,$_POST['phone']);
    $gender = mysqli_real_escape_string($con,$_POST['gender']);
    $spec   = mysqli_real_escape_string($con,$_POST['specialization']);
    $exp    = (int)$_POST['experience'];
    $addr   = mysqli_real_escape_string($con,$_POST['address']);
    $uname  = mysqli_real_escape_string($con,$_POST['username']);
    $pass   = mysqli_real_escape_string($con,$_POST['password']);
    $status = $_POST['status'];
    $type   = $_POST['type'];

    // Check duplicate username
    $chk = mysqli_query($con,"SELECT id FROM trainers WHERE username='$uname'");
    if(mysqli_num_rows($chk) > 0){
        $error = "Username already exists. Choose another.";
    } else {
        mysqli_query($con,"INSERT INTO trainers(name,email,phone,gender,specialization,experience,address,username,password,type,status,created_at)
        VALUES('$name','$email','$phone','$gender','$spec','$exp','$addr','$uname','$pass','$type','$status',NOW())");
        $success = "Trainer added successfully!";
    }
}

$res = mysqli_query($con,"SELECT * FROM trainers ORDER BY id DESC");
?>

<div class="pg-title">Trainers</div>

<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if($error):   ?><div class="al al-d">⚠ <?php echo $error; ?></div><?php endif; ?>

<div class="card">
    <h2>Add New Trainer</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Name</label><input type="text" name="name" required></div>
            <div class="fg"><label>Email</label><input type="email" name="email" required></div>
            <div class="fg"><label>Phone</label><input type="text" name="phone" required></div>
            <div class="fg"><label>Gender</label>
                <select name="gender" required>
                    <option value="">Select</option>
                    <option>Male</option><option>Female</option>
                </select>
            </div>
        </div>
        <div class="frow">
            <div class="fg"><label>Specialization</label><input type="text" name="specialization"></div>
            <div class="fg"><label>Experience (Years)</label><input type="number" name="experience" min="0"></div>
            <div class="fg"><label>Username</label><input type="text" name="username" required></div>
            <div class="fg"><label>Password</label><input type="text" name="password" required></div>
        </div>
        <div class="frow">
            <div class="fg"><label>Trainer Type</label>
                <select name="type" required>
                    <option value="">Select Type</option>
                    <option value="personal">Personal Trainer</option>
                    <option value="batch">Batch Trainer</option>
                </select>
            </div>
            <div class="fg"><label>Status</label>
                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <div class="fg"><label>Address</label><input type="text" name="address"></div>
        </div>
        <button type="submit" name="add" class="btn btn-o">+ Add Trainer</button>
    </form>
</div>

<div class="twrap">
    <div class="thead">🏋 All Trainers</div>
    <div class="tscroll">
    <table>
        <tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Gender</th><th>Specialization</th><th>Exp</th><th>Username</th><th>Type</th><th>Status</th><th>Action</th></tr>
        <?php if(mysqli_num_rows($res)>0): while($t=mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?php echo $t['id']; ?></td>
            <td><?php echo htmlspecialchars($t['name']); ?></td>
            <td><?php echo htmlspecialchars($t['email']); ?></td>
            <td><?php echo $t['phone']; ?></td>
            <td><?php echo $t['gender']; ?></td>
            <td><?php echo htmlspecialchars($t['specialization']); ?></td>
            <td><?php echo $t['experience']; ?> yr</td>
            <td><?php echo htmlspecialchars($t['username']); ?></td>
            <td><span class="bx <?php echo $t['type']=='personal'?'bx-s':'bx-i'; ?>"><?php echo ucfirst($t['type']); ?></span></td>
            <td><span class="bx <?php echo $t['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($t['status']); ?></span></td>
            <td style="white-space:nowrap;">
                <a href="edit_trainer.php?id=<?php echo $t['id']; ?>" class="btn btn-b">Edit</a>
                <a href="delete_trainer.php?id=<?php echo $t['id']; ?>" class="btn btn-r" onclick="return confirm('Delete this trainer?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="11" style="text-align:center;color:#888;padding:20px;">No trainers found.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
