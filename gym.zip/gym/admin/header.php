﻿<?php
// Start buffer so any downstream redirects can set headers safely
ob_start();
include "db.php";
$cur = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Gym Admin Panel</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;}

/* TOP BAR */
.topbar{position:fixed;top:0;left:0;right:0;height:56px;background:#1a1a2e;display:flex;align-items:center;justify-content:space-between;padding:0 20px;z-index:1000;box-shadow:0 2px 8px rgba(0,0,0,0.3);}
.topbar .brand{font-size:20px;font-weight:800;color:#ff6600;letter-spacing:1px;}.topbar .brand span{color:#fff;}
.topbar .tadmin{font-size:13px;color:rgba(255,255,255,0.7);}

/* SIDEBAR */
.sidebar{position:fixed;top:56px;left:0;width:220px;height:calc(100vh - 56px);background:#16213e;overflow-y:auto;z-index:900;padding-bottom:20px;}
.sidebar .sb-head{padding:18px 16px 12px;border-bottom:1px solid rgba(255,255,255,0.07);text-align:center;}
.sidebar .sb-head .av{width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,#ff6600,#cc5200);display:inline-flex;align-items:center;justify-content:center;font-size:18px;margin-bottom:6px;}
.sidebar .sb-head h4{color:#fff;font-size:13px;}
.sidebar .sb-head p{color:rgba(255,255,255,0.38);font-size:11px;}
.sb-sec{padding:12px 16px 3px;color:rgba(255,255,255,0.28);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;}
.sidebar a{display:flex;align-items:center;gap:9px;color:rgba(255,255,255,0.62);padding:10px 16px;text-decoration:none;font-size:13px;border-left:3px solid transparent;transition:all 0.2s;}
.sidebar a:hover,.sidebar a.on{background:rgba(255,255,255,0.07);color:#fff;border-left-color:#ff6600;}
.sidebar a .ic{font-size:14px;width:17px;text-align:center;}

/* MAIN */
.main{margin-left:220px;margin-top:56px;padding:24px;min-height:calc(100vh - 56px);}

/* PAGE TITLE */
.pg-title{font-size:20px;font-weight:700;color:#1a1a2e;margin-bottom:18px;padding-bottom:7px;border-bottom:2px solid #ff6600;display:inline-block;}

/* CARD */
.card{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.07);padding:22px;margin-bottom:22px;}
.card h2{font-size:16px;font-weight:700;color:#1a1a2e;margin-bottom:16px;padding-bottom:8px;border-bottom:1px solid #eee;}

/* STAT CARDS */
.sc-row{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:22px;}
.sc{background:#fff;border-radius:10px;padding:18px 22px;flex:1;min-width:140px;box-shadow:0 2px 10px rgba(0,0,0,0.07);border-left:4px solid #ff6600;transition:transform 0.2s;}.sc:hover{transform:translateY(-2px);}
.sc .n{font-size:26px;font-weight:800;color:#1a1a2e;}.sc .l{color:#888;font-size:12px;margin-top:3px;}
.sc.g{border-left-color:#27ae60;}.sc.b{border-left-color:#2980b9;}.sc.p{border-left-color:#8e44ad;}.sc.o{border-left-color:#e67e22;}

/* FORM */
.fg{flex:1;min-width:190px;margin-bottom:14px;}
.fg label{display:block;font-size:12px;color:#555;font-weight:600;margin-bottom:5px;}
.fg input,.fg select,.fg textarea{width:100%;padding:9px 12px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;color:#333;outline:none;transition:border 0.2s;font-family:inherit;background:#fff;}
.fg input:focus,.fg select:focus,.fg textarea:focus{border-color:#ff6600;}
.frow{display:flex;gap:14px;flex-wrap:wrap;}
.full-w{flex:0 0 100%;max-width:100%;}

/* TABLE */
.twrap{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.07);overflow:hidden;margin-bottom:22px;}
.thead{background:#1a1a2e;color:#fff;padding:13px 18px;font-size:14px;font-weight:600;}
.tscroll{overflow-x:auto;}
table{width:100%;border-collapse:collapse;min-width:600px;}
th{background:#f8f9fa;padding:10px 13px;text-align:left;font-size:12px;color:#555;font-weight:600;border-bottom:2px solid #eee;}
td{padding:10px 13px;font-size:13px;color:#333;border-bottom:1px solid #f0f0f0;}
tr:last-child td{border-bottom:none;}tr:hover td{background:#fafafa;}

/* BUTTONS */
.btn{padding:8px 16px;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block;border:none;transition:opacity 0.2s;}
.btn:hover{opacity:0.85;}.btn-o{background:#ff6600;color:#fff;}.btn-g{background:#27ae60;color:#fff;}.btn-b{background:#2980b9;color:#fff;}.btn-r{background:#e74c3c;color:#fff;}.btn-dk{background:#1a1a2e;color:#fff;}.btn-w{background:#e67e22;color:#fff;}

/* ALERTS */
.al{padding:10px 15px;border-radius:7px;margin-bottom:14px;font-size:13px;font-weight:500;}
.al-s{background:#d4edda;color:#155724;border:1px solid #c3e6cb;}
.al-d{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;}
.al-i{background:#d1ecf1;color:#0c5460;border:1px solid #bee5eb;}
.al-w{background:#fff3cd;color:#856404;border:1px solid #ffeeba;}

/* BADGE */
.bx{padding:3px 9px;border-radius:10px;font-size:11px;font-weight:600;display:inline-block;}
.bx-s{background:#d4edda;color:#155724;}.bx-d{background:#f8d7da;color:#721c24;}.bx-i{background:#d1ecf1;color:#0c5460;}.bx-w{background:#fff3cd;color:#856404;}

/* FEATURES GRID */
.feat-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:6px;}
.feat-grid label{display:flex;align-items:center;gap:6px;font-size:13px;color:#444;cursor:pointer;}
</style>
</head>
<body>
<div class="topbar">
    <div class="brand">GYM <span>Admin</span></div>
    <span class="tadmin">Admin Panel</span>
</div>
<div class="sidebar">
    <div class="sb-head">
        <div class="av">&#9881;</div>
        <h4>Administrator</h4>
        <p>Gym Management</p>
    </div>
    <div class="sb-sec">Main</div>
    <a href="dashboard.php"         class="<?php echo $cur=='dashboard.php'?'on':'';?>"><span class="ic">&#127968;</span> Dashboard</a>
    <div class="sb-sec">Membership</div>
    <a href="membership.php"        class="<?php echo in_array($cur,['membership.php','membership_edit.php'])?'on':'';?>"><span class="ic">&#128179;</span> Membership Plans</a>
    <a href="purchase_requests.php" class="<?php echo $cur=='purchase_requests.php'?'on':'';?>"><span class="ic">&#128203;</span> Purchase Requests</a>
    <a href="view_receipts.php"     class="<?php echo $cur=='view_receipts.php'?'on':'';?>"><span class="ic">&#129534;</span> View Receipts</a>
    <a href="free_items.php"        class="<?php echo $cur=='free_items.php' && !isset($_GET['open_stock'])?'on':'';?>"><span class="ic">&#127873;</span> Free Items</a>
    <a href="free_items.php?open_stock=1" class="<?php echo $cur=='free_items.php' && isset($_GET['open_stock'])?'on':'';?>"><span class="ic">&#128230;</span> Free Item Stock</a>
    <div class="sb-sec">Trainers</div>
    <a href="trainers.php"          class="<?php echo in_array($cur,['trainers.php','edit_trainer.php'])?'on':'';?>"><span class="ic">&#127947;</span> Trainers</a>
    <a href="assign_trainer.php"    class="<?php echo in_array($cur,['assign_trainer.php','edit_assign_trainer.php'])?'on':'';?>"><span class="ic">&#128279;</span> Assign Trainer</a>
    <div class="sb-sec">Batches</div>
    <a href="batches.php"           class="<?php echo in_array($cur,['batches.php','edit_batch.php'])?'on':'';?>"><span class="ic">&#128230;</span> Manage Batches</a>
    <a href="assign_member_batch.php" class="<?php echo in_array($cur,['assign_member_batch.php','edit_member_batch.php'])?'on':'';?>"><span class="ic">&#10133;</span> Assign Batch</a>
    <div class="sb-sec">Attendance</div>
    <a href="attendance.php"        class="<?php echo $cur=='attendance.php'?'on':'';?>"><span class="ic">&#128197;</span> Member Attendance</a>
    <a href="trainer_attendance.php" class="<?php echo $cur=='trainer_attendance.php'?'on':'';?>"><span class="ic">&#128197;</span> Trainer Attendance</a>
    <a href="attendance_report.php" class="<?php echo $cur=='attendance_report.php'?'on':'';?>"><span class="ic">&#128202;</span> Attendance Report</a>
    <div class="sb-sec">Events</div>
    <!-- Primary click on Events opens Add Event -->
    <a href="add_event.php"         class="<?php echo in_array($cur,['add_event.php','events.php'])?'on':'';?>"><span class="ic">&#127881;</span> Events</a>
    <a href="events.php"            class="<?php echo $cur=='events.php'?'on':'';?>"><span class="ic">&#128197;</span> All Events</a>
    <a href="event_requests.php"    class="<?php echo $cur=='event_requests.php'?'on':'';?>"><span class="ic">&#128203;</span> Event Requests</a>
    <div class="sb-sec">Products</div>
    <a href="products.php"          class="<?php echo $cur=='products.php'?'on':'';?>"><span class="ic">&#128722;</span> All Products</a>
    <a href="add_product.php"       class="<?php echo $cur=='add_product.php'?'on':'';?>"><span class="ic">&#10133;</span> Add Product</a>
    <a href="orders.php"            class="<?php echo $cur=='orders.php'?'on':'';?>"><span class="ic">&#128465;</span> Product Requests</a>
</div>
<div class="main">
