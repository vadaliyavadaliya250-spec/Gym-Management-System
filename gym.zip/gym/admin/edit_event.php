﻿<?php
session_start();
include "db.php";
if( !isset($_SESSION['admin']) && (($_SESSION['username'] ?? '') !== 'admin') && (($_SESSION['role'] ?? '') !== 'admin') ){
    // header("Location: ../admin.php");
    // exit();
}

$id = (int)($_GET['id'] ?? 0);
$event = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM events WHERE id='$id'"));
if(!$event){ die("Event not found"); }

$msg='';
$err='';
$trainers = mysqli_query($con,"SELECT id,name FROM trainers ORDER BY name");

if($_SERVER['REQUEST_METHOD']==='POST'){
    $title       = mysqli_real_escape_string($con, trim($_POST['title'] ?? ''));
    $event_date  = mysqli_real_escape_string($con, $_POST['event_date'] ?? '');
    $event_time  = mysqli_real_escape_string($con, $_POST['event_time'] ?? '');
    $location    = mysqli_real_escape_string($con, trim($_POST['location'] ?? ''));
    $trainer_id  = (int)($_POST['trainer_id'] ?? 0);
    $max_seats   = (int)($_POST['max_seats'] ?? 0);
    $description = mysqli_real_escape_string($con, trim($_POST['description'] ?? ''));
    $status      = mysqli_real_escape_string($con, $_POST['status'] ?? 'active');

    if(!$title || !$event_date){
        $err = "Title and Date are required.";
    } else {
        $ok = mysqli_query($con,"UPDATE events SET
            title='$title',
            event_date='$event_date',
            event_time='$event_time',
            location='$location',
            trainer_id=".($trainer_id?:'NULL').",
            max_seats='$max_seats',
            description='$description',
            status='$status'
            WHERE id='$id'
        ");
        if($ok){
            $msg="Event updated successfully.";
            $event = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM events WHERE id='$id'"));
        } else {
            $err = "Could not update event.";
        }
    }
}

include "header.php";
?>

<div class="pg-title">Edit Event</div>
<?php if($msg): ?><div class="al al-s"><?php echo $msg; ?></div><?php endif; ?>
<?php if($err): ?><div class="al al-d"><?php echo $err; ?></div><?php endif; ?>

<div class="card">
    <h2>Event Details</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Title *</label><input type="text" name="title" value="<?php echo htmlspecialchars($event['title']); ?>" required></div>
            <div class="fg"><label>Date *</label><input type="date" name="event_date" value="<?php echo $event['event_date']; ?>" required></div>
            <div class="fg"><label>Time</label><input type="time" name="event_time" value="<?php echo $event['event_time']; ?>"></div>
        </div>
        <div class="frow">
            <div class="fg"><label>Location</label><input type="text" name="location" value="<?php echo htmlspecialchars($event['location']); ?>"></div>
            <div class="fg"><label>Trainer</label>
                <select name="trainer_id">
                    <option value="">-- Select Trainer --</option>
                    <?php if($trainers): mysqli_data_seek($trainers,0); while($t=mysqli_fetch_assoc($trainers)): ?>
                        <option value="<?php echo $t['id']; ?>" <?php echo $event['trainer_id']==$t['id']?'selected':''; ?>><?php echo htmlspecialchars($t['name']); ?></option>
                    <?php endwhile; endif; ?>
                </select>
            </div>
            <div class="fg"><label>Max Seats (0 = unlimited)</label><input type="number" name="max_seats" min="0" value="<?php echo $event['max_seats']; ?>"></div>
        </div>
        <div class="frow">
            <div class="fg full-w"><label>Description / Notes</label><textarea name="description" rows="3"><?php echo htmlspecialchars($event['description']); ?></textarea></div>
        </div>
        <div class="frow">
            <div class="fg"><label>Status</label>
                <select name="status">
                    <option value="active" <?php echo $event['status']=='active'?'selected':''; ?>>Active</option>
                    <option value="inactive" <?php echo $event['status']=='inactive'?'selected':''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <button class="btn btn-o" type="submit">Update Event</button>
        <a class="btn btn-dk" href="events.php" style="margin-left:8px;">Back to Events</a>
    </form>
</div>

<?php include "footer.php"; ?>
