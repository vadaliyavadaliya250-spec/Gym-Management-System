<?php include "header.php"; ?>
<?php
// ── edit_product.php (admin) ──────────────────────────────────────────────
$id = (int)($_GET['id'] ?? 0);
$res = mysqli_query($con,"SELECT p.*, pc.category_name FROM products_new p JOIN product_categories pc ON pc.id=p.category_id WHERE p.id='$id'");
$p = mysqli_fetch_assoc($res);
if(!$p){ echo "<div class='al al-d'>Product not found.</div>"; include "footer.php"; exit(); }

$success=''; $error='';

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_product'])){
    $pname    = mysqli_real_escape_string($con, trim($_POST['product_name']));
    $desc     = mysqli_real_escape_string($con, trim($_POST['description']));
    $price    = (float)$_POST['price'];
    $discount = (float)$_POST['discount'];
    $fp       = round($price - ($price*$discount/100), 2);
    $status   = $_POST['status'];

    $img_sql = "";
    if(!empty($_FILES['image']['name']) && $_FILES['image']['error']==0){
        $fname = time().'_'.preg_replace('/[^a-zA-Z0-9_.]/','',$_FILES['image']['name']);
        $dest  = "../uploads/products/".$fname;
        if(!is_dir("../uploads/products/")) mkdir("../uploads/products/",0755,true);
        if(move_uploaded_file($_FILES['image']['tmp_name'],$dest))
            $img_sql = ",image='$fname'";
    }

    mysqli_query($con,"UPDATE products_new SET product_name='$pname',description='$desc',price='$price',discount='$discount',final_price='$fp',status='$status' $img_sql WHERE id='$id'");

    // Update variant stock & extra price
    $vstocks = $_POST['variant_stock'] ?? [];
    $vextras = $_POST['variant_extra'] ?? [];
    foreach($vstocks as $vid => $stk){
        $vid  = (int)$vid;
        $stk  = (int)$stk;
        $extr = (float)($vextras[$vid] ?? 0);
        $vfp  = round($fp + $extr, 2);
        mysqli_query($con,"UPDATE product_variants SET stock='$stk',extra_price='$extr',final_price='$vfp' WHERE id='$vid' AND product_id='$id'");
    }

    $res = mysqli_query($con,"SELECT p.*, pc.category_name FROM products_new p JOIN product_categories pc ON pc.id=p.category_id WHERE p.id='$id'");
    $p = mysqli_fetch_assoc($res);
    $success = "Product updated successfully!";
}

$variants = mysqli_query($con,"SELECT * FROM product_variants WHERE product_id='$id' ORDER BY id");
?>

<div class="pg-title">✏ Edit Product</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if($error):   ?><div class="al al-d">❌ <?php echo $error; ?></div><?php endif; ?>

<form method="POST" enctype="multipart/form-data">
<div class="card">
    <h2>Product Info — <?php echo htmlspecialchars($p['product_name']); ?> <span class="bx bx-i"><?php echo htmlspecialchars($p['category_name']); ?></span></h2>
    <div class="frow">
        <div class="fg"><label>Product Name *</label>
            <input type="text" name="product_name" value="<?php echo htmlspecialchars($p['product_name']); ?>" required>
        </div>
        <div class="fg"><label>Status</label>
            <select name="status">
                <option value="active"   <?php echo $p['status']==='active'?'selected':''; ?>>Active</option>
                <option value="inactive" <?php echo $p['status']==='inactive'?'selected':''; ?>>Inactive</option>
            </select>
        </div>
    </div>
    <div class="frow">
        <div class="fg"><label>Base Price (₹) *</label>
            <input type="number" name="price" step="0.01" value="<?php echo $p['price']; ?>" required>
        </div>
        <div class="fg"><label>Discount (%)</label>
            <input type="number" name="discount" step="0.01" value="<?php echo $p['discount']; ?>">
        </div>
    </div>
    <div class="frow">
        <div class="fg"><label>Image <small>(leave blank to keep current)</small></label>
            <input type="file" name="image" accept="image/*">
            <?php if($p['image']): ?>
            <div style="margin-top:6px;"><img src="../uploads/products/<?php echo htmlspecialchars($p['image']); ?>" style="width:54px;height:54px;object-fit:cover;border-radius:6px;border:1px solid #eee;"></div>
            <?php endif; ?>
        </div>
        <div class="fg full-w"><label>Description</label>
            <textarea name="description" rows="2"><?php echo htmlspecialchars($p['description']??''); ?></textarea>
        </div>
    </div>
</div>

<?php if(mysqli_num_rows($variants) > 0): ?>
<div class="card">
    <h2>📦 Variants — Stock & Pricing</h2>
    <div class="tscroll">
    <table>
        <tr><th>Variant</th><th>SKU</th><th>Extra Price (₹)</th><th>Current Final (₹)</th><th>Stock</th></tr>
        <?php while($v=mysqli_fetch_assoc($variants)): ?>
        <tr>
            <td><strong><?php echo htmlspecialchars($v['variant_name']); ?></strong></td>
            <td style="font-size:11px;color:#888;"><?php echo htmlspecialchars($v['sku']??''); ?></td>
            <td><input type="number" name="variant_extra[<?php echo $v['id']; ?>]" value="<?php echo $v['extra_price']; ?>" step="0.01" min="0" style="width:90px;padding:6px 8px;border:1.5px solid #ddd;border-radius:6px;"></td>
            <td style="font-weight:700;color:#27ae60;">₹<?php echo number_format($v['final_price'],2); ?></td>
            <td><input type="number" name="variant_stock[<?php echo $v['id']; ?>]" value="<?php echo $v['stock']; ?>" min="0" style="width:80px;padding:6px 8px;border:1.5px solid #ddd;border-radius:6px;"></td>
        </tr>
        <?php endwhile; ?>
    </table>
    </div>
</div>
<?php endif; ?>

<div style="margin-bottom:30px;">
    <button type="submit" name="update_product" class="btn btn-o">💾 Update Product</button>
    <a href="products.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
    <a href="manage_stock.php?id=<?php echo $id; ?>" class="btn btn-g" style="margin-left:10px;">📦 Manage Stock</a>
</div>
</form>

<?php include "footer.php"; ?>
