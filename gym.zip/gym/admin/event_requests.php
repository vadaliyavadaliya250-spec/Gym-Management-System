﻿<?php
session_start();
include "db.php";
if( !isset($_SESSION['admin']) && (($_SESSION['username'] ?? '') !== 'admin') && (($_SESSION['role'] ?? '') !== 'admin') ){
    // header("Location: ../admin.php");
    // exit();
}

$filter_event = isset($_GET['event_id']) ? (int)$_GET['event_id'] : 0;
$event_qs = $filter_event ? '&event_id='.$filter_event : '';

// actions
if(isset($_GET['approve'])){
    $id=(int)$_GET['approve'];
    $req = mysqli_fetch_assoc(mysqli_query($con,"
        SELECT er.id, er.event_id, er.status, e.max_seats, e.status as event_status,
               (SELECT COUNT(*) FROM event_registrations x WHERE x.event_id=er.event_id AND x.status='approved') as approved_count
        FROM event_registrations er
        JOIN events e ON e.id=er.event_id
        WHERE er.id='$id'
        LIMIT 1
    "));

    if(!$req){
        header("Location: event_requests.php?msg=notfound$event_qs"); exit();
    }
    if($req['status'] !== 'pending'){
        header("Location: event_requests.php?msg=processed$event_qs"); exit();
    }
    if($req['event_status'] !== 'active'){
        header("Location: event_requests.php?msg=inactive$event_qs"); exit();
    }
    if((int)$req['max_seats'] > 0 && (int)$req['approved_count'] >= (int)$req['max_seats']){
        header("Location: event_requests.php?msg=full$event_qs"); exit();
    }

    mysqli_query($con,"UPDATE event_registrations SET status='approved' WHERE id='$id'");
    header("Location: event_requests.php?msg=approved$event_qs"); exit();
}
if(isset($_GET['cancel'])){
    $id=(int)$_GET['cancel'];
    mysqli_query($con,"UPDATE event_registrations SET status='cancelled' WHERE id='$id'");
    header("Location: event_requests.php?msg=cancelled$event_qs"); exit();
}

$pending = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(*) c FROM event_registrations WHERE status='pending'"))['c'];
$where = $filter_event ? "WHERE er.event_id='$filter_event'" : "";

$regs = mysqli_query($con,"
    SELECT er.*, e.title, e.event_date, e.event_time,
           COALESCE(ud.fullname, er.fullname) as member_name,
           COALESCE(ud.username, er.username) as member_username
    FROM event_registrations er
    JOIN events e ON er.event_id=e.id
    LEFT JOIN user_details ud ON ud.id=er.user_id
    $where
    ORDER BY er.registered_at DESC, er.id DESC
");

include "header.php";

$msg = $_GET['msg'] ?? '';
$msgMap = [
    'approved'  => 'Request approved.',
    'cancelled' => 'Request cancelled.',
    'full'      => 'Cannot approve. This event is full.',
    'inactive'  => 'Cannot approve. Event is inactive.',
    'notfound'  => 'Request not found.',
    'processed' => 'Request already processed.'
];
?>

<div class="pg-title">Event Requests</div>
<?php if($msg): ?>
    <?php $isWarn = in_array($msg,['full','inactive','notfound','processed'],true); ?>
    <div class="al <?php echo $isWarn ? 'al-w' : 'al-s'; ?>"><?php echo htmlspecialchars($msgMap[$msg] ?? 'Action completed.'); ?></div>
<?php endif; ?>

<div class="twrap">
    <div class="thead">All Requests <?php if($pending>0 && !$filter_event): ?><span class="bx bx-w" style="margin-left:8px;"><?php echo $pending; ?> pending</span><?php endif; ?></div>
    <div class="tscroll">
    <table>
        <tr>
            <th>#</th><th>Event</th><th>Date/Time</th><th>Member</th><th>Phone</th><th>Status</th><th>Requested At</th><th>Actions</th>
        </tr>
        <?php $i=1; if($regs && mysqli_num_rows($regs)>0): while($r=mysqli_fetch_assoc($regs)): ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($r['title']); ?></td>
            <td><?php echo date('d M Y',strtotime($r['event_date'])); ?> <?php if($r['event_time']) echo '<br><small>'.date('h:i A',strtotime($r['event_time'])).'</small>'; ?></td>
            <td><?php echo htmlspecialchars($r['member_name'] ?: '-'); ?> <small>(<?php echo htmlspecialchars($r['member_username'] ?: '-'); ?>)</small></td>
            <td><?php echo htmlspecialchars($r['phone'] ?? '-'); ?></td>
            <td><span class="bx <?php echo $r['status']=='approved'?'bx-s':($r['status']=='pending'?'bx-w':'bx-i'); ?>"><?php echo ucfirst($r['status']); ?></span></td>
            <td><?php echo date('d M Y H:i',strtotime($r['registered_at'] ?? 'now')); ?></td>
            <td style="white-space:nowrap;">
                <?php if($r['status']=='pending'): ?>
                    <a href="?approve=<?php echo $r['id']; ?><?php echo $filter_event ? '&event_id='.$filter_event : ''; ?>" class="btn btn-g">Approve</a>
                    <a href="?cancel=<?php echo $r['id']; ?><?php echo $filter_event ? '&event_id='.$filter_event : ''; ?>" class="btn btn-r" onclick="return confirm('Cancel this request?');">Cancel</a>
                <?php else: ?><span style="color:#888;">No actions</span><?php endif; ?>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" style="text-align:center;padding:16px;color:#888;">No requests.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
