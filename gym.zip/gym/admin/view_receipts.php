<?php
session_start();
include "db.php";

if( !isset($_SESSION['admin']) && (($_SESSION['username'] ?? '') !== 'admin') && (($_SESSION['role'] ?? '') !== 'admin') ){
    // header("Location: ../admin.php");
    // exit(); 
}

$db_row = mysqli_fetch_row(mysqli_query($con, "SELECT DATABASE()"));
$db_name = $db_row[0] ?? '';
$db_name_esc = mysqli_real_escape_string($con, (string)$db_name);

$has_col = function(string $col) use ($con, $db_name_esc): bool {
    $col_esc = mysqli_real_escape_string($con, $col);
    $q = mysqli_query(
        $con,
        "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA='{$db_name_esc}'
           AND TABLE_NAME='membership_purchases'
           AND COLUMN_NAME='{$col_esc}'
         LIMIT 1"
    );
    return $q && mysqli_num_rows($q) > 0;
};

$status_filter = $_GET['status'] ?? 'all';
$allowed_status = ['all','pending','approved','cancelled'];
if(!in_array($status_filter, $allowed_status, true)){
    $status_filter = 'all';
}

$search = trim((string)($_GET['q'] ?? ''));
$where = [];

if($status_filter !== 'all' && $has_col('status')){
    $safe_status = mysqli_real_escape_string($con, $status_filter);
    $where[] = "mp.status='{$safe_status}'";
}

if($search !== ''){
    $safe_search = mysqli_real_escape_string($con, $search);
    $where[] = "(mp.username LIKE '%{$safe_search}%' OR mp.plan_name LIKE '%{$safe_search}%' OR mp.txn LIKE '%{$safe_search}%')";
}

$where_sql = count($where) > 0 ? ("WHERE " . implode(" AND ", $where)) : "";

$date_col = $has_col('purchase_date') ? 'purchase_date' : ($has_col('created_at') ? 'created_at' : 'id');
$date_select = $date_col === 'id' ? "mp.id AS receipt_date" : "mp.{$date_col} AS receipt_date";
$duration_col = $has_col('duration') ? 'duration' : ($has_col('duration_days') ? 'duration_days' : '');
$duration_select = $duration_col !== '' ? "mp.{$duration_col} AS duration" : "'' AS duration";

$res = mysqli_query($con, "
    SELECT
        mp.id,
        mp.username,
        ud.fullname AS member_name,
        mp.plan_name,
        mp.amount,
        {$duration_select},
        mp.txn,
        mp.status,
        {$date_select}
    FROM membership_purchases mp
    LEFT JOIN user_details ud ON ud.username = mp.username
    {$where_sql}
    ORDER BY {$date_col} DESC, mp.id DESC
");

$stats = ['all' => 0, 'pending' => 0, 'approved' => 0, 'cancelled' => 0];
$c_all = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) AS c FROM membership_purchases"));
$stats['all'] = (int)($c_all['c'] ?? 0);
foreach(['pending','approved','cancelled'] as $st){
    $safe = mysqli_real_escape_string($con, $st);
    $q = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) AS c FROM membership_purchases WHERE status='{$safe}'"));
    $stats[$st] = (int)($q['c'] ?? 0);
}

include "header.php";
?>

<div class="pg-title">Membership Receipts</div>

<div class="sc-row">
    <div class="sc"><div class="n"><?php echo $stats['all']; ?></div><div class="l">All Receipts</div></div>
    <div class="sc o"><div class="n"><?php echo $stats['pending']; ?></div><div class="l">Pending</div></div>
    <div class="sc g"><div class="n"><?php echo $stats['approved']; ?></div><div class="l">Approved</div></div>
    <div class="sc" style="border-left-color:#e74c3c;"><div class="n"><?php echo $stats['cancelled']; ?></div><div class="l">Cancelled</div></div>
</div>

<div class="card" style="margin-bottom:16px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div class="fg" style="max-width:180px;">
            <label>Status</label>
            <select name="status">
                <option value="all" <?php echo $status_filter==='all'?'selected':''; ?>>All</option>
                <option value="pending" <?php echo $status_filter==='pending'?'selected':''; ?>>Pending</option>
                <option value="approved" <?php echo $status_filter==='approved'?'selected':''; ?>>Approved</option>
                <option value="cancelled" <?php echo $status_filter==='cancelled'?'selected':''; ?>>Cancelled</option>
            </select>
        </div>
        <div class="fg" style="min-width:260px;flex:1;">
            <label>Search (username / plan / txn)</label>
            <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Type to search...">
        </div>
        <button type="submit" class="btn btn-o">Filter</button>
        <a href="view_receipts.php" class="btn btn-b">Reset</a>
    </form>
</div>

<div class="twrap">
    <div class="thead">All Membership Purchase Receipts</div>
    <div class="tscroll">
        <table>
            <tr>
                <th>#</th>
                <th>Member</th>
                <th>Plan</th>
                <th>Amount</th>
                <th>Duration</th>
                <th>Transaction</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            <?php if($res && mysqli_num_rows($res)>0): ?>
                <?php while($r = mysqli_fetch_assoc($res)): ?>
                    <?php
                        $st = strtolower(trim((string)($r['status'] ?? 'pending')));
                        if($st === 'canceled') $st = 'cancelled';
                        $badge = $st === 'approved' ? 'bx-s' : ($st === 'pending' ? 'bx-w' : 'bx-d');
                        $date_val = (string)($r['receipt_date'] ?? '');
                        $date_show = '—';
                        if($date_val !== ''){
                            $date_show = $date_col === 'id'
                                ? ('#' . (int)$date_val)
                                : date('d M Y', strtotime($date_val));
                        }
                    ?>
                    <tr>
                        <td>#<?php echo (int)$r['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars((string)$r['username']); ?></strong><br>
                            <span style="color:#6b7280;font-size:12px;"><?php echo htmlspecialchars((string)($r['member_name'] ?? '-')); ?></span>
                        </td>
                        <td><?php echo htmlspecialchars((string)($r['plan_name'] ?? 'Membership')); ?></td>
                        <td>Rs <?php echo number_format((float)($r['amount'] ?? 0), 2); ?></td>
                        <td><?php echo htmlspecialchars((string)($r['duration'] ?? '-')); ?> days</td>
                        <td><?php echo htmlspecialchars((string)($r['txn'] ?? '-')); ?></td>
                        <td><span class="bx <?php echo $badge; ?>"><?php echo ucfirst($st); ?></span></td>
                        <td><?php echo $date_show; ?></td>
                        <td style="white-space:nowrap;">
                            <a href="../membership_receipt.php?id=<?php echo (int)$r['id']; ?>" target="_blank" class="btn btn-b">View</a>
                            <a href="../membership_receipt.php?id=<?php echo (int)$r['id']; ?>&download=1" class="btn btn-g">Download</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="9" style="text-align:center;color:#888;padding:20px;">No receipts found.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<?php include "footer.php"; ?>
