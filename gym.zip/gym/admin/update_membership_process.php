<?php
include "db.php";
if(isset($_POST['id'])){
    $id       = (int)$_POST['id'];
    $name     = mysqli_real_escape_string($con,$_POST['plan_name']);
    $duration = (int)$_POST['duration'];
    $price    = (float)$_POST['price'];
    $desc     = mysqli_real_escape_string($con,$_POST['description']);
    $status   = $_POST['status'];
    $features = isset($_POST['features']) ? implode(",",$_POST['features']) : "";
    mysqli_query($con,"UPDATE membership_plans SET plan_name='$name',duration='$duration',price='$price',description='$desc',features='$features',status='$status' WHERE id='$id'");
}
header("Location: membership.php"); exit();
