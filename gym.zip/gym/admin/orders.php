﻿<?php
include "header.php";

$msg = '';

$has_col = function($table,$col) use ($con){
    $db = mysqli_fetch_row(mysqli_query($con,"SELECT DATABASE()"))[0] ?? '';
    $db = mysqli_real_escape_string($con,$db);
    $table = mysqli_real_escape_string($con,$table);
    $col = mysqli_real_escape_string($con,$col);
    $q = mysqli_query($con,"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$db' AND TABLE_NAME='$table' AND COLUMN_NAME='$col' LIMIT 1");
    return $q && mysqli_num_rows($q)>0;
};

if(isset($_POST['order_id'], $_POST['status'])){
    $oid = (int)$_POST['order_id'];
    $st  = mysqli_real_escape_string($con, trim($_POST['status']));
    if($oid > 0 && $st !== ''){
        mysqli_query($con,"UPDATE orders SET status='$st' WHERE id='$oid'");
        $msg = "Status updated.";
    }
}

$has_product_id = $has_col('orders','product_id');
$has_variant_id = $has_col('orders','variant_id');
$has_qty        = $has_col('orders','qty');
$has_items      = $has_col('orders','items');
$has_created_at = $has_col('orders','created_at');
$has_payment    = $has_col('orders','payment_method');

if($has_product_id && $has_variant_id){
    $orders = mysqli_query($con,"
        SELECT o.*, p.product_name, pv.variant_name, u.username
        FROM orders o
        LEFT JOIN products_new p ON p.id=o.product_id
        LEFT JOIN product_variants pv ON pv.id=o.variant_id
        LEFT JOIN user_table u ON u.id=o.user_id
        ORDER BY ".($has_created_at ? "o.created_at DESC" : "o.id DESC")."
    ");
} else {
    $orders = mysqli_query($con,"
        SELECT o.*, u.username
        FROM orders o
        LEFT JOIN user_table u ON u.id=o.user_id
        ORDER BY ".($has_created_at ? "o.created_at DESC" : "o.id DESC")."
    ");
}
?>

<div class="pg-title">Orders</div>
<?php if($msg): ?><div class="al al-s"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

<div class="twrap">
  <div class="thead">Recent Orders</div>
  <div class="tscroll">
    <table>
      <tr>
        <th>ID</th><th>User</th><th>Product</th><th>Variant</th><th>Qty</th><th>Total</th><th>Payment</th><th>Status</th><th>Action</th>
      </tr>
      <?php if($orders && mysqli_num_rows($orders)>0): while($o=mysqli_fetch_assoc($orders)):
          $product_name = '-';
          $variant_name = '-';
          $qty = '-';

          if($has_product_id && $has_variant_id){
              $product_name = $o['product_name'] ?? ('Product #'.($o['product_id'] ?? ''));
              $variant_name = $o['variant_name'] ?? ('Variant #'.($o['variant_id'] ?? ''));
              $qty = $has_qty ? (int)($o['qty'] ?? 0) : '-';
          } elseif($has_items && !empty($o['items'])){
              $items = json_decode($o['items'], true);
              if(is_array($items) && count($items)>0){
                  $names = [];
                  $sumQty = 0;
                  foreach($items as $it){
                      $n = trim((string)($it['name'] ?? 'Item'));
                      if($n !== '') $names[] = $n;
                      $sumQty += max(0, (int)($it['qty'] ?? 0));
                  }
                  if(count($names)>0){
                      $product_name = implode(', ', array_slice($names,0,2));
                      if(count($names)>2) $product_name .= ' +'.(count($names)-2).' more';
                  }
                  $variant_name = 'Cart Items';
                  $qty = $sumQty > 0 ? $sumQty : '-';
              }
          }

          $current_status = strtolower(trim((string)($o['status'] ?? 'pending')));
          if($current_status === '') $current_status = 'pending';
          $status_list = array_values(array_unique(array_merge([$current_status], ['pending','processing','completed','delivered','cancelled','canceled'])));
      ?>
      <tr>
        <td><?php echo (int)$o['id']; ?></td>
        <td><?php echo htmlspecialchars($o['username'] ?? ('User #'.($o['user_id'] ?? ''))); ?></td>
        <td><?php echo htmlspecialchars($product_name); ?></td>
        <td><?php echo htmlspecialchars($variant_name); ?></td>
        <td><?php echo htmlspecialchars((string)$qty); ?></td>
        <td>Rs <?php echo number_format((float)($o['total'] ?? 0),2); ?></td>
        <td><?php echo htmlspecialchars($has_payment ? ($o['payment_method'] ?? '-') : '-'); ?></td>
        <td><?php echo ucfirst(htmlspecialchars($current_status)); ?></td>
        <td>
          <form method="POST" style="display:flex;gap:6px;align-items:center;">
            <input type="hidden" name="order_id" value="<?php echo (int)$o['id']; ?>">
            <select name="status" style="padding:6px;">
              <?php foreach($status_list as $st): ?>
                <option value="<?php echo htmlspecialchars($st); ?>" <?php echo $current_status===$st?'selected':''; ?>><?php echo ucfirst($st); ?></option>
              <?php endforeach; ?>
            </select>
            <button class="btn btn-b" type="submit">Update</button>
          </form>
        </td>
      </tr>
      <?php endwhile; else: ?>
      <tr><td colspan="9" style="text-align:center;color:#888;padding:20px;">No orders yet.</td></tr>
      <?php endif; ?>
    </table>
  </div>
</div>

<?php include "footer.php"; ?>
