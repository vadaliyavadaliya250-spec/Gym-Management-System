<?php include "header.php"; ?>

<?php
$success = '';
if(isset($_POST['save_attendance'])){
    $date     = $_POST['date'];
    $type     = $_POST['trainer_type'];
    $batch_id = isset($_POST['batch']) ? (int)$_POST['batch'] : 0;
    foreach($_POST['status'] as $trainer_id => $status){
        $trainer_id = (int)$trainer_id;
        $chk = mysqli_query($con,"SELECT id FROM trainer_attendance WHERE trainer_id='$trainer_id' AND date='$date'");
        if(mysqli_num_rows($chk) > 0){
            mysqli_query($con,"UPDATE trainer_attendance SET status='$status' WHERE trainer_id='$trainer_id' AND date='$date'");
        } else {
            mysqli_query($con,"INSERT INTO trainer_attendance(trainer_id,batch_id,date,status,entity_type) VALUES('$trainer_id','$batch_id','$date','$status','$type')");
        }
    }
    $success = "Trainer attendance saved!";
}
$batches_q = mysqli_query($con,"SELECT * FROM batches");
?>

<div class="pg-title">Trainer Attendance</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>

<div class="card">
    <h2>Select Type & Date</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Trainer Type</label>
                <select name="trainer_type" id="ttype" onchange="toggleBatch()" required>
                    <option value="">-- Select Type --</option>
                    <option value="batch"    <?php echo (isset($_POST['trainer_type'])&&$_POST['trainer_type']=='batch')?'selected':''; ?>>Batch Trainer</option>
                    <option value="personal" <?php echo (isset($_POST['trainer_type'])&&$_POST['trainer_type']=='personal')?'selected':''; ?>>Personal Trainer</option>
                </select>
            </div>
            <div class="fg" id="batchDiv" style="display:none;">
                <label>Select Batch</label>
                <select name="batch" id="batchSel">
                    <option value="">-- Select Batch --</option>
                    <?php while($b=mysqli_fetch_assoc($batches_q)): ?>
                    <option value="<?php echo $b['id']; ?>" <?php echo (isset($_POST['batch'])&&$_POST['batch']==$b['id'])?'selected':''; ?>><?php echo htmlspecialchars($b['batch_name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="fg"><label>Date</label>
                <input type="date" name="date" value="<?php echo isset($_POST['date'])?$_POST['date']:date('Y-m-d'); ?>" required>
            </div>
        </div>
        <button type="submit" name="load_trainers" class="btn btn-b">Load Trainers</button>
    </form>
</div>

<?php
if(isset($_POST['load_trainers']) || isset($_POST['save_attendance'])){
    $type     = $_POST['trainer_type'];
    $batch_id = isset($_POST['batch']) ? (int)$_POST['batch'] : 0;
    $date     = $_POST['date'];

    if($type == 'batch'){
        // Fixed: was using wrong JOIN — now just gets all batch trainers
        if($batch_id > 0){
            $trainers = mysqli_query($con,"SELECT t.* FROM trainers t JOIN batches b ON b.trainer_id=t.id WHERE b.id='$batch_id' AND t.type='batch' AND t.status='active'");
        } else {
            $trainers = mysqli_query($con,"SELECT * FROM trainers WHERE type='batch' AND status='active'");
        }
    } else {
        $trainers = mysqli_query($con,"SELECT DISTINCT t.* FROM trainers t JOIN assign_trainer at ON t.id=at.trainer_id WHERE t.type='personal' AND t.status='active'");
    }

    if(mysqli_num_rows($trainers) > 0):
?>
<div class="card">
    <h2>Mark Attendance — <?php echo ucfirst($type); ?> Trainers — <?php echo $date; ?></h2>
    <form method="POST">
        <input type="hidden" name="trainer_type" value="<?php echo $type; ?>">
        <input type="hidden" name="batch"        value="<?php echo $batch_id; ?>">
        <input type="hidden" name="date"         value="<?php echo $date; ?>">
        <div class="tscroll">
        <table>
            <tr><th>#</th><th>Trainer Name</th><th>Specialization</th><th>Present</th><th>Absent</th></tr>
            <?php $i=1; while($t=mysqli_fetch_assoc($trainers)):
                $ex = mysqli_query($con,"SELECT status FROM trainer_attendance WHERE trainer_id='{$t['id']}' AND date='$date'");
                $ex = mysqli_fetch_assoc($ex);
            ?>
            <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo htmlspecialchars($t['name']); ?></td>
                <td><?php echo htmlspecialchars($t['specialization']); ?></td>
                <td><input type="radio" name="status[<?php echo $t['id']; ?>]" value="Present" <?php echo (!$ex||$ex['status']=='Present')?'checked':''; ?> required></td>
                <td><input type="radio" name="status[<?php echo $t['id']; ?>]" value="Absent"  <?php echo ($ex&&$ex['status']=='Absent')?'checked':''; ?>></td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
        <br>
        <button type="submit" name="save_attendance" class="btn btn-g">💾 Save Attendance</button>
    </form>
</div>
<?php else: ?>
<div class="al al-w">⚠ No trainers found for selected type/batch.</div>
<?php endif; } ?>

<script>
function toggleBatch(){
    var t = document.getElementById('ttype').value;
    var d = document.getElementById('batchDiv');
    if(t=='batch'){ d.style.display='block'; } else { d.style.display='none'; }
}
window.onload = function(){ toggleBatch(); };
</script>

<?php include "footer.php"; ?>
