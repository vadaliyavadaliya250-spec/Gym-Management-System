<?php include "header.php"; ?>

<?php
$success = '';
if(isset($_POST['save_attendance'])){
    $date  = $_POST['date'];
    $batch = (int)$_POST['batch'];
    foreach($_POST['status'] as $member_id => $status){
        $member_id = (int)$member_id;
        $chk = mysqli_query($con,"SELECT id FROM attendance WHERE member_id='$member_id' AND date='$date'");
        if(mysqli_num_rows($chk) > 0){
            mysqli_query($con,"UPDATE attendance SET status='$status',batch_id='$batch' WHERE member_id='$member_id' AND date='$date'");
        } else {
            mysqli_query($con,"INSERT INTO attendance(member_id,batch_id,date,status) VALUES('$member_id','$batch','$date','$status')");
        }
    }
    $success = "Attendance saved successfully!";
}
$batches_q = mysqli_query($con,"SELECT * FROM batches");
?>

<div class="pg-title">Member Attendance</div>
<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>

<div class="card">
    <h2>Select Batch & Date</h2>
    <form method="POST" id="loadForm">
        <div class="frow">
            <div class="fg"><label>Select Batch</label>
                <select name="batch" id="batchSel" required>
                    <option value="">-- Select Batch --</option>
                    <?php while($b=mysqli_fetch_assoc($batches_q)): ?>
                    <option value="<?php echo $b['id']; ?>" <?php echo (isset($_POST['batch']) && $_POST['batch']==$b['id'])?'selected':''; ?>><?php echo htmlspecialchars($b['batch_name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="fg"><label>Date</label>
                <input type="date" name="date" value="<?php echo isset($_POST['date'])?$_POST['date']:date('Y-m-d'); ?>" required>
            </div>
        </div>
        <button type="submit" name="load_members" class="btn btn-b">Load Members</button>
    </form>
</div>

<?php
if(isset($_POST['load_members']) || isset($_POST['save_attendance'])){
    $batch = (int)$_POST['batch'];
    $date  = $_POST['date'];
    $members = mysqli_query($con,"SELECT * FROM user_details WHERE batch_id='$batch'");
    if(mysqli_num_rows($members) > 0):
?>
<div class="card">
    <h2>Mark Attendance — <?php echo $date; ?></h2>
    <form method="POST">
        <input type="hidden" name="batch" value="<?php echo $batch; ?>">
        <input type="hidden" name="date"  value="<?php echo $date; ?>">
        <div class="tscroll">
        <table>
            <tr><th>#</th><th>Member Name</th><th>Present</th><th>Absent</th></tr>
            <?php $i=1; while($m=mysqli_fetch_assoc($members)):
                $existing = mysqli_query($con,"SELECT status FROM attendance WHERE member_id='{$m['id']}' AND date='$date'");
                $ex = mysqli_fetch_assoc($existing);
            ?>
            <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo htmlspecialchars($m['fullname']); ?></td>
                <td><input type="radio" name="status[<?php echo $m['id']; ?>]" value="Present" <?php echo (!$ex || $ex['status']=='Present')?'checked':''; ?> required></td>
                <td><input type="radio" name="status[<?php echo $m['id']; ?>]" value="Absent"  <?php echo ($ex && $ex['status']=='Absent')?'checked':''; ?>></td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
        <br>
        <button type="submit" name="save_attendance" class="btn btn-g">💾 Save Attendance</button>
    </form>
</div>
<?php else: ?>
<div class="al al-w">⚠ No members found in this batch.</div>
<?php endif; } ?>

<?php include "footer.php"; ?>
