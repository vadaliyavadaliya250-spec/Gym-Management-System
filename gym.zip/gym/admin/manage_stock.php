<?php include "header.php"; ?>
<?php
// ── manage_stock.php (admin) ──────────────────────────────────────────────
$id = (int)($_GET['id'] ?? 0);
$res = mysqli_query($con,"SELECT p.*, pc.category_name FROM products_new p JOIN product_categories pc ON pc.id=p.category_id WHERE p.id='$id'");
$product = mysqli_fetch_assoc($res);
if(!$product){ header("Location: products.php"); exit(); }

$success=''; $error='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $variant_id  = (int)$_POST['variant_id'];
    $change_type = $_POST['change_type'];
    $quantity    = (int)$_POST['quantity'];
    $note        = mysqli_real_escape_string($con, trim($_POST['note']??''));

    if($quantity <= 0){
        $error = "Quantity must be a positive number.";
    } else {
        $cur = mysqli_fetch_assoc(mysqli_query($con,"SELECT stock FROM product_variants WHERE id='$variant_id' AND product_id='$id'"));
        if(!$cur){
            $error = "Variant not found.";
        } else {
            $old = (int)$cur['stock'];
            if($change_type==='add')            $new = $old + $quantity;
            elseif($change_type==='reduce'){
                if($quantity > $old){ $error = "Cannot reduce more than current stock ($old)."; }
                else $new = $old - $quantity;
            } else { // adjustment
                $new = $quantity;
                $quantity = abs($new - $old);
            }

            if(!$error){
                mysqli_query($con,"UPDATE product_variants SET stock='$new' WHERE id='$variant_id'");
                mysqli_query($con,"INSERT INTO stock_log (variant_id,change_type,quantity,stock_before,stock_after,note)
                    VALUES('$variant_id','$change_type','$quantity','$old','$new','$note')");
                $success = "Stock updated successfully!";
            }
        }
    }
}

$variants = mysqli_query($con,"
    SELECT pv.*,
           GROUP_CONCAT(av.value_label ORDER BY at.id SEPARATOR ' / ') AS attr_labels
    FROM product_variants pv
    LEFT JOIN variant_attributes va ON va.variant_id=pv.id
    LEFT JOIN attribute_values av ON av.id=va.value_id
    LEFT JOIN product_attribute_types at ON at.id=va.attribute_id
    WHERE pv.product_id='$id'
    GROUP BY pv.id ORDER BY pv.id
");

$logs = mysqli_query($con,"
    SELECT sl.*, pv.variant_name
    FROM stock_log sl
    JOIN product_variants pv ON pv.id=sl.variant_id
    WHERE pv.product_id='$id'
    ORDER BY sl.created_at DESC LIMIT 30
");
?>

<div class="pg-title">📦 Manage Stock — <?php echo htmlspecialchars($product['product_name']); ?></div>

<div style="margin-bottom:16px;">
    <a href="products.php" class="btn btn-dk">← Back to Products</a>
    <a href="edit_product.php?id=<?php echo $id; ?>" class="btn btn-w" style="margin-left:8px;">✏ Edit Product</a>
</div>

<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if($error):   ?><div class="al al-d">❌ <?php echo $error; ?></div><?php endif; ?>

<style>
.vcard{display:flex;align-items:center;justify-content:space-between;border:1.5px solid #eee;border-radius:8px;padding:11px 14px;cursor:pointer;transition:all 0.2s;margin-bottom:8px;}
.vcard:hover{border-color:#ff6600;background:#fffaf7;}
.vcard.sel{border-color:#ff6600;background:#fff3e9;}
.type-btn{padding:7px 16px;border-radius:20px;border:2px solid #ddd;background:#fff;cursor:pointer;font-size:12px;font-weight:600;margin-right:6px;margin-bottom:6px;}
.type-btn.add-t{border-color:#27ae60;color:#27ae60;} .type-btn.add-t.on{background:#27ae60;color:#fff;}
.type-btn.red-t{border-color:#e67e22;color:#e67e22;} .type-btn.red-t.on{background:#e67e22;color:#fff;}
.type-btn.adj-t{border-color:#2980b9;color:#2980b9;} .type-btn.adj-t.on{background:#2980b9;color:#fff;}
.two-col{display:grid;grid-template-columns:1fr 360px;gap:20px;}
@media(max-width:768px){.two-col{grid-template-columns:1fr;}}
</style>

<div class="two-col">
<!-- Left: Variants list + log -->
<div>
    <div class="card">
        <h2>Variants (<?php echo mysqli_num_rows($variants); ?>) — Click to select</h2>
        <?php mysqli_data_seek($variants,0); while($v=mysqli_fetch_assoc($variants)):
            $sc = $v['stock']==0 ? '#e74c3c' : ($v['stock']<=5 ? '#e67e22' : '#27ae60');
        ?>
        <div class="vcard" id="vc-<?php echo $v['id']; ?>" onclick="selectVariant(<?php echo $v['id']; ?>,'<?php echo addslashes($v['variant_name']); ?>')">
            <div>
                <div style="font-weight:700;font-size:13px;"><?php echo htmlspecialchars($v['variant_name']); ?></div>
                <div style="font-size:11px;color:#888;">SKU: <?php echo htmlspecialchars($v['sku']??'-'); ?> &nbsp;|&nbsp; ₹<?php echo number_format($v['final_price'],2); ?></div>
            </div>
            <div style="font-weight:800;font-size:1.1rem;color:<?php echo $sc; ?>" id="sd-<?php echo $v['id']; ?>">
                <?php echo $v['stock']; ?> units
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <div class="twrap">
        <div class="thead">📋 Stock Log (Last 30 movements)</div>
        <div class="tscroll">
        <table>
            <tr><th>Variant</th><th>Type</th><th>Qty</th><th>Before</th><th>After</th><th>Note</th><th>Date</th></tr>
            <?php if(mysqli_num_rows($logs)==0): ?>
            <tr><td colspan="7" style="text-align:center;color:#888;padding:20px;">No stock movements yet.</td></tr>
            <?php endif; ?>
            <?php while($l=mysqli_fetch_assoc($logs)):
                $ctc = ['add'=>'#27ae60','reduce'=>'#e74c3c','sale'=>'#e74c3c','adjustment'=>'#2980b9','return'=>'#8e44ad'][$l['change_type']] ?? '#333';
            ?>
            <tr>
                <td><?php echo htmlspecialchars($l['variant_name']); ?></td>
                <td style="color:<?php echo $ctc; ?>;font-weight:700;"><?php echo ucfirst($l['change_type']); ?></td>
                <td><?php echo $l['quantity']; ?></td>
                <td><?php echo $l['stock_before']; ?></td>
                <td><strong><?php echo $l['stock_after']; ?></strong></td>
                <td style="font-size:11px;"><?php echo htmlspecialchars($l['note']??''); ?></td>
                <td style="font-size:11px;"><?php echo date('d M, H:i', strtotime($l['created_at'])); ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
    </div>
</div>

<!-- Right: Update form -->
<div>
    <div class="card" style="position:sticky;top:70px;">
        <h2>✏ Update Stock</h2>
        <p style="font-size:12px;color:#888;margin-bottom:14px;">Click a variant on the left, then fill the form below.</p>
        <form method="POST" id="stockForm">
            <input type="hidden" name="variant_id" id="f_vid" value="">
            <div class="fg" style="margin-bottom:14px;">
                <label>Selected Variant</label>
                <input type="text" id="f_vname" readonly value="— none selected —" style="background:#f9f9f9;color:#888;">
            </div>
            <div class="fg" style="margin-bottom:14px;">
                <label>Change Type</label><br>
                <button type="button" class="type-btn add-t on" onclick="setType('add',this)">＋ Add</button>
                <button type="button" class="type-btn red-t" onclick="setType('reduce',this)">－ Reduce</button>
                <button type="button" class="type-btn adj-t" onclick="setType('adjustment',this)">= Set Exact</button>
                <input type="hidden" name="change_type" id="f_ctype" value="add">
            </div>
            <div class="fg" style="margin-bottom:14px;">
                <label id="qty_label">Quantity to Add</label>
                <input type="number" name="quantity" min="1" required placeholder="e.g. 10">
            </div>
            <div class="fg" style="margin-bottom:14px;">
                <label>Note (optional)</label>
                <input type="text" name="note" placeholder="e.g. New shipment received">
            </div>
            <button type="submit" class="btn btn-o" style="width:100%;" onclick="return checkVariant()">💾 Update Stock</button>
        </form>
    </div>
</div>
</div>

<script>
let selVid = null;
function selectVariant(id, name){
    selVid = id;
    document.getElementById('f_vid').value = id;
    document.getElementById('f_vname').value = name;
    document.querySelectorAll('.vcard').forEach(c=>c.classList.remove('sel'));
    document.getElementById('vc-'+id).classList.add('sel');
}
function setType(type, btn){
    document.getElementById('f_ctype').value = type;
    document.querySelectorAll('.type-btn').forEach(b=>b.classList.remove('on'));
    btn.classList.add('on');
    const lbl = {add:'Quantity to Add', reduce:'Quantity to Reduce', adjustment:'Set Exact Stock Value'};
    document.getElementById('qty_label').textContent = lbl[type];
}
function checkVariant(){
    if(!selVid){ alert('Please click a variant from the list first!'); return false; }
    return true;
}
</script>

<?php include "footer.php"; ?>
