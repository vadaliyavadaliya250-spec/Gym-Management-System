<?php include "header.php"; ?>
<?php
// ── add_product.php  (admin) ──────────────────────────────────────────────
$success = ''; $error = '';

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit_product'])){
    $category_id  = (int)$_POST['category_id'];
    $product_name = mysqli_real_escape_string($con, trim($_POST['product_name']));
    $description  = mysqli_real_escape_string($con, trim($_POST['description']));
    $price        = (float)$_POST['price'];
    $discount     = (float)($_POST['discount'] ?? 0);
    $final_price  = round($price - ($price * $discount / 100), 2);

    if(!$category_id || !$product_name || !$price){
        $error = "Please fill all required fields.";
    } else {
        // Image upload
        $image = 'NULL';
        if(!empty($_FILES['image']['name']) && $_FILES['image']['error']==0){
            $fname = time().'_'.preg_replace('/[^a-zA-Z0-9_.]/','',$_FILES['image']['name']);
            $dest  = "../uploads/products/".$fname;
            if(!is_dir("../uploads/products/")) mkdir("../uploads/products/", 0755, true);
            if(move_uploaded_file($_FILES['image']['tmp_name'], $dest)){
                $image = "'$fname'";
            }
        }

        mysqli_query($con,"
            INSERT INTO products_new (category_id,product_name,image,description,price,discount,final_price)
            VALUES('$category_id','$product_name',$image,'$description','$price','$discount','$final_price')
        ");
        $product_id = mysqli_insert_id($con);

        // Insert variants
        $variants = $_POST['variants'] ?? [];
        $vcount = 0;
        foreach($variants as $v){
            $extra      = (float)($v['extra_price'] ?? 0);
            $vfinal     = round($final_price + $extra, 2);
            $stock      = (int)($v['stock'] ?? 0);
            $attrs      = $v['attributes'] ?? [];

            // Build variant name
            $nameParts = [];
            foreach($attrs as $attr_id => $val_id){
                if(!$val_id) continue; // allow optional attributes (e.g., merchandise sizes)
                $vq = mysqli_query($con,"SELECT value_label FROM attribute_values WHERE id='".((int)$val_id)."'");
                $vr = mysqli_fetch_assoc($vq);
                if($vr) $nameParts[] = $vr['value_label'];
            }
            $variant_name = mysqli_real_escape_string($con, implode(' / ', $nameParts) ?: 'Default');
            $sku = strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/','', $product_name),0,5)).'-'.strtoupper(preg_replace('/[^A-Z0-9]/','',strtoupper($variant_name))).'-'.$product_id;
            $sku = mysqli_real_escape_string($con, substr($sku,0,80));

            mysqli_query($con,"
                INSERT INTO product_variants (product_id,variant_name,sku,extra_price,final_price,stock)
                VALUES('$product_id','$variant_name','$sku','$extra','$vfinal','$stock')
            ");
            $variant_id = mysqli_insert_id($con);

            if($stock > 0){
                mysqli_query($con,"INSERT INTO stock_log (variant_id,change_type,quantity,stock_before,stock_after,note)
                    VALUES('$variant_id','add','$stock',0,'$stock','Initial stock on product creation')");
            }

            foreach($attrs as $attr_id => $val_id){
                if(!$val_id) continue;
                $aid = (int)$attr_id; $vid = (int)$val_id;
                mysqli_query($con,"INSERT INTO variant_attributes (variant_id,attribute_id,value_id) VALUES('$variant_id','$aid','$vid')");
            }
            $vcount++;
        }
        $success = "Product <strong>$product_name</strong> added successfully with $vcount variant(s)!";
    }
}

$categories = mysqli_query($con,"SELECT * FROM product_categories WHERE status='active' ORDER BY category_name");
?>

<div class="pg-title">➕ Add New Product</div>

<?php if($success): ?><div class="al al-s">✅ <?php echo $success; ?></div><?php endif; ?>
<?php if($error):   ?><div class="al al-d">❌ <?php echo $error; ?></div><?php endif; ?>

<style>
.cat-tab{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border:2px solid #ddd;border-radius:25px;background:#fff;cursor:pointer;font-weight:600;font-size:13px;margin:4px;transition:all 0.2s;}
.cat-tab:hover{border-color:#ff6600;color:#ff6600;}
.cat-tab.active{background:#ff6600;color:#fff;border-color:#ff6600;}
.variant-row{background:#fafafa;border:1.5px solid #eee;border-radius:8px;padding:14px;margin-bottom:10px;position:relative;}
.variant-row .vrow-grid{display:flex;gap:12px;flex-wrap:wrap;}
.variant-row .vrow-grid .fg{min-width:140px;flex:1;}
.remove-vbtn{position:absolute;top:10px;right:10px;background:#fde8e8;color:#e74c3c;border:none;border-radius:5px;width:26px;height:26px;cursor:pointer;font-size:13px;}
#attr-loading{color:#ff6600;font-size:13px;display:none;padding:8px 0;}
</style>

<form method="POST" enctype="multipart/form-data" id="productForm">

<!-- STEP 1: Category -->
<div class="card">
    <h2>Step 1 — Select Category</h2>
    <input type="hidden" name="category_id" id="category_id_input" required>
    <div>
        <?php mysqli_data_seek($categories, 0); while($c=mysqli_fetch_assoc($categories)): 
            $slug = strtolower(str_replace(' ','-',$c['category_name']));
            $icon = ['equipments'=>'🏋️','supplements'=>'💊','merchandise'=>'👕'][$slug] ?? '📦';
        ?>
        <div class="cat-tab" data-id="<?php echo $c['id']; ?>" onclick="selectCat(this)">
            <?php echo $icon.' '.htmlspecialchars($c['category_name']); ?>
        </div>
        <?php endwhile; ?>
    </div>
    <div id="attr-loading">⏳ Loading attributes...</div>
</div>

<!-- STEP 2: Product Details -->
<div class="card">
    <h2>Step 2 — Product Details</h2>
    <div class="frow">
        <div class="fg"><label>Product Name *</label><input type="text" name="product_name" placeholder="e.g. Iron Dumbbell, Whey Protein" required></div>
        <div class="fg"><label>Product Image</label><input type="file" name="image" accept="image/*"></div>
    </div>
    <div class="frow">
        <div class="fg"><label>Base Price (₹) *</label><input type="number" name="price" id="base_price" min="0" step="0.01" required oninput="recalc()"></div>
        <div class="fg"><label>Discount (%)</label><input type="number" name="discount" id="discount_pct" min="0" max="100" step="0.01" value="0" oninput="recalc()"></div>
    </div>
    <div class="frow">
        <div class="fg full-w"><label>Description</label><textarea name="description" rows="2" placeholder="Product description..."></textarea></div>
    </div>
</div>

<!-- STEP 3: Variants -->
<div class="card" id="variants-card" style="display:none;">
    <h2 style="display:flex;justify-content:space-between;align-items:center;">
        Step 3 — Add Variants
        <span id="variant-count-badge" style="background:#ff6600;color:#fff;padding:3px 10px;border-radius:12px;font-size:12px;">0 variants</span>
    </h2>
    <p style="font-size:12px;color:#888;margin-bottom:14px;">Each variant = one combination of attributes (e.g. 1 KG + Chocolate). Add stock per variant.</p>
    <div id="variants-container"></div>
    <button type="button" class="btn btn-b" onclick="addVariant()">+ Add Variant</button>
</div>

<!-- Submit -->
<div style="margin-bottom:30px;">
    <button type="submit" name="submit_product" class="btn btn-o" style="font-size:15px;padding:11px 28px;">💾 Save Product</button>
    <a href="products.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
</div>
</form>

<script>
let currentCatId = null;
let currentAttrs = [];
let varIdx = 0;

function selectCat(el){
    document.querySelectorAll('.cat-tab').forEach(t=>t.classList.remove('active'));
    el.classList.add('active');
    currentCatId = el.dataset.id;
    document.getElementById('category_id_input').value = currentCatId;
    loadAttrs(currentCatId);
}

function loadAttrs(catId){
    document.getElementById('attr-loading').style.display = 'block';
    document.getElementById('variants-card').style.display = 'none';
    document.getElementById('variants-container').innerHTML = '';
    varIdx = 0;
    updateCount();
    fetch('get_category_attributes.php?category_id='+catId)
        .then(r=>r.json())
        .then(data=>{
            currentAttrs = data.attributes;
            document.getElementById('attr-loading').style.display = 'none';
            document.getElementById('variants-card').style.display = 'block';
            addVariant();
        })
        .catch(()=>{ document.getElementById('attr-loading').style.display='none'; alert('Failed to load attributes.'); });
}

function addVariant(){
    if(!currentAttrs.length){ alert('Select a category first.'); return; }
    const idx = varIdx++;
    let attrHtml = currentAttrs.map(a=>`
        <div class="fg">
            <label>${a.attribute_name}${a.unit_label?' ('+a.unit_label+')':''}</label>
            <select name="variants[${idx}][attributes][${a.id}]">
                <option value="">-- Select --</option>
                ${a.values.map(v=>`<option value="${v.id}">${v.value_label}</option>`).join('')}
            </select>
        </div>`).join('');
    const row = document.createElement('div');
    row.className='variant-row'; row.id='vrow-'+idx;
    row.innerHTML=`
        <button type="button" class="remove-vbtn" onclick="removeVariant(${idx})" title="Remove">✕</button>
        <div class="vrow-grid">
            ${attrHtml}
            <div class="fg"><label>Extra Price (₹)</label>
                <input type="number" name="variants[${idx}][extra_price]" class="ep" value="0" min="0" step="0.01" oninput="recalc()">
            </div>
            <div class="fg"><label>Stock Qty *</label>
                <input type="number" name="variants[${idx}][stock]" value="0" min="0" required>
            </div>
            <div class="fg"><label>Final Price</label>
                <input type="text" class="vfp" readonly style="background:#f0fdf4;font-weight:700;color:#155724;" placeholder="Auto-calc">
            </div>
        </div>`;
    document.getElementById('variants-container').appendChild(row);
    updateCount(); recalc();
}

function removeVariant(idx){
    const r=document.getElementById('vrow-'+idx); if(r) r.remove(); updateCount();
}
function updateCount(){
    const c=document.querySelectorAll('.variant-row').length;
    document.getElementById('variant-count-badge').textContent=c+' variant'+(c!==1?'s':'');
}
function recalc(){
    const base=parseFloat(document.getElementById('base_price').value)||0;
    const disc=parseFloat(document.getElementById('discount_pct').value)||0;
    const bf=base-(base*disc/100);
    document.querySelectorAll('.variant-row').forEach(row=>{
        const ep=parseFloat(row.querySelector('.ep')?.value)||0;
        const fp=row.querySelector('.vfp');
        if(fp) fp.value='₹'+(bf+ep).toFixed(2);
    });
}
</script>

<?php include "footer.php"; ?>
