﻿<?php
session_start();
include "db.php";
if( !isset($_SESSION['admin']) && (($_SESSION['username'] ?? '') !== 'admin') && (($_SESSION['role'] ?? '') !== 'admin') ){
    // header("Location: ../admin.php");
    // exit();
}

// Delete event
if(isset($_GET['delete'])){
    $id=(int)$_GET['delete'];
    if($id > 0){
        $ok = mysqli_query($con,"DELETE FROM events WHERE id='$id'");
        header("Location: events.php?msg=".($ok?'deleted':'delete_failed'));
        exit();
    }
}

// Toggle status
if(isset($_GET['toggle'])){
    $id=(int)$_GET['toggle'];
    $r = mysqli_fetch_assoc(mysqli_query($con,"SELECT status FROM events WHERE id='$id'"));
    if($r){
        $ns = ($r['status']=='active') ? 'inactive' : 'active';
        mysqli_query($con,"UPDATE events SET status='$ns' WHERE id='$id'");
    }
    header("Location: events.php");
    exit();
}

$events = mysqli_query($con,"
    SELECT e.*, t.name as trainer_name
    FROM events e
    LEFT JOIN trainers t ON e.trainer_id=t.id
    ORDER BY e.event_date DESC, e.event_time DESC
");

$total   = $events ? mysqli_num_rows($events) : 0;
$active  = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(*) c FROM events WHERE status='active'"))['c'];
$pending = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(*) c FROM event_registrations WHERE status='pending'"))['c'];

include "header.php";

$msg = $_GET['msg'] ?? '';
$msgMap = [
    'deleted' => 'Event deleted successfully.',
    'delete_failed' => 'Could not delete event.'
];
?>

<div class="pg-title">Events Management</div>

<div class="sc-row">
    <div class="sc b"><div class="n"><?php echo $total; ?></div><div class="l">Total Events</div></div>
    <div class="sc g"><div class="n"><?php echo $active; ?></div><div class="l">Active Events</div></div>
    <div class="sc o"><div class="n"><?php echo $pending; ?></div><div class="l">Pending Requests</div></div>
</div>

<?php if($msg): ?>
    <div class="al <?php echo $msg==='deleted' ? 'al-s' : 'al-w'; ?>">
        <?php echo htmlspecialchars($msgMap[$msg] ?? 'Action completed.'); ?>
    </div>
<?php endif; ?>

<div style="display:flex;justify-content:flex-end;gap:10px;margin-bottom:16px;flex-wrap:wrap;">
    <a href="add_event.php" class="btn btn-g">Add New Event</a>
    <a href="event_requests.php" class="btn btn-o">
        Requests
        <?php if($pending>0): ?><span style="background:#e74c3c;color:#fff;border-radius:50%;padding:1px 7px;font-size:11px;margin-left:5px;"><?php echo $pending; ?></span><?php endif; ?>
    </a>
</div>

<div class="twrap">
    <div class="thead">All Events</div>
    <div class="tscroll">
    <table>
        <tr>
            <th>#</th><th>Title</th><th>Date &amp; Time</th><th>Location</th>
            <th>Trainer</th><th>Seats</th><th>Approved / Pending</th><th>Status</th><th>Actions</th>
        </tr>
        <?php $i=1; if($events && mysqli_num_rows($events)>0): while($ev=mysqli_fetch_assoc($events)):
            $approved_count = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(*) c FROM event_registrations WHERE event_id='{$ev['id']}' AND status='approved'"))['c'];
            $pending_count  = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(*) c FROM event_registrations WHERE event_id='{$ev['id']}' AND status='pending'"))['c'];
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><strong><?php echo htmlspecialchars($ev['title']); ?></strong></td>
            <td><?php echo date('d M Y',strtotime($ev['event_date'])); ?><?php if($ev['event_time']): ?><br><small style="color:#888;"><?php echo date('h:i A',strtotime($ev['event_time'])); ?></small><?php endif; ?></td>
            <td><?php echo htmlspecialchars($ev['location'] ?: '-'); ?></td>
            <td><?php echo $ev['trainer_name'] ? '<span style="color:#27ae60;">'.htmlspecialchars($ev['trainer_name']).'</span>' : '<span style="color:#aaa;">No Trainer</span>'; ?></td>
            <td><?php echo $ev['max_seats']>0 ? $ev['max_seats'] : '<span style="color:#aaa;">Unlimited</span>'; ?></td>
            <td><a href="event_requests.php?event_id=<?php echo $ev['id']; ?>" style="color:#2980b9;font-weight:600;"><?php echo $approved_count; ?> / <?php echo $pending_count; ?></a></td>
            <td><span class="bx <?php echo $ev['status']=='active'?'bx-s':'bx-d'; ?>"><?php echo ucfirst($ev['status']); ?></span></td>
            <td style="white-space:nowrap;">
                <a href="edit_event.php?id=<?php echo $ev['id']; ?>" class="btn btn-b">Update</a>
                <a href="?toggle=<?php echo $ev['id']; ?>" class="btn btn-w"><?php echo $ev['status']=='active'?'Deactivate':'Activate'; ?></a>
                <a href="?delete=<?php echo $ev['id']; ?>" class="btn btn-r" onclick="return confirm('Delete this event? Registrations will also be removed.');">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="9" style="text-align:center;color:#888;padding:20px;">No events yet. <a href="add_event.php">Add your first event.</a></td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php include "footer.php"; ?>
