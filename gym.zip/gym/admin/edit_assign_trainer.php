<?php
include "db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if(isset($_POST['update'])){
    $member_id  = (int)$_POST['member'];
    $trainer_id = (int)$_POST['trainer'];

    mysqli_query($con,"UPDATE assign_trainer SET member_id='$member_id',trainer_id='$trainer_id' WHERE id='$id'");

    header("Location: assign_trainer.php");
    exit();
}

$q        = mysqli_query($con,"SELECT * FROM assign_trainer WHERE id='$id'");
$a        = mysqli_fetch_assoc($q);
$members  = mysqli_query($con,"SELECT ud.id,ud.fullname,mp.plan_name FROM user_details ud JOIN membership_purchases mp ON ud.username=mp.username WHERE mp.status='approved' GROUP BY ud.id");
$trainers = mysqli_query($con,"SELECT * FROM trainers WHERE status='active' AND type='personal'");
?>
<?php include "header.php"; ?>

<?php if(!$a): ?>
    <div class="al al-d">Assignment not found.</div>
<?php else: ?>

<div class="pg-title">Edit Assignment</div>
<div class="card">
    <h2>Edit Trainer Assignment</h2>
    <form method="POST">
        <div class="frow">
            <div class="fg"><label>Select Member</label>
                <select name="member" required>
                    <option value="">-- Select Member --</option>
                    <?php while($m=mysqli_fetch_assoc($members)): ?>
                    <option value="<?php echo $m['id']; ?>" <?php echo $m['id']==$a['member_id']?'selected':''; ?>><?php echo htmlspecialchars($m['fullname']); ?> — <?php echo $m['plan_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="fg"><label>Select Trainer</label>
                <select name="trainer" required>
                    <option value="">-- Select Trainer --</option>
                    <?php while($t=mysqli_fetch_assoc($trainers)): ?>
                    <option value="<?php echo $t['id']; ?>" <?php echo $t['id']==$a['trainer_id']?'selected':''; ?>><?php echo htmlspecialchars($t['name']); ?> — <?php echo htmlspecialchars($t['specialization']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>
        <button type="submit" name="update" class="btn btn-o">💾 Update</button>
        <a href="assign_trainer.php" class="btn btn-dk" style="margin-left:10px;">Cancel</a>
    </form>
</div>

<?php endif; ?>
<?php include "footer.php"; ?>