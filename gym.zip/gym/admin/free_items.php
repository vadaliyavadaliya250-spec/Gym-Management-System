<?php
session_start();
include "db.php";
if( !isset($_SESSION['admin']) && (($_SESSION['username'] ?? '') !== 'admin') && (($_SESSION['role'] ?? '') !== 'admin') ){
    // header("Location: ../admin.php");
    // exit();
}

// Ensure free-item member status table exists
mysqli_query($con,"
CREATE TABLE IF NOT EXISTS free_membership_items (
    id INT(11) NOT NULL AUTO_INCREMENT,
    purchase_id INT(11) DEFAULT NULL,
    username VARCHAR(100) NOT NULL,
    member_name VARCHAR(150) DEFAULT NULL,
    plan_name VARCHAR(150) DEFAULT NULL,
    gymbag_status ENUM('not_given','given') DEFAULT 'not_given',
    bottle_status ENUM('not_given','given') DEFAULT 'not_given',
    note VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_purchase_id (purchase_id),
    KEY idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Ensure free-item stock table exists
mysqli_query($con,"
CREATE TABLE IF NOT EXISTS free_item_stock (
    item_key VARCHAR(30) NOT NULL,
    item_label VARCHAR(100) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (item_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Ensure stock log table exists
mysqli_query($con,"
CREATE TABLE IF NOT EXISTS free_item_stock_log (
    id INT(11) NOT NULL AUTO_INCREMENT,
    item_key VARCHAR(30) NOT NULL,
    change_type ENUM('add','reduce','adjustment','auto_issue','auto_return') NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    stock_before INT NOT NULL DEFAULT 0,
    stock_after INT NOT NULL DEFAULT 0,
    reference_id INT DEFAULT NULL,
    note VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_item_key (item_key),
    KEY idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Seed stock rows for two free items
mysqli_query($con,"
INSERT IGNORE INTO free_item_stock (item_key, item_label, stock)
VALUES
('gymbag','Gym Bag',0),
('bottle','Bottle',0)
");

$get_stock_map = function() use ($con): array {
    $map = [
        'gymbag' => ['label' => 'Gym Bag', 'stock' => 0],
        'bottle' => ['label' => 'Bottle',  'stock' => 0],
    ];
    $q = mysqli_query($con,"SELECT item_key, item_label, stock FROM free_item_stock");
    if($q){
        while($r = mysqli_fetch_assoc($q)){
            $k = $r['item_key'];
            $map[$k] = [
                'label' => $r['item_label'] ?: ucfirst($k),
                'stock' => (int)$r['stock']
            ];
        }
    }
    return $map;
};

$msg = '';
$msg_type = 'success';

// Keep free-items rows synced with approved memberships
mysqli_query($con,"
    INSERT INTO free_membership_items (purchase_id, username, member_name, plan_name)
    SELECT mp.id, mp.username, ud.fullname, mp.plan_name
    FROM membership_purchases mp
    LEFT JOIN user_details ud ON ud.username = mp.username
    LEFT JOIN free_membership_items fi ON fi.purchase_id = mp.id
    WHERE mp.status='approved' AND fi.id IS NULL
");

// Remove free-items rows when linked membership is no longer approved/cancelled/deleted.
mysqli_query($con,"
    DELETE fi
    FROM free_membership_items fi
    LEFT JOIN membership_purchases mp ON mp.id = fi.purchase_id
    WHERE fi.purchase_id IS NOT NULL
      AND (mp.id IS NULL OR mp.status <> 'approved')
");

// Manual stock management from popup
if(isset($_POST['update_free_stock'])){
    $item_key = trim((string)($_POST['item_key'] ?? ''));
    $change_type = trim((string)($_POST['change_type'] ?? 'add'));
    $quantity = (int)($_POST['quantity'] ?? 0);
    $note = mysqli_real_escape_string($con, trim((string)($_POST['note'] ?? '')));

    $allowed_items = ['gymbag', 'bottle'];
    $allowed_types = ['add', 'reduce', 'adjustment'];

    if(!in_array($item_key, $allowed_items, true) || !in_array($change_type, $allowed_types, true)){
        $msg = "Invalid stock action.";
        $msg_type = 'error';
    } else {
        $cur_row = mysqli_fetch_assoc(mysqli_query($con, "SELECT stock FROM free_item_stock WHERE item_key='".mysqli_real_escape_string($con,$item_key)."'"));
        $old = (int)($cur_row['stock'] ?? 0);

        if($change_type !== 'adjustment' && $quantity <= 0){
            $msg = "Quantity must be greater than 0.";
            $msg_type = 'error';
        } else {
            if($change_type === 'add'){
                $new = $old + $quantity;
                $move_qty = $quantity;
            } elseif($change_type === 'reduce'){
                if($quantity > $old){
                    $msg = "Cannot reduce more than current stock (".$old.").";
                    $msg_type = 'error';
                } else {
                    $new = $old - $quantity;
                    $move_qty = $quantity;
                }
            } else {
                if($quantity < 0){
                    $msg = "Exact stock cannot be negative.";
                    $msg_type = 'error';
                } else {
                    $new = $quantity;
                    $move_qty = abs($new - $old);
                }
            }

            if($msg === ''){
                mysqli_query($con,"UPDATE free_item_stock SET stock='".(int)$new."' WHERE item_key='".mysqli_real_escape_string($con,$item_key)."'");
                mysqli_query($con,"INSERT INTO free_item_stock_log (item_key, change_type, quantity, stock_before, stock_after, note)
                                 VALUES ('".mysqli_real_escape_string($con,$item_key)."','".mysqli_real_escape_string($con,$change_type)."','".(int)$move_qty."','".(int)$old."','".(int)$new."','$note')");
                $msg = "Free item stock updated.";
                $msg_type = 'success';
            }
        }
    }
}

// Update member row + auto stock issue/return
if(isset($_POST['update_item'])){
    $id = (int)($_POST['id'] ?? 0);
    $gymbag = ($_POST['gymbag_status'] ?? 'not_given') === 'given' ? 'given' : 'not_given';
    $bottle = ($_POST['bottle_status'] ?? 'not_given') === 'given' ? 'given' : 'not_given';
    $note = mysqli_real_escape_string($con, trim($_POST['note'] ?? ''));

    if($id > 0){
        $old_item = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM free_membership_items WHERE id='$id'"));
        if($old_item){
            $stock_map = $get_stock_map();

            $need_issue_gymbag = ($old_item['gymbag_status'] !== 'given' && $gymbag === 'given');
            $need_issue_bottle = ($old_item['bottle_status'] !== 'given' && $bottle === 'given');
            $need_return_gymbag = ($old_item['gymbag_status'] === 'given' && $gymbag !== 'given');
            $need_return_bottle = ($old_item['bottle_status'] === 'given' && $bottle !== 'given');

            if($need_issue_gymbag && (int)$stock_map['gymbag']['stock'] <= 0){
                $msg = "Gym Bag stock is 0. Add stock first.";
                $msg_type = 'error';
            } elseif($need_issue_bottle && (int)$stock_map['bottle']['stock'] <= 0){
                $msg = "Bottle stock is 0. Add stock first.";
                $msg_type = 'error';
            } else {
                mysqli_begin_transaction($con);
                try {
                    mysqli_query($con,"UPDATE free_membership_items SET gymbag_status='$gymbag', bottle_status='$bottle', note='$note' WHERE id='$id'");

                    if($need_issue_gymbag){
                        $cur = mysqli_fetch_assoc(mysqli_query($con,"SELECT stock FROM free_item_stock WHERE item_key='gymbag' FOR UPDATE"));
                        $old = (int)($cur['stock'] ?? 0);
                        if($old <= 0){ throw new Exception('Gym Bag stock finished while updating.'); }
                        $new = $old - 1;
                        mysqli_query($con,"UPDATE free_item_stock SET stock='$new' WHERE item_key='gymbag'");
                        mysqli_query($con,"INSERT INTO free_item_stock_log (item_key,change_type,quantity,stock_before,stock_after,reference_id,note)
                                         VALUES ('gymbag','auto_issue',1,'$old','$new','$id','Auto deduct when marked Given')");
                    }

                    if($need_issue_bottle){
                        $cur = mysqli_fetch_assoc(mysqli_query($con,"SELECT stock FROM free_item_stock WHERE item_key='bottle' FOR UPDATE"));
                        $old = (int)($cur['stock'] ?? 0);
                        if($old <= 0){ throw new Exception('Bottle stock finished while updating.'); }
                        $new = $old - 1;
                        mysqli_query($con,"UPDATE free_item_stock SET stock='$new' WHERE item_key='bottle'");
                        mysqli_query($con,"INSERT INTO free_item_stock_log (item_key,change_type,quantity,stock_before,stock_after,reference_id,note)
                                         VALUES ('bottle','auto_issue',1,'$old','$new','$id','Auto deduct when marked Given')");
                    }

                    if($need_return_gymbag){
                        $cur = mysqli_fetch_assoc(mysqli_query($con,"SELECT stock FROM free_item_stock WHERE item_key='gymbag' FOR UPDATE"));
                        $old = (int)($cur['stock'] ?? 0);
                        $new = $old + 1;
                        mysqli_query($con,"UPDATE free_item_stock SET stock='$new' WHERE item_key='gymbag'");
                        mysqli_query($con,"INSERT INTO free_item_stock_log (item_key,change_type,quantity,stock_before,stock_after,reference_id,note)
                                         VALUES ('gymbag','auto_return',1,'$old','$new','$id','Auto return when changed back to Not Given')");
                    }

                    if($need_return_bottle){
                        $cur = mysqli_fetch_assoc(mysqli_query($con,"SELECT stock FROM free_item_stock WHERE item_key='bottle' FOR UPDATE"));
                        $old = (int)($cur['stock'] ?? 0);
                        $new = $old + 1;
                        mysqli_query($con,"UPDATE free_item_stock SET stock='$new' WHERE item_key='bottle'");
                        mysqli_query($con,"INSERT INTO free_item_stock_log (item_key,change_type,quantity,stock_before,stock_after,reference_id,note)
                                         VALUES ('bottle','auto_return',1,'$old','$new','$id','Auto return when changed back to Not Given')");
                    }

                    mysqli_commit($con);
                    $msg = "Free item status updated.";
                    $msg_type = 'success';
                } catch (Throwable $e) {
                    mysqli_rollback($con);
                    $msg = "Update failed: " . $e->getMessage();
                    $msg_type = 'error';
                }
            }
        }
    }
}

// Delete row
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    if($id > 0){
        mysqli_query($con,"DELETE FROM free_membership_items WHERE id='$id'");
        header("Location: free_items.php?msg=deleted");
        exit();
    }
}

if(isset($_GET['msg']) && $_GET['msg']==='deleted'){
    $msg = "Free item record deleted.";
    $msg_type = 'success';
}

$rows = mysqli_query($con,"
    SELECT fi.*,
           CASE WHEN fi.gymbag_status='given' AND fi.bottle_status='given' THEN 'Got' ELSE 'Not Yet' END AS overall_status
    FROM free_membership_items fi
    ORDER BY fi.updated_at DESC, fi.id DESC
");

$stock_map = $get_stock_map();
$stock_logs = mysqli_query($con,"
    SELECT * FROM free_item_stock_log
    ORDER BY created_at DESC, id DESC
    LIMIT 20
");

$tot = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(*) c FROM free_membership_items"))['c'];
$got = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(*) c FROM free_membership_items WHERE gymbag_status='given' AND bottle_status='given'"))['c'];
$pending = (int)$tot - (int)$got;

include "header.php";
?>

<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div class="pg-title" style="margin-bottom:0;">Free Items</div>
    <button type="button" class="btn btn-dk" onclick="openStockModal()">Manage Stock</button>
</div>

<div style="margin-top:12px;"></div>
<?php if($msg): ?><div class="al <?php echo $msg_type==='error'?'al-d':'al-s'; ?>"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

<div class="sc-row">
    <div class="sc b"><div class="n"><?php echo (int)$tot; ?></div><div class="l">Members Listed</div></div>
    <div class="sc g"><div class="n"><?php echo (int)$got; ?></div><div class="l">Items Given</div></div>
    <div class="sc o"><div class="n"><?php echo (int)$pending; ?></div><div class="l">Pending Items</div></div>
    <div class="sc" style="border-left-color:#2980b9;"><div class="n"><?php echo (int)$stock_map['gymbag']['stock']; ?></div><div class="l">Gym Bag Stock</div></div>
    <div class="sc" style="border-left-color:#16a085;"><div class="n"><?php echo (int)$stock_map['bottle']['stock']; ?></div><div class="l">Bottle Stock</div></div>
</div>

<div class="twrap">
    <div class="thead">Membership Members - Free Items Status (Gym Bag / Bottle)</div>
    <div class="tscroll">
    <table>
        <tr>
            <th>#</th><th>Username</th><th>Member Name</th><th>Plan</th><th>Gym Bag</th><th>Bottle</th><th>Overall</th><th>Note</th><th>Updated</th><th>Actions</th>
        </tr>
        <?php $i=1; if($rows && mysqli_num_rows($rows)>0): while($r=mysqli_fetch_assoc($rows)): ?>
        <tr>
            <form method="POST">
                <td><?php echo $i++; ?><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>"></td>
                <td><?php echo htmlspecialchars($r['username']); ?></td>
                <td><?php echo htmlspecialchars($r['member_name'] ?: '-'); ?></td>
                <td><?php echo htmlspecialchars($r['plan_name'] ?: '-'); ?></td>
                <td>
                    <select name="gymbag_status" style="padding:6px;">
                        <option value="not_given" <?php echo $r['gymbag_status']==='not_given'?'selected':''; ?>>Not Given</option>
                        <option value="given" <?php echo $r['gymbag_status']==='given'?'selected':''; ?>>Given</option>
                    </select>
                </td>
                <td>
                    <select name="bottle_status" style="padding:6px;">
                        <option value="not_given" <?php echo $r['bottle_status']==='not_given'?'selected':''; ?>>Not Given</option>
                        <option value="given" <?php echo $r['bottle_status']==='given'?'selected':''; ?>>Given</option>
                    </select>
                </td>
                <td>
                    <span class="bx <?php echo $r['overall_status']==='Got'?'bx-s':'bx-w'; ?>"><?php echo $r['overall_status']; ?></span>
                </td>
                <td><input type="text" name="note" value="<?php echo htmlspecialchars($r['note'] ?? ''); ?>" placeholder="Optional note" style="min-width:140px;"></td>
                <td><?php echo date('d M Y H:i', strtotime($r['updated_at'])); ?></td>
                <td style="white-space:nowrap;">
                    <button class="btn btn-b" type="submit" name="update_item" value="1">Update</button>
                    <a class="btn btn-r" href="?delete=<?php echo (int)$r['id']; ?>" onclick="return confirm('Delete this free item record?');">Delete</a>
                </td>
            </form>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="10" style="text-align:center;color:#888;padding:20px;">No approved membership members yet.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<div class="twrap">
    <div class="thead">Free Item Stock Log (Last 20)</div>
    <div class="tscroll">
        <table>
            <tr><th>Item</th><th>Type</th><th>Qty</th><th>Before</th><th>After</th><th>Note</th><th>Date</th></tr>
            <?php if($stock_logs && mysqli_num_rows($stock_logs)>0): ?>
                <?php while($l=mysqli_fetch_assoc($stock_logs)): ?>
                    <?php
                        $tc = '#333';
                        if(in_array($l['change_type'], ['add','auto_return'], true)) $tc = '#27ae60';
                        if(in_array($l['change_type'], ['reduce','auto_issue'], true)) $tc = '#e74c3c';
                        if($l['change_type'] === 'adjustment') $tc = '#2980b9';
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($l['item_key']==='gymbag' ? 'Gym Bag' : 'Bottle'); ?></td>
                        <td style="color:<?php echo $tc; ?>;font-weight:700;"><?php echo htmlspecialchars(ucfirst(str_replace('_',' ',$l['change_type']))); ?></td>
                        <td><?php echo (int)$l['quantity']; ?></td>
                        <td><?php echo (int)$l['stock_before']; ?></td>
                        <td><strong><?php echo (int)$l['stock_after']; ?></strong></td>
                        <td><?php echo htmlspecialchars((string)($l['note'] ?? '')); ?></td>
                        <td><?php echo date('d M Y H:i', strtotime($l['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;color:#888;padding:20px;">No stock movements yet.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<style>
.modal-backdrop{
    position:fixed; inset:0; background:rgba(0,0,0,0.45); display:none;
    align-items:center; justify-content:center; z-index:1600;
}
.modal-box{
    width:min(520px,92vw); background:#fff; border-radius:10px; padding:20px;
    box-shadow:0 10px 26px rgba(0,0,0,0.2);
}
.modal-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;}
.modal-head h3{font-size:18px;color:#1a1a2e;}
.xbtn{border:none;background:#f1f3f5;padding:5px 10px;border-radius:6px;cursor:pointer;font-weight:700;}
</style>

<div class="modal-backdrop" id="stockModal" onclick="if(event.target===this){closeStockModal();}">
    <div class="modal-box">
        <div class="modal-head">
            <h3>Manage Free Item Stock</h3>
            <button type="button" class="xbtn" onclick="closeStockModal()">X</button>
        </div>
        <form method="POST">
            <input type="hidden" name="update_free_stock" value="1">
            <div class="frow">
                <div class="fg">
                    <label>Item</label>
                    <select name="item_key" required>
                        <option value="gymbag">Gym Bag (Current: <?php echo (int)$stock_map['gymbag']['stock']; ?>)</option>
                        <option value="bottle">Bottle (Current: <?php echo (int)$stock_map['bottle']['stock']; ?>)</option>
                    </select>
                </div>
                <div class="fg">
                    <label>Change Type</label>
                    <select name="change_type" id="changeType" required onchange="updateQtyLabel()">
                        <option value="add">Add</option>
                        <option value="reduce">Reduce</option>
                        <option value="adjustment">Set Exact</option>
                    </select>
                </div>
                <div class="fg">
                    <label id="qtyLabel">Quantity</label>
                    <input type="number" name="quantity" min="0" required>
                </div>
                <div class="fg full-w">
                    <label>Note (optional)</label>
                    <input type="text" name="note" placeholder="Reason for stock change">
                </div>
            </div>
            <button class="btn btn-o" type="submit">Save Stock Change</button>
            <button class="btn" type="button" style="background:#f1f3f5;color:#333;margin-left:8px;" onclick="closeStockModal()">Cancel</button>
        </form>
    </div>
</div>

<script>
function openStockModal(){
    document.getElementById('stockModal').style.display = 'flex';
}
function closeStockModal(){
    document.getElementById('stockModal').style.display = 'none';
}
function updateQtyLabel(){
    var t = document.getElementById('changeType').value;
    var l = document.getElementById('qtyLabel');
    if(t === 'adjustment') l.textContent = 'Exact Stock Value';
    else if(t === 'reduce') l.textContent = 'Quantity to Reduce';
    else l.textContent = 'Quantity to Add';
}
<?php if(isset($_GET['open_stock'])): ?>
openStockModal();
<?php endif; ?>
</script>

<?php include "footer.php"; ?>
