﻿<?php
header('Location: newhome.php#events');
exit;

