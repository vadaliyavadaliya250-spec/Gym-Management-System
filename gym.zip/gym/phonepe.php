<?php
$merchantId = 'MERCHANTUAT'; // SANDBOX MERCHANT ID
$apiKey = '099eb0cd-02cf-4e2a-8aca-3e6c6aff0399'; // SANDBOX API KEY
$redirectUrl = 'http://localhost/gym/success.php';

$paymentData = [
    "merchantId" => $merchantId,
    "merchantTransactionId" => "MT" . rand(111111,999999), 
    "merchantUserId" => "MUID" . time(),
    "amount" => 100 * 100, // Amount in paise (100 INR)
    "redirectUrl" => $redirectUrl,
    "redirectMode" => "POST",
    "callbackUrl" => $redirectUrl,
    "mobileNumber" => "9999999999",
    "paymentInstrument" => [
        "type" => "PAY_PAGE"
    ]
];

$payloadMain = base64_encode(json_encode($paymentData));
$salt_index = 1; // KEY_INDEX
$payload = $payloadMain . "/pg/v1/pay" . $apiKey;
$sha256 = hash("sha256", $payload);
$final_x_header = $sha256 . '###' . $salt_index;

// $url = "https://api.phonepe.com/apis/hermes/pg/v1/pay"; // <PRODUCTION URL>
$url = "https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay"; // <TESTING URL>

$curl = curl_init($url);

curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    "Content-Type: application/json",
    "X-VERIFY: " . $final_x_header,
    "accept: application/json"
));
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(['request' => $payloadMain]));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    $res = json_decode($response);
    
    if(isset($res->success) && $res->success == '1'){
        $payUrl = $res->data->instrumentResponse->redirectInfo->url;
        header('Location:' . $payUrl);
    } else {
        echo "Payment Initiation Failed: " . print_r($res, true);
    }
}
?>