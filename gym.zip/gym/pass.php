<?php
$password = "";

if(isset($_POST['generate'])){
    $password = bin2hex(random_bytes(6)); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title></title>
<style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        background: linear-gradient(135deg, #74ebd5, #acb6e5);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .outer {
        background: #fff;
        padding: 30px 40px;
        border-radius: 15px;
        box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        width: 300px;
        text-align: center;
    }

    .outer h2 {
        margin-bottom: 20px;
        color: #333;
    }

    select, input[type="text"], input[type="password"] {
        width: 100%;
        padding: 12px 15px;
        margin: 10px 0;
        border-radius: 8px;
        border: 1px solid #ccc;
        outline: none;
        transition: 0.3s;
        font-size: 14px;
    }

    select:focus, input[type="text"]:focus, input[type="password"]:focus {
        border-color: black;
        box-shadow: 0 0 5px rgba(108,99,255,0.5);
    }

    input[type="submit"] {
        background: #6c63ff;
        color: #fff;
        padding: 12px 20px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        margin-top: 15px;
        transition: 0.3s;
    }

    input[type="submit"]:hover {
        background: #574fd6;
    }


</style>
</head>
<body>

<div class="outer">
    <h2>Password 2.0</h2>
    <form action="" method="POST">
        <select name="social">
            <option value="">Select Social Media</option>
            <option value="instagram">Instagram</option>
            <option value="snapchat">Snapchat</option>
            <option value="gmail">Gmail</option>
            <option value="facebook">Facebook</option>
        </select>
        <input type="text" name="n2" placeholder="Username" required>
       <input type="text" name="password" value="<?php echo $password; ?>" placeholder="Your Password">
       <button type="submit" name="generate">Generate Password</button>

        <input type="submit" name="b2" value="Submit">
    </form>
</div>


</body>
</html>














