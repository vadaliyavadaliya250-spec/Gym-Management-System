<?php
session_start();
$con = mysqli_connect("localhost","root","","gym");
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: newhome.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = mysqli_real_escape_string($con, $_POST['name']);
    $email   = mysqli_real_escape_string($con, $_POST['email']);
    $message = mysqli_real_escape_string($con, $_POST['message']);
    $sql = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";
    if (mysqli_query($con, $sql)) {
        echo "<script>alert('Message sent successfully!');window.location.href='newhome.php#contact';</script>";
    } else {
        echo "<script>alert('Something went wrong!');window.history.back();</script>";
    }
}

$prod_cats = mysqli_query($con,"SELECT * FROM product_categories WHERE status='active' ORDER BY category_name");
$cat_list = [];
if($prod_cats) while($pc = mysqli_fetch_assoc($prod_cats)) $cat_list[] = $pc;

$active_cat = isset($_GET['pcat']) ? (int)$_GET['pcat'] : 0;
$pcat_where = $active_cat ? "AND p.category_id='$active_cat'" : "";

$prod_res = mysqli_query($con,"
    SELECT p.id, p.product_name, p.image, p.description, pc.category_name, pc.id as cat_id,
           MIN(pv.final_price) as min_price, MAX(pv.final_price) as max_price,
           COALESCE(SUM(pv.stock),0) as total_stock,
           COUNT(DISTINCT pv.id) as variant_count
    FROM products_new p
    JOIN product_categories pc ON pc.id=p.category_id
    LEFT JOIN product_variants pv ON pv.product_id=p.id
    WHERE p.status='active' $pcat_where
    GROUP BY p.id
    ORDER BY p.created_at DESC
    LIMIT 12
");
$all_products = [];
if($prod_res){
    while($pr = mysqli_fetch_assoc($prod_res)) {
        $attr_res = mysqli_query($con,"
            SELECT DISTINCT pat.attribute_name as attr_name,
                   GROUP_CONCAT(DISTINCT av.value_label ORDER BY av.sort_order SEPARATOR ', ') as values_list
            FROM product_variants pv
            JOIN variant_attributes va ON va.variant_id=pv.id
            JOIN attribute_values av ON av.id=va.value_id
            JOIN product_attribute_types pat ON pat.id=va.attribute_id
            WHERE pv.product_id='{$pr['id']}'
            GROUP BY pat.id ORDER BY pat.id
        ");
        $pr['attributes'] = [];
        if($attr_res) while($ar = mysqli_fetch_assoc($attr_res)) $pr['attributes'][] = $ar;
        $all_products[] = $pr;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Gymness</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
* { margin:0; padding:0; box-sizing:border-box; font-family:Arial, Helvetica, sans-serif; color:black; }
html { scroll-behavior:smooth; }
.navbar { padding:20px 60px; display:flex; justify-content:space-between; align-items:center; position:sticky; top:0; background:#fff; z-index:10; box-shadow:0 2px 10px rgba(0,0,0,0.1); }
.logo { font-size:26px; font-weight:800; }
.nav-menu { list-style:none; display:flex; gap:30px; }
.nav-menu li a { text-decoration:none; color:black; font-weight:600; transition:color 0.3s; padding:8px 0; }
.nav-menu li a:hover { color:#c82027; }
.nav-btns button { padding:12px 24px; border-radius:8px; border:none; cursor:pointer; margin-left:10px; font-weight:600; transition:all 0.3s; }
.nav-btns button:hover { transform:translateY(-2px); }
.nav-btns a { text-decoration:none; color:black; }
.signup { background:#c82027 !important; }
.signup a { color:white !important; }
.profile-link { display:flex; align-items:center; padding:12px 24px; border-radius:8px; text-decoration:none; font-weight:600; color:black; transition:all 0.3s; }
.profile-link:hover { background:#f8f9fa; color:#c82027; }
.profile-icon { font-size:26px; margin-right:12px; color:#c82027; }
.dropdown-menu { border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,0.2); border:none; margin-top:12px; }
.dropdown-item { padding:12px 20px; font-weight:500; transition:all 0.3s; }
.dropdown-item:hover { background:#f8f9fa; padding-left:28px; }
.hero { padding:80px 60px; display:flex; align-items:center; background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%); }
.hero-left { width:50%; }
.hero-left span { color:#c82027; letter-spacing:2px; font-weight:600; }
.hero-left h1 { font-size:52px; margin:20px 0; line-height:1.2; }
.hero-left p { color:#666; max-width:480px; font-size:18px; }
.hero-left button { margin-top:30px; margin-right:10px; padding:16px 32px; border:none; border-radius:8px; background:#c82027; color:#fff; font-weight:600; cursor:pointer; transition:all 0.3s; }
.hero-left button:hover { transform:translateY(-3px); box-shadow:0 10px 25px rgba(200,32,39,0.3); }
.hero-right { width:50%; }
.hero-right img { width:100%; border-radius:20px; box-shadow:0 20px 40px rgba(0,0,0,0.1); }
.section { background:#111; color:white; padding:90px 60px; display:flex; gap:60px; }
.section-left,.section-right { width:50%; }
.section-left img,.section-right img { width:100%; border-radius:20px; }
.section-right span { color:#c82027; letter-spacing:2px; font-weight:600; }
.section-right h2 { font-size:40px; margin:15px 0; }
.section-right p { color:#ccc; line-height:1.7; font-size:16px; }
.section-box { background:#1f1f1f; padding:25px; margin:25px 0; border-left:4px solid #c82027; border-radius:10px; }
.contact { padding:90px 60px; background:#f8f9fa; }
.contact-title { text-align:center; margin-bottom:60px; }
.contact-title span { color:#c82027; letter-spacing:2px; font-weight:600; }
.contact-title h2 { font-size:40px; margin-top:10px; }
.contact-wrapper { display:flex; gap:40px; }
.info-card { background:white; padding:35px; border-radius:20px; box-shadow:0 15px 35px rgba(0,0,0,0.1); transition:all 0.4s; flex:1; min-width:320px; }
.info-card:hover { transform:translateY(-12px); box-shadow:0 25px 50px rgba(0,0,0,0.2); }
.info-card h4 { margin-bottom:15px; color:#c82027; font-size:24px; }
.contact-info { width:40%; display:flex; flex-direction:column; gap:20px; }
.contact-form { width:60%; background:white; padding:45px; border-radius:20px; box-shadow:0 15px 35px rgba(0,0,0,0.1); }
.contact-form input,.contact-form textarea { width:100%; padding:16px; margin-bottom:20px; border-radius:10px; border:1px solid #ddd; font-size:16px; }
.contact-form button { padding:16px 40px; background:#c82027; color:white; border:none; border-radius:10px; cursor:pointer; font-size:16px; font-weight:600; width:100%; transition:all 0.3s; }
.contact-form button:hover { transform:translateY(-2px); }
.footer { background:#000; color:#aaa; text-align:center; padding:30px; font-size:14px; }
.membership-section { padding:100px 60px; background:linear-gradient(135deg,#ffffff,#f0f2f5); }
.membership-container { display:flex; align-items:center; justify-content:space-between; gap:60px; }
.membership-left { width:50%; }
.membership-left span { color:#c82027; letter-spacing:2px; font-weight:600; }
.membership-left h2 { font-size:42px; margin:20px 0; font-weight:800; }
.membership-left p { color:#555; font-size:17px; line-height:1.7; margin-bottom:30px; }
.membership-points .point { display:flex; align-items:center; margin-bottom:15px; font-size:16px; font-weight:500; }
.membership-points i { color:#c82027; margin-right:12px; font-size:20px; }
.explore-btn { display:inline-block; margin-top:30px; padding:15px 35px; background:#c82027; color:white; text-decoration:none; border-radius:8px; font-weight:600; transition:all 0.3s; }
.explore-btn:hover { background:black; color:white; transform:translateY(-3px); box-shadow:0 10px 25px rgba(0,0,0,0.2); }
.membership-right { width:50%; }
.membership-right img { width:100%; border-radius:20px; box-shadow:0 25px 50px rgba(0,0,0,0.15); }
/* PRODUCTS */
.products-section { padding:80px 60px; background:#f4f6fb; }
.prod-filter-tabs { display:flex; gap:10px; flex-wrap:wrap; justify-content:center; margin-bottom:35px; }
.prod-filter-tab { padding:9px 24px; border-radius:25px; border:2px solid #ddd; background:#fff; cursor:pointer; font-weight:600; font-size:13px; text-decoration:none; color:#333; transition:all 0.2s; }
.prod-filter-tab:hover,.prod-filter-tab.active { background:#c82027; color:#fff; border-color:#c82027; }
.prod-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:24px; max-width:1200px; margin:0 auto; }
.prod-card { background:#fff; border-radius:16px; overflow:hidden; box-shadow:0 4px 18px rgba(0,0,0,0.09); transition:transform 0.2s,box-shadow 0.2s; }
.prod-card:hover { transform:translateY(-6px); box-shadow:0 14px 35px rgba(0,0,0,0.15); }
.prod-card img { width:100%; height:200px; object-fit:cover; }
.prod-card-noimg { width:100%; height:200px; background:linear-gradient(135deg,#f0f0f0,#e0e0e0); display:flex; align-items:center; justify-content:center; font-size:60px; }
.prod-card-body { padding:16px; }
.prod-cat-badge { display:inline-block; background:#fff3e0; color:#e65100; font-size:11px; font-weight:700; padding:3px 10px; border-radius:20px; margin-bottom:8px; }
.prod-card-body h3 { font-size:16px; font-weight:700; margin:0 0 8px; color:#1a1a2e; }
.prod-attrs { display:flex; flex-wrap:wrap; gap:5px; margin:8px 0; }
.prod-attr-chip { background:#eef2ff; color:#3949ab; font-size:11px; padding:3px 9px; border-radius:12px; font-weight:600; }
.prod-attr-label { color:#888; font-size:10px; margin-right:2px; }
.prod-price { font-size:19px; font-weight:800; color:#c82027; margin:10px 0 4px; }
.prod-price-range { font-size:13px; color:#999; }
.prod-stock-ok { color:#27ae60; font-size:12px; font-weight:600; }
.prod-stock-out { color:#e74c3c; font-size:12px; font-weight:600; }
.prod-variants-badge { font-size:11px; color:#888; margin-bottom:5px; }
.prod-no-data { text-align:center; padding:60px; color:#aaa; font-size:16px; grid-column:1/-1; }
</style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
<div class="logo">UNIQUE GYM</div>
<ul class="nav-menu">
<li><a href="#">Home</a></li>
<li><a href="#about">About</a></li>
<li><a href="#product">Products</a></li>
<li><a href="#membership">Membership</a></li>
<li><a href="#contact">Contact</a></li>
</ul>
<div class="nav-btns">
<?php if (empty($username)): ?>
    <button class="login" style="background:#0066ff;"><a href="login.php">Login</a></button>
    <button class="signup"><a href="signup.php">Sign Up</a></button>
<?php else: ?>
    <div class="dropdown">
        <a href="#" class="profile-link dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle profile-icon"></i>
            <span><?php echo htmlspecialchars($username); ?></span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
            <li><a class="dropdown-item" href="sampleprofile.php"><i class="bi bi-person me-2"></i>View Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="?logout=1"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
    </div>
<?php endif; ?>
</div>
</div>

<!-- HERO -->
<div class="hero">
<div class="hero-left">
<span>WELCOME AT UNIQUE GYM</span>
<h1>THE MOST COMPLETED<br>GYM TO WORK OUT</h1>
<p>Build your body, improve your strength and stay fit with our professional trainers.</p>
<button onclick="location.href='#about'">About Us</button>
<button onclick="location.href='#contact'">Contact</button>
</div>
<div class="hero-right"><img src="image1.jpeg" alt="Gym"></div>
</div>

<!-- ABOUT -->
<div class="section" id="about">
<div class="section-left"><img src="image1.jpeg" alt="About"></div>
<div class="section-right">
<span>ABOUT UNIQUE GYM</span>
<h2 style="color:white;">We Help You Build Your Body</h2>
<p>Unique Gym is a modern fitness center where strength, discipline and healthy lifestyle come together.</p>
<div class="section-box" style="color:white;">✔ Certified Trainers<br>✔ Yoga &amp; Zumba <br>✔ Modern Equipment</div>
<p>Join Unique Gym and transform yourself with expert guidance and a motivating environment.</p>
</div>
</div>

<!-- MEMBERSHIP -->
<div class="membership-section" id="membership">
<div class="membership-container">
<div class="membership-left">
<span>OUR MEMBERSHIP</span>
<h2>Flexible Plans Designed For Every Fitness Goal</h2>
<p>Whether you're just starting your fitness journey or you're a professional athlete, Gymness offers flexible and affordable membership plans tailored to your needs.</p>
<div class="membership-points">
<div class="point"><i class="bi bi-check-circle-fill"></i>Access to modern gym equipment</div>
<div class="point"><i class="bi bi-check-circle-fill"></i>Certified personal trainers</div>
<div class="point"><i class="bi bi-check-circle-fill"></i>Steam, sauna &amp; shower facility</div>
<div class="point"><i class="bi bi-check-circle-fill"></i>Flexible duration plans</div>
</div>
<a href="mmm.php" class="explore-btn">Explore Membership Plans →</a>
</div>
<div class="membership-right"><img src="image1.jpeg" alt="Membership"></div>
</div>
</div>

<!-- PRODUCTS -->
<div class="products-section" id="product">
<div class="contact-title">
<span>PRODUCTS</span>
<h2>Our Gym Products</h2>
<p style="color:#666;margin-top:8px;">Browse products — available to all visitors</p>
</div>

<!-- Category Filter Tabs -->
<div class="prod-filter-tabs">
    <a href="newhome.php#product" class="prod-filter-tab <?php echo $active_cat==0?'active':''; ?>">🏠 All</a>
    <?php foreach($cat_list as $cl):
        $icons=['equipments'=>'🏋️','supplements'=>'💊','merchandise'=>'👕'];
        $slug=strtolower(str_replace(' ','-',$cl['category_name']));
        $icon=$icons[$slug]??'📦';
    ?>
    <a href="newhome.php?pcat=<?php echo $cl['id']; ?>#product"
       class="prod-filter-tab <?php echo $active_cat==$cl['id']?'active':''; ?>">
        <?php echo $icon.' '.htmlspecialchars($cl['category_name']); ?>
    </a>
    <?php endforeach; ?>
</div>

<!-- Products Grid -->
<div class="prod-grid">
<?php if(count($all_products)>0): ?>
    <?php foreach($all_products as $prod): ?>
    <div class="prod-card">
        <?php if(!empty($prod['image'])): ?>
        <img src="uploads/products/<?php echo htmlspecialchars($prod['image']); ?>" alt="<?php echo htmlspecialchars($prod['product_name']); ?>">
        <?php else: ?><div class="prod-card-noimg">📦</div><?php endif; ?>
        <div class="prod-card-body">
            <div class="prod-cat-badge"><?php echo htmlspecialchars($prod['category_name']); ?></div>
            <h3><?php echo htmlspecialchars($prod['product_name']); ?></h3>
            <?php if(!empty($prod['attributes'])): ?>
            <div class="prod-attrs">
                <?php foreach($prod['attributes'] as $attr): ?>
                <span class="prod-attr-chip">
                    <span class="prod-attr-label"><?php echo htmlspecialchars($attr['attr_name']); ?>:</span>
                    <?php echo htmlspecialchars($attr['values_list']); ?>
                </span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php if($prod['variant_count']>1): ?>
            <div class="prod-variants-badge">📦 <?php echo $prod['variant_count']; ?> variants available</div>
            <?php endif; ?>
            <div class="prod-price">
                ₹<?php echo number_format($prod['min_price'],2); ?>
                <?php if($prod['min_price']!=$prod['max_price']): ?>
                <span class="prod-price-range"> – ₹<?php echo number_format($prod['max_price'],2); ?></span>
                <?php endif; ?>
            </div>
            <?php if($prod['total_stock']>0): ?>
            <div class="prod-stock-ok">✅ In Stock (<?php echo $prod['total_stock']; ?> units)</div>
            <?php else: ?>
            <div class="prod-stock-out">❌ Out of Stock</div>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="prod-no-data">📭 No products available yet.<br><small>Check back soon!</small></div>
<?php endif; ?>
</div>

<div style="text-align:center;margin-top:40px;">
<a href="products.php" style="display:inline-block;padding:14px 36px;background:#c82027;color:#fff;border-radius:8px;font-weight:700;font-size:15px;text-decoration:none;">View All Products →</a>
</div>
</div>

<!-- CONTACT -->
<div class="contact" id="contact">
<div class="contact-title">
<span>CONTACT US</span>
<h2>We'd Love To Hear From You</h2>
</div>
<div class="contact-wrapper">
<div class="contact-info">
<div class="info-card"><h4><i class="bi bi-geo-alt me-2 text-primary"></i>Address</h4>Ghodasar, Ahmedabad</div>
<div class="info-card"><h4><i class="bi bi-telephone me-2 text-success"></i>Phone</h4>+91 98765 43210</div>
<div class="info-card"><h4><i class="bi bi-envelope me-2 text-danger"></i>Email</h4><a href="mailto:gymness@gmail.com">gymness@gmail.com</a></div>
</div>
<div class="contact-form">
<h3>Send Message</h3>
<form action="newhome.php" method="POST">
<input type="text" name="name" placeholder="Your Name" required>
<input type="email" name="email" placeholder="Your Email" required>
<textarea name="message" rows="5" placeholder="Your Message" required></textarea>
<button type="submit">Send Message <i class="bi bi-send ms-2"></i></button>
</form>
</div>
</div>
</div>

<div class="footer"><?php include 'footer.php';?></div>

</body>
</html>