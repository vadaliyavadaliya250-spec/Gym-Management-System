<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="home.css">

</head>
<body>

<?php include "header.php"; ?>
    
<div id="main">
    <section class="hero">
        <img src="slide2.jpeg" class="hero-img" alt="Gym Image">
        <div class="hero-text">
            <h1>We Create <span>Stronger You</span></h1>
            <p>Train Hard | Stay Fit | Be Unstoppable</p>
        </div>
    </section>
</div>





































<?php include "footer.php"; ?>
</body>
</html>