<?php
session_start();
$conn = mysqli_connect("localhost","root","","gym");
if(!$conn){ die("Connection Failed"); }

// Plans fetch
$result = mysqli_query($conn,"SELECT * FROM membership_plans WHERE status='active'");
$plans = [];
while($row = mysqli_fetch_assoc($result)){ $plans[] = $row; }

$success = $error = "";
if(isset($_POST['buy_plan'])){
    $user_id = $_SESSION['user_id'] ?? 1;
    $plan_id = (int)$_POST['plan_id'];
    
    $plan_query = mysqli_query($conn,"SELECT * FROM membership_plans WHERE id=$plan_id");
    $plan = mysqli_fetch_assoc($plan_query);
    
    if($plan){
        $days = $plan['duration_days'] ?? $plan['days'] ?? 30;
        $end_date = date('Y-m-d', strtotime("+{$days} days"));
        $txn_id = 'TXN_' . time();
        
        // Table exists check + safe insert
        $check_table = mysqli_query($conn,"SHOW TABLES LIKE 'user_memberships'");
        if(mysqli_num_rows($check_table) > 0){
            $sql = "INSERT INTO user_memberships (user_id, plan_id, purchase_date, duration_days, end_date, txn_id, status) 
                    VALUES ($user_id, $plan_id, CURDATE(), $days, '$end_date', '$txn_id', 'pending')";
            if(mysqli_query($conn, $sql)){
                $success = "✅ Membership Purchased! Txn: $txn_id | Awaiting Admin Approval";
            } else {
                $error = "❌ Insert Failed: " . mysqli_error($conn);
            }
        } else {
            $error = "❌ Table 'user_memberships' not found! Run SQL first.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Gym Membership Purchase</title>
<style>
body{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:white;font-family:Arial;padding:20px;margin:0;}
.container{max-width:1200px;margin:auto;}
.plans{display:flex;justify-content:center;flex-wrap:wrap;gap:20px;}
.plan-card{background:rgba(255,255,255,0.1);backdrop-filter:blur(10px);border-radius:20px;padding:25px;width:280px;text-align:center;transition:transform 0.3s;box-shadow:0 8px 32px rgba(0,0,0,0.3);}
.plan-card:hover{transform:translateY(-10px);}
h1{text-align:center;font-size:2.5em;margin-bottom:10px;}
.price{font-size:2em;color:#ffd700;font-weight:bold;}
.btn{background:linear-gradient(45deg,#ff6b6b,#ee5a24);color:white;border:none;padding:15px 30px;border-radius:50px;font-size:16px;cursor:pointer;transition:all 0.3s;}
.btn:hover{background:linear-gradient(45deg,#ff5252,#ff4081);transform:scale(1.05);}
.message{padding:15px 20px;border-radius:10px;margin:20px 0;text-align:center;font-size:18px;}
.success{background:rgba(76,175,80,0.3);border:2px solid #4caf50;}
.error{background:rgba(244,67,54,0.3);border:2px solid #f44336;}
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:1000;justify-content:center;align-items:center;}
.modal-content{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:white;padding:40px;border-radius:20px;text-align:center;max-width:500px;width:90%;}
.progress-bar{background:rgba(255,255,255,0.2);height:10px;border-radius:5px;overflow:hidden;margin:20px 0;}
.progress-fill{background:linear-gradient(90deg,#4caf50,#8bc34a);height:100%;width:0%;transition:width 0.5s;border-radius:5px;}
</style>
</head>
<body>
<div class="container">
<h1>🏋️‍♂️ Elite Gym Membership</h1>

<?php if($success): ?>
<div class="message success"><?php echo $success; ?></div>
<?php endif; ?>
<?php if($error): ?>
<div class="message error"><?php echo $error; ?></div>
<?php endif; ?>

<div class="plans">
<?php foreach($plans as $plan): ?>
<div class="plan-card">
<h3><?php echo htmlspecialchars($plan['plan_name'] ?? $plan['name'] ?? 'Premium Plan'); ?></h3>
<div class="price">₹<?php echo number_format($plan['price'] ?? 0); ?></div>
<div style="margin:15px 0;font-size:1.2em;">
<?php echo ($plan['duration_days'] ?? $plan['days'] ?? 0); ?> Days Access
</div>
<form method="post">
<input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
<button type="submit" name="buy_plan" class="btn">🛒 Buy Now</button>
</form>
</div>
<?php endforeach; ?>
</div>
</div>

<!-- Payment Success Modal -->
<div id="successModal" class="modal">
<div class="modal-content">
<h2>🎉 Payment Successful!</h2>
<div class="progress-bar"><div class="progress-fill" id="progressBar"></div></div>
<p id="modalStatus">Processing your membership...</p>
<button onclick="closeModal()" style="background:#ff6b6b;color:white;border:none;padding:12px 24px;border-radius:25px;cursor:pointer;font-size:16px;margin-top:20px;">Done</button>
</div>
</div>

<script>
<?php if($success): ?>
// Auto show success modal
document.getElementById('successModal').style.display = 'flex';
let width = 0;
const interval = setInterval(() => {
    width += 10;
    document.getElementById('progressBar').style.width = width + '%';
    if(width >= 100) {
        clearInterval(interval);
        document.getElementById('modalStatus').innerText = '✅ Membership Pending Admin Approval';
    }
}, 200);
<?php endif; ?>

function closeModal() {
    document.getElementById('successModal').style.display = 'none';
}
</script>
</body>
</html>
