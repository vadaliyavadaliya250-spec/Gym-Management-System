<?php
$con = mysqli_connect("localhost","root","","gym");

if(isset($_POST['signup'])){

    $username = $_POST['username'];
    $password = $_POST['password'];
    $email    = $_POST['email'];

    // Check username already exists
    $check = mysqli_query($con,"SELECT * FROM user_table WHERE username='$username'");
    if(mysqli_num_rows($check)>0){
        echo "<script>alert('Username already exists');</script>";
    }
    else
    {
        mysqli_query($con,"INSERT INTO user_table
        (username,password,email)
        VALUES
        ('$username','$password','$email')");

        echo "<script>alert('Signup Successful');window.location='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Gym Signup</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
}

.card{
    width:380px;
    padding:25px;
    background:rgba(255,255,255,.1);
    backdrop-filter:blur(10px);
    border-radius:15px;
    box-shadow:0 0 20px rgba(0,0,0,.5);
    color:white;
}

.card h2{
    text-align:center;
    margin-bottom:20px;
}

label{
    display:block;
    margin-top:12px;
    font-size:14px;
}

input,select{
    width:100%;
    padding:8px;
    margin-top:5px;
    border:none;
    border-radius:6px;
    outline:none;
}

button{
    width:100%;
    margin-top:18px;
    padding:10px;
    border:none;
    border-radius:6px;
    background:#00c6ff;
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition:.3s;
}

button:hover{
    background:#0072ff;
}
</style>

</head>
<body>

<div class="card">
<h2>Create Account</h2>

<form method="POST">

<label>Username</label>
<input name="username" required>

<label>Password</label>
<input type="password" name="password" required>

<label>Email</label>
<input type="email" name="email" required>
<button name="signup">Signup</button>

</form>
</div>

</body>
</html>
