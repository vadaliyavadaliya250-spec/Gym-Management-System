<?php

// JSON file name
$file = 'data.json';

// Get name from form
$name = $_POST['name'];

// Check if file exists
if (file_exists($file)) {
    $data = json_decode(file_get_contents($file), true);
} else {
    $data = [];
}

// Add new name
$data[] = [
    "name" => $name
];

// Save back to JSON file
file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));

// Redirect back
header("Location: p.html");
exit();

?>
