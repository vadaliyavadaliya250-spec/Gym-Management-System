﻿<?php
header('Location: newhome.php');
exit;

