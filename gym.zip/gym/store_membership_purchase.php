<?php
$conn = mysqli_connect("localhost","root","","gym");

if(!$conn){
    die("Connection Failed");
}

$username = $_POST['username'];
$plan_id = $_POST['plan_id'];
$plan_name = $_POST['plan_name'];
$amount = $_POST['amount'];
$duration = $_POST['duration'];
$txn = $_POST['txn'];

$sql = "INSERT INTO membership_purchases 
(username,plan_id,plan_name,amount,duration,txn,status)
VALUES 
('$username','$plan_id','$plan_name','$amount','$duration','$txn','pending')";

if(mysqli_query($conn,$sql)){
    echo "success";
}else{
    echo "error: ".mysqli_error($conn);
}
?>