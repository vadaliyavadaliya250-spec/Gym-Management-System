﻿<?php
session_start();
$con = mysqli_connect("localhost","root","","gym");
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

if (isset($_GET['logout'])) { session_destroy(); header("Location: newhome.php"); exit; }

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id) { header("Location: products.php"); exit; }

// Main product
$prod = mysqli_fetch_assoc(mysqli_query($con,"
    SELECT p.*, pc.category_name, pc.slug as cat_slug, pc.id as cat_id
    FROM products_new p
    JOIN product_categories pc ON pc.id=p.category_id
    WHERE p.id='$id' AND p.status='active'
"));
if(!$prod) { header("Location: products.php"); exit; }

// Variants + attributes
$var_res = mysqli_query($con,"
    SELECT pv.id, pv.variant_name, pv.sku, pv.final_price, pv.stock, pv.status,
           GROUP_CONCAT(CONCAT(pat.attribute_name,'::',av.value_label,'::',pat.unit_label) ORDER BY pat.id SEPARATOR '||') as attrs_str
    FROM product_variants pv
    LEFT JOIN variant_attributes va ON va.variant_id=pv.id
    LEFT JOIN attribute_values av ON av.id=va.value_id
    LEFT JOIN product_attribute_types pat ON pat.id=va.attribute_id
    WHERE pv.product_id='$id' AND pv.status='active'
    GROUP BY pv.id
    ORDER BY pv.final_price ASC
");
$variants=[];
while($v=mysqli_fetch_assoc($var_res)){
    $v['attrs']=[];
    if($v['attrs_str']){
        foreach(explode('||',$v['attrs_str']) as $ap){
            $parts = explode('::',$ap);
            if(count($parts)>=2) $v['attrs'][] = ['name'=>$parts[0],'value'=>$parts[1],'unit'=>$parts[2]??''];
        }
    }
    $variants[]=$v;
}

$total_stock = array_sum(array_column($variants,'stock'));
$min_price   = count($variants) ? min(array_column($variants,'final_price')) : $prod['final_price'];
$max_price   = count($variants) ? max(array_column($variants,'final_price')) : $prod['final_price'];
$savings     = $prod['price'] - $min_price;
$ci = ['equipments'=>'🏋️','supplements'=>'💊','merchandise'=>'🧥'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($prod['product_name']); ?> – Unique Gym</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;}
:root{--red:#c82027;--dark:#1a1a2e;--light:#f4f6fb;}
body{background:var(--light);}a{text-decoration:none;color:inherit;}
.navbar-c{padding:18px 60px;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:100;box-shadow:0 2px 12px rgba(0,0,0,.1);}
.logo{font-size:24px;font-weight:800;color:var(--dark);} .logo span{color:var(--red);} .nav-menu{list-style:none;display:flex;gap:28px;margin:0;}
.nav-menu a{color:#333;font-weight:600;font-size:14px;} .nav-menu a:hover{color:var(--red);} .nav-btns button{padding:10px 20px;border-radius:8px;border:none;cursor:pointer;margin-left:8px;font-weight:600;font-size:13px;}
.btn-login{background:#0066ff;color:#fff;} .btn-signup{background:var(--red);color:#fff;}
.bc-bar{background:#fff;padding:14px 60px;border-bottom:1px solid #eee;display:flex;align-items:center;gap:7px;font-size:13px;}
.pd-page{padding:30px 60px;min-height:80vh;}
.pd-main{display:flex;gap:48px;align-items:flex-start;background:#fff;border-radius:24px;box-shadow:0 6px 30px rgba(0,0,0,.08);padding:32px;margin-bottom:24px;}
.pd-img-panel{width:420px;flex-shrink:0;} .pd-img-main{width:100%;height:380px;object-fit:cover;border-radius:18px;box-shadow:0 8px 28px rgba(0,0,0,.12);} .pd-img-noimg{width:100%;height:380px;background:linear-gradient(135deg,#f0f0f0,#ddd);border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:90px;}
.pd-cat{display:inline-block;padding:6px 12px;border-radius:10px;background:#f8e7ea;color:var(--red);font-weight:700;font-size:12px;margin-bottom:10px;}
.pd-title{font-size:26px;margin:0 0 10px;} .pd-desc{color:#555;line-height:1.6;margin:0 0 12px;}
.pd-price{font-size:28px;font-weight:900;color:var(--red);} .pd-price-sub{color:#888;font-size:14px;}
.pd-stock{font-weight:700;font-size:13px;margin-top:4px;} .pd-stock.ok{color:#1f9d55;} .pd-stock.bad{color:#c42431;}
.attrs-title{font-weight:800;font-size:15px;color:#111;}
.pd-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px;}
.btn-w{background:#fff;border:1px solid #e5e7eb;padding:12px 18px;border-radius:10px;font-weight:700;}
.btn-b{background:var(--dark);color:#fff;border:none;padding:12px 18px;border-radius:10px;font-weight:700;}
.spec-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:14px 0;}
.spec-card{background:#f8fafc;border:1px solid #e5e7eb;border-radius:12px;padding:12px;display:flex;gap:10px;align-items:center;}
.spec-icon{font-size:18px;} .spec-label{color:#6b7280;font-size:12px;} .spec-val{font-weight:700;}
.pd-cta{margin-top:18px;display:flex;gap:10px;flex-wrap:wrap;} .btn-back,.btn-all{padding:10px 14px;border-radius:10px;border:1px solid #e5e7eb;font-weight:700;}
.related-section,.variants-section{display:none;} /* hidden per request */
@media(max-width:900px){.navbar-c{padding:14px 16px;}.pd-page{padding:18px;}.pd-main{flex-direction:column;gap:20px;}.pd-img-panel{width:100%;}}
</style>
</head>
<body>
<div class="navbar-c">
    <a class="logo" href="newhome.php">UNIQUE <span>GYM</span></a>
    <ul class="nav-menu">
        <li><a href="newhome.php">Home</a></li>
        <li><a href="products.php" class="active">Products</a></li>
        <li><a href="mmm.php">Membership</a></li>
    </ul>
    <div class="nav-btns" style="display:flex;align-items:center;gap:8px;">
        <?php if (empty($username)): ?>
            <button class="btn-login" onclick="location.href='login.php'">Login</button>
            <button class="btn-signup" onclick="location.href='signup.php'">Sign Up</button>
        <?php else: ?>
            <div style="display:flex;flex-direction:column;align-items:flex-start;gap:6px;">
                <span style="font-weight:700;">Hello, <?php echo htmlspecialchars($username); ?></span>
                <a href="cart.php" class="btn-b" style="padding:8px 12px;border-radius:8px;font-size:12px;background:#0d6efd;color:#fff;border:none;text-decoration:none;">Cart</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="bc-bar">
    <a href="products.php">Products</a><span>/</span><span class="cur"><?php echo htmlspecialchars($prod['product_name']); ?></span>
</div>

<div class="pd-page">
    <div class="pd-main">
        <div class="pd-img-panel">
            <?php if($prod['image']): ?>
                <img src="uploads/products/<?php echo htmlspecialchars($prod['image']); ?>" class="pd-img-main">
            <?php else: ?><div class="pd-img-noimg">📦</div><?php endif; ?>
        </div>
        <div class="pd-info">
            <div class="pd-cat"><?php echo ($ci[$prod['cat_slug']] ?? '📦').' '.htmlspecialchars($prod['category_name']); ?></div>
            <h1 class="pd-title"><?php echo htmlspecialchars($prod['product_name']); ?></h1>
            <?php if(!empty($prod['description'])): ?><div class="pd-desc"><?php echo nl2br(htmlspecialchars($prod['description'])); ?></div><?php endif; ?>

            <div class="spec-grid">
                <div class="spec-card"><div class="spec-icon">💰</div><div><div class="spec-label">Starts at</div><div class="spec-val">₹<?php echo number_format($min_price,2); ?></div></div></div>
                <div class="spec-card"><div class="spec-icon">📦</div><div><div class="spec-label">Variants</div><div class="spec-val"><?php echo count($variants); ?></div></div></div>
                <div class="spec-card"><div class="spec-icon"><?php echo $total_stock>0?'✅':'❌'; ?></div><div><div class="spec-label">Stock</div><div class="spec-val"><?php echo $total_stock>0?$total_stock.' units':'Out of stock'; ?></div></div></div>
            </div>

            <?php if(!empty($variants)): ?>
            <div class="variant-box" style="margin:12px 0;">
                <div class="attrs-title" style="margin:0 0 8px;">Select variant</div>
                <select id="variantSelect" class="form-select" style="max-width:320px;">
                    <?php foreach($variants as $idx=>$v):
                        $label = $v['variant_name'];
                        if(!$label && !empty($v['attrs'])){
                            $parts=[]; foreach($v['attrs'] as $a){ $parts[]=$a['value']; }
                            $label = implode(' / ', $parts);
                        }
                    ?>
                    <option value="<?php echo $v['id']; ?>" data-price="<?php echo $v['final_price']; ?>" data-stock="<?php echo $v['stock']; ?>">
                        <?php echo htmlspecialchars($label ?: 'Option '.($idx+1)); ?> — ₹<?php echo number_format($v['final_price'],2); ?> (<?php echo $v['stock']>0?'In stock':'Out'; ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
                <div style="margin-top:10px;font-weight:900;font-size:24px;" id="livePrice">₹<?php echo number_format($min_price,2); ?></div>
                <div id="liveStock" style="font-size:13px;color:<?php echo $total_stock>0?'#1f9d55':'#c42431'; ?>;">
                    <?php echo $total_stock>0?'In stock':'Out of stock'; ?>
                </div>
            </div>
            <?php else: ?>
                <div style="margin:12px 0;color:#c42431;font-weight:700;">No variants available for purchase.</div>
            <?php endif; ?>

            <form action="cart_action.php" method="POST" class="pd-actions" style="gap:10px;">
                <input type="hidden" name="variant_id" id="variantField" value="<?php echo $variants[0]['id'] ?? 0; ?>">
                <input type="number" name="qty" value="1" min="1" style="width:80px;padding:10px;border:1px solid #e5e7eb;border-radius:8px;" <?php echo empty($variants)?'disabled':''; ?>>
                <button class="btn-b" name="action" value="add" type="submit" <?php echo empty($variants)?'disabled':''; ?>>Add to Cart</button>
            </form>

            <div class="pd-cta">
                <a href="products.php" class="btn-back"><i class="bi bi-arrow-left"></i> Back to Products</a>
            </div>
        </div>
    </div>
</div>

<script>
const sel = document.getElementById('variantSelect');
const priceEl = document.getElementById('livePrice');
const stockEl = document.getElementById('liveStock');
const vField  = document.getElementById('variantField');
function upd(){
  if(!sel) return;
  const opt = sel.options[sel.selectedIndex];
  vField.value = opt.value;
  const price = parseFloat(opt.dataset.price||0).toFixed(2);
  const stock = parseInt(opt.dataset.stock||0);
  priceEl.textContent = '₹'+price;
  stockEl.textContent = stock>0 ? 'In stock ('+stock+')' : 'Out of stock';
  stockEl.style.color = stock>0 ? '#1f9d55' : '#c42431';
}
upd();
if(sel) sel.addEventListener('change', upd);
</script>
</body>
</html>
