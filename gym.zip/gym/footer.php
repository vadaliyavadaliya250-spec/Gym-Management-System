<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Footer with Icons</title>

<style>
body{
    margin:0;
    font-family: Arial, sans-serif;
    color:white;
}

/* FOOTER */
.footer{
    background:#111;
    padding:40px 8%;
}

/* MAIN ROW */
.footer-row{
    display:flex;
    flex-wrap:wrap;
    gap:40px;
}

/* BRAND */
.footer-brand{
    flex:1;
    min-width:250px;
}
.footer-brand h2{
    font-size:26px;
}
.footer-brand span{
    color:#4fdcff;
}
.footer-brand p{
    font-size:14px;
    color:#bbb;
    margin-top:10px;
}

/* LOCATION */
.footer-location{
    flex:1;
    min-width:250px;
}
.footer-location h3{
    color:#4fdcff;
    margin-bottom:10px;
}
.footer-location p{
    font-size:14px;
    color:#ccc;
}
.footer-location iframe{
    width:100%;
    height:200px;
    border:0;
    margin-top:10px;
}

/* CONTACT */
.footer-contact{
    flex:1;
    min-width:250px;
}
.footer-contact h3{
    color:#4fdcff;
    margin-bottom:15px;
}

/* ICON + TEXT */
.contact-item{
    display:flex;
    align-items:center;
    margin-bottom:12px;
    font-size:14px;
    color:#ccc;
}
.contact-item img{
    width:30px;
    height:30px;
    margin-right:10px;
}

/* SOCIAL ICONS */
.social{
    margin-top:15px;
}
.social img{
    width:30px;
    height:30px;
    margin-right:10px;
    cursor:pointer;
}

/* BOTTOM */
.footer-bottom{
    margin-top:30px;
    padding-top:15px;
    border-top:1px solid #333;
    text-align:center;
    font-size:13px;
    color:#aaa;
}
</style>
</head>

<body>

<footer class="footer">

    <div class="footer-row">

        <!-- BRAND -->
        <div class="footer-brand">
            <h2 style="color:white;">Unique <span>GYM</span></h2>
            <p>Simple gym management system for daily operations.</p>
        </div>

        <!-- LOCATION -->
        <div class="footer-location">
            <h3>Our Location</h3>
            <p>Unique Gym</p>
            <p>Ghodasar, Ahmedabad</p>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14693.343821360679!2d72.60770128090084!3d22.974670423075363!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e8f5590ffcd7d%3A0x4b0554bef6153a98!2sGhodasar%2C%20Ahmedabad%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1766742844620!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

        <!-- CONTACT -->
        <div class="footer-contact">
            <h3>Contact</h3>

            <div class="contact-item">
                <img src="mail.png">
                <span style="color:white;">uniquegym.ghodasar17@gmail.com</span>
            </div>

            <div class="contact-item">
                <img src="call.png">
                <span style="color:white;">+91 9727974099</span>
            </div>

            <div class="contact-item">
                <img src="location.png">
                <span style="color:white;">Ghodasar, Ahmedabad</span>
            </div>

            <div class="social">
                <img src="insta.png">
                <img src="wh.png">
                <img src="twitter.png">
                <img src="facebook.png">
            </div>
        </div>

    </div>

    <div class="footer-bottom">
        © 2025 Unique Gym. All rights reserved.
    </div>

</footer>

</body>
</html>
