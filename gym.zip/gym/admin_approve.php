<?php
session_start();
$conn = mysqli_connect("localhost","root","","gym");
if(!$conn){ die("Connection Failed"); }

if(isset($_GET['approve'])){
    $id = (int)$_GET['approve'];
    mysqli_query($conn,"UPDATE user_memberships SET status='approved' WHERE id=$id");
    header("Location: admin_approve.php?msg=✅ Approved!");
    exit;
}

if(isset($_GET['cancel'])){
    $id = (int)$_GET['cancel'];
    mysqli_query($conn,"DELETE FROM user_memberships WHERE id=$id");
    header("Location: admin_approve.php?msg=❌ Cancelled!");
    exit;
}

// SAFE Query - users table optional
$pendings = [];
$result = mysqli_query($conn,"SELECT um.*, mp.plan_name, mp.price FROM user_memberships um 
JOIN membership_plans mp ON um.plan_id=mp.id 
WHERE um.status='pending' ORDER BY um.created_at DESC");
while($row=mysqli_fetch_assoc($result)){ 
    // User name optional
    $row['user_name'] = 'User ID: ' . $row['user_id'];
    $pendings[]=$row; 
}
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin - Approve Memberships</title>
<style>
* {margin:0;padding:0;box-sizing:border-box;}
body {background:linear-gradient(135deg,#1e3c72 0%,#2a5298 100%);color:white;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;padding:20px;min-height:100vh;}
.container {max-width:1000px;margin:auto;}
h1 {text-align:center;font-size:2.5em;margin:30px 0;text-shadow:0 0 20px rgba(255,255,255,0.5);}
.message {padding:20px;border-radius:15px;margin:20px 0;text-align:center;font-size:20px;font-weight:bold;}
.success {background:rgba(76,175,80,0.4);border:2px solid #4caf50;}
.error {background:rgba(244,67,54,0.4);border:2px solid #f44336;}
.admin-card {background:rgba(255,107,107,0.3);backdrop-filter:blur(15px);border-radius:20px;padding:25px;margin:20px 0;border:2px solid #ff6b6b;transition:all 0.3s;box-shadow:0 10px 30px rgba(0,0,0,0.3);}
.admin-card:hover {transform:translateY(-5px);box-shadow:0 20px 40px rgba(0,0,0,0.4);}
.user-info {background:rgba(255,255,255,0.1);padding:15px;border-radius:10px;margin-bottom:15px;}
.actions {display:flex;gap:15px;justify-content:center;flex-wrap:wrap;}
.btn {padding:12px 25px;border:none;border-radius:25px;font-size:16px;font-weight:bold;cursor:pointer;transition:all 0.3s;text-decoration:none;display:inline-block;text-align:center;}
.approve {background:linear-gradient(45deg,#4caf50,#8bc34a);color:white;width:120px;}
.cancel {background:linear-gradient(45deg,#ff5722,#ff8a65);color:white;width:120px;}
.profile {background:linear-gradient(45deg,#2196f3,#21cbf3);color:white;width:140px;}
.btn:hover {transform:scale(1.05);}
.empty {text-align:center;padding:50px;color:#ffd700;font-size:1.5em;}
.stats {display:flex;justify-content:space-around;margin:30px 0;background:rgba(255,255,255,0.1);padding:20px;border-radius:15px;}
@media(max-width:768px){.stats,.actions{flex-direction:column;gap:10px;}.admin-card{padding:20px;}}
</style>
</head>
<body>
<div class="container">
<h1>🔧 Admin Panel - Membership Approvals</h1>

<?php if($msg): ?>
<div class="message success"><?php echo htmlspecialchars($msg); ?></div>
<?php endif; ?>

<div class="stats">
<div><strong><?php echo count($pendings); ?></strong><br>Pending</div>
<div><strong><?php echo mysqli_num_rows(mysqli_query($conn,"SELECT * FROM user_memberships WHERE status='approved'")); ?></strong><br>Approved</div>
</div>

<?php if(empty($pendings)): ?>
<div class="empty">🎉 All memberships approved! No pending requests.</div>
<?php else: ?>
<?php foreach($pendings as $p): ?>
<div class="admin-card">
<div class="user-info">
<strong>👤 <?php echo $p['user_name']; ?></strong> (ID: <?php echo $p['user_id']; ?>)
</div>
<div style="font-size:1.3em;margin:15px 0;">
<strong>🏋️ <?php echo htmlspecialchars($p['plan_name'] ?? 'Premium'); ?></strong>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;margin:15px 0;font-size:1.1em;">
<div>📅 <?php echo $p['purchase_date']; ?></div>
<div>⏱ <?php echo $p['duration_days']; ?> days</div>
<div>📱 Txn: <?php echo $p['txn_id']; ?></div>
<div>📅 Ends: <?php echo $p['end_date']; ?></div>
</div>
<div class="actions">
<a href="?approve=<?php echo $p['id']; ?>" class="btn approve">✅ Approve</a>
<a href="?cancel=<?php echo $p['id']; ?>" class="btn cancel" onclick="return confirm('Cancel this purchase?')">❌ Cancel</a>
<a href="user_profile.php?user_id=<?php echo $p['user_id']; ?>" class="btn profile">👤 Profile</a>
</div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<div style="text-align:center;margin-top:40px;">
<a href="buy_membership.php" class="btn" style="background:linear-gradient(45deg,#9c27b0,#ab47bc);width:auto;">➕ Add Test Purchase</a>
</div>
</div>
</body>
</html>
