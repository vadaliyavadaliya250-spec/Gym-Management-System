<?php
session_start();
$con = mysqli_connect("localhost","root","","gym");

if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

$user = $_SESSION['username'];

/* Get name from signup table */
$userData = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM user_table WHERE username='$user'"));
$signupName = $userData['fullname'] ?? "";

/* Fetch user profile details */
$q = mysqli_query($con,"SELECT * FROM user_details WHERE username='$user'");
$data = mysqli_fetch_assoc($q);

/* SAVE or UPDATE */
if(isset($_POST['save'])){

    $fullname = $_POST['fullname'];
    $age      = $_POST['age'];
    $gender   = $_POST['gender'];
    $height   = $_POST['height'];
    $weight   = $_POST['weight'];
    $medical  = $_POST['medical'];

    // Upload Photo
    if($_FILES['photo']['name']!=""){
        if(!is_dir("uploads")){
            mkdir("uploads");
        }
        $photo = "uploads/".time()."_".$_FILES['photo']['name'];
        move_uploaded_file($_FILES['photo']['tmp_name'],$photo);
    } else {
        $photo = $data['photo'] ?? "";
    }

    if($data){
        mysqli_query($con,"UPDATE user_details SET
            fullname='$fullname',
            age='$age',
            gender='$gender',
            height='$height',
            weight='$weight',
            medical='$medical',
            photo='$photo'
            WHERE username='$user'");
    } else {
        mysqli_query($con,"INSERT INTO user_details
        (username,fullname,age,gender,height,weight,medical,photo)
        VALUES
        ('$user','$fullname','$age','$gender','$height','$weight','$medical','$photo')");
    }

    header("Location: profile.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>My Profile</title>

<style>
body{
    margin:0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#1d2b64,#f8cdda);
}

.container{
    width:750px;
    margin:50px auto;
    background:white;
    padding:40px;
    border-radius:20px;
    box-shadow:0 20px 40px rgba(0,0,0,.2);
}

h2{
    text-align:center;
    margin-bottom:30px;
}

.profile-view img{
    width:150px;
    height:150px;
    border-radius:50%;
    object-fit:cover;
    border:5px solid #1d2b64;
    display:block;
    margin:0 auto 20px;
}

.profile-view p{
    font-size:17px;
    margin:8px 0;
}

button{
    padding:12px 25px;
    border:none;
    border-radius:8px;
    background:#1d2b64;
    color:white;
    font-size:15px;
    cursor:pointer;
    transition:.3s;
}

button:hover{
    background:#14204a;
}

.edit-btn{
    display:block;
    margin:20px auto 0;
    background:#28a745;
}

form input, form select, form textarea{
    width:100%;
    padding:12px;
    margin-top:15px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:14px;
}

form textarea{
    resize:none;
}

.save-btn{
    width:100%;
    margin-top:20px;
}

label{
    font-weight:600;
    margin-top:15px;
    display:block;
}
.back-btn{
    display:inline-block;
    text-decoration:none;
    padding:8px 18px;
    background:#333;
    color:white;
    border-radius:30px;
    font-size:14px;
    transition:.3s;
    margin-bottom:20px;
}

.back-btn:hover{
    background:#000;
    transform:translateX(-5px);
}

</style>
</head>
<body>

<div class="container">
<a href="newhome.php" class="back-btn">⬅ Back to Home</a>
<?php if($data && !isset($_GET['edit'])): ?>

    <!-- PROFILE VIEW -->
    <div class="profile-view">
        <h2><?= $data['fullname'] ?>'s Profile</h2>

        <img src="<?= !empty($data['photo']) ? $data['photo'] : 'default.png' ?>">

        <p><b>Age:</b> <?= $data['age'] ?></p>
        <p><b>Gender:</b> <?= $data['gender'] ?></p>
        <p><b>Height:</b> <?= $data['height'] ?> cm</p>
        <p><b>Weight:</b> <?= $data['weight'] ?> kg</p>
        <p><b>Medical:</b> <?= $data['medical'] ?></p>

        <a href="?edit=1"><button class="edit-btn">Edit Profile</button></a>
    </div>

<?php else: ?>

    <!-- FORM -->
    <h2><?= $data ? "Edit Profile" : "Complete Your Profile" ?></h2>

    <form method="POST" enctype="multipart/form-data">

        <label>Full Name</label>
        <input name="fullname"
        value="<?= $data['fullname'] ?? $signupName ?>" required>

        <label>Age</label>
        <input type="number" name="age"
        value="<?= $data['age'] ?? '' ?>" required>

        <label>Gender</label>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male" <?=($data['gender']??'')=="Male"?"selected":""?>>Male</option>
            <option value="Female" <?=($data['gender']??'')=="Female"?"selected":""?>>Female</option>
        </select>

        <label>Height (cm)</label>
        <input name="height"
        value="<?= $data['height'] ?? '' ?>">

        <label>Weight (kg)</label>
        <input name="weight"
        value="<?= $data['weight'] ?? '' ?>">

        <label>Medical Problems</label>
        <textarea name="medical"><?= $data['medical'] ?? '' ?></textarea>

        <label>Profile Photo</label>
        <input type="file" name="photo">

        <button name="save" class="save-btn">Save Profile</button>

    </form>

<?php endif; ?>

</div>
</body>
</html>
