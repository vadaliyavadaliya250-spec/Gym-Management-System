<?php
$type=$_SESSION['trainer_type'];
?>

<style>

.sidebar{
width:220px;
height:100vh;
background:#34495e;
position:fixed;
padding-top:20px;
}

.sidebar a{
display:block;
color:white;
padding:12px 20px;
text-decoration:none;
}

.sidebar a:hover{
background:#2c3e50;
}

.content{
margin-left:230px;
padding:30px;
}

</style>

<div class="sidebar">

<h5 class="text-white text-center mb-4">Trainer</h5>

<a href="trainer_dashboard.php">Dashboard</a>

<?php if($type=="personal"){ ?>

<a href="members.php">My Members</a>
<a href="create_diet_plan.php">Create Diet Plan</a>

<?php } ?>

<?php if($type=="batch"){ ?>

<a href="batches.php">My Batches</a>
<a href="batch_members.php">Batch Members</a>

<?php } ?>

<a href="trainer_attendance.php">Attendance</a>

<a href="trainer_profile.php">Profile</a>

</div>

<div class="content">