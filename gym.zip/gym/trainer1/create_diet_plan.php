<?php
session_start();
include "../db.php";
include "trainer_header.php";

$trainer_id = $_SESSION['trainer_id'];

// Save new diet plan
if(isset($_POST['save'])) {
    $member_id = (int)$_POST['member_id'];
    $title     = mysqli_real_escape_string($con, $_POST['title']);
    $morning   = mysqli_real_escape_string($con, $_POST['morning']);
    $lunch     = mysqli_real_escape_string($con, $_POST['lunch']);
    $evening   = mysqli_real_escape_string($con, $_POST['evening']);
    $dinner    = mysqli_real_escape_string($con, $_POST['dinner']);

    $sql = "INSERT INTO diet_plans (trainer_id,member_id,title,morning,lunch,evening,dinner,created_at)
            VALUES ('$trainer_id','$member_id','$title','$morning','$lunch','$evening','$dinner',NOW())";

    if(mysqli_query($con, $sql)) {
        $success = "Diet plan saved successfully!";
    } else {
        $error = "Error: " . mysqli_error($con);
    }
}

// Members dropdown
$members = mysqli_query($con, "
    SELECT ud.*
    FROM user_details ud
    JOIN assign_trainer a ON ud.id = a.member_id
    WHERE a.trainer_id='$trainer_id'
");

// Existing diet plans
$plans = mysqli_query($con, "
    SELECT d.*, ud.username
    FROM diet_plans d
    JOIN user_details ud ON d.member_id = ud.id
    WHERE d.trainer_id='$trainer_id'
    ORDER BY d.id DESC
");

$preselect = isset($_GET['member_id']) ? (int)$_GET['member_id'] : 0;
?>

<div class="page-title">Create Diet Plan</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success">✅ <?php echo $success; ?></div>
<?php endif; ?>
<?php if(isset($error)): ?>
    <div class="alert alert-danger">⚠ <?php echo $error; ?></div>
<?php endif; ?>

<div class="form-card">
    <div class="form-card-head">🥗 New Diet Plan</div>
    <div class="form-card-body">
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label>Select Member</label>
                    <select name="member_id" required>
                        <option value="">-- Choose Member --</option>
                        <?php
                        while($m = mysqli_fetch_assoc($members)) {
                            $sel = ($m['id'] == $preselect) ? 'selected' : '';
                            echo "<option value='{$m['id']}' $sel>{$m['username']} ({$m['fullname']})</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Diet Plan Title</label>
                    <input type="text" name="title" placeholder="e.g. Weight Loss Plan" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>🌅 Morning</label>
                    <textarea name="morning" rows="3" placeholder="Oats, Banana, Milk, Boiled Eggs..."></textarea>
                </div>
                <div class="form-group">
                    <label>☀ Lunch</label>
                    <textarea name="lunch" rows="3" placeholder="Chapati, Dal, Vegetables, Salad..."></textarea>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>🌆 Evening Snack</label>
                    <textarea name="evening" rows="3" placeholder="Fruits, Protein Shake, Nuts..."></textarea>
                </div>
                <div class="form-group">
                    <label>🌙 Dinner</label>
                    <textarea name="dinner" rows="3" placeholder="Light soup, Chapati, Dal..."></textarea>
                </div>
            </div>
            <button type="submit" name="save" class="btn btn-success">💾 Save Diet Plan</button>
        </form>
    </div>
</div>

<!-- Existing Plans -->
<div class="table-wrap">
    <div class="table-head">📋 Existing Diet Plans</div>
    <table>
        <tr>
            <th>#</th>
            <th>Member</th>
            <th>Title</th>
            <th>Morning</th>
            <th>Lunch</th>
            <th>Evening</th>
            <th>Dinner</th>
            <th>Action</th>
        </tr>
        <?php
        $i = 1;
        if(mysqli_num_rows($plans) > 0):
            while($p = mysqli_fetch_assoc($plans)):
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($p['username']); ?></td>
            <td><?php echo htmlspecialchars($p['title']); ?></td>
            <td><?php echo htmlspecialchars(substr($p['morning'],0,30)); ?>...</td>
            <td><?php echo htmlspecialchars(substr($p['lunch'],0,30)); ?>...</td>
            <td><?php echo htmlspecialchars(substr($p['evening'],0,30)); ?>...</td>
            <td><?php echo htmlspecialchars(substr($p['dinner'],0,30)); ?>...</td>
            <td>
                <a href="edit_diet.php?id=<?php echo $p['id']; ?>" class="btn btn-warning">Edit</a>
                <a href="delete_diet.php?id=<?php echo $p['id']; ?>" class="btn btn-danger"
                   onclick="return confirm('Delete this plan?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" style="text-align:center; color:#888; padding:24px;">No diet plans created yet.</td></tr>
        <?php endif; ?>
    </table>
</div>

</div>
</body>
</html>