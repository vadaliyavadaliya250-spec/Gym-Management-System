<?php
session_start();
include "../db.php";
include "trainer_header.php";

$trainer_id = $_SESSION['trainer_id'];

$q = mysqli_query($con, "SELECT * FROM batches WHERE trainer_id='$trainer_id' ORDER BY created_at DESC");
?>

<div class="page-title">My Batches</div>

<div class="table-wrap">
    <div class="table-head">📋 Assigned Batches</div>
    <table>
        <tr>
            <th>#</th>
            <th>Batch Name</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Capacity</th>
            <th>Status</th>
            <th>Created</th>
            <th>Action</th>
        </tr>
        <?php
        $i = 1;
        if(mysqli_num_rows($q) > 0):
            while($row = mysqli_fetch_assoc($q)):
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($row['batch_name']); ?></td>
            <td><?php echo date('h:i A', strtotime($row['start_time'])); ?></td>
            <td><?php echo date('h:i A', strtotime($row['end_time'])); ?></td>
            <td><?php echo $row['capacity']; ?> members</td>
            <td>
                <span class="badge <?php echo $row['status']=='active' ? 'badge-success' : 'badge-danger'; ?>">
                    <?php echo ucfirst($row['status']); ?>
                </span>
            </td>
            <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
            <td>
                <a href="change_batch_time.php?batch_id=<?php echo $row['id']; ?>" class="btn btn-warning">⏰ Change Time</a>
                <a href="batch_members.php?batch_id=<?php echo $row['id']; ?>" class="btn btn-primary">👥 Members</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr>
            <td colspan="8" style="text-align:center; color:#888; padding:30px;">No batches assigned yet.</td>
        </tr>
        <?php endif; ?>
    </table>
</div>

</div>
</body>
</html>