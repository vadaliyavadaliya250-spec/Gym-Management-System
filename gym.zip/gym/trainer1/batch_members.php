<?php
session_start();
include "../db.php";
include "trainer_header.php";

$trainer_id = $_SESSION['trainer_id'];
$batch_filter = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : 0;

// Get this trainer's batches for filter dropdown
$my_batches = mysqli_query($con, "SELECT * FROM batches WHERE trainer_id='$trainer_id'");

if($batch_filter > 0) {
    $query = mysqli_query($con, "
        SELECT ud.*, b.batch_name, COALESCE(bm.joined_at, ud.updated_at) AS joined_at
        FROM user_details ud
        JOIN batches b ON ud.batch_id = b.id
        LEFT JOIN batch_members bm ON bm.member_id = ud.id AND bm.batch_id = b.id
        WHERE b.trainer_id='$trainer_id' AND ud.batch_id='$batch_filter'
        ORDER BY joined_at DESC
    ");
} else {
    $query = mysqli_query($con, "
        SELECT ud.*, b.batch_name, COALESCE(bm.joined_at, ud.updated_at) AS joined_at
        FROM user_details ud
        JOIN batches b ON ud.batch_id = b.id
        LEFT JOIN batch_members bm ON bm.member_id = ud.id AND bm.batch_id = b.id
        WHERE b.trainer_id='$trainer_id'
        ORDER BY b.batch_name, joined_at DESC
    ");
}
?>

<div class="page-title">Batch Members</div>

<div class="form-card" style="margin-bottom:20px;">
    <div class="form-card-body" style="padding:16px 22px;">
        <form method="GET" style="display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
            <div class="form-group" style="min-width:200px; margin-bottom:0;">
                <label>Filter by Batch</label>
                <select name="batch_id" onchange="this.form.submit()">
                    <option value="0">All Batches</option>
                    <?php
                    while($b = mysqli_fetch_assoc($my_batches)) {
                        $sel = ($b['id'] == $batch_filter) ? 'selected' : '';
                        echo "<option value='{$b['id']}' $sel>{$b['batch_name']}</option>";
                    }
                    ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="table-wrap">
    <div class="table-head">👥 Members in Your Batches</div>
    <table>
        <tr>
            <th>#</th>
            <th>Username</th>
            <th>Full Name</th>
            <th>Batch</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Height</th>
            <th>Weight</th>
            <th>Joined</th>
        </tr>
        <?php
        $i = 1;
        if(mysqli_num_rows($query) > 0):
            while($row = mysqli_fetch_assoc($query)):
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo htmlspecialchars($row['fullname']); ?></td>
            <td><span class="badge badge-info"><?php echo htmlspecialchars($row['batch_name']); ?></span></td>
            <td><?php echo $row['age']; ?></td>
            <td><?php echo $row['gender']; ?></td>
            <td><?php echo $row['height'] ? $row['height'].' ft' : '-'; ?></td>
            <td><?php echo $row['weight'] ? $row['weight'].' kg' : '-'; ?></td>
            <td><?php echo date('d M Y', strtotime($row['joined_at'])); ?></td>
        </tr>
        <?php endwhile; else: ?>
        <tr>
            <td colspan="9" style="text-align:center; color:#888; padding:30px;">No members found in your batches.</td>
        </tr>
        <?php endif; ?>
    </table>
</div>

</div>
</body>
</html>
