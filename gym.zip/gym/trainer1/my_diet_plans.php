<?php
include "trainer_header.php";
include "trainer_sidebar.php";
include "../db.php";

$trainer_id=$_SESSION['trainer_id'];

$q=mysqli_query($con,"
SELECT d.*,m.name
FROM diet_plans d
JOIN members m ON m.id=d.member_id
WHERE d.trainer_id='$trainer_id'
");
?>

<h3>My Diet Plans</h3>

<table class="table table-striped">

<tr>
<th>Member</th>
<th>Title</th>
<th>Morning</th>
<th>Lunch</th>
<th>Dinner</th>
</tr>

<?php while($row=mysqli_fetch_assoc($q)){ ?>

<tr>

<td><?php echo $row['name']; ?></td>
<td><?php echo $row['title']; ?></td>
<td><?php echo $row['morning']; ?></td>
<td><?php echo $row['lunch']; ?></td>
<td><?php echo $row['dinner']; ?></td>

</tr>

<?php } ?>

</table>