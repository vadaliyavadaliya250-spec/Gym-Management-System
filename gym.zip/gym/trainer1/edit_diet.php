<?php
session_start();
include "../db.php";
include "trainer_header.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$trainer_id = $_SESSION['trainer_id'];

// Fetch the diet plan (make sure it belongs to this trainer)
$q    = mysqli_query($con, "SELECT * FROM diet_plans WHERE id='$id' AND trainer_id='$trainer_id'");
$data = mysqli_fetch_assoc($q);

if(!$data) {
    echo "<div class='alert alert-danger'>⚠ Diet plan not found or access denied.</div>";
    echo "</div></body></html>";
    exit();
}

if(isset($_POST['update'])) {
    $title   = mysqli_real_escape_string($con, $_POST['title']);
    $morning = mysqli_real_escape_string($con, $_POST['morning']);
    $lunch   = mysqli_real_escape_string($con, $_POST['lunch']);
    $evening = mysqli_real_escape_string($con, $_POST['evening']);
    $dinner  = mysqli_real_escape_string($con, $_POST['dinner']);

    mysqli_query($con, "UPDATE diet_plans SET
        title='$title', morning='$morning', lunch='$lunch',
        evening='$evening', dinner='$dinner'
        WHERE id='$id' AND trainer_id='$trainer_id'");

    $success = "Diet plan updated successfully!";

    // Refresh data
    $q    = mysqli_query($con, "SELECT * FROM diet_plans WHERE id='$id'");
    $data = mysqli_fetch_assoc($q);
}
?>

<div class="page-title">Edit Diet Plan</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success">✅ <?php echo $success; ?></div>
<?php endif; ?>

<div class="form-card" style="max-width:700px;">
    <div class="form-card-head">🥗 Edit Diet Plan</div>
    <div class="form-card-body">
        <form method="POST">
            <div class="form-group" style="margin-bottom:18px;">
                <label>Diet Plan Title</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($data['title']); ?>" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>🌅 Morning</label>
                    <textarea name="morning" rows="3"><?php echo htmlspecialchars($data['morning']); ?></textarea>
                </div>
                <div class="form-group">
                    <label>☀ Lunch</label>
                    <textarea name="lunch" rows="3"><?php echo htmlspecialchars($data['lunch']); ?></textarea>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>🌆 Evening Snack</label>
                    <textarea name="evening" rows="3"><?php echo htmlspecialchars($data['evening']); ?></textarea>
                </div>
                <div class="form-group">
                    <label>🌙 Dinner</label>
                    <textarea name="dinner" rows="3"><?php echo htmlspecialchars($data['dinner']); ?></textarea>
                </div>
            </div>
            <button type="submit" name="update" class="btn btn-success">💾 Update Diet Plan</button>
            <a href="create_diet_plan.php" class="btn btn-dark" style="margin-left:10px;">← Back</a>
        </form>
    </div>
</div>

</div>
</body>
</html>