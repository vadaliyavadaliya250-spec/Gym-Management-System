<?php
if(!isset($_SESSION['trainer_id'])){
    header("Location: trainer_login.php");
    exit();
}
$trainer_type = $_SESSION['trainer_type'];
$trainer_name = $_SESSION['trainer_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trainer Panel – GymPro</title>
<style>
/* ===== RESET ===== */
*{ margin:0; padding:0; box-sizing:border-box; }
body{ font-family:'Segoe UI', Arial, sans-serif; background:#f0f2f5; }

/* ===== HEADER ===== */
.top-header{
    width: 100%;
    height: 62px;
    background: linear-gradient(90deg, #1a1a2e, #16213e);
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 24px;
    position: fixed;
    top: 0; left: 0;
    z-index: 1000;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
}
.top-header .brand{
    font-size: 20px;
    font-weight: 700;
    color: #e74c3c;
    letter-spacing: 1px;
}
.top-header .brand span{ color: #fff; }
.top-header .right-info{
    display: flex;
    align-items: center;
    gap: 16px;
}
.top-header .trainer-info{
    font-size: 14px;
    color: rgba(255,255,255,0.8);
}
.top-header .trainer-info strong{ color: #fff; }
.badge-type{
    background: <?php echo ($trainer_type=='personal') ? '#27ae60' : '#2980b9'; ?>;
    color: white;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.btn-logout{
    background: #e74c3c;
    color: white;
    padding: 7px 16px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    transition: background 0.3s;
}
.btn-logout:hover{ background: #c0392b; }

/* ===== SIDEBAR ===== */
.sidebar{
    width: 230px;
    min-height: 100vh;
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    position: fixed;
    top: 62px; left: 0;
    overflow-y: auto;
    z-index: 900;
    padding-bottom: 30px;
}
.sidebar-logo{
    padding: 22px 20px 14px;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    text-align: center;
}
.sidebar-logo .avatar{
    width: 52px; height: 52px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e74c3c, #c0392b);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    margin-bottom: 8px;
}
.sidebar-logo p{
    color: rgba(255,255,255,0.6);
    font-size: 12px;
    margin-top: 2px;
}
.sidebar-logo h4{ color: #fff; font-size: 15px; }
.sidebar-section{
    padding: 14px 16px 4px;
    color: rgba(255,255,255,0.3);
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
}
.sidebar a{
    display: flex;
    align-items: center;
    gap: 12px;
    color: rgba(255,255,255,0.7);
    padding: 11px 20px;
    text-decoration: none;
    font-size: 14px;
    border-left: 3px solid transparent;
    transition: all 0.25s;
}
.sidebar a:hover, .sidebar a.active{
    background: rgba(255,255,255,0.07);
    color: #fff;
    border-left-color: #e74c3c;
}
.sidebar a .icon{ font-size: 16px; width: 20px; text-align: center; }

/* ===== MAIN CONTENT ===== */
.main-content{
    margin-left: 230px;
    margin-top: 62px;
    padding: 28px;
    min-height: calc(100vh - 62px);
}

/* ===== CARDS ===== */
.page-title{
    font-size: 22px;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 22px;
    padding-bottom: 10px;
    border-bottom: 2px solid #e74c3c;
    display: inline-block;
}
.stat-cards{ display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 28px; }
.stat-card{
    background: white;
    border-radius: 12px;
    padding: 22px 28px;
    flex: 1; min-width: 180px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
    border-left: 4px solid #e74c3c;
    transition: transform 0.2s;
}
.stat-card:hover{ transform: translateY(-3px); }
.stat-card .num{ font-size: 32px; font-weight: 800; color: #1a1a2e; }
.stat-card .lbl{ color: #888; font-size: 13px; margin-top: 4px; }
.stat-card.blue{ border-left-color: #2980b9; }
.stat-card.green{ border-left-color: #27ae60; }
.stat-card.orange{ border-left-color: #e67e22; }

/* ===== TABLE ===== */
.table-wrap{
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
    overflow: hidden;
    margin-bottom: 24px;
}
.table-head{
    background: #1a1a2e;
    color: white;
    padding: 16px 22px;
    font-size: 15px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
}
table{ width: 100%; border-collapse: collapse; }
table th{
    background: #f8f9fa;
    padding: 12px 16px;
    text-align: left;
    font-size: 13px;
    color: #555;
    font-weight: 600;
    border-bottom: 2px solid #eee;
}
table td{
    padding: 12px 16px;
    font-size: 14px;
    color: #333;
    border-bottom: 1px solid #f0f0f0;
}
table tr:last-child td{ border-bottom: none; }
table tr:hover td{ background: #fafafa; }

/* ===== BUTTONS ===== */
.btn{
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    border: none;
    transition: opacity 0.2s, transform 0.2s;
}
.btn:hover{ opacity: 0.85; transform: translateY(-1px); }
.btn-primary{ background: #2980b9; color: white; }
.btn-success{ background: #27ae60; color: white; }
.btn-warning{ background: #e67e22; color: white; }
.btn-danger{ background: #e74c3c; color: white; }
.btn-dark{ background: #1a1a2e; color: white; }

/* ===== FORM STYLES ===== */
.form-card{
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
    overflow: hidden;
    margin-bottom: 24px;
}
.form-card-head{
    background: #1a1a2e;
    color: white;
    padding: 16px 22px;
    font-size: 15px;
    font-weight: 600;
}
.form-card-body{ padding: 24px 22px; }
.form-row{ display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 18px; }
.form-group{ flex: 1; min-width: 220px; }
.form-group label{
    display: block;
    font-size: 13px;
    color: #555;
    font-weight: 600;
    margin-bottom: 6px;
}
.form-group input,
.form-group select,
.form-group textarea{
    width: 100%;
    padding: 10px 14px;
    border: 1.5px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    color: #333;
    outline: none;
    transition: border 0.3s;
    font-family: inherit;
}
.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus{ border-color: #e74c3c; }

/* ===== ALERTS ===== */
.alert{
    padding: 12px 18px;
    border-radius: 8px;
    margin-bottom: 18px;
    font-size: 14px;
    font-weight: 500;
}
.alert-success{ background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
.alert-danger{ background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
.alert-info{ background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }

/* ===== BADGE ===== */
.badge{
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}
.badge-success{ background: #d4edda; color: #155724; }
.badge-danger{ background: #f8d7da; color: #721c24; }
.badge-warning{ background: #fff3cd; color: #856404; }
.badge-info{ background: #d1ecf1; color: #0c5460; }
</style>
</head>
<body>

<!-- TOP HEADER -->
<div class="top-header">
    <div class="brand">GYM<span>Pro</span></div>
    <div class="right-info">
        <span class="trainer-info">Welcome, <strong><?php echo htmlspecialchars($trainer_name); ?></strong></span>
        <span class="badge-type"><?php echo $trainer_type; ?> Trainer</span>
        <a href="trainer_logout.php" class="btn-logout">Logout</a>
    </div>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="sidebar-logo">
        <div class="avatar">🏋</div>
        <h4><?php echo htmlspecialchars($trainer_name); ?></h4>
        <p><?php echo ucfirst($trainer_type); ?> Trainer</p>
    </div>

    <div class="sidebar-section">Main</div>
    <a href="trainer_dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='trainer_dashboard.php'?'active':''; ?>">
        <span class="icon">🏠</span> Dashboard
    </a>

    <?php if($trainer_type == 'personal'): ?>
    <div class="sidebar-section">Personal Training</div>
    <a href="members.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='members.php'?'active':''; ?>">
        <span class="icon">👥</span> My Members
    </a>
    <a href="create_diet_plan.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='create_diet_plan.php'?'active':''; ?>">
        <span class="icon">🥗</span> Create Diet Plan
    </a>
    <a href="trainer_attendance.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='trainer_attendance.php'?'active':''; ?>">
        <span class="icon">📅</span> Attendance
    </a>

    <?php elseif($trainer_type == 'batch'): ?>
    <div class="sidebar-section">Batch Training</div>
    <a href="batches.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='batches.php'?'active':''; ?>">
        <span class="icon">📋</span> My Batches
    </a>
    <a href="batch_members.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='batch_members.php'?'active':''; ?>">
        <span class="icon">👥</span> Batch Members
    </a>
    <a href="change_batch_time.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='change_batch_time.php'?'active':''; ?>">
        <span class="icon">⏰</span> Change Batch Time
    </a>
    <a href="trainer_batch_att.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='trainer_batch_att.php'?'active':''; ?>">
        <span class="icon">📅</span> Attendance
    </a>
    <?php endif; ?>

    <div class="sidebar-section">Account</div>
    <a href="trainer_profile.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='trainer_profile.php'?'active':''; ?>">
        <span class="icon">👤</span> Profile
    </a>
</div>

<!-- MAIN CONTENT starts after this include -->
<div class="main-content">