<?php
session_start();
include "../db.php";
include "trainer_header.php";

$id = $_SESSION['trainer_id'];
$q  = mysqli_query($con, "SELECT * FROM trainers WHERE id='$id'");
$data = mysqli_fetch_assoc($q);

// Batch info if batch trainer
$batch_info = null;
if($data['type'] == 'batch') {
    $bq = mysqli_query($con, "SELECT * FROM batches WHERE trainer_id='$id'");
}

// Attendance summary
$q_att = mysqli_query($con, "SELECT status, COUNT(*) as cnt FROM trainer_attendance WHERE trainer_id='$id' GROUP BY status");
$att_stats = ['Present'=>0,'Absent'=>0];
while($r = mysqli_fetch_assoc($q_att)) {
    $att_stats[$r['status']] = $r['cnt'];
}
$total_att = $att_stats['Present'] + $att_stats['Absent'];
$pct = $total_att > 0 ? round(($att_stats['Present']/$total_att)*100) : 0;
?>

<div class="page-title">My Profile</div>

<div style="display:flex; gap:24px; flex-wrap:wrap; align-items:flex-start;">

    <!-- Profile Card -->
    <div style="background:white; border-radius:14px; box-shadow:0 2px 16px rgba(0,0,0,0.08); overflow:hidden; min-width:280px; flex:1; max-width:380px;">
        <div style="background:linear-gradient(135deg,#1a1a2e,#0f3460); padding:36px 24px; text-align:center;">
            <div style="width:80px; height:80px; border-radius:50%; background:linear-gradient(135deg,#e74c3c,#c0392b); display:inline-flex; align-items:center; justify-content:center; font-size:36px; margin-bottom:14px;">🏋</div>
            <h2 style="color:white; font-size:20px; margin-bottom:6px;"><?php echo htmlspecialchars($data['name']); ?></h2>
            <span style="background:<?php echo $data['type']=='personal' ? '#27ae60' : '#2980b9'; ?>; color:white; padding:4px 14px; border-radius:20px; font-size:12px; font-weight:600; text-transform:uppercase;">
                <?php echo $data['type']; ?> Trainer
            </span>
        </div>
        <div style="padding:24px;">
            <div style="margin-bottom:14px; padding-bottom:14px; border-bottom:1px solid #f0f0f0;">
                <span style="font-size:12px; color:#888; display:block; margin-bottom:3px;">Email</span>
                <span style="font-size:15px; color:#333; font-weight:500;">📧 <?php echo htmlspecialchars($data['email']); ?></span>
            </div>
            <div style="margin-bottom:14px; padding-bottom:14px; border-bottom:1px solid #f0f0f0;">
                <span style="font-size:12px; color:#888; display:block; margin-bottom:3px;">Phone</span>
                <span style="font-size:15px; color:#333; font-weight:500;">📞 <?php echo htmlspecialchars($data['phone']); ?></span>
            </div>
            <div style="margin-bottom:14px; padding-bottom:14px; border-bottom:1px solid #f0f0f0;">
                <span style="font-size:12px; color:#888; display:block; margin-bottom:3px;">Gender</span>
                <span style="font-size:15px; color:#333; font-weight:500;"><?php echo $data['gender']; ?></span>
            </div>
            <div style="margin-bottom:14px; padding-bottom:14px; border-bottom:1px solid #f0f0f0;">
                <span style="font-size:12px; color:#888; display:block; margin-bottom:3px;">Specialization</span>
                <span style="font-size:15px; color:#333; font-weight:500;">🎯 <?php echo htmlspecialchars($data['specialization']); ?></span>
            </div>
            <div style="margin-bottom:14px; padding-bottom:14px; border-bottom:1px solid #f0f0f0;">
                <span style="font-size:12px; color:#888; display:block; margin-bottom:3px;">Experience</span>
                <span style="font-size:15px; color:#333; font-weight:500;">⭐ <?php echo $data['experience']; ?> years</span>
            </div>
            <div style="margin-bottom:20px;">
                <span style="font-size:12px; color:#888; display:block; margin-bottom:3px;">Address</span>
                <span style="font-size:15px; color:#333; font-weight:500;">📍 <?php echo htmlspecialchars($data['address']); ?></span>
            </div>
            <a href="update_profile.php" class="btn btn-primary" style="width:100%; text-align:center; padding:11px;">✏ Edit Profile</a>
        </div>
    </div>

    <!-- Right side -->
    <div style="flex:2; min-width:280px;">

        <!-- Attendance Stats -->
        <div style="background:white; border-radius:14px; box-shadow:0 2px 16px rgba(0,0,0,0.08); padding:22px; margin-bottom:22px;">
            <h3 style="font-size:16px; font-weight:700; color:#1a1a2e; margin-bottom:18px; padding-bottom:10px; border-bottom:2px solid #e74c3c; display:inline-block;">📊 Attendance Overview</h3>
            <div style="display:flex; gap:16px; flex-wrap:wrap; margin-bottom:18px;">
                <div style="flex:1; min-width:100px; background:#d4edda; border-radius:10px; padding:16px; text-align:center;">
                    <div style="font-size:28px; font-weight:800; color:#155724;"><?php echo $att_stats['Present']; ?></div>
                    <div style="font-size:12px; color:#155724; margin-top:4px;">Present</div>
                </div>
                <div style="flex:1; min-width:100px; background:#f8d7da; border-radius:10px; padding:16px; text-align:center;">
                    <div style="font-size:28px; font-weight:800; color:#721c24;"><?php echo $att_stats['Absent']; ?></div>
                    <div style="font-size:12px; color:#721c24; margin-top:4px;">Absent</div>
                </div>
                <div style="flex:1; min-width:100px; background:#d1ecf1; border-radius:10px; padding:16px; text-align:center;">
                    <div style="font-size:28px; font-weight:800; color:#0c5460;"><?php echo $pct; ?>%</div>
                    <div style="font-size:12px; color:#0c5460; margin-top:4px;">Rate</div>
                </div>
            </div>
            <div style="background:#f0f0f0; border-radius:20px; height:12px;">
                <div style="width:<?php echo $pct; ?>%; background:<?php echo $pct>=75 ? '#27ae60' : ($pct>=50 ? '#e67e22' : '#e74c3c'); ?>; height:12px; border-radius:20px;"></div>
            </div>
        </div>

        <?php if($data['type'] == 'batch'): ?>
        <!-- Batch Info -->
        <div style="background:white; border-radius:14px; box-shadow:0 2px 16px rgba(0,0,0,0.08); padding:22px; margin-bottom:22px;">
            <h3 style="font-size:16px; font-weight:700; color:#1a1a2e; margin-bottom:18px; padding-bottom:10px; border-bottom:2px solid #2980b9; display:inline-block;">📋 My Batches</h3>
            <table style="width:100%; border-collapse:collapse;">
                <tr style="background:#f8f9fa;">
                    <th style="padding:10px 14px; text-align:left; font-size:13px; color:#555; border-bottom:2px solid #eee;">Batch</th>
                    <th style="padding:10px 14px; text-align:left; font-size:13px; color:#555; border-bottom:2px solid #eee;">Time</th>
                    <th style="padding:10px 14px; text-align:left; font-size:13px; color:#555; border-bottom:2px solid #eee;">Capacity</th>
                    <th style="padding:10px 14px; text-align:left; font-size:13px; color:#555; border-bottom:2px solid #eee;">Status</th>
                </tr>
                <?php while($b = mysqli_fetch_assoc($bq)): ?>
                <tr>
                    <td style="padding:10px 14px; font-size:14px; border-bottom:1px solid #f0f0f0;"><?php echo htmlspecialchars($b['batch_name']); ?></td>
                    <td style="padding:10px 14px; font-size:14px; border-bottom:1px solid #f0f0f0;">
                        <?php echo date('h:i A', strtotime($b['start_time'])); ?> –
                        <?php echo date('h:i A', strtotime($b['end_time'])); ?>
                    </td>
                    <td style="padding:10px 14px; font-size:14px; border-bottom:1px solid #f0f0f0;"><?php echo $b['capacity']; ?></td>
                    <td style="padding:10px 14px; font-size:14px; border-bottom:1px solid #f0f0f0;">
                        <span class="badge <?php echo $b['status']=='active' ? 'badge-success' : 'badge-danger'; ?>">
                            <?php echo ucfirst($b['status']); ?>
                        </span>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
            <a href="change_batch_time.php" class="btn btn-warning" style="margin-top:14px;">⏰ Change Batch Time</a>
        </div>

        <?php else: ?>
        <!-- Personal trainer member count -->
        <?php
        $q_mc = mysqli_query($con, "SELECT COUNT(*) as cnt FROM assign_trainer WHERE trainer_id='$id'");
        $mc = mysqli_fetch_assoc($q_mc)['cnt'];
        $q_dc = mysqli_query($con, "SELECT COUNT(*) as cnt FROM diet_plans WHERE trainer_id='$id'");
        $dc = mysqli_fetch_assoc($q_dc)['cnt'];
        ?>
        <div style="background:white; border-radius:14px; box-shadow:0 2px 16px rgba(0,0,0,0.08); padding:22px; margin-bottom:22px;">
            <h3 style="font-size:16px; font-weight:700; color:#1a1a2e; margin-bottom:18px; padding-bottom:10px; border-bottom:2px solid #27ae60; display:inline-block;">📈 Activity Summary</h3>
            <div style="display:flex; gap:16px; flex-wrap:wrap;">
                <div style="flex:1; min-width:130px; background:linear-gradient(135deg,#8e44ad,#6c3483); border-radius:10px; padding:18px; text-align:center;">
                    <div style="font-size:30px; font-weight:800; color:#fff;"><?php echo $mc; ?></div>
                    <div style="font-size:12px; color:rgba(255,255,255,0.8); margin-top:4px;">Members Assigned</div>
                </div>
                <div style="flex:1; min-width:130px; background:linear-gradient(135deg,#27ae60,#1e8449); border-radius:10px; padding:18px; text-align:center;">
                    <div style="font-size:30px; font-weight:800; color:#fff;"><?php echo $dc; ?></div>
                    <div style="font-size:12px; color:rgba(255,255,255,0.8); margin-top:4px;">Diet Plans Made</div>
                </div>
            </div>
            <a href="members.php" class="btn btn-primary" style="margin-top:14px;">👥 View My Members</a>
        </div>
        <?php endif; ?>

    </div>
</div>

</div>
</body>
</html>