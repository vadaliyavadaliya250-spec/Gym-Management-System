<?php
session_start();
include "../db.php";
include "trainer_header.php";

$trainer_id = $_SESSION['trainer_id'];

$query = mysqli_query($con, "
    SELECT ud.*, at.assigned_at
    FROM user_details ud
    JOIN assign_trainer at ON ud.id = at.member_id
    WHERE at.trainer_id='$trainer_id'
    ORDER BY at.assigned_at DESC
");
?>

<div class="page-title">My Members</div>

<div class="table-wrap">
    <div class="table-head">👥 Assigned Members</div>
    <table>
        <tr>
            <th>#</th>
            <th>Username</th>
            <th>Full Name</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Height</th>
            <th>Weight</th>
            <th>Assigned On</th>
            <th>Action</th>
        </tr>
        <?php
        $i = 1;
        if(mysqli_num_rows($query) > 0):
            while($row = mysqli_fetch_assoc($query)):
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo htmlspecialchars($row['fullname']); ?></td>
            <td><?php echo $row['age']; ?></td>
            <td><?php echo $row['gender']; ?></td>
            <td><?php echo $row['height'] ? $row['height'].' ft' : '-'; ?></td>
            <td><?php echo $row['weight'] ? $row['weight'].' kg' : '-'; ?></td>
            <td><?php echo date('d M Y', strtotime($row['assigned_at'])); ?></td>
            <td>
                <a href="create_diet_plan.php?member_id=<?php echo $row['id']; ?>" class="btn btn-success">Diet Plan</a>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr>
            <td colspan="9" style="text-align:center; color:#888; padding:30px;">No members assigned yet.</td>
        </tr>
        <?php endif; ?>
    </table>
</div>

</div>
</body>
</html>