<?php
session_start();
include "../db.php";
include "trainer_header.php";

$trainer_id = $_SESSION['trainer_id'];
$batch_id_pre = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : 0;

// Handle form submit
if(isset($_POST['update_time'])) {
    $bid        = (int)$_POST['batch_id'];
    $start_time = mysqli_real_escape_string($con, $_POST['start_time']);
    $end_time   = mysqli_real_escape_string($con, $_POST['end_time']);

    // Verify this batch belongs to this trainer
    $check = mysqli_query($con, "SELECT id FROM batches WHERE id='$bid' AND trainer_id='$trainer_id'");
    if(mysqli_num_rows($check) > 0) {
        mysqli_query($con, "UPDATE batches SET start_time='$start_time', end_time='$end_time' WHERE id='$bid'");
        $success = "Batch time updated successfully! Admin can see the updated schedule.";
    } else {
        $error = "Unauthorized: This batch does not belong to you.";
    }
}

// Get trainer's batches
$my_batches = mysqli_query($con, "SELECT * FROM batches WHERE trainer_id='$trainer_id'");
$batches_arr = [];
while($b = mysqli_fetch_assoc($my_batches)) {
    $batches_arr[] = $b;
}
?>

<div class="page-title">Change Batch Time</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success">✅ <?php echo $success; ?></div>
<?php endif; ?>
<?php if(isset($error)): ?>
    <div class="alert alert-danger">⚠ <?php echo $error; ?></div>
<?php endif; ?>

<div class="alert alert-info">
    ℹ Once you update the batch time, it will be immediately visible to the Admin in the batch management panel.
</div>

<?php if(count($batches_arr) > 0): foreach($batches_arr as $batch): ?>
<div class="form-card" style="margin-bottom:22px;">
    <div class="form-card-head">
        📋 <?php echo htmlspecialchars($batch['batch_name']); ?>
        <span style="font-size:12px; font-weight:400; margin-left:12px; opacity:0.7;">
            Current: <?php echo date('h:i A', strtotime($batch['start_time'])); ?> –
                     <?php echo date('h:i A', strtotime($batch['end_time'])); ?>
        </span>
    </div>
    <div class="form-card-body">
        <form method="POST">
            <input type="hidden" name="batch_id" value="<?php echo $batch['id']; ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>New Start Time</label>
                    <input type="time" name="start_time" value="<?php echo $batch['start_time']; ?>" required>
                </div>
                <div class="form-group">
                    <label>New End Time</label>
                    <input type="time" name="end_time" value="<?php echo $batch['end_time']; ?>" required>
                </div>
                <div class="form-group" style="display:flex; align-items:flex-end;">
                    <button type="submit" name="update_time" class="btn btn-warning"
                        style="width:100%; padding:11px;"
                        onclick="return confirm('Update time for <?php echo htmlspecialchars($batch['batch_name']); ?>?')">
                        ⏰ Update Time
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endforeach; else: ?>
<div class="alert alert-info">No batches assigned to you yet.</div>
<?php endif; ?>

<!-- Current schedule overview -->
<div class="table-wrap">
    <div class="table-head">📅 Current Batch Schedule</div>
    <table>
        <tr>
            <th>Batch Name</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Capacity</th>
            <th>Status</th>
        </tr>
        <?php foreach($batches_arr as $batch): ?>
        <tr>
            <td><?php echo htmlspecialchars($batch['batch_name']); ?></td>
            <td><?php echo date('h:i A', strtotime($batch['start_time'])); ?></td>
            <td><?php echo date('h:i A', strtotime($batch['end_time'])); ?></td>
            <td><?php echo $batch['capacity']; ?></td>
            <td>
                <span class="badge <?php echo $batch['status']=='active' ? 'badge-success' : 'badge-danger'; ?>">
                    <?php echo ucfirst($batch['status']); ?>
                </span>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

</div>
</body>
</html>