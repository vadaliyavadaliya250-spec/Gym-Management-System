<?php
session_start();
include "../db.php";
include "trainer_header.php";

$id = $_SESSION['trainer_id'];
$q  = mysqli_query($con, "SELECT * FROM trainers WHERE id='$id'");
$data = mysqli_fetch_assoc($q);

if(isset($_POST['update'])) {
    $name   = mysqli_real_escape_string($con, $_POST['name']);
    $email  = mysqli_real_escape_string($con, $_POST['email']);
    $phone  = mysqli_real_escape_string($con, $_POST['phone']);
    $spec   = mysqli_real_escape_string($con, $_POST['specialization']);
    $exp    = (int)$_POST['experience'];
    $addr   = mysqli_real_escape_string($con, $_POST['address']);

    mysqli_query($con, "UPDATE trainers SET
        name='$name', email='$email', phone='$phone',
        specialization='$spec', experience='$exp', address='$addr'
        WHERE id='$id'");

    $_SESSION['trainer_name'] = $name;
    $success = "Profile updated successfully!";

    // Refresh data
    $q    = mysqli_query($con, "SELECT * FROM trainers WHERE id='$id'");
    $data = mysqli_fetch_assoc($q);
}
?>

<div class="page-title">Edit Profile</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success">✅ <?php echo $success; ?></div>
<?php endif; ?>

<div class="form-card" style="max-width:680px;">
    <div class="form-card-head">✏ Update Your Profile</div>
    <div class="form-card-body">
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($data['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($data['email']); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($data['phone']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Specialization</label>
                    <input type="text" name="specialization" value="<?php echo htmlspecialchars($data['specialization']); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Experience (years)</label>
                    <input type="number" name="experience" value="<?php echo $data['experience']; ?>" min="0">
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="address" value="<?php echo htmlspecialchars($data['address']); ?>">
                </div>
            </div>
            <button type="submit" name="update" class="btn btn-success">💾 Update Profile</button>
            <a href="trainer_profile.php" class="btn btn-dark" style="margin-left:10px;">Cancel</a>
        </form>
    </div>
</div>

</div>
</body>
</html>