<?php
session_start();
include "../db.php";
include "trainer_header.php";

$trainer_id   = $_SESSION['trainer_id'];
$trainer_type = $_SESSION['trainer_type'];
$date_filter  = isset($_GET['date']) ? $_GET['date'] : '';

if($date_filter != '') {
    $query = mysqli_query($con, "
        SELECT ta.*, b.batch_name
        FROM trainer_attendance ta
        LEFT JOIN batches b ON ta.batch_id = b.id
        WHERE ta.trainer_id='$trainer_id' AND ta.date='$date_filter'
        ORDER BY ta.date DESC
    ");
} else {
    $query = mysqli_query($con, "
        SELECT ta.*, b.batch_name
        FROM trainer_attendance ta
        LEFT JOIN batches b ON ta.batch_id = b.id
        WHERE ta.trainer_id='$trainer_id'
        ORDER BY ta.date DESC
    ");
}

// Stats
$q_total   = mysqli_query($con, "SELECT COUNT(*) as cnt FROM trainer_attendance WHERE trainer_id='$trainer_id'");
$total     = mysqli_fetch_assoc($q_total)['cnt'];

$q_present = mysqli_query($con, "SELECT COUNT(*) as cnt FROM trainer_attendance WHERE trainer_id='$trainer_id' AND status='Present'");
$present   = mysqli_fetch_assoc($q_present)['cnt'];

$q_absent  = mysqli_query($con, "SELECT COUNT(*) as cnt FROM trainer_attendance WHERE trainer_id='$trainer_id' AND status='Absent'");
$absent    = mysqli_fetch_assoc($q_absent)['cnt'];

$pct = ($total > 0) ? round(($present/$total)*100) : 0;
?>

<div class="page-title">My Attendance</div>

<div class="stat-cards">
    <div class="stat-card green">
        <div class="num"><?php echo $present; ?></div>
        <div class="lbl">✅ Present Days</div>
    </div>
    <div class="stat-card" style="border-left-color:#e74c3c;">
        <div class="num"><?php echo $absent; ?></div>
        <div class="lbl">❌ Absent Days</div>
    </div>
    <div class="stat-card blue">
        <div class="num"><?php echo $total; ?></div>
        <div class="lbl">📅 Total Records</div>
    </div>
    <div class="stat-card orange">
        <div class="num"><?php echo $pct; ?>%</div>
        <div class="lbl">📊 Attendance Rate</div>
    </div>
</div>

<!-- Progress bar -->
<div style="background:white; border-radius:10px; padding:18px 22px; margin-bottom:22px; box-shadow:0 2px 10px rgba(0,0,0,0.06);">
    <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
        <span style="font-weight:600; color:#333;">Attendance Rate</span>
        <span style="font-weight:700; color:#27ae60;"><?php echo $pct; ?>%</span>
    </div>
    <div style="background:#e0e0e0; border-radius:20px; height:10px;">
        <div style="width:<?php echo $pct; ?>%; background:<?php echo $pct>=75 ? '#27ae60' : ($pct>=50 ? '#e67e22' : '#e74c3c'); ?>; height:10px; border-radius:20px; transition:width 0.5s;"></div>
    </div>
</div>

<!-- Filter -->
<div class="form-card" style="margin-bottom:20px;">
    <div class="form-card-body" style="padding:14px 22px;">
        <form method="GET" style="display:flex; gap:14px; align-items:flex-end; flex-wrap:wrap;">
            <div class="form-group" style="min-width:180px; margin-bottom:0;">
                <label>Filter by Date</label>
                <input type="date" name="date" value="<?php echo $date_filter; ?>">
            </div>
            <button type="submit" class="btn btn-dark" style="margin-bottom:0; padding:10px 20px;">Filter</button>
            <?php if($date_filter): ?>
                <a href="trainer_attendance.php" class="btn btn-danger" style="padding:10px 20px;">Clear</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="table-wrap">
    <div class="table-head">📅 Attendance Records</div>
    <table>
        <tr>
            <th>#</th>
            <th>Date</th>
            <th>Type</th>
            <?php if($trainer_type == 'batch'): ?><th>Batch</th><?php endif; ?>
            <th>Status</th>
        </tr>
        <?php
        $i = 1;
        if(mysqli_num_rows($query) > 0):
            while($row = mysqli_fetch_assoc($query)):
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo date('d M Y', strtotime($row['date'])); ?></td>
            <td><span class="badge badge-info"><?php echo ucfirst($row['entity_type']); ?></span></td>
            <?php if($trainer_type == 'batch'): ?>
            <td><?php echo $row['batch_name'] ? htmlspecialchars($row['batch_name']) : '-'; ?></td>
            <?php endif; ?>
            <td>
                <span class="badge <?php echo strtolower($row['status'])=='present' ? 'badge-success' : 'badge-danger'; ?>">
                    <?php echo $row['status']; ?>
                </span>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr>
            <td colspan="<?php echo $trainer_type=='batch' ? 5 : 4; ?>" style="text-align:center; color:#888; padding:30px;">
                No attendance records found.
            </td>
        </tr>
        <?php endif; ?>
    </table>
</div>

</div>
</body>
</html>