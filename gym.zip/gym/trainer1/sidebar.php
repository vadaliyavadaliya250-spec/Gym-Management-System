<div class="sidebar">
    <h2>Trainer Panel</h2>
    <a href="dashboard_batch.php">Dashboard</a>
    <a href="trainer_batch_att.php">Check Attendance</a>
    <a href="batch_list.php">My Batches</a>
    <a href="../profile.php">Profile</a>
</div>