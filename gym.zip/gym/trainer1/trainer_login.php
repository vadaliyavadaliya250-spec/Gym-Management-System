<?php
session_start();
include "../db.php";

if(isset($_POST['login'])){
    $username = mysqli_real_escape_string($con,$_POST['username']);
    $password = mysqli_real_escape_string($con,$_POST['password']);
    $q = mysqli_query($con,"SELECT * FROM trainers WHERE username='$username' AND password='$password' AND status='active'");
    if(mysqli_num_rows($q)>0){
        $data = mysqli_fetch_assoc($q);
        $_SESSION['trainer_id']   = $data['id'];
        $_SESSION['trainer_type'] = $data['type'];
        $_SESSION['trainer_name'] = $data['name'];
        header("Location: trainer_dashboard.php");
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Trainer Login</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Segoe UI',Arial,sans-serif;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 60%,#0f3460 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;}
.box{width:380px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:14px;padding:44px 36px;backdrop-filter:blur(10px);box-shadow:0 20px 50px rgba(0,0,0,0.5);}
.logo{text-align:center;margin-bottom:28px;}
.logo .icon{display:inline-block;width:56px;height:56px;background:linear-gradient(135deg,#e74c3c,#c0392b);border-radius:50%;font-size:24px;line-height:56px;margin-bottom:10px;}
.logo h2{color:#fff;font-size:22px;font-weight:700;}
.logo p{color:rgba(255,255,255,0.45);font-size:12px;margin-top:3px;}
.err{background:rgba(231,76,60,0.2);border:1px solid #e74c3c;color:#ff6b6b;padding:9px 13px;border-radius:7px;margin-bottom:18px;font-size:13px;}
.fg{margin-bottom:18px;}
.fg label{display:block;color:rgba(255,255,255,0.65);font-size:12px;font-weight:600;margin-bottom:5px;}
.fg input{width:100%;padding:11px 14px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.13);border-radius:7px;color:#fff;font-size:14px;outline:none;transition:border 0.25s;}
.fg input:focus{border-color:#e74c3c;}
.fg input::placeholder{color:rgba(255,255,255,0.28);}
.sbtn{width:100%;padding:12px;background:linear-gradient(135deg,#e74c3c,#c0392b);color:#fff;border:none;border-radius:7px;font-size:15px;font-weight:700;cursor:pointer;margin-top:4px;transition:opacity 0.2s;}
.sbtn:hover{opacity:0.88;}
.back{text-align:center;margin-top:18px;}
.back a{color:rgba(255,255,255,0.35);font-size:12px;text-decoration:none;}
.back a:hover{color:#fff;}
</style>
</head>
<body>
<div class="box">
    <div class="logo">
        <div class="icon">🏋</div>
        <h2>Trainer Login</h2>
        <p>GymPro Management System</p>
    </div>
    <?php if(isset($error)): ?><div class="err">⚠ <?php echo $error;?></div><?php endif; ?>
    <form method="POST">
        <div class="fg"><label>Username</label><input type="text" name="username" placeholder="Enter username" required></div>
        <div class="fg"><label>Password</label><input type="password" name="password" placeholder="Enter password" required></div>
        <button type="submit" name="login" class="sbtn">Login</button>
    </form>
    <div class="back"><a href="../index.php">← Back to Home</a></div>
</div>
</body>
</html>