<?php

include "../db.php";

$id=$_GET['id'];

mysqli_query($con,"DELETE FROM diet_plans WHERE id='$id'");

header("Location:create_diet_plan.php");

?>