<?php
session_start();
include "../db.php";

$trainer_id=$_SESSION['trainer_id'];

$member_id=$_POST['member_id'];
$title=$_POST['title'];
$morning=$_POST['morning'];
$lunch=$_POST['lunch'];
$evening=$_POST['evening'];
$dinner=$_POST['dinner'];

mysqli_query($con,"
INSERT INTO diet_plans
(trainer_id,member_id,title,morning,lunch,evening,dinner)
VALUES
('$trainer_id','$member_id','$title','$morning','$lunch','$evening','$dinner')
");

header("Location: my_diet_plans.php");