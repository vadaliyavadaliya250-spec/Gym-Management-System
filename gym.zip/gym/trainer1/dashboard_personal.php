<?php

include "../db.php";
include "trainer_header.php";
include "trainer_sidebar.php";

?>