<?php
session_start();
include "../db.php";

if(!isset($_SESSION['trainer_id'])) {
    header("location:trainer_login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$date_filter = isset($_GET['date']) ? $_GET['date'] : "";

// Fetch only this trainer's batch attendance from trainer_attendance table
if($date_filter != "") {
    $query = mysqli_query($con, "
        SELECT * 
        FROM trainer_attendance
        WHERE trainer_id='$trainer_id'
        AND entity_type='batch'
        AND date='$date_filter'
        ORDER BY date DESC
    ");
} else {
    $query = mysqli_query($con, "
        SELECT * 
        FROM trainer_attendance
        WHERE trainer_id='$trainer_id'
        AND entity_type='batch'
        ORDER BY date DESC
    ");
}

?>

<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>

<div class="content" style="margin-left:220px; padding:20px; margin-top:70px;">
    <h2>My Batch Attendance</h2>

    <form method="get" style="margin-bottom:15px;">
        <input type="date" name="date" value="<?= $date_filter ?>">
        <button type="submit">Filter</button>
    </form>

    <table border="1" cellpadding="10" cellspacing="0" width="100%">
        <tr>
            <th>ID</th>
            <th>Date</th>
            <th>Status</th>
        </tr>
        <?php if(mysqli_num_rows($query) > 0) {
            while($row = mysqli_fetch_assoc($query)) { ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['date'] ?></td>
                    <td>
                        <?php if(strtolower($row['status']) == "present") { ?>
                            <span style="color:green; font-weight:bold;">Present</span>
                        <?php } else { ?>
                            <span style="color:red; font-weight:bold;">Absent</span>
                        <?php } ?>
                    </td>
                </tr>
        <?php } } else { ?>
            <tr>
                <td colspan="3" style="text-align:center;">No attendance found</td>
            </tr>
        <?php } ?>
    </table>
</div>