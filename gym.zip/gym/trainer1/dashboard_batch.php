<?php
session_start();
include "../db.php";

if(!isset($_SESSION['trainer_id']))
{
header("location: login.php");
exit();
}

$id = $_SESSION['trainer_id'];

$q = mysqli_query($con,"SELECT * FROM trainers WHERE id='$id'");
$data = mysqli_fetch_assoc($q);
?>

<!DOCTYPE html>
<html>
<head>

<title>Trainer Dashboard</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial;
}

body{
background:#f4f6f9;
}

.container{
display:flex;
}

/* Sidebar */

.sidebar{
width:230px;
height:100vh;
background:#1f2937;
color:white;
padding-top:20px;
}

.sidebar h2{
text-align:center;
margin-bottom:30px;
}

.sidebar a{
display:block;
color:white;
text-decoration:none;
padding:14px 20px;
transition:0.3s;
}

.sidebar a:hover{
background:#3b82f6;
}

/* Main */

.main{
flex:1;
}

/* Header */

.header{
background:white;
padding:20px;
display:flex;
justify-content:space-between;
align-items:center;
box-shadow:0 2px 5px rgba(0,0,0,0.1);
}

.welcome{
font-size:18px;
font-weight:bold;
color:#333;
}

.logout{
text-decoration:none;
background:#ef4444;
color:white;
padding:8px 16px;
border-radius:5px;
}

.logout:hover{
background:#dc2626;
}

/* Cards */

.cards{
display:flex;
gap:20px;
padding:30px;
}

.card{
background:white;
flex:1;
padding:25px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.1);
text-align:center;
transition:0.3s;
}

.card:hover{
transform:translateY(-5px);
}

.card h3{
margin-bottom:10px;
}

.card p{
color:gray;
margin-bottom:20px;
}

.card a{
display:inline-block;
padding:10px 18px;
background:#3b82f6;
color:white;
text-decoration:none;
border-radius:5px;
}

.card a:hover{
background:#2563eb;
}

</style>

</head>

<body>

<div class="container">

<?php include "sidebar.php"; ?>

<div class="main">

<?php include "header.php"; ?>

<div class="cards">

<div class="card">
<h3>Check Attendance</h3>
<p>View member attendance</p>
<a href="attendance.php">Open</a>
</div>

<div class="card">
<h3>My Batches</h3>
<p>View assigned batches</p>
<a href="batch_list.php">Open</a>
</div>

<div class="card">
<h3>Profile</h3>
<p>Manage your profile</p>
<a href="../profile.php">Open</a>
</div>

</div>

</div>

</div>

</body>
</html>