<?php
session_start();
include "../db.php";
include "trainer_header.php";

$trainer_id   = $_SESSION['trainer_id'];
$trainer_type = $_SESSION['trainer_type'];

if($trainer_type == 'personal') {
    // Count assigned members
    $q_members = mysqli_query($con, "SELECT COUNT(*) as cnt FROM assign_trainer WHERE trainer_id='$trainer_id'");
    $members_count = mysqli_fetch_assoc($q_members)['cnt'];

    // Count diet plans created
    $q_diet = mysqli_query($con, "SELECT COUNT(*) as cnt FROM diet_plans WHERE trainer_id='$trainer_id'");
    $diet_count = mysqli_fetch_assoc($q_diet)['cnt'];

    // Today attendance
    $today = date('Y-m-d');
    $q_att = mysqli_query($con, "SELECT COUNT(*) as cnt FROM trainer_attendance WHERE trainer_id='$trainer_id' AND date='$today'");
    $att_today = mysqli_fetch_assoc($q_att)['cnt'];

    // Recent members
    $q_recent = mysqli_query($con, "
        SELECT ud.username, ud.fullname, ud.age, ud.gender, at.assigned_at
        FROM user_details ud
        JOIN assign_trainer at ON ud.id = at.member_id
        WHERE at.trainer_id='$trainer_id'
        ORDER BY at.assigned_at DESC LIMIT 5
    ");

} else {
    // Batch trainer stats
    $q_batches = mysqli_query($con, "SELECT COUNT(*) as cnt FROM batches WHERE trainer_id='$trainer_id'");
    $batch_count = mysqli_fetch_assoc($q_batches)['cnt'];

    $q_bm = mysqli_query($con, "
        SELECT COUNT(*) as cnt FROM batch_members bm
        JOIN batches b ON bm.batch_id = b.id
        WHERE b.trainer_id='$trainer_id'
    ");
    $bmember_count = mysqli_fetch_assoc($q_bm)['cnt'];

    $today = date('Y-m-d');
    $q_att = mysqli_query($con, "SELECT COUNT(*) as cnt FROM trainer_attendance WHERE trainer_id='$trainer_id' AND date='$today'");
    $att_today = mysqli_fetch_assoc($q_att)['cnt'];

    // Recent batches
    $q_batches_list = mysqli_query($con, "SELECT * FROM batches WHERE trainer_id='$trainer_id' ORDER BY created_at DESC LIMIT 5");
}
?>

<div class="page-title">Dashboard</div>

<?php if($trainer_type == 'personal'): ?>
<!-- PERSONAL TRAINER DASHBOARD -->
<div class="stat-cards">
    <div class="stat-card">
        <div class="num"><?php echo $members_count; ?></div>
        <div class="lbl">👥 My Members</div>
    </div>
    <div class="stat-card green">
        <div class="num"><?php echo $diet_count; ?></div>
        <div class="lbl">🥗 Diet Plans Created</div>
    </div>
    <div class="stat-card blue">
        <div class="num"><?php echo $att_today > 0 ? 'Present' : 'N/A'; ?></div>
        <div class="lbl">📅 Today's Attendance</div>
    </div>
</div>

<div style="display:flex; gap:20px; flex-wrap:wrap;">
    <a href="members.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card" style="text-align:center; cursor:pointer; border-left-color:#8e44ad;">
            <div style="font-size:36px;">👥</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">My Members</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">View & manage assigned members</div>
        </div>
    </a>
    <a href="create_diet_plan.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card green" style="text-align:center; cursor:pointer;">
            <div style="font-size:36px;">🥗</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">Create Diet Plan</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">Create & assign diet to members</div>
        </div>
    </a>
    <a href="trainer_attendance.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card blue" style="text-align:center; cursor:pointer;">
            <div style="font-size:36px;">📅</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">Attendance</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">View your attendance record</div>
        </div>
    </a>
    <a href="trainer_profile.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card orange" style="text-align:center; cursor:pointer;">
            <div style="font-size:36px;">👤</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">Profile</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">View & update your profile</div>
        </div>
    </a>
</div>

<div class="table-wrap" style="margin-top:24px;">
    <div class="table-head">👥 Recently Assigned Members</div>
    <table>
        <tr>
            <th>Name</th>
            <th>Full Name</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Assigned</th>
            <th>Action</th>
        </tr>
        <?php if(mysqli_num_rows($q_recent) > 0): while($row = mysqli_fetch_assoc($q_recent)): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo htmlspecialchars($row['fullname']); ?></td>
            <td><?php echo $row['age']; ?></td>
            <td><?php echo $row['gender']; ?></td>
            <td><?php echo date('d M Y', strtotime($row['assigned_at'])); ?></td>
            <td><a href="create_diet_plan.php" class="btn btn-success">Diet Plan</a></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="6" style="text-align:center; color:#888; padding:24px;">No members assigned yet.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php else: ?>
<!-- BATCH TRAINER DASHBOARD -->
<div class="stat-cards">
    <div class="stat-card">
        <div class="num"><?php echo $batch_count; ?></div>
        <div class="lbl">📋 My Batches</div>
    </div>
    <div class="stat-card green">
        <div class="num"><?php echo $bmember_count; ?></div>
        <div class="lbl">👥 Total Members</div>
    </div>
    <div class="stat-card blue">
        <div class="num"><?php echo $att_today > 0 ? 'Present' : 'N/A'; ?></div>
        <div class="lbl">📅 Today's Attendance</div>
    </div>
</div>

<div style="display:flex; gap:20px; flex-wrap:wrap;">
    <a href="batches.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card" style="text-align:center; cursor:pointer;">
            <div style="font-size:36px;">📋</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">My Batches</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">View your assigned batches</div>
        </div>
    </a>
    <a href="batch_members.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card green" style="text-align:center; cursor:pointer;">
            <div style="font-size:36px;">👥</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">Batch Members</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">View members in your batches</div>
        </div>
    </a>
    <a href="change_batch_time.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card orange" style="text-align:center; cursor:pointer;">
            <div style="font-size:36px;">⏰</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">Change Batch Time</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">Request batch time change</div>
        </div>
    </a>
    <a href="trainer_batch_att.php" style="flex:1; min-width:200px; text-decoration:none;">
        <div class="stat-card blue" style="text-align:center; cursor:pointer;">
            <div style="font-size:36px;">📅</div>
            <div style="font-size:15px; font-weight:700; margin-top:8px; color:#1a1a2e;">Attendance</div>
            <div style="font-size:12px; color:#888; margin-top:4px;">View your attendance record</div>
        </div>
    </a>
</div>

<div class="table-wrap" style="margin-top:24px;">
    <div class="table-head">📋 My Batches Overview</div>
    <table>
        <tr>
            <th>Batch Name</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Capacity</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php if(mysqli_num_rows($q_batches_list) > 0): while($row = mysqli_fetch_assoc($q_batches_list)): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['batch_name']); ?></td>
            <td><?php echo date('h:i A', strtotime($row['start_time'])); ?></td>
            <td><?php echo date('h:i A', strtotime($row['end_time'])); ?></td>
            <td><?php echo $row['capacity']; ?></td>
            <td>
                <span class="badge <?php echo $row['status']=='active' ? 'badge-success' : 'badge-danger'; ?>">
                    <?php echo ucfirst($row['status']); ?>
                </span>
            </td>
            <td><a href="change_batch_time.php?batch_id=<?php echo $row['id']; ?>" class="btn btn-warning">Change Time</a></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="6" style="text-align:center; color:#888; padding:24px;">No batches assigned yet.</td></tr>
        <?php endif; ?>
    </table>
</div>
<?php endif; ?>

</div><!-- end main-content -->
</body>
</html>