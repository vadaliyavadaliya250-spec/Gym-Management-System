<?php
if(!isset($_SESSION['trainer_id'])){
    header("Location: trainer_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trainer Panel</title>
<style>
/* BODY */
body{
    margin:0;
    font-family: Arial, Helvetica, sans-serif;
    background:#f4f6f9;
}

/* HEADER */
.header{
    width:100%;
    height:60px;
    background:#2c3e50;
    color:white;
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:0 20px;
    box-sizing:border-box;
    position:fixed;
    top:0;
    left:0;
    z-index:1000;
    box-shadow:0 2px 5px rgba(0,0,0,0.2);
}
.header .welcome{
    font-size:18px;
    font-weight:500;
}
.header .logout{
    color:white;
    text-decoration:none;
    background:#e74c3c;
    padding:6px 14px;
    border-radius:4px;
    transition:0.3s;
}
.header .logout:hover{
    background:#c0392b;
}

/* SIDEBAR */
.sidebar{
    width:220px;
    height:100vh;
    background:#34495e;
    position:fixed;
    top:60px;
    left:0;
    padding-top:20px;
    box-sizing:border-box;
    overflow-y:auto;
}
.sidebar h2{
    color:white;
    text-align:center;
    margin-bottom:20px;
    font-size:20px;
}
.sidebar a{
    display:block;
    color:white;
    padding:12px 20px;
    text-decoration:none;
    border-bottom:1px solid rgba(255,255,255,0.1);
    transition:0.3s;
}
.sidebar a:hover{
    background:#1abc9c;
    padding-left:25px;
}

/* PAGE CONTENT */
.container{
    margin-left:240px;
    margin-top:80px;
    padding:20px;
}
</style>
</head>
<body>

<div class="header">
    <div class="welcome" style="color:white;">Welcome <?= $_SESSION['trainer_name'] ?></div>
    <a href="trainer_logout.php" class="logout">Logout</a>
</div>