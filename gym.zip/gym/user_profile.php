<?php
session_start();
$conn = mysqli_connect("localhost","root","","gym");
$user_id = $_SESSION['user_id'] ?? 1;

$pending = $live = [];
$result = mysqli_query($conn,"SELECT um.*, mp.plan_name, mp.price FROM user_memberships um 
JOIN membership_plans mp ON um.plan_id=mp.id WHERE um.user_id=$user_id ORDER BY um.created_at DESC");
while($row = mysqli_fetch_assoc($result)){
    $days_left = (strtotime($row['end_date']) - time()) / (60*60*24);
    $row['days_left'] = max(0, floor($days_left));
    
    if($row['status']=='pending') $pending[] = $row;
    elseif($row['status']=='approved' && $days_left > 0) $live[] = $row;
}
?>
<!DOCTYPE html>
<html>
<head><title>My Profile</title>
<style>
/* Same CSS as buy_membership.php + extras */
.profile-card {background:rgba(255,255,255,0.15);backdrop-filter:blur(15px);border-radius:20px;padding:25px;margin:20px 0;text-align:center;transition:all 0.3s;}
.pending-card {border:3px solid orange;background:linear-gradient(135deg,rgba(255,165,0,0.3),rgba(255,140,0,0.2));}
.live-card {border:3px solid limegreen;background:linear-gradient(135deg,rgba(50,205,50,0.3),rgba(34,139,34,0.2));}
</style>
</head>
<body>
<div class="container">
<h1>👤 My Membership Status</h1>

<h2 style="color:orange;">⏳ Pending Approvals (<?php echo count($pending); ?>)</h2>
<?php foreach($pending as $m): ?>
<div class="profile-card pending-card">
<div style="font-size:2em;margin-bottom:15px;">⏳</div>
<strong><?php echo htmlspecialchars($m['plan_name']); ?></strong><br>
<?php echo $m['duration_days']; ?> days | Txn: <?php echo $m['txn_id']; ?><br>
<a href="admin_approve.php" style="color:lime;font-size:18px;">Admin will approve soon →</a>
</div>
<?php endforeach; ?>

<h2 style="color:limegreen;">✅ Active Memberships (<?php echo count($live); ?>)</h2>
<?php foreach($live as $m): ?>
<div class="profile-card live-card">
<div style="font-size:2em;margin-bottom:15px;">✅</div>
<strong><?php echo htmlspecialchars($m['plan_name']); ?></strong><br>
<strong style="color:#ffd700;font-size:1.5em;"><?php echo $m['days_left']; ?></strong> days remaining<br>
Ends: <?php echo $m['end_date']; ?>
</div>
<?php endforeach; ?>

<?php if(empty($pending) && empty($live)): ?>
<div style="text-align:center;padding:60px;color:#ffd700;">
<div style="font-size:3em;margin-bottom:20px;">🚀</div>
No active memberships!<br>
<a href="buy_membership.php" style="color:lime;font-size:24px;font-weight:bold;">Buy Membership Now →</a>
</div>
<?php endif; ?>

<div style="text-align:center;margin-top:40px;">
<a href="admin_approve.php" class="btn" style="background:linear-gradient(45deg,#ff9800,#ffb74d);">🔧 Admin Panel</a>
</div>
</div>
</body>
</html>
