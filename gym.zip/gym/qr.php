<?php 
if(isset($_GET['content']))
{
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="qr.php" method="GET">
        <input type="text" name="content" placeholder="Enter id">
        <button type="submit">Get QR </button>
    </form>
</body>
</html>