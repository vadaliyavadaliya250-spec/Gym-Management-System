﻿<?php
$con = mysqli_connect('localhost','root','','gym');
if(!$con){ die('db fail'); }
$q = mysqli_query($con, "SELECT id, image FROM products_new ORDER BY id DESC LIMIT 30");
echo "products_new images:\n";
while($r=mysqli_fetch_assoc($q)){
    echo $r['id']." => ".($r['image'] ?? 'NULL')."\n";
}

echo "\norders joined images:\n";
$q2 = mysqli_query($con, "SELECT o.id as oid, o.user_id, o.product_id, p.image FROM orders o LEFT JOIN products_new p ON p.id=o.product_id ORDER BY o.id DESC LIMIT 30");
while($r=mysqli_fetch_assoc($q2)){
    echo $r['oid']." uid=".$r['user_id']." pid=".$r['product_id']." img=".($r['image'] ?? 'NULL')."\n";
}
?>
