<?php

$city = "Ahmedabad";
$apiKey = "YOUR_API_KEY_HERE";

// API URL
$url = "https://api.openweathermap.org/data/2.5/weather?q=".$city."&appid=".$apiKey."&units=metric";

// Get API response
$response = file_get_contents($url);

// Convert JSON to PHP array
$data = json_decode($response, true);

// Display data
echo "City: ".$data['name'];
echo "<br>";
echo "Temperature: ".$data['main']['temp']." °C";
echo "<br>";
echo "Weather: ".$data['weather'][0]['main'];

?>